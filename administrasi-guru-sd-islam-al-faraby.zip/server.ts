/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Helper for GoogleGenAI - lazy initialization to prevent startup crash if key is missing/dummy
let aiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI {
  const key = process.env.GEMINI_API_KEY;
  if (!key || key === "MY_GEMINI_API_KEY" || key.trim() === "") {
    throw new Error("Missing valid GEMINI_API_KEY");
  }
  if (!aiClient) {
    aiClient = new GoogleGenAI({
      apiKey: key,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  }
  return aiClient;
}

// ==========================================
// API ENDPOINTS
// ==========================================

app.get("/api/health", (req, res) => {
  res.json({
    status: "ok",
    timestamp: new Date().toISOString(),
    geminiConfigured: !!(process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY !== "MY_GEMINI_API_KEY"),
  });
});

// Endpoint to generate RPP (Rancangan Pelaksanaan Pembelajaran)
app.post("/api/gemini/generate-rpp", async (req, res) => {
  const { subject, grade, topic, duration, islamicIntegration } = req.body;

  if (!subject || !grade || !topic) {
    res.status(400).json({ error: "Missing required parameters (subject, grade, topic)" });
    return;
  }

  const userPrompt = `Buatkan Rancangan Pelaksanaan Pembelajaran (RPP) Kurikulum Merdeka yang lengkap, rapi dan siap pakai untuk guru SD Islam Al Faraby dengan rincian berikut:
- Mata Pelajaran: ${subject}
- Kelas: ${grade}
- Alokasi Waktu: ${duration || "2 JP x 35 Menit"}
- Topik/Materi Pembelajaran: ${topic}
- Fokus Integrasi Nilai-Nilai Islam: ${islamicIntegration || "Adab Islami, ayat Al-Qur'an/Hadis yang relevan"}

Format output RPP harus memuat:
1. Identitas RPP (Nama Sekolah: SD ISLAM AL FARABY, dsb)
2. Kompetensi Dasar atau Capaian Pembelajaran & Indikator Pencapaian (IPK)
3. Tujuan Pembelajaran (mencakup integrasi afektif, kognitif, spiritual)
4. Integrasi Nilai Islam (Sertakan kutipan ayat Al-Qur'an atau Hadis yang berkaitan langsung dengan materi dengan syarah singkatnya, serta aspek Tazkiyatun Nafs/karakter mulia)
5. Langkah-Langkah Pembelajaran (Pendahuluan yang islami, Inti Pembelajaran sapa, diskusi, simulasi praktis, dan Penutup doa kaffarotu majlis)
6. Asesmen/Metode Penilaian (sikap spiritual, ahlak, kognitif)

Tulis dalam Markdown yang sangat rapi, terstruktur, santun, dan profesional dalam Bahasa Indonesia.`;

  try {
    const ai = getGeminiClient();
    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: userPrompt,
      config: {
        systemInstruction: "Anda adalah seorang pakar penyusun kurikulum sekolah Islam Terpadu dan guru teladan senior di SD Islam Al Faraby. Anda selalu menyulam kandungan keilmuan akademis dengan hikmah ketuhanan, adab islami, serta rujukan dalil syar'i Al-Quran dan As-Sunnah yang shahih untuk mencetak generasi Rabbani.",
        temperature: 0.7,
      },
    });

    res.json({ content: response.text, isMock: false });
  } catch (err: any) {
    console.warn("Gemini API error or missing integration key. Using simulated pedagogical template. Error:", err.message);
    
    // Simulate generation with a beautiful mock database response of high-fidelity
    setTimeout(() => {
      const mockRPP = `### RANCANGAN PELAKSANAAN PEMBELAJARAN (RPP)
**SD ISLAM AL FARABY (SIMULASI AI)**

*   **Sekolah:** SD ISLAM AL FARABY
*   **Mata Pelajaran:** ${subject}
*   **Kelas / Semester:** ${grade} / Ganjil
*   **Alokasi Waktu:** ${duration || "2 JP x 35 Menit"}
*   **Materi Pokok:** ${topic}

---

#### A. CAPAIAN PEMBELAJARAN (CP) & MATERI
Siswa mampu memahami, mengenali, dan mempraktikkan konsep dasar terkait **${topic}** sebagai manifestasi ibadah dan pembentukan pribadi yang tafakkur atas ciptaan dan syariat Allah SWT.

#### B. TUJUAN PEMBELAJARAN (INTEGRAL)
1. Siswa dapat menjelaskan konsep esensial dari **${topic}** dengan benar.
2. Siswa mampu mempraktikkan keterampilan spiritual harian yang berkaitan dengan materi tersebut.
3. Siswa membiasakan sikap disiplin, toleransi, dan rasa bersyukur atas rezeki intelektual yang Allah anugerahkan.

#### C. INTEGRASI NILAI-NILAI ISLAM & ADAB
*   **Kutipan Dalil Pembelajaran:** 
    *"Katakanlah: 'Adakah sama orang-orang yang mengetahui dengan orang-orang yang tidak mengetahui?' Sesungguhnya orang yang berakallah yang dapat menerima pelajaran."* (QS. Az-Zumar [39]: 9)
*   **Wawasan Karakter Terpadu:**
     Menumbuhkan keyakinan bahwa semua ilmu bersumber dari *Al-Alim* (Yang Maha Mengetahui). Pada bahasan tentang **${topic}**, siswa diajak mengeksplorasi keterkaitan antara sains-humaniora dengan ${islamicIntegration || "adab dan ketaatan kepada Allah SWT"}.

#### D. SKENARIO KEGIATAN PEMBELAJARAN
1.  **Pendahuluan (15 Menit):**
    *   Membuka kelas dengan salam islami penuh kehangatan, berdoa bersama (*Radhitu billahi rabba...*), dan membaca surah pendek atau tilawah Quran singkat.
    *   Apersepsi: Guru mengaitkan kebesaran Allah dengan sub-materi **${topic}** sebagai pemantik rasa ingin tahu.
2.  **Kegiatan Inti (45 Menit):**
    *   **Eksplorasi (Tafakkur):** Siswa mengamati video pembelajaran atau media visual mengenai kaitan ${topic} dengan kehidupan sehari-hari.
    *   **Elaborasi (Ta'awun):** Siswa membentuk kelompok kerja (*Syura*) untuk memecahkan lembar aktivitas terstruktur tentang pengamatan materi.
    *   **Konfirmasi (Uswah):** Perwakilan mempresentasikan penemuannya, guru menyisipkan keteladanan para ulama terdahulu dan mengoreksi pemahaman santri.
3.  **Penutup (10 Menit):**
    *   Siswa bersama Guru merangkum butir-butir hikmah pembelajaran (istighfar dan kesyukuran).
    *   Pemberian lembar mutaba'ah (jurnal mandiri rumah).
    *   Majelis ditutup dengan doa kafaratul majelis (*Subhanakallahumma wa bihamdika asyhadu alla ilaaha illa anta astaghfiruka wa atuubu ilaika*).

#### E. ASESMEN & EVALUASI
*   **Asesmen Afektif:** Sikap bersuci, sopan berdiskusi, rukun berteman (*Muhasabah & Akhlak Mulia*).
*   **Asesmen Kognitif:** Tes lisan interaktif dan penugasan lembar kerja mandiri.
*   **Asesmen Psikomotorik:** Kelancaran demonstrasi visual dari topik **${topic}**.`;
      
      res.json({ content: mockRPP, isMock: true });
    }, 1500);
  }
});

// Endpoint to draft report card paragraph narratives (Deskripsi Raport Akademik & Karakter Islami)
app.post("/api/gemini/evaluate-character", async (req, res) => {
  const { studentName, classroom, academicScore, shalatScore, notes } = req.body;

  if (!studentName) {
    res.status(400).json({ error: "Missing required parameter (studentName)" });
    return;
  }

  const userPrompt = `Buatkan deskripsi perkembangan akademik dan karakter (Raport Narasi Tarbiyah) dalam Bahasa Indonesia untuk siswa SD Islam Al Faraby berikut ini:
- Nama Siswa: ${studentName}
- Kelas: ${classroom || "Kelas IV"}
- Rerata Nilai Akademik: ${academicScore || 85} (Skala 0-100)
- Skor Kelurusan Shalat & Ibadah: ${shalatScore || 90} (Skala 0-100)
- Catatan/Observasi Guru selama semester ini: ${notes || "Anak yang aktif, ramah, sesekali perlu diingatkan untuk tenang di kelas."}

Narasi raport harus memuat 3 bagian penting:
1. Apresiasi Perkembangan Akademis: Tuliskan capaian belajarnya secara apresiatif, menyebutkan potensi terbaiknya di kelas.
2. Catatan Karakter Islami & Ibadah (Tarbiyah): Berikan apresiasi atas kedisiplinan shalat atau akhlak sosialnya, serta kaitkan dengan nasihat qur'ani yang mendidik kalbu.
3. Saran Pengembangan Diri (Tazkiyah): Rekomendasi konstruktif bernada penuh kasih sayang bagi orang tua di rumah untuk membimbing ananda agar menjadi insan bertaqwa di semester depan.

Tuliskan dalam satu paragraf gabungan yang luwes, sejuk, mengayomi, dan menyentuh hati orang tua siswa (Gaya bahasa guru muslim yang beradab).`;

  try {
    const ai = getGeminiClient();
    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: userPrompt,
      config: {
        systemInstruction: "Anda adalah wali kelas senior yang sangat bijak, lembut hatinya, dan penyayang di SD Islam Al Faraby. Anda menuliskan catatan perkembangan murid dengan bahasa yang halus, memotivasi, menguatkan spiritualitas anak, dan mendorong kerja sama harmonis antara pihak sekolah dan orang tua di rumah.",
        temperature: 0.6,
      },
    });

    res.json({ content: response.text, isMock: false });
  } catch (err: any) {
    console.warn("Gemini API error. Generating high-fidelity mock report card paragraph.");
    
    setTimeout(() => {
      const g = Math.random() > 0.5 ? "Ananda" : "Ananda";
      const mockNarrative = `Alhamdulillah, selama semester ini ${g} ${studentName} telah menunjukkan perkembangan yang sangat menggembirakan di ${classroom || "Kelas IV"}. Secara akademik (rerata ${academicScore || 82}), ananda memiliki daya tangkap yang baik, terutama pada penyelesaian tugas kreatif dan pemahaman teks keagamaan. Di bidang tarbiyah karakter dan ibadah, penegakan shalat berjamaah dan kedisiplinan dhuha ananda berjalan sangat konsisten (skor ${shalatScore || 88}/100), memperlihatkan kecintaan ananda yang tumbuh terhadap syariat. ${notes ? `Catatan pendampingan: ${notes}.` : "Ananda senantiasa ramah dan gemar menolong teman-temannya di kelas."} Kami menyarankan di rumah agar para orang tua mulia terus memotivasi ananda untuk mengulang (*muraja'ah*) hafalan Quran secara rutin agar bacaannya semakin fasih dan kelak menjadi mahkota kehormatan bagi ayah bunda di akhirat. Semoga Allah SWT selalu meneguhkan langkah ananda menjadi generasi qur'ani yang cerdas lagi berakhlak mulia.`;
      
      res.json({ content: mockNarrative, isMock: true });
    }, 1200);
  }
});

// Endpoint to generate mapping KD/KI Curriculum Table rows
app.post("/api/gemini/generate-syllabus", async (req, res) => {
  const { subject, grade } = req.body;
  if (!subject) {
    res.status(400).json({ error: "Missing subject parameter" });
    return;
  }

  const prompt = `Hasilkan 3 baris data pemetaan kurikulum (Kompetensi Dasar, Indikator Pencapaian, dan Alokasi Waktu) yang sangat relevan untuk mata pelajaran '${subject}', tingkat '${grade || "Kelas IV"}' di sekolah dasar dasar Islam terpadu SD ISLAM AL FARABY.
  
  Kembalikan data dalam format JSON murni terstruktur berupa array objek dengan properti:
  - kd: String (contoh: "KD 3.1")
  - kompetensi: String (Isi detail kompetensi dasar akademis islami)
  - indikator: String (Isi indikator pencapaian hasil belajar kongkrit)
  - alokasiWaktu: String (contoh: "4 JP")
  
  Do tidak memberikan pembungkus markdown ataupun penjelasan ekstra. Kembalikan array JSON murni saja.`;

  try {
    const ai = getGeminiClient();
    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
      },
    });

    const parsedData = JSON.parse(response.text.trim());
    res.json({ rows: parsedData, isMock: false });
  } catch (err: any) {
    console.warn("Gemini API error on syllabus mapping. Providing initial smart templates.");
    
    setTimeout(() => {
      const mockResult = [
        {
          kd: "KD 3.1",
          kompetensi: `Memahami konsep pokok ajaran/keutamaan ${subject} serta pengamalan adab mulia dalam menuntut ilmu.`,
          indikator: `Mampu mengidentifikasi dalil utama ${subject} dan menyebutkan 3 hikmah aplikatifnya untuk akhlak siswa.`,
          alokasiWaktu: "4 JP"
        },
        {
          kd: "KD 3.2",
          kompetensi: `Menganalisis implementasi nilai keteladanan dari ${subject} terhadap ketertiban sosial dan cinta lingkungan.`,
          indikator: `Mendemonstrasikan rancangan aksi nyata bertemakan kebersihan batin dan pengampunan dosa sesama guru & orang tua.`,
          alokasiWaktu: "6 JP"
        },
        {
          kd: "KD 4.1",
          kompetensi: `Mempersiapkan portofolio karya mandiri/praktis yang mencerminkan pemahaman integral ${subject}.`,
          indikator: `Menyusun laporan reflektif harian shalat dhuha terintegrasi dengan pemahaman materi terkait.`,
          alokasiWaktu: "2 JP"
        }
      ];
      res.json({ rows: mockResult, isMock: true });
    }, 1000);
  }
});


// ==========================================
// VITE & STATIC FILES SERVING MIDDLEWARE
// ==========================================

async function startServer() {
  const distPath = path.join(process.cwd(), "dist");

  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`SD Islam Al Faraby Teachers' App server booted successfully on http://0.0.0.0:${PORT}`);
  });
}

startServer();
