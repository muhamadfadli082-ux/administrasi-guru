import { Student, Teacher, Subject, LessonPlan, AttendanceLog, TeachingJournal, CharacterLog, AcademicScore, DigitalFile, ActivityLog, UserRole, Classroom, AcademicYear } from './types';

export const INITIAL_STUDENTS: Student[] = [
  { id: 'S001', nis: '2401', nisn: '012111301', name: 'Ahmad Fauzan Al-Hazmi', gender: 'L', classroom: 'Kelas 4A', parentsName: 'Muhammad Hazmi', phone: '081234567801', shalatPoin: 95, tahfidzStatus: 'Juz 30 (Selesai s.d An-Nas), Mulai Juz 29 (Al-Mulk)', birthplace: 'Bogor', birthdate: '2016-05-12', religion: 'Islam', address: 'Komp. Al Faraby No. 4, Sukamanah, Bogor', fatherName: 'Muhammad Hazmi', motherName: 'Khadijah', status: 'Aktif' },
  { id: 'S002', nis: '2402', nisn: '012111302', name: 'Fatima Az-Zahra Ramadhani', gender: 'P', classroom: 'Kelas 4A', parentsName: 'Rahmat Ramadhan', phone: '081234567802', shalatPoin: 98, tahfidzStatus: 'Juz 30 (Selesai An-Naba s.d At-Takwir)', birthplace: 'Bogor', birthdate: '2016-10-24', religion: 'Islam', address: 'Jl. Dahlia Indah No. 12, Sukamanah, Bogor', fatherName: 'Rahmat Ramadhan', motherName: 'Aisyah', status: 'Aktif' },
  { id: 'S003', nis: '2403', nisn: '012111303', name: 'Ali Zainal Abidin', gender: 'L', classroom: 'Kelas 4A', parentsName: 'Hasan Abidin', phone: '081234567803', shalatPoin: 88, tahfidzStatus: 'Juz 30 (Tahfidz s.d Al-Balad)', birthplace: 'Jakarta', birthdate: '2016-01-15', religion: 'Islam', address: 'Gg. Masjid Al-Ikhlas No. 8, Bogor', fatherName: 'Hasan Abidin', motherName: 'Mariam', status: 'Aktif' },
  { id: 'S004', nis: '2404', nisn: '012111304', name: 'Aisha Humaira Al-Kahfi', gender: 'P', classroom: 'Kelas 4A', parentsName: 'Irwan Al-Kahfi', phone: '081234567804', shalatPoin: 92, tahfidzStatus: 'Juz 30 (Selesai s.d Ad-Duha)', birthplace: 'Bogor', birthdate: '2016-08-09', religion: 'Islam', address: 'Perumahan Suka Asri Blok B/14, Bogor', fatherName: 'Irwan Al-Kahfi', motherName: 'Sarah', status: 'Aktif' },
  { id: 'S005', nis: '2405', nisn: '012111305', name: 'Zayd Al-Khair Praditya', gender: 'L', classroom: 'Kelas 4A', parentsName: 'Agus Praditya', phone: '081234567805', shalatPoin: 85, tahfidzStatus: 'Juz 30 (Iqra 6, Mulai An-Nas)', birthplace: 'Sukabumi', birthdate: '2016-03-30', religion: 'Islam', address: 'Jl. Pajajaran Regency No. 40, Bogor', fatherName: 'Agus Praditya', motherName: 'Rina', status: 'Aktif' },
  { id: 'S006', nis: '2406', nisn: '012111306', name: 'Yusuf Al-Faraby', gender: 'L', classroom: 'Kelas 4B', parentsName: 'Sholehuddin', phone: '081234567806', shalatPoin: 90, tahfidzStatus: 'Juz 30 (Selesai s.d Al-Ma`un)', birthplace: 'Bogor', birthdate: '2016-07-07', religion: 'Islam', address: 'Kp. Baru Tengah No. 11, Sukamanah, Bogor', fatherName: 'Sholehuddin', motherName: 'Amina', status: 'Aktif' },
  { id: 'S007', nis: '2407', nisn: '012111307', name: 'Khadijah Al-Kubra', gender: 'P', classroom: 'Kelas 4B', parentsName: 'Bambang Yudho', phone: '081234567807', shalatPoin: 96, tahfidzStatus: 'Juz 30 (Selesai s.d Abasa)', birthplace: 'Surabaya', birthdate: '2016-11-12', religion: 'Islam', address: 'Perumahan Pakuan Heights Blok C/2, Bogor', fatherName: 'Bambang Yudho', motherName: 'Ratih', status: 'Aktif' },
  { id: 'S008', nis: '2408', nisn: '012111308', name: 'Bilal bin Rabah Saputra', gender: 'L', classroom: 'Kelas 4B', parentsName: 'Hari Saputra', phone: '081234567808', shalatPoin: 80, tahfidzStatus: 'Juz 30 (Selesai s.d Al-Humazah)', birthplace: 'Bogor', birthdate: '2016-02-28', religion: 'Islam', address: 'Kp. Sawah Gede RT 03/02, Sukamanah, Bogor', fatherName: 'Hari Saputra', motherName: 'Yuni', status: 'Aktif' },
  { id: 'S009', nis: '2409', nisn: '012111309', name: 'Safiyyah Mumtaz', gender: 'P', classroom: 'Kelas 5', parentsName: 'Yusuf Mumtaz', phone: '081234567809', shalatPoin: 94, tahfidzStatus: 'Juz 29 (Selesai s.d Nuh)', birthplace: 'Bandung', birthdate: '2015-09-18', religion: 'Islam', address: 'Jl. Siliwangi Residences No. 102, Bogor', fatherName: 'Yusuf Mumtaz', motherName: 'Zalfa', status: 'Aktif' },
  { id: 'S010', nis: '2410', nisn: '012111310', name: 'Umar bin Khattab Al-Asad', gender: 'L', classroom: 'Kelas 5', parentsName: 'Farid Al-Asad', phone: '081234567810', shalatPoin: 89, tahfidzStatus: 'Juz 30 (Selesai s.d Al-Fiil)', birthplace: 'Bogor', birthdate: '2015-06-21', religion: 'Islam', address: 'Perumahan Kedung Halang Blok D1/5, Bogor', fatherName: 'Farid Al-Asad', motherName: 'Halimah', status: 'Aktif' }
];

export const INITIAL_TEACHERS: Teacher[] = [
  { id: 'T001', nip: '198506122010011002', name: 'Siti Nurhaliza, S.Pd.I.', role: UserRole.GURU, email: 'siti.alfaraby@gmail.com', classroomAssigned: 'Kelas 4A', subjectsAssigned: ['Aqidah Akhlak', 'Al-Qur\'an Hadis', 'Bahasa Arab'], phone: '085211223344', nuptk: '3456187629381023', gender: 'P', birthplaceDate: 'Bogor, 12 Juni 1985', lastEducation: 'S1 Pendidikan Agama Islam (IAIN)', jobTitle: 'Guru Kelas 4A / Wali Kelas', employmentStatus: 'Tetap Yayasan (GTY)', address: 'Komp. Pondok Indah Blok A/4, Sukamanah, Bogor', photoUrl: '🧕' },
  { id: 'T002', nip: '198204152008012001', name: 'Ahmad Dahlan, M.Pd.', role: UserRole.GURU, email: 'dahlan.alfaraby@gmail.com', classroomAssigned: 'Kelas 4B', subjectsAssigned: ['Fikih', 'Sejarah Kebudayaan Islam (SKI)', 'Matematika'], phone: '085299887766', nuptk: '4092176219381045', gender: 'L', birthplaceDate: 'Yogyakarta, 15 April 1982', lastEducation: 'S2 Manajemen Pendidikan (UIKA)', jobTitle: 'Guru Kelas 4B / Wali Kelas', employmentStatus: 'Pegawai Negeri Sipil (PNS)', address: 'Jl. Merak Mulia No. 45, Kecamatan Sukamanah, Bogor', photoUrl: '👨‍💼' },
  { id: 'T003', nip: '197609202005011003', name: 'Hj. Siti Aminah, S.Pd.I.', role: UserRole.KEPSEK, email: 'aminah.kepsek@gmail.com', phone: '081122233344', nuptk: '2154187630381011', gender: 'P', birthplaceDate: 'Bandung, 20 September 1976', lastEducation: 'S1 Kependidikan Islam (UIN Syarif Hidayatullah)', jobTitle: 'Kepala Sekolah', employmentStatus: 'Tetap Yayasan (GTY)', address: 'Komp. Danau Bogor Raya Blok B2 No. 1, Bogor', photoUrl: '🧕' },
  { id: 'T004', nip: '199211052018021004', name: 'Muhamad Jafar, S.Kom.', role: UserRole.ADMIN, email: 'jafar.admin@gmail.com', phone: '081255556666', nuptk: '8910187640381002', gender: 'L', birthplaceDate: 'Jakarta, 5 November 1992', lastEducation: 'S1 Teknik Informatika (IPB)', jobTitle: 'Administrator / Kepala IT', employmentStatus: 'Kontrak Kerja', address: 'Ardio Residence Blok G/2, Bogor', photoUrl: '👨‍💻' },
  { id: 'T005', nip: '199512302021042005', name: 'Rani Wijaya, S.Pd.', role: UserRole.OPERATOR, email: 'rani.ops@gmail.com', phone: '081344445555', nuptk: '7611187645381016', gender: 'P', birthplaceDate: 'Sukabumi, 30 Desember 1995', lastEducation: 'S1 Pendidikan Guru SD (UPI)', jobTitle: 'Operator Sekolah & Siskeu', employmentStatus: 'Honorer', address: 'Gg. Kenanga No. 34, Baranangsiang, Bogor', photoUrl: '👩‍💼' }
];

export const INITIAL_SUBJECTS: Subject[] = [
  { id: 'MAPEL01', code: 'AA-04', name: 'Aqidah Akhlak', category: 'Agama', fase: 'Fase B', gradeLevel: 'Kelas 4', allocatedHours: '4 JP / Pekan' },
  { id: 'MAPEL02', code: 'QH-04', name: 'Al-Qur\'an Hadis', category: 'Agama', fase: 'Fase B', gradeLevel: 'Kelas 4', allocatedHours: '4 JP / Pekan' },
  { id: 'MAPEL03', code: 'FIK-04', name: 'Fikih', category: 'Agama', fase: 'Fase B', gradeLevel: 'Kelas 4', allocatedHours: '4 JP / Pekan' },
  { id: 'MAPEL04', code: 'SKI-04', name: 'Sejarah Kebudayaan Islam (SKI)', category: 'Agama', fase: 'Fase B', gradeLevel: 'Kelas 4', allocatedHours: '2 JP / Pekan' },
  { id: 'MAPEL05', code: 'BA-04', name: 'Bahasa Arab', category: 'Agama', fase: 'Fase B', gradeLevel: 'Kelas 4', allocatedHours: '2 JP / Pekan' },
  { id: 'MAPEL06', code: 'MTK-04', name: 'Matematika', category: 'Umum', fase: 'Fase B', gradeLevel: 'Kelas 4', allocatedHours: '5 JP / Pekan' },
  { id: 'MAPEL07', code: 'IPA-04', name: 'Ilmu Pengetahuan Alam (IPA)', category: 'Umum', fase: 'Fase B', gradeLevel: 'Kelas 4', allocatedHours: '4 JP / Pekan' },
  { id: 'MAPEL08', code: 'BIN-04', name: 'Bahasa Indonesia', category: 'Umum', fase: 'Fase B', gradeLevel: 'Kelas 4', allocatedHours: '6 JP / Pekan' },
  { id: 'MAPEL09', code: 'PPK-04', name: 'PPKn', category: 'Umum', fase: 'Fase B', gradeLevel: 'Kelas 4', allocatedHours: '4 JP / Pekan' }
];

export const INITIAL_CLASSROOMS: Classroom[] = [
  { id: 'C01', grade: '4', name: 'Kelas 4A', homeroomTeacher: 'Siti Nurhaliza, S.Pd.I.', studentCount: 5 },
  { id: 'C02', grade: '4', name: 'Kelas 4B', homeroomTeacher: 'Ahmad Dahlan, M.Pd.', studentCount: 3 },
  { id: 'C03', grade: '5', name: 'Kelas 5', homeroomTeacher: 'Rani Wijaya, S.Pd.', studentCount: 2 },
  { id: 'C04', grade: '6', name: 'Kelas 6', homeroomTeacher: 'Tidak Ada', studentCount: 0 }
];

export const INITIAL_ACADEMIC_YEARS: AcademicYear[] = [
  { id: 'TA01', year: '2026/2027', semester: 'Ganjil', isActive: true },
  { id: 'TA02', year: '2025/2026', semester: 'Genap', isActive: false },
  { id: 'TA03', year: '2025/2026', semester: 'Ganjil', isActive: false },
  { id: 'TA04', year: '2024/2025', semester: 'Genap', isActive: false }
];

export const INITIAL_LESSON_PLANS: LessonPlan[] = [
  {
    id: 'RPP001',
    title: 'Adab terhadap Kedua Orang Tua (Birrul Walidain)',
    subject: 'Aqidah Akhlak',
    grade: 'Kelas 4A',
    topic: 'Menghormati Orang Tua',
    duration: '2 JP x 35 Menit',
    createdAt: '2026-06-12',
    islamicIntegration: 'Integrasi QS. Al-Isra ayat 23-24 tentang larangan berkata "ah" kepada orang tua dan keharusan bersikap tawadhu.',
    content: `### RANCANGAN PELAKSANAAN PEMBELAJARAN (RPP)
**SD ISLAM AL FARABY**

*   **Mata Pelajaran:** Aqidah Akhlak
*   **Kelas / Semester:** IV / Ganjil
*   **Pertemuan ke / Alokasi Waktu:** 1 / 2 x 35 Menit
*   **Materi Pokok:** Akhlak terpuji kepada kedua orang tua (Birrul Walidain)

#### A. KOMPETENSI DASAR (KD) & INDIKATOR INDEKS (IPK)
1.  **KD 3.2** Memahami makna berbakti kepada kedua orang tua berdasarkan dalil naqli.
    *   **IPK:** Menyebutkan contoh akhlak terpuji kepada bapak dan ibu guru serta orang tua di rumah.
2.  **KD 4.2** Mensimulasikan tata cara berbakti kepada kedua orang tua secara santun.

#### B. TUJUAN PEMBELAJARAN
Melalui model *Contextual Learning*, siswa mampu menguraikan hikmah dibalik bakti kepada orang tua, mempraktikkan tutur kata yang santun dirumah, serta mengintegrasikan nilai tazkiyah ahlak dalam keseharian dengan penuh tanggung jawab.

#### C. INTEGRASI NILAI ISLAM
*   **QS. Al-Isra (17): 23-24:** Larangan membangkang dan perintah menyayangi dalam doa harian.
*   **Hadis Riwayat Al-Bukhari:** *"Ridhallah fi ridhal walidain..."* (Ridha Allah ada pada ridha kedua orang tua).

#### D. KEGIATAN PEMBELAJARAN
1.  **Pendahuluan (10 Menit):** Tadarus surat pendek, menyanyikan lagu nasyid bakti orang tua, dan apersepsi kisah keteladanan Uwais Al-Qarni.
2.  **Kegiatan Inti (50 Menit):**
    *   Siswa dibagi kelompok kecil guna menganalisis skenario kasus adab menolak permintaan orang tua secara halus.
    *   Siswa membuat peta konsep "Doa dan Aksi Nyata Berbakti Berkelanjutan".
    *   Guru mempraktikkan sapaan takzim islami: menyalami, mencium tangan, menyimak dengan khidmat.
3.  **Penutup (10 Menit):** Refleksi kalbu, penugasan jurnal harian dirumah (mendoakan dan membantu menyapu), ditutup kafaratul majlis.

#### E. EVALUASI
*   Performance test (simulasi sungkem/salam takzim kepada orang tua).
*   Penilaian kognitif (menuliskan urutan nasab keluarga mulia).`,
    syncedToDocs: true
  },
  {
    id: 'RPP002',
    title: 'Adab Bersuci (Thaharah) - Tata Cara Wudhu Sesuai Sunnah',
    subject: 'Fikih',
    grade: 'Kelas 4A',
    topic: 'Wudhu Sempurna',
    duration: '2 JP x 35 Menit',
    createdAt: '2026-06-15',
    islamicIntegration: 'Menggali nilai kebersihan lahiriyah dan batiniyah (Hadis: At-Thahuru syathrul iman). Integrasi praktis kesempurnaan shalat.',
    content: `### RANCANGAN PELAKSANAAN PEMBELAJARAN (RPP)
**SD ISLAM AL FARABY**

*   **Mata Pelajaran:** Fikih
*   **Kelas / Semester:** IV / Ganjil
*   **Alokasi Waktu:** 2 x 35 Menit
*   **Materi Pokok:** Tata Cara Berwudhu (Thaharah)

#### A. INDIKATOR & MATERI
1.  Siswa memahami rukun-rukun wudhu dan sunnah wudhu.
2.  Siswa memperagakan wudhu secara runtut dan hemat air.

#### B. INTEGRASI ISLAM
Hadis Nabi SAW: *"Sesungguhnya umatku akan dipanggil pada hari kiamat dalam keadaan dahi dan anggota wudhu mereka bercahaya karena bekas wudhu..."* (HR. Bukhari & Muslim). Mengajarkan karakter ramah lingkungan (tidak boros air sesuai wasiat nabi).

#### C. KEGIATAN PEMBELAJARAN
1.  **Kondisioning:** Mengecek kebersihan saku & kuku siswa, dilanjutkan baca doa sebelum belajar.
2.  **Inti:**
    *   Menyimak poster infografis urutan rukun wudhu dari niat hingga kaki.
    *   Demonstrasi di area tempat wudhu sekolah secara tertib dengan pengawasan.
    *   Diskusi bersama: "Bagaimana wudhu jika air terbatas?" (Pengenalan konsep tayamum sekilas).
3.  **Kesimpulan:** Mengulas bacaan doa setelah wudhu beserta artinya.`,
    syncedToDocs: false
  }
];

export const INITIAL_ATTENDANCE: AttendanceLog[] = [
  { id: 'A001', studentId: 'S001', studentName: 'Ahmad Fauzan Al-Hazmi', classroom: 'Kelas 4A', date: '2026-06-17', status: 'H' },
  { id: 'A002', studentId: 'S002', studentName: 'Fatima Az-Zahra Ramadhani', classroom: 'Kelas 4A', date: '2026-06-17', status: 'H' },
  { id: 'A003', studentId: 'S003', studentName: 'Ali Zainal Abidin', classroom: 'Kelas 4A', date: '2026-06-17', status: 'H' },
  { id: 'A004', studentId: 'S004', studentName: 'Aisha Humaira Al-Kahfi', classroom: 'Kelas 4A', date: '2026-06-17', status: 'S', notes: 'Sakit Deman Tinggi' },
  { id: 'A005', studentId: 'S005', studentName: 'Zayd Al-Khair Praditya', classroom: 'Kelas 4A', date: '2026-06-17', status: 'I', notes: 'Izin Mendampingi Nenek Berobat' },
  { id: 'A006', studentId: 'S001', studentName: 'Ahmad Fauzan Al-Hazmi', classroom: 'Kelas 4A', date: '2026-06-16', status: 'H' },
  { id: 'A007', studentId: 'S002', studentName: 'Fatima Az-Zahra Ramadhani', classroom: 'Kelas 4A', date: '2026-06-16', status: 'H' },
  { id: 'A008', studentId: 'S003', studentName: 'Ali Zainal Abidin', classroom: 'Kelas 4A', date: '2026-06-16', status: 'A', notes: 'Tanpa Keterangan' }
];

export const INITIAL_JOURNALS: TeachingJournal[] = [
  {
    id: 'J001',
    date: '2026-06-17',
    classroom: 'Kelas 4A',
    subject: 'Aqidah Akhlak',
    topic: 'Kisah Keteladanan Nabi Ayub AS & Pembelajaran Sabar',
    contentSummary: 'Menyampaikan materi sabar menghadapi ujian, meneladani nabi Ayub AS. Siswa mewarnai pohon hikmah sabar. Secara umum materi diserap baik.',
    attendanceSummary: { hadir: 3, sakit: 1, izin: 1, alpa: 0 }
  },
  {
    id: 'J002',
    date: '2026-06-16',
    classroom: 'Kelas 4A',
    subject: 'Matematika',
    topic: 'Pecahan Senilai dengan Model Gambar Arsir',
    contentSummary: 'Diskusi pecahan 1/2, 2/4, 3/6 dengan membagi kertas lipat (origami). Siswa aktif memperagakan.',
    attendanceSummary: { hadir: 4, sakit: 0, izin: 0, alpa: 1 }
  }
];

export const INITIAL_CHARACTER_LOGS: CharacterLog[] = [
  { id: 'C001', studentId: 'S001', studentName: 'Ahmad Fauzan Al-Hazmi', date: '2026-06-17', ahlak: 'Sangat Baik', ibadah: 'Sangat Baik', disiplin: 'Baik', notes: 'Hari ini membantu merapikan sajadah shalat Dhuha sehabis berjamaah kelas, inisiatif pribadi yang luar biasa.', loggedBy: 'Siti Nurhaliza, S.Pd.I.' },
  { id: 'C002', studentId: 'S002', studentName: 'Fatima Az-Zahra Ramadhani', date: '2026-06-17', ahlak: 'Sangat Baik', ibadah: 'Sangat Baik', disiplin: 'Sangat Baik', notes: 'Sangat santun bicaranya, memimpin tadarus pagi dengan tartil yang mapan.', loggedBy: 'Siti Nurhaliza, S.Pd.I.' },
  { id: 'C003', studentId: 'S003', studentName: 'Ali Zainal Abidin', date: '2026-06-17', ahlak: 'Baik', ibadah: 'Baik', disiplin: 'Cukup', notes: 'Sedikit terlambat shalat dzuhur bersama karena asyik bermain bola di halaman, sudah diarahkan agar lebih sigap.', loggedBy: 'Siti Nurhaliza, S.Pd.I.' },
  { id: 'C004', studentId: 'S005', studentName: 'Zayd Al-Khair Praditya', date: '2026-06-16', ahlak: 'Baik', ibadah: 'Cukup', disiplin: 'Baik', notes: 'Peningkatan konsentrasi tadarus, perlu dibina agar merapatkan shaf shalat dengan tenang.', loggedBy: 'Siti Nurhaliza, S.Pd.I.' }
];

export const INITIAL_ACADEMIC_SCORES: AcademicScore[] = [
  { id: 'N001', studentId: 'S001', studentName: 'Ahmad Fauzan Al-Hazmi', classroom: 'Kelas 4A', subjectId: 'MAPEL01', subjectName: 'Aqidah Akhlak', harian: 85, uts: 88, uas: 90, finalScore: 87.5, notes: 'Menunjukkan pemahaman yang mendalam mengenai asmaul husna, akhlaknya terpuji.' },
  { id: 'N002', studentId: 'S002', studentName: 'Fatima Az-Zahra Ramadhani', classroom: 'Kelas 4A', subjectId: 'MAPEL01', subjectName: 'Aqidah Akhlak', harian: 95, uts: 92, uas: 96, finalScore: 94.6, notes: 'Luar biasa, selalu unggul dalam materi tertulis dan praktik adab harian.' },
  { id: 'N003', studentId: 'S003', studentName: 'Ali Zainal Abidin', classroom: 'Kelas 4A', subjectId: 'MAPEL01', subjectName: 'Aqidah Akhlak', harian: 78, uts: 75, uas: 82, finalScore: 78.5, notes: 'Bagus, perlu memperkuat hafalan lafadz asmaul husna secara menyeluruh.' },
  { id: 'N004', studentId: 'S001', studentName: 'Ahmad Fauzan Al-Hazmi', classroom: 'Kelas 4A', subjectId: 'MAPEL02', subjectName: 'Al-Qur\'an Hadis', harian: 90, uts: 85, uas: 92, finalScore: 89.5, notes: 'Tajwid memuaskan, makharijul huruf pada surah mufasshal sangat mumpuni.' },
  { id: 'N005', studentId: 'S002', studentName: 'Fatima Az-Zahra Ramadhani', classroom: 'Kelas 4A', subjectId: 'MAPEL02', subjectName: 'Al-Qur\'an Hadis', harian: 98, uts: 98, uas: 99, finalScore: 98.3, notes: 'Sempurna, pelafalan fasih dan memiliki hafalan yang kokoh melebihi rata-rata kelas.' }
];

export const INITIAL_DIGITAL_FILES: DigitalFile[] = [
  { id: 'D001', name: 'Database Kelas IV-A SD Al Faraby - Google Sheets', type: 'Spreadsheet', url: 'https://docs.google.com/spreadsheets/d/1SheetsMockFarabyDBClass4A/edit', lastUpdated: '2026-06-17 07:45', size: '1.2 MB' },
  { id: 'D002', name: 'Syllabus Kurikulum Merdeka PAI 4_TingkatSD - Google Sheets', type: 'Spreadsheet', url: 'https://docs.google.com/spreadsheets/d/1SheetsMockFarabySyllabus/edit', lastUpdated: '2026-05-12 11:30', size: '2.5 MB' },
  { id: 'D003', name: 'Adab terhadap Kedua Orang Tua (RPP001) - Google Docs', type: 'Document', url: 'https://docs.google.com/document/d/1DocsMockBirrulWalidain/edit', lastUpdated: '2026-06-17 10:48', size: '150 KB' },
  { id: 'D004', name: 'Formulir Kehadiran Santri Al Faraby - Google Forms', type: 'Form', url: 'https://docs.google.com/forms/d/1FormsMockFarabyAttendance/viewform', lastUpdated: '2026-06-16 13:00', size: '45 KB' },
  { id: 'D005', name: 'Surat Keputusan Kalender Akademik 2026-2027.pdf', type: 'PDF', url: '#', lastUpdated: '2026-06-01 09:00', size: '4.8 MB' }
];

export const INITIAL_ACTIVITY_LOGS: ActivityLog[] = [
  { id: 'L001', userEmail: 'siti.alfaraby@gmail.com', userName: 'Siti Nurhaliza, S.Pd.I.', userRole: 'Guru', timestamp: '2026-06-17 08:12:05', action: 'Login Sukses', details: 'Akses dashboard utama via Perangkat Guru Kelas 4A' },
  { id: 'L002', userEmail: 'siti.alfaraby@gmail.com', userName: 'Siti Nurhaliza, S.Pd.I.', userRole: 'Guru', timestamp: '2026-06-17 08:35:12', action: 'Update Absensi', details: 'Melakukan pencatatan presensi Kelas 4A untuk tanggal 2026-06-17' },
  { id: 'L003', userEmail: 'siti.alfaraby@gmail.com', userName: 'Siti Nurhaliza, S.Pd.I.', userRole: 'Guru', timestamp: '2026-06-17 09:15:40', action: 'Input Karakter', details: 'Menambahkan catatan ahlak & shalat untuk santri Ahmad Fauzan' },
  { id: 'L004', userEmail: 'aminah.kepsek@gmail.com', userName: 'Hj. Siti Aminah, S.Pd.I.', userRole: 'Kepala Sekolah', timestamp: '2026-06-17 09:40:02', action: 'Login Sukses', details: 'Memeriksa ringkasan kepatuhan administrasi dan tingkat kelulusan shalat' },
  { id: 'L005', userEmail: 'jafar.admin@gmail.com', userName: 'Muhamad Jafar, S.Kom.', userRole: 'Administrator', timestamp: '2026-06-17 07:05:00', action: 'Koneksi Workspace', details: 'Menyinkronkan API Google Sheets Database dengan klaster SD Al Faraby' }
];

export const SCHOOL_PROFILE = {
  name: 'SD ISLAM AL FARABY',
  npsn: '20224419',
  address: 'Jl. Pemuda No. 45, Kecamatan Sukamanah, Kota Bogor, Jawa Barat',
  principal: 'Hj. Siti Aminah, S.Pd.I.',
  nipPrincipal: '197609202005012003',
  schoolTerm: 'Semester Ganjil 2026/2027',
  accreditation: 'A (Unggul)'
};
