/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export enum UserRole {
  ADMIN = "Administrator",
  KEPSEK = "Kepala Sekolah",
  GURU = "Guru",
  OPERATOR = "Operator"
}

export interface Student {
  id: string;
  nis: string;
  nisn: string;
  name: string;
  gender: 'L' | 'P'; // Laki-laki / Perempuan
  classroom: string; // e.g., "Kelas 1A", "Kelas 2B", "Kelas 6"
  parentsName: string;
  phone: string;
  shalatPoin: number; // 0-100 score based on ibadah logs
  tahfidzStatus: string; // progress, e.g., "Juz 30 (An-Naba s.d Abasa)"
  // Extended requested fields:
  birthplace?: string;
  birthdate?: string;
  religion?: string;
  address?: string;
  fatherName?: string;
  motherName?: string;
  status?: string; // e.g. "Aktif", "Pindahan", "Lulus", "Keluar"
}

export interface Teacher {
  id: string;
  nip: string;
  name: string;
  role: UserRole;
  email: string;
  classroomAssigned?: string;
  subjectsAssigned?: string[];
  phone: string;
  // Extended requested fields:
  nuptk?: string;
  gender?: 'L' | 'P';
  birthplaceDate?: string; // Tempat dan tanggal lahir
  lastEducation?: string; // Pendidikan terakhir
  jobTitle?: string; // Jabatan
  employmentStatus?: string; // Status kepegawaian
  address?: string;
  photoUrl?: string; // Foto (URL, Base64, or emoji representation)
}

export interface Subject {
  id: string;
  code: string;
  name: string;
  category: 'Agama' | 'Umum';
  // Extended requested fields:
  fase?: string; // Fase A, B, C, etc.
  gradeLevel?: string; // Tingkat kelas
  allocatedHours?: string; // Alokasi waktu
}

export interface Classroom {
  id: string;
  grade: string; // Tingkat: 1, 2, 3, 4, 5, 6
  name: string; // Nama kelas: Kelas 4A, Kelas 4B, etc.
  homeroomTeacher: string; // Nama Wali Kelas
  studentCount: number; // Jumlah siswa
}

export interface AcademicYear {
  id: string;
  year: string; // Tahun pelajaran (e.g. "2026/2027")
  semester: 'Ganjil' | 'Genap';
  isActive: boolean; // Status aktif
}

export interface LessonPlan {
  id: string;
  title: string;
  subject: string;
  grade: string;
  topic: string;
  duration: string;
  content: string; // Generated Markdown plan
  islamicIntegration: string; // The Islamic values woven in
  createdAt: string;
  syncedToDocs?: boolean;
}

export interface AttendanceLog {
  id: string;
  studentId: string;
  studentName: string;
  classroom: string;
  date: string; // YYYY-MM-DD
  status: 'H' | 'S' | 'I' | 'A'; // Hadir, Sakit, Izin, Alpa
  notes?: string;
}

export interface TeachingJournal {
  id: string;
  date: string; // YYYY-MM-DD
  classroom: string;
  subject: string;
  topic: string;
  contentSummary: string;
  attendanceSummary: { hadir: number; sakit: number; izin: number; alpa: number };
}

export interface CharacterLog {
  id: string;
  studentId: string;
  studentName: string;
  date: string;
  ahlak: 'Sangat Baik' | 'Baik' | 'Cukup' | 'Perlu Bimbingan';
  ibadah: 'Sangat Baik' | 'Baik' | 'Cukup' | 'Perlu Bimbingan';
  disiplin: 'Sangat Baik' | 'Baik' | 'Cukup' | 'Perlu Bimbingan';
  notes: string;
  loggedBy: string;
}

export interface AcademicScore {
  id: string;
  studentId: string;
  studentName: string;
  classroom: string;
  subjectId: string;
  subjectName: string;
  harian: number; // 0-100
  uts: number; // 0-100
  uas: number; // 0-100
  finalScore: number; // weighted average
  notes: string; // teacher's comments
}

export interface DigitalFile {
  id: string;
  name: string;
  type: 'Spreadsheet' | 'Document' | 'Form' | 'PDF' | 'Folder';
  url: string;
  lastUpdated: string;
  size: string;
}

export interface ActivityLog {
  id: string;
  userEmail: string;
  userName: string;
  userRole: string;
  timestamp: string;
  action: string;
  details: string;
}

export interface SyncStatus {
  sheetsLastSynced: string | null;
  driveLastSynced: string | null;
  calendarLastSynced: string | null;
  gmailLastSynced: string | null;
}

export interface SchoolProfile {
  name: string;
  npsn: string;
  address: string;
  headmaster?: string;
  principal?: string;
  nipPrincipal?: string;
  schoolTerm?: string;
  accreditation: string;
  phone?: string;
}

// === MODUL 4: ADMINISTRASI PEMBELAJARAN INTERFACES ===

export interface CapaianPembelajaran {
  id: string;
  code: string;
  subjectName: string;
  fase: string;
  gradeLevel: string;
  element: string; // Elemen CP (e.g. Al-Qur'an, Hadist, Aqidah, Akhlak)
  description: string;
}

export interface TujuanPembelajaran {
  id: string;
  code: string;
  cpId: string; // Hubungkan dengan CP
  cpCode?: string;
  subjectName: string;
  gradeLevel: string;
  description: string;
}

export interface AlurTujuanPembelajaran {
  id: string;
  code: string;
  subjectName: string;
  fase: string;
  gradeLevel: string;
  steps: Array<{
    stepNumber: number;
    tpCode: string;
    tpDescription: string;
    materialSummary: string; // Ringkasan Materi
    hoursAllocation: string; // Alokasi Waktu (JP)
    assessments: string; // Asesmen
  }>;
}

export interface ModulAjarModel {
  id: string;
  title: string;
  subjectName: string;
  gradeLevel: string;
  phase: string;
  // 18 Rincian Isi Modul Ajar Kurikulum Merdeka:
  identitas: {
    namaPenyusun: string;
    institusi: string;
    tahunPenyusunan: string;
    jenjang: string;
    kelas: string;
    alokasiWaktu: string;
  };
  kompetensiAwal: string;
  profilPelajarPancasila: string;
  saranaPrasarana: string;
  targetPesertaDidik: string;
  modelPembelajaran: string;
  metodePembelajaran: string;
  materi: string;
  tujuanPembelajaran: string;
  pemahamanBermakna: string;
  pertanyaanPemantik: string;
  kegiatanPendahuluan: string;
  kegiatanInti: string;
  kegiatanPenutup: string;
  asesmen: string;
  refleksiGuru: string;
  refleksiPesertaDidik: string;
  lampiran: string;
}

export interface ProgramTahunan {
  id: string;
  subjectName: string;
  gradeLevel: string;
  academicYear: string;
  elements: Array<{
    id: string;
    semester: 'Ganjil' | 'Genap';
    tpCode: string;
    tpDescription: string;
    allocatedHours: string;
    targetMonth: string; // e.g. "Agustus", "September"
  }>;
}

export interface ProgramSemester {
  id: string;
  subjectName: string;
  gradeLevel: string;
  academicYear: string;
  semester: 'Ganjil' | 'Genap';
  elements: Array<{
    id: string;
    tpCode: string;
    tpDescription: string;
    allocatedHours: string;
    monthlySchedule: { [monthName: string]: string[] }; // Month Name -> array of weekly indicators e.g., ["4 JP", "", "", ""]
  }>;
}

export interface AnalisisMingguEfektif {
  id: string;
  academicYear: string;
  semester: 'Ganjil' | 'Genap';
  months: Array<{
    name: string;
    totalWeeks: number;
    effectiveWeeks: number;
    nonEffectiveWeeks: number;
    remarks: string; // Keterangan (e.g. "Libur Semester", "PAS", etc.)
  }>;
}

export interface GoogleCalendarEvent {
  id: string;
  title: string;
  startDate: string; // YYYY-MM-DD
  endDate: string; // YYYY-MM-DD
  type: 'Akademik' | 'Keagamaan' | 'Libur' | 'Ujian';
  color: string;
}

export interface JadwalMengajar {
  id: string;
  teacherName: string;
  subjectName: string;
  classroomName: string;
  day: 'Senin' | 'Selasa' | 'Rabu' | 'Kamis' | 'Jumat' | 'Sabtu';
  periodStart: number; // e.g. 1
  periodEnd: number; // e.g. 2
  timeRange: string; // e.g. "07:30 - 08:45"
}

// === MODUL 5: ADMINISTRASI KELAS INTERFACES ===

export interface BukuAgendaMengajar {
  id: string;
  date: string;
  activity: string;
  classroom: string;
  teacherName: string;
  status: 'Selesai' | 'Tertunda' | 'Belum Mulai';
  notes?: string;
}

export interface JurnalMengajarModul5 {
  id: string;
  date: string;
  hours: string; // Jam ke-
  subject: string;
  materi: string;
  metode: string;
  attendanceDetails: string; // e.g. "Hadir: 23, Sakit: 1 (Budi), Izin: 0, Alpa: 0"
  hambatan: string;
  tindakLanjut: string;
  classroom: string;
}

export interface CatatanPerkembangan {
  id: string;
  studentId: string;
  studentName: string;
  classroom: string;
  date: string;
  aspect: 'Akademik' | 'Perilaku';
  category: string; // e.g. "Sikap Spiritual", "Sikap Sosial", "Prestasi", "Kesulitan Belajar"
  notes: string; // Deskripsi perkembangan
  actionTaken: string; // Tindak lanjut / bimbingan
}

export interface BukuTamu {
  id: string;
  date: string;
  visitorName: string;
  institution: string; // Instansi/Jabatan
  purpose: string; // Keperluan
  suggestions: string; // Saran atau kesan
  contactPhone?: string;
}

export interface InventarisBarang {
  id: string;
  itemName: string;
  itemCode: string;
  quantity: number;
  condition: 'Baik' | 'Rusak Ringan' | 'Rusak Berat';
  source: string; // Asal/Sumber barang (e.g. "BOS", "Iuran Wali", "Yayasan")
  classroom: string;
}

export interface SystemUser {
  id: string;
  name: string;
  email: string;
  role: string;
  isActive: boolean;
  phone: string;
  createdAt: string;
}


