/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  FileText,
  Settings,
  Sparkles,
  Download,
  Printer,
  ChevronRight,
  Plus,
  Compass,
  FileCheck,
  CheckCircle,
  Clock,
  RotateCw,
  FolderOpen,
  Share2,
  Trash2,
  ListOrdered,
  BookOpen,
  Users,
  Award,
  AlertCircle,
  HelpCircle,
  FileSpreadsheet
} from 'lucide-react';
import { Subject } from '../types';

interface LkpdViewProps {
  subjects: Subject[];
}

export interface GeneratedLKPD {
  id: string;
  subjectId: string;
  subjectName: string;
  className: string;
  material: string;
  objective: string;
  questionCount: number;
  dateCreated: string;
  introduction: string;
  activities: string[];
  tasks: Array<{ question: string; points: number }>;
  reflectionTitle: string;
  reflectionQuestion: string;
}

// Some preloaded sample LKPDs to show content on first loading
const INITIAL_LKPDS: GeneratedLKPD[] = [
  {
    id: 'LKPD-001',
    subjectId: 'MAPEL01',
    subjectName: 'Aqidah Akhlak',
    className: 'Kelas 4A',
    material: 'Asmaul Husna Al-Mu\'min dan Al-Lathif',
    objective: 'Peserta didik mampu meneladani sifat Al-Mu\'min (Maha Memberi Keamanan) dan Al-Lathif (Maha Lembut) dalam hubungan bertetangga di kehidupan sehari-hari.',
    questionCount: 5,
    dateCreated: '2026-06-16',
    introduction: 'Asmaul Husna adalah nama-nama baik yang dimiliki oleh Allah SWT. Mengimani nama-nama-Nya berarti kita harus meneladani sifat mulia tersebut dalam tingkatan manusiawi sebagai bekal pembinaan adab.',
    activities: [
      'Bentuklah kelompok kecil beranggotakan 3-4 santri.',
      'Sebutkan 3 sifat mulia tetangga Anda lalu diskusikan bagaimana cara melunakkan sikap jika menghadapi perselisihan.',
      'Tuliskan simpulan hikmah perdamaian pada tabel aktivitas.'
    ],
    tasks: [
      { question: 'Uraikan makna asmaul husna Al-Mu\'min secara bahasa dan istilah syariat!', points: 20 },
      { question: 'Mengapa Allah SWT disebut Al-Lathif? Berikan 2 contoh bukti kelembutan-Nya di alam semesta!', points: 20 },
      { question: 'Bagaimana cara seorang siswa mempraktikkan asmaul husna Al-Mu\'min di lingkungan sekolah?', points: 20 },
      { question: 'Tuliskan lafadz doa memohon keamanan negara dan keluarga beserta artinya!', points: 20 },
      { question: 'Ceritakan kisah singkat pengalaman Anda berbuat lembut kepada adik atau teman sebaya!', points: 20 }
    ],
    reflectionTitle: 'Refleksi Adab & Birrul Walidain',
    reflectionQuestion: 'Bagaimanakah sikap kalian di rumah apabila orang tua memberikan nasihat secara tegas namun lembut? Hubungkan dengan asmaul husna Al-Lathif.'
  }
];

export default function LkpdView({ subjects }: LkpdViewProps) {
  const [lkpds, setLkpds] = useState<GeneratedLKPD[]>(INITIAL_LKPDS);
  const [activeLkpd, setActiveLkpd] = useState<GeneratedLKPD | null>(INITIAL_LKPDS[0]);

  // Form Generator inputs
  const [selectedSubjectId, setSelectedSubjectId] = useState(subjects[0]?.id || 'MAPEL01');
  const [selectedClass, setSelectedClass] = useState('Kelas 4A');
  const [materiInput, setMateriInput] = useState('');
  const [tujuanInput, setTujuanInput] = useState('');
  const [numQuestions, setNumQuestions] = useState(5);

  // Loading States
  const [isGenerating, setIsGenerating] = useState(false);
  const [generationSteps, setGenerationSteps] = useState<string[]>([]);
  const [stepIndex, setStepIndex] = useState(0);

  // Google syncing simulation
  const [isGDocsSynced, setIsGDocsSynced] = useState(false);
  const [isSyncingGDocs, setIsSyncingGDocs] = useState(false);
  const [syncLogs, setSyncLogs] = useState<string[]>([]);

  // Default parameters templates to help teacher autofill
  const loadAutofillTemplate = () => {
    const mapel = subjects.find(s => s.id === selectedSubjectId);
    if (!mapel) return;

    if (mapel.name.includes('Aqidah') || mapel.name.includes('Akhlak')) {
      setMateriInput('Adab Bertamu dan Menerima Tamu Islami');
      setTujuanInput('Santri dapat mendemonstrasikan adab bertamu serta menyambut tamu dengan sopan santun sesuai syariat Nabi Muhammad SAW.');
    } else if (mapel.name.includes('Fiqih')) {
      setMateriInput('Ketentuan Shalat Jama\' dan Qashar');
      setTujuanInput('Siswa mampu menghitung syarat safar serta mempraktikkan tata cara shalat rukhsah (jama\' qashar) dalam perjalanan jauh.');
    } else if (mapel.name.includes('Matematika')) {
      setMateriInput('Penyajian Data dan Membaca Diagram Batang');
      setTujuanInput('Siswa dapat memecahkan masalah keseharian dengan merancang diagram batang dan menyajikan grafik analisis statistik.');
    } else if (mapel.name.includes('Arab')) {
      setMateriInput('Mufrodat tentang Peralatan Sekolah (Adawatul Madrosiyyah)');
      setTujuanInput('Peserta didik mampu melafalkan kosa kata Arab peralatan sekolah dan melengkapi teks rumpang dengan dhomir yang tepat.');
    } else {
      setMateriInput('Analisis Sila-Sila Pancasila');
      setTujuanInput('Peserta didik mampu menyimpulkan integrasi nilai moral gotong royong dengan akhlakul karimah kemasyarakatan.');
    }
  };

  // Generate Handler
  const handleGenerateLkpd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!materiInput.trim() || !tujuanInput.trim()) {
      alert('Silakan lengkapi kolom materi pokok dan tujuan pembelajaran terlebih dahulu ustadz/ustadzah!');
      return;
    }

    setIsGenerating(true);
    setGenerationSteps([]);
    setStepIndex(0);

    const steps = [
      'Menghubungkan ke Mesin Kurikulum Merdeka AI Al Faraby...',
      '[Analisis] Membaca silabus Mata Pelajaran & KKTP target...',
      '[Konseptual] Memformulasikan struktur rangkuman materi ringkas...',
      '[Task builder] Merancang kuis mandiri & butir penugasan interaktif...',
      '[Evaluasi] Memasukkan unsur adab birrul walidain ke kolom refleksi...',
      'Alhamdulillah, Lembar Kerja (LKPD) sukses dirakit secara paripurna!'
    ];

    // Simulated progress steps
    let currentStep = 0;
    const interval = setInterval(() => {
      if (currentStep < steps.length) {
        setGenerationSteps(prev => [...prev, steps[currentStep]]);
        currentStep++;
      } else {
        clearInterval(interval);
        
        // Finalize state
        const subjectObj = subjects.find(s => s.id === selectedSubjectId);
        const subjName = subjectObj ? subjectObj.name : 'Mata Pelajaran';

        // Compiling dynamic simulation of tasks
        const computedTasks = [];
        for (let i = 1; i <= numQuestions; i++) {
          computedTasks.push({
            question: `Analisislah permasalahan terkait ${materiInput} pada nomor tantangan ${i}, bagaimana korelasi solusi yang Anda usulkan?`,
            points: Math.round(100 / numQuestions)
          });
        }

        const newLkpd: GeneratedLKPD = {
          id: 'LKPD-' + Math.floor(Math.random() * 1000).toString().padStart(3, '0'),
          subjectId: selectedSubjectId,
          subjectName: subjName,
          className: selectedClass,
          material: materiInput,
          objective: tujuanInput,
          questionCount: numQuestions,
          dateCreated: new Date().toISOString().split('T')[0],
          introduction: `Lembar kerja ini disusun guna menelaah pemahaman mendasar seputar ${materiInput}. Bacalah ringkasan materi dan instruksi kegiatan dengan saksama di bawah petunjuk guru wali kelas.`,
          activities: [
            'Duduklah bersama pasangan kelompok diskusi Anda.',
            `Lakukan telaah bahan ajar sekilas mengenai bahasan pokok ${materiInput}.`,
            'Diskusikan jawaban pertanyaan tantangan lalu sampaikan hasilnya di depan forum kelas.'
          ],
          tasks: computedTasks,
          reflectionTitle: 'Refleksi Karakter & Akhlakul Karimah',
          reflectionQuestion: `Bagaimana implementasi nilai kejujuran dhuha dan ketaatan ibadah yang kalian petik dari pembelajaran membahas ${materiInput}?`
        };

        setLkpds(prev => [newLkpd, ...prev]);
        setActiveLkpd(newLkpd);
        setIsGenerating(false);
        setIsGDocsSynced(false); // Reset sync state for new documents
        
        // Clear forms
        setMateriInput('');
        setTujuanInput('');
      }
    }, 1000);
  };

  // Sync to Google Docs Simulator
  const handleSyncToGoogleDocs = () => {
    if (!activeLkpd) return;
    setIsSyncingGDocs(true);
    setSyncLogs(['Inisialisasi koneksi OAuth 2.0 Google Workspace...']);

    setTimeout(() => {
      setSyncLogs(prev => [...prev, 'Mengidentifikasi folder induk "Al-Faraby LKPD Generator" di Google Drive...']);
    }, 800);

    setTimeout(() => {
      setSyncLogs(prev => [...prev, `Merancang Dokumen Baru: "LKPD_${activeLkpd.subjectName.replace(' ', '_')}_${activeLkpd.material.replace(' ', '_')}"`]);
    }, 1600);

    setTimeout(() => {
      setSyncLogs(prev => [...prev, 'Sukses menulis tabel identitas santri & baris tugas ke naskah Google Docs...']);
    }, 2400);

    setTimeout(() => {
      setSyncLogs(prev => [...prev, 'Sinkronisasi Selesai! Dokumen G-Suite siap diakses oleh dewan pengajar.']);
      setIsSyncingGDocs(false);
      setIsGDocsSynced(true);
      alert('Alhamdulillah! Lembar Kerja Peserta Didik berhasil diekspor & disinkronisasikan ke akun Google Docs G-Suite Anda.');
    }, 3200);
  };

  // Export as Word Document File Maker
  const handleExportWord = () => {
    if (!activeLkpd) return;

    let docHtml = `
      <html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'>
      <head>
        <title>LKPD ${activeLkpd.material}</title>
        <style>
          body { font-family: Arial, sans-serif; padding: 25px; line-height: 1.6; }
          .kop { text-align: center; border-bottom: 3px double #000; padding-bottom: 5px; margin-bottom: 20px; }
          .title { text-align: center; font-weight: bold; font-size: 16px; margin-top: 15px; }
          .grid-table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
          .grid-table td { border: 1px solid #ddd; padding: 8px; font-size: 12px; }
          .section-title { font-weight: bold; font-size: 13px; background-color: #f2f2f2; padding: 5px; margin-top: 15px; border-left: 4px solid #047857; }
          .content-text { font-size: 12px; text-align: justify; margin: 8px 0; }
          .task-box { border: 1px solid #ccc; padding: 10px; margin-bottom: 10px; border-radius: 5px; background-color: #fafafa; }
        </style>
      </head>
      <body>
        <div class="kop">
          <h2 style="margin: 0; font-size: 15px; uppercase">SD ISLAM INTEGRASI AL-FARABY BOGOR</h2>
          <p style="margin: 3px 0; font-size: 10px; color: #555;">"Unggul dalam Adab, Cerdas dalam Pengetahuan" &bull; TA 2026/2027</p>
        </div>

        <div class="title">LEMBAR KERJA PESERTA DIDIK (LKPD)</div>
        <p style="text-align: center; margin-top: 2px; font-size: 11px; font-style: italic;">Materi: ${activeLkpd.material}</p>

        <table class="grid-table">
          <tr>
            <td style="width: 150px;"><b>Nama Lengkap Santri:</b></td>
            <td>...................................................</td>
            <td style="width: 120px;"><b>Hari / Tanggal:</b></td>
            <td>............................</td>
          </tr>
          <tr>
            <td><b>Kelas / Nomor Absen:</b></td>
            <td>${activeLkpd.className} / ........</td>
            <td><b>Mata Pelajaran:</b></td>
            <td><b>${activeLkpd.subjectName}</b></td>
          </tr>
        </table>

        <div class="section-title">A. TUJUAN PEMBELAJARAN (LEARNING GOALS)</div>
        <p class="content-text">${activeLkpd.objective}</p>

        <div class="section-title">B. PENGANTAR & RINGKASAN MATERI</div>
        <p class="content-text">${activeLkpd.introduction}</p>

        <div class="section-title">C. LANGKAH-LANGKAH AKTIVITAS KELOMPOK</div>
        <ol style="font-size: 12px; padding-left: 20px;">
          ${activeLkpd.activities.map(act => `<li>${act}</li>`).join('')}
        </ol>

        <div class="section-title">D. LEMBAR TUGAS MANDIRI & ANALISIS SISWA</div>
        <p class="content-text">Tuliskan pemaparan logis dari butir penugasan berikut di bawah kertas kerja:</p>
        ${activeLkpd.tasks.map((t, idx) => `
          <div class="task-box">
            <p style="margin: 0; font-size: 12px; font-weight: bold;">Tantangan Soal ${idx + 1} (${t.points} Poin)</p>
            <p style="margin: 5px 0 0 0; font-size: 12px; color: #333;">${t.question}</p>
            <br/><br/><br/>
          </div>
        `).join('')}

        <div class="section-title">E. REFLEKSI KARAKTER ADAB ISLAMI</div>
        <p style="font-size: 12px; font-weight: bold; margin-bottom: 2px;">${activeLkpd.reflectionTitle}</p>
        <p style="font-size: 12px; font-style: italic; color: #555;">${activeLkpd.reflectionQuestion}</p>
        <br/><br/>

        <table style="width: 100%; border: none; margin-top: 30px; font-size: 10px; border-collapse: collapse;">
          <tr>
            <td style="border: none; text-align: center; width: 33%">
              <p>Mengetahui,</p>
              <p><b>Orang Tua / Wali Santri</b></p>
              <br/><br/><br/>
              <p>( .................................... )</p>
            </td>
            <td style="border: none; text-align: center; width: 33%">
              <p>Catatan / Feedback Guru:</p>
              <div style="border: 1px dotted #ccc; width: 80%; height: 50px; margin: auto;"></div>
            </td>
            <td style="border: none; text-align: center; width: 33%">
              <p>Bogor, ........................ 2026</p>
              <p><b>Guru Mata Pelajaran</b></p>
              <br/><br/><br/>
              <p><b>Siti Nurhaliza, S.Pd.I.</b></p>
            </td>
          </tr>
        </table>
      </body>
      </html>
    `;

    const blob = new Blob(['\ufeff' + docHtml], {
      type: 'application/msword;charset=utf-8'
    });
    
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `LKPD_${activeLkpd.subjectName.replace(' ', '_')}_${activeLkpd.className.replace(' ', '_')}.doc`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleDeleteLkpd = (id: string) => {
    if (confirm('Apakah ustadz yakin mau menghapus LKPD ini dari sejarah arsip?')) {
      const remaining = lkpds.filter(l => l.id !== id);
      setLkpds(remaining);
      if (activeLkpd?.id === id) {
        setActiveLkpd(remaining[0] || null);
      }
    }
  };

  return (
    <div id="lkpd-generator-wrapper" className="space-y-6">
      
      {/* HEADER SECTION */}
      <div className="pb-4 border-b border-slate-200">
        <div className="flex items-center gap-2">
          <span className="bg-emerald-100 text-emerald-800 text-xxxxs uppercase font-extrabold px-2.5 py-1 rounded-full">
            Modul 8
          </span>
          <h2 className="text-lg font-bold text-slate-800 school-display">
            Automated LKPD / LKS Worksheet Generator
          </h2>
        </div>
        <p className="text-xxs text-slate-500 mt-1">
          Menyusun Lemba Kerja Peserta Didik (LKPD) secara instan berbasis integrasi Kurikulum Merdeka Terpadu Basmalah. Ekspor naskah Anda langsung ke format MS Word, cetakan PDF, atau sinkronisasikan ke G-Suite Docs.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* LEFT COLUMN: PARAMETER SETUP */}
        <div className="space-y-6">
          
          <form onSubmit={handleGenerateLkpd} className="bg-white p-5 rounded-2xl border border-slate-100 shadow-xxs space-y-4">
            <div className="pb-2.5 border-b border-slate-100 flex items-center justify-between">
              <span className="font-extrabold text-xs text-slate-800 uppercase tracking-wide">Pengaturan Lembar Kerja</span>
              <button
                type="button"
                onClick={loadAutofillTemplate}
                className="text-xxxxs bg-brand-gold-50 text-brand-gold-800 hover:bg-brand-gold-100 font-extrabold px-2 py-1 rounded-lg transition"
                title="Isikan otomatis contoh rancangan materi sesuai mapel terpilih"
              >
                Template Pengisian
              </button>
            </div>

            {/* SUBJECT SELECT */}
            <div>
              <label className="block text-xxs font-bold text-slate-500 uppercase mb-1">Mata Pelajaran</label>
              <select
                value={selectedSubjectId}
                onChange={e => setSelectedSubjectId(e.target.value)}
                className="w-full text-xs px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:bg-white focus:border-brand-green-600"
              >
                {subjects.map(s => (
                  <option key={s.id} value={s.id}>{s.name} ({s.code})</option>
                ))}
              </select>
            </div>

            {/* CLASS SELECT */}
            <div>
              <label className="block text-xxs font-bold text-slate-500 uppercase mb-1">Rombel Kelas</label>
              <select
                value={selectedClass}
                onChange={e => setSelectedClass(e.target.value)}
                className="w-full text-xs px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:bg-white focus:border-brand-green-600"
              >
                <option value="Kelas 4A">Kelas 4A</option>
                <option value="Kelas 4B">Kelas 4B</option>
                <option value="Kelas 5">Kelas 5 (Fase C)</option>
                <option value="Kelas 6">Kelas 6 (Fase C)</option>
              </select>
            </div>

            {/* MATERI POKOK */}
            <div>
              <label className="block text-xxs font-bold text-slate-500 uppercase mb-1">Materi Pokok / Bahasan Utama</label>
              <input
                type="text"
                placeholder="Contoh: Menghindari Akhlak Madzmumah"
                required
                className="w-full text-xs px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:bg-white focus:border-brand-green-600 text-slate-800 font-medium"
                value={materiInput}
                onChange={e => setMateriInput(e.target.value)}
              />
            </div>

            {/* TUJUAN PEMBELAJARAN */}
            <div>
              <label className="block text-xxs font-bold text-slate-500 uppercase mb-1">Tujuan Pembelajaran (Learning Goals)</label>
              <textarea
                rows={3}
                placeholder="Siswa dapat merinci contoh akhlak madzmumah..."
                required
                className="w-full text-xs p-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:bg-white focus:border-brand-green-600 text-slate-800 leading-normal"
                value={tujuanInput}
                onChange={e => setTujuanInput(e.target.value)}
              />
            </div>

            {/* QUESTION QUANTITY */}
            <div>
              <label className="block text-xxs font-bold text-slate-500 uppercase mb-1">Banyaknya Butir Tugas (Tantangan Soal)</label>
              <select
                value={numQuestions}
                onChange={e => setNumQuestions(parseInt(e.target.value))}
                className="w-full text-xs px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:bg-white focus:border-brand-green-600 font-bold"
              >
                <option value={3}>3 Soal Mandiri</option>
                <option value={5}>5 Soal Mandiri (Standar)</option>
                <option value={10}>10 Soal Mandiri</option>
                <option value={15}>15 Soal Mandiri (Komprehensif)</option>
              </select>
            </div>

            {/* SUBMIT */}
            <button
              type="submit"
              disabled={isGenerating}
              className="w-full bg-brand-green-700 hover:bg-brand-green-800 text-white font-extrabold text-xs py-3 rounded-xl shadow-xs transition cursor-pointer flex items-center justify-center gap-1.5"
            >
              {isGenerating ? (
                <>
                  <RotateCw className="h-4 w-4 animate-spin text-white" /> Merakit lembaran LKS...
                </>
              ) : (
                <>
                  <Sparkles className="h-4 w-4 text-brand-gold-500 fill-brand-gold-500" /> Generate LKPD Otomatis
                </>
              )}
            </button>
          </form>

          {/* SIDEBAR RECENT HISTORY list */}
          <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-xxs space-y-4">
            <span className="font-extrabold text-xs text-slate-800 block uppercase tracking-wide">Daftar Arsip LKPD Al Faraby</span>
            
            <div className="space-y-2">
              {lkpds.length === 0 ? (
                <p className="text-xxs text-slate-400 text-center py-6">Belum ada LKPD yang dirakit.</p>
              ) : (
                lkpds.map(item => (
                  <div
                    key={item.id}
                    onClick={() => setActiveLkpd(item)}
                    className={`p-3 rounded-xl border text-left cursor-pointer transition flex items-center justify-between gap-2 ${
                      activeLkpd?.id === item.id
                        ? 'border-brand-green-600 bg-brand-green-50/40'
                        : 'border-slate-150 bg-slate-50/20 hover:bg-slate-50'
                    }`}
                  >
                    <div className="min-w-0">
                      <div className="font-extrabold text-slate-800 text-xxs truncate">{item.material}</div>
                      <div className="text-[10px] text-slate-400 mt-0.5">{item.subjectName} &bull; {item.className}</div>
                    </div>
                    <button
                      type="button"
                      onClick={(e) => { e.stopPropagation(); handleDeleteLkpd(item.id); }}
                      className="text-slate-400 hover:text-red-600 transition p-1 cursor-pointer shrink-0"
                    >
                      <Trash2 className="h-3 w-3" />
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>

        </div>

        {/* MIDDLE & RIGHT PANEL: DOCUMENT PREVIEW & OUTPUT ACTIONS */}
        <div className="lg:col-span-2 space-y-6">
          
          {isGenerating ? (
            <div className="bg-white rounded-2xl border border-slate-150 p-12 text-center flex flex-col items-center justify-center space-y-4 shadow-xxs">
              <RotateCw className="h-10 w-10 text-brand-green-700 animate-spin" />
              <div className="font-extrabold text-slate-800 text-xs">Mempersiapkan Lembar Kerja Mandiri Beradab...</div>
              
              <div className="w-full max-w-sm text-left bg-slate-50 p-4 rounded-xl border border-slate-200 text-xxxxs font-mono space-y-1 text-slate-550 leading-normal">
                {generationSteps.map((step, sIdx) => {
                  const isLast = sIdx === generationSteps.length - 1;
                  return (
                    <div key={sIdx} className="flex gap-2">
                      <span className={isLast ? 'text-brand-gold-700 font-bold' : 'text-emerald-700'}>&gt;</span>
                      <span className={isLast ? 'text-slate-800 font-bold' : ''}>{step}</span>
                    </div>
                  );
                })}
              </div>
            </div>
          ) : activeLkpd ? (
            <div className="space-y-6">
              
              {/* EXPORTS / OUTPUT BAR */}
              <div className="bg-white p-4 rounded-2xl border border-slate-150 shadow-xxs flex flex-wrap items-center justify-between gap-3 text-xxs">
                <span className="font-extrabold text-slate-500 uppercase tracking-widest text-[9px]">Opsi Ekspor LKPD :</span>
                
                <div className="flex flex-wrap items-center gap-2">
                  <button
                    onClick={handleExportWord}
                    className="bg-blue-50 hover:bg-blue-100 text-blue-700 font-bold px-3.5 py-2 rounded-xl border border-blue-200 transition flex items-center gap-1.5 cursor-pointer shadow-xxs"
                  >
                    <Download className="h-3.5 w-3.5" /> Microsoft Word (.doc)
                  </button>

                  <button
                    onClick={() => {
                      window.print();
                    }}
                    className="bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold px-3.5 py-2 rounded-xl border border-indigo-200 transition flex items-center gap-1.5 cursor-pointer shadow-xxs"
                  >
                    <Printer className="h-3.5 w-3.5" /> Cetak Lembar / LKS (PDF)
                  </button>

                  <button
                    onClick={handleSyncToGoogleDocs}
                    disabled={isSyncingGDocs}
                    className={`font-bold px-3.5 py-2 rounded-xl border transition flex items-center gap-1.5 cursor-pointer shadow-xxs ${
                      isGDocsSynced
                        ? 'bg-emerald-100 border-emerald-300 text-emerald-800 font-extrabold'
                        : 'bg-emerald-50 hover:bg-emerald-100 border-emerald-200 text-emerald-700'
                    }`}
                  >
                    {isSyncingGDocs ? (
                      <RotateCw className="h-3.5 w-3.5 animate-spin" />
                    ) : (
                      <svg className="h-3.5 w-3.5" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-2 10h-4v4h-2v-4H7v-2h4V7h2v4h4v2z" />
                      </svg>
                    )}
                    {isGDocsSynced ? 'Sindikat Google Docs (Sukses)' : 'Sinkron Google Docs'}
                  </button>
                </div>
              </div>

              {/* GOOGLE DOCS SYNC LOGS PANEL TRACE */}
              {syncLogs.length > 0 && (
                <div className="bg-emerald-950 text-emerald-200 p-4 rounded-xl border border-emerald-900 font-mono text-[9px] leading-relaxed shadow-md space-y-1">
                  <div className="font-extrabold text-[10px] text-emerald-300 uppercase pb-1.5 border-b border-emerald-900 mb-1">
                    G-Suite Docs Cloud Integration Tracker
                  </div>
                  {syncLogs.map((log, sidx) => (
                    <div key={sidx} className="flex gap-1.5">
                      <span className="text-brand-gold-500">&bull;</span>
                      <span>{log}</span>
                    </div>
                  ))}
                </div>
              )}

              {/* CORE WORKSHEET CONTAINER (Interactive Sheet) */}
              <div className="bg-white p-8 rounded-2xl border border-slate-200 shadow-xs space-y-6 text-slate-800">
                
                {/* BRANDING LOGO */}
                <div className="border-b-2 border-slate-800 pb-3 text-center">
                  <h3 className="font-extrabold text-sm text-slate-900 uppercase tracking-wide leading-tight">SD ISLAM INTEGRASI AL-FARABY BOGOR</h3>
                  <p className="text-[10px] text-slate-500 mt-0.5 italic">"Unggul dalam Adab, Cerdas dalam Pengetahuan" &bull; TA 2026/2027</p>
                </div>

                {/* THEMATIC HEADING */}
                <div className="text-center space-y-1">
                  <div className="inline-block bg-teal-50 border border-teal-200 text-teal-800 text-xxs font-extrabold px-3.5 py-1 rounded-full uppercase tracking-wider">
                    LEMBAR KERJA PESERTA DIDIK (LKPD)
                  </div>
                  <h4 className="font-bold text-xs text-slate-700">Materi Pokok: {activeLkpd.material}</h4>
                </div>

                {/* STUDENT NAME FILL SPACES */}
                <div className="grid grid-cols-2 gap-4 text-xxs border border-slate-100 p-3.5 rounded-xl bg-slate-50/50">
                  <div className="space-y-1.5">
                    <div>
                      <span className="text-slate-400 font-extrabold block uppercase text-[9px]">Nama Lengkap Santri :</span>
                      <span className="border-b border-slate-300 block pb-1 h-4 italic text-slate-400">...................................................</span>
                    </div>
                    <div>
                      <span className="text-slate-400 font-extrabold block uppercase text-[9px]">Nomor Absen :</span>
                      <span className="border-b border-slate-300 block pb-1 h-4 italic text-slate-400">...................................................</span>
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <div>
                      <span className="text-slate-400 font-extrabold block uppercase text-[9px]">Kelas / Fase :</span>
                      <strong className="text-slate-800 block border-b border-slate-300 pb-1 h-4">{activeLkpd.className}</strong>
                    </div>
                    <div>
                      <span className="text-slate-400 font-extrabold block uppercase text-[9px]">Hari / Tanggal Pengerjaan :</span>
                      <span className="border-b border-slate-300 block pb-1 h-4 italic text-slate-400">...................................................</span>
                    </div>
                  </div>
                </div>

                {/* SECTION 1: LEARNING OBJECTIVE */}
                <div className="space-y-2">
                  <span className="font-extrabold text-xxs bg-slate-100 px-3 py-1 rounded-md text-slate-700 inline-block uppercase tracking-wide">A. TUJUAN PEMBELAJARAN (LEARNING OBJECTIVES)</span>
                  <p className="text-xxs text-slate-650 leading-relaxed font-medium pl-2">
                    {activeLkpd.objective}
                  </p>
                </div>

                {/* SECTION 2: INTRODUCTION SUMMARY */}
                <div className="space-y-2">
                  <span className="font-extrabold text-xxs bg-slate-100 px-3 py-1 rounded-md text-slate-700 inline-block uppercase tracking-wide">B. RINGKASAN PEMAHAMAN MATERI DASAR</span>
                  <p className="text-xxs text-slate-650 leading-relaxed text-justify pl-2">
                    {activeLkpd.introduction}
                  </p>
                </div>

                {/* SECTION 3: INSTRUCTIONS ACTIVITIES */}
                <div className="space-y-2">
                  <span className="font-extrabold text-xxs bg-slate-100 px-3 py-1 rounded-md text-slate-700 inline-block uppercase tracking-wide">C. LANGKAH-LANGKAH AKTIVITAS KELOMPOK</span>
                  <div className="space-y-1.5 pl-4 text-xxs text-slate-650 leading-relaxed font-semibold">
                    {activeLkpd.activities.map((act, aIdx) => (
                      <div key={aIdx} className="flex gap-2">
                        <span>{aIdx + 1}.</span>
                        <span>{act}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* SECTION 4: ASSIGNMENTS QUESTIONS */}
                <div className="space-y-4">
                  <span className="font-extrabold text-xxs bg-slate-100 px-3 py-1 rounded-md text-slate-700 inline-block uppercase tracking-wide">D. LEMBAR SOAL TANTANGAN MANDIRI</span>
                  <div className="space-y-4 pl-2 font-semibold">
                    {activeLkpd.tasks.map((task, tIdx) => (
                      <div key={tIdx} className="space-y-2">
                        <div className="text-xxs font-bold text-slate-800 leading-normal flex items-center justify-between">
                          <span>{tIdx + 1}. {task.question}</span>
                          <span className="text-[10px] text-teal-800 bg-teal-50 px-2 py-0.5 rounded-full font-mono font-bold">Bobot: {task.points} Poin</span>
                        </div>
                        <div className="border border-slate-200 border-dotted h-16 w-full rounded-xl bg-slate-50/25" />
                      </div>
                    ))}
                  </div>
                </div>

                {/* SECTION 5: ISLAMIC REFLECTION */}
                <div className="bg-amber-50/30 p-4 rounded-2xl border border-amber-100 spacing-y-2">
                  <div className="flex items-center gap-1 text-xs font-bold text-amber-900 border-b border-amber-100 pb-2 mb-2">
                    <Compass className="h-4 w-4 text-amber-700 fill-amber-200" />
                    <span>{activeLkpd.reflectionTitle}</span>
                  </div>
                  <p className="text-xxs text-amber-950 font-medium leading-relaxed italic mb-3">
                    "{activeLkpd.reflectionQuestion}"
                  </p>
                  <div className="border border-amber-200 border-dashed h-16 w-full rounded-xl bg-white" />
                </div>

                {/* SECTION 6: FEEDBACK GURU & ORANG TUA */}
                <div className="pt-6 border-t border-slate-200 grid grid-cols-1 sm:grid-cols-2 gap-4 text-center text-xxxxs text-slate-600 leading-normal font-semibold">
                  <div className="border border-slate-150 p-3 rounded-2xl bg-slate-50">
                    <p className="text-[10px] text-slate-700 font-extrabold">Catatan & Feedback Guru Wali:</p>
                    <br/><br/>
                    <div className="border-t border-slate-300 w-32 mx-auto pt-1 font-bold">Siti Nurhaliza, S.Pd.I.</div>
                  </div>
                  <div className="border border-slate-150 p-3 rounded-2xl bg-slate-50">
                    <p className="text-[10px] text-slate-700 font-extrabold">Tanda Tangan Orang Tua / Wali:</p>
                    <br/><br/>
                    <div className="border-t border-slate-300 w-32 mx-auto pt-1 font-bold">Tanda Tangan</div>
                  </div>
                </div>

              </div>
            </div>
          ) : (
            <div className="bg-white rounded-2xl border border-slate-150 p-16 text-center text-slate-400 shadow-xxs">
              <FileCheck className="h-12 w-12 text-slate-250 mx-auto mb-2.5" />
              <p className="text-xs font-semibold">Gunakan menu pengisian sebelah kiri untuk menghasilkan lembar aktivitas LKS / LKPD perdana Anda.</p>
            </div>
          )}
        </div>

      </div>

    </div>
  );
}
