/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Users, BookOpen, Clock, ShieldAlert, Award, Star, ArrowUpRight, TrendingUp, Calendar as CalendarIcon, RefreshCw, User, Bell, AlertCircle, CheckSquare, Sparkles } from 'lucide-react';
import { Student, ActivityLog, Teacher, Subject } from '../types';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, Legend } from 'recharts';

interface DashboardViewProps {
  students: Student[];
  teachers: Teacher[];
  subjects: Subject[];
  rppCount: number;
  activityLogs: ActivityLog[];
  activeUser: { name: string; role: string; email: string };
  onNavigateTo: (menu: string) => void;
}

export default function DashboardView({
  students,
  teachers,
  subjects,
  rppCount,
  activityLogs,
  activeUser,
  onNavigateTo
}: DashboardViewProps) {
  // Compute metrics
  const totalStudents = students.length;
  const totalTeachers = teachers.length;
  const totalSubjects = subjects.length;
  
  // Calculate shalat / ibadah metrics averages
  const avgShalatPoin = Math.round(students.reduce((acc, curr) => acc + curr.shalatPoin, 0) / totalStudents);

  // Find current teacher profile from database or mock
  const currentTeacher = teachers.find(t => t.email.toLowerCase() === activeUser.email.toLowerCase()) || {
    nip: '19951012 202311 2 004',
    classroomAssigned: 'Kelas 4-A',
    phone: '0812-7744-8902'
  };

  // Dynamic calculation for completed administration percentage (combines RPPs, audits activity logs)
  const adminCompletion = Math.min(
    100,
    Math.round(62 + (rppCount * 6) + (activityLogs.length > 5 ? 12 : activityLogs.length * 2))
  );

  // Role-based teaching schedules (Jadwal Mengajar Hari Ini)
  const getScheduleForRole = (role: string) => {
    if (role.toLowerCase().includes('kepala') || role.toLowerCase().includes('kepsek')) {
      return [
        { time: '07:30 - 08:30', class: 'Ruangan Kepsek', subject: 'Pemeriksaan Berkas Rencana RPP', icon: '📝', status: 'Selesai' },
        { time: '09:00 - 10:30', class: 'Kelas 4-A & 4-B', subject: 'Supervisi Kelas Pembiasaan Shalat Dhuha', icon: '🕌', status: 'Berlangsung' },
        { time: '13:00 - 14:00', class: 'Aula Utama', subject: 'Koordinasi Rapor Hasil Belajar Bulanan', icon: '📊', status: 'Mendatang' }
      ];
    } else if (role.toLowerCase().includes('admin') || role.toLowerCase().includes('operator')) {
      return [
        { time: '08:00 - 09:30', class: 'Ruang Operator', subject: 'Sinkronisasi Spreadsheet Kehadiran Santri', icon: '🖳', status: 'Selesai' },
        { time: '10:00 - 11:30', class: 'Server Room', subject: 'Integrasi Cloud Storage & API Workspace', icon: '💻', status: 'Berlangsung' },
        { time: '13:30 - 15:00', class: 'Tata Usaha', subject: 'Otorisasi Backup Data Rapor Wali Kelas', icon: '🛡️', status: 'Mendatang' }
      ];
    } else { // Guru/Wali Kelas
      return [
        { time: '07:15 - 08:30', class: 'Kelas 4-A', subject: 'Tematik Terpadu Al-Quran: Adab Belajar', icon: '📖', status: 'Selesai' },
        { time: '08:45 - 10:15', class: 'Kelas 4-A', subject: 'Bahasa Arab: Kosakata Fasilitas Sekolah', icon: '🕌', status: 'Selesai' },
        { time: '10:45 - 12:15', class: 'Kelas 4-B', subject: 'Fiqih Praktis: Thaharah & Tatacara Berwudhu', icon: '💧', status: 'Mendatang' }
      ];
    }
  };

  // Learning agendas for today & tomorrow (Agenda Pembelajaran)
  const getAgendaForRole = (role: string) => {
    if (role.toLowerCase().includes('kepala') || role.toLowerCase().includes('kepsek')) {
      return [
        { date: 'Hari Ini', time: '09:30', class: 'Yayasan', target: 'Peningkatan Karakter Santri', desc: 'Observasi adab santri saat pelaksanaan Shalat Berjamaah' },
        { date: 'Hari Ini', time: '11:00', class: 'Kurikulum', target: 'Evaluasi Pembelajaran', desc: 'Mengkaji efektivitas integrasi nilai Islam pada RPP' },
        { date: 'Besok', time: '08:30', class: 'Sekolah', target: 'Rapat Pleno Akreditasi', desc: 'Persiapan kelengkapan dokumen standar proses sekolah' }
      ];
    } else if (role.toLowerCase().includes('admin') || role.toLowerCase().includes('operator')) {
      return [
        { date: 'Hari Ini', time: '08:00', class: 'Server', target: 'Maintenance API G-Suite', desc: 'Validasi token OAuth & sinkronisasi data dhuha harian' },
        { date: 'Besok', time: '09:00', class: 'Arsip', target: 'Backup & Arsip Digital', desc: 'Arsip bulanan nilai kuis & rekap kehadiran seluruh santri' }
      ];
    } else { // Guru/Wali Kelas
      return [
        { date: 'Hari Ini', time: '08:45', class: 'Kelas 4-A', target: 'Keterampilan Menulis Arab', desc: 'Menghafal 10 kosakata baru tentang perlengkapan belajar' },
        { date: 'Hari Ini', time: '10:45', class: 'Kelas 4-B', target: 'Gerakan Wudhu Sempurna', desc: 'Demonstrasi satu-persatu rukun & sunnah wudhu di area air' },
        { date: 'Besok', time: '07:15', class: 'Kelas 4-A', target: 'Hafalan Ayat Ke-16 s.d 30', desc: 'Penyetoran lisan hafalan Surat Al-Mutaffifin' },
        { date: 'Besok', time: '09:30', class: 'Kelas 5', target: 'Kisah Hijrah Nabi', desc: 'Menceritakan kembali strategi dakwah Nabi ketika di Madinah' }
      ];
    }
  };

  // Administrative task notifications (Notifikasi tugas administrasi)
  const getNotificationsForRole = (role: string) => {
    if (role.toLowerCase().includes('kepala') || role.toLowerCase().includes('kepsek')) {
      return [
        { id: 'notif-1', title: 'Verifikasi Modul Belajar', desc: 'Ada 4 pengajuan RPP guru baru memerlukan tinjauan & tanda tangan Anda.', level: 'warning', date: 'Hari ini' },
        { id: 'notif-2', title: 'Legalitas Kelulusan Rapor', desc: 'Segera lakukan approval digital nilai rapor santri akhir tingkat Kelas 6.', level: 'danger', date: 'Batas 2 hari' },
        { id: 'notif-3', title: 'Laporan Semester Tersedia', desc: 'Berkas rekapitulasi poin ibadah santri semester ganjil siap diunduh.', level: 'info', date: 'Kemarin' }
      ];
    } else if (role.toLowerCase().includes('admin') || role.toLowerCase().includes('operator')) {
      return [
        { id: 'notif-1', title: 'Lisensi Google Workspace Sync', desc: 'Masa berlaku credentials API Sheets terdeteksi sisa 3 hari lagi. Lakukan re-auth.', level: 'danger', date: 'Batas 3 hari' },
        { id: 'notif-2', title: 'Permintaan Akun Guru', desc: 'Ada 2 pengajar baru yang meminta pembuatan email resmi bernisbah @alfaraby.sch.id.', level: 'warning', date: 'Hari ini' },
        { id: 'notif-3', title: 'Sistem Backup Berhasil', desc: 'Database SQL telah dicadangkan ke Cloud Storage dengan status Sukses.', level: 'info', date: 'Tadi Malam' }
      ];
    } else { // Guru/Wali Kelas
      return [
        { id: 'notif-1', title: 'Modul RPP Belum Lengkap', desc: 'Unggah atau buat modul Rencana Program Pembelajaran (RPP) untuk pekan depan.', level: 'warning', date: 'Batas 2 hari' },
        { id: 'notif-2', title: 'Presensi Absen Harian', desc: 'Satu santri Kelas 4-A (Azhar) terdeteksi belum diisi status hadir/sakit hari ini.', level: 'danger', date: 'Hari ini' },
        { id: 'notif-3', title: 'Peningkatan Kualitas Adab', desc: 'Silakan isi jurnal perkembangan karakter dhuha milik 5 santri binaan yang tertunda.', level: 'info', date: 'Kemarin' }
      ];
    }
  };

  // Academic Calendar (Kalender akademik)
  const academicCalendar = [
    { date: '19 Jun', day: 'Jum', event: 'Batas Akhir Penyerahan Nilai UTS', type: 'akademik' },
    { date: '22 Jun', day: 'Sen', event: 'Ujian Akhir Semester (UAS) Ganjil', type: 'ujian' },
    { date: '26 Jun', day: 'Jum', event: 'Rapat Pleno Dewan Asatidzah & Wali Kelas', type: 'rapat' },
    { date: '03 Jul', day: 'Jum', event: 'Pembagian Rapor Hasil Studi Santri', type: 'rapor' },
    { date: '06 Jul', day: 'Sen', event: 'Awal Libur Akhir Semester Ganjil', type: 'libur' },
  ];

  const roleSchedule = getScheduleForRole(activeUser.role);
  const roleAgenda = getAgendaForRole(activeUser.role);
  const roleNotifications = getNotificationsForRole(activeUser.role);

  // Custom mock data for our spiritual and academic growth charts (Grafik nilai)
  const monthlyData = [
    { bulan: 'Jan', Akademik: 78, Akhlak: 82, Shalat: 85 },
    { bulan: 'Feb', Akademik: 80, Akhlak: 85, Shalat: 88 },
    { bulan: 'Mar', Akademik: 82, Akhlak: 86, Shalat: 90 },
    { bulan: 'Apr', Akademik: 81, Akhlak: 89, Shalat: 92 },
    { bulan: 'Mei', Akademik: 84, Akhlak: 91, Shalat: 94 },
    { bulan: 'Jun', Akademik: 86, Akhlak: 93, Shalat: 95 },
  ];

  // Attendance bar chart metrics (Grafik kehadiran)
  const classMatesData = [
    { name: 'Kls 1', Hadir: 98, Sakit: 2, Izin: 0, Alpa: 0 },
    { name: 'Kls 2', Hadir: 96, Sakit: 3, Izin: 1, Alpa: 0 },
    { name: 'Kls 3', Hadir: 95, Sakit: 4, Izin: 1, Alpa: 0 },
    { name: 'Kls 4A', Hadir: 97, Sakit: 1, Izin: 1, Alpa: 1 },
    { name: 'Kls 4B', Hadir: 94, Sakit: 4, Izin: 2, Alpa: 0 },
    { name: 'Kls 5', Hadir: 98, Sakit: 1, Izin: 1, Alpa: 0 },
    { name: 'Kls 6', Hadir: 99, Sakit: 1, Izin: 0, Alpa: 0 },
  ];

  return (
    <div id="dashboard-view-wrapper" className="space-y-6">
      
      {/* 1. TOP LAYOUT ROW: WELCOME BANNER & TEACHER IDENTITY PROFILE PROFILE */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Welcome message banner with active school year */}
        <div className="lg:col-span-2 bg-gradient-to-r from-brand-green-700 to-brand-green-900 rounded p-6 text-white relative overflow-hidden shadow-sm flex flex-col justify-between">
          <div className="absolute right-0 top-0 translate-x-12 -translate-y-12 h-64 w-64 bg-emerald-600 rounded-full opacity-20 blur-xl" />
          <div className="absolute left-1/3 bottom-0 h-48 w-48 bg-emerald-500 rounded-full opacity-10 blur-2xl" />
          
          <div className="relative z-10">
            <span className="bg-emerald-800 text-emerald-300 border border-emerald-700 font-bold text-[10px] tracking-wider uppercase px-3 py-1 rounded shadow-xs inline-block">
              SISTEM INFORMASI AKADEMIK AL FARABY
            </span>
            <h1 className="text-2xl md:text-3xl font-extrabold mt-4 school-display tracking-tight text-white leading-tight">
              Selamat Datang, {activeUser.name}
            </h1>
            <p className="text-emerald-100/90 text-xs mt-2 max-w-xl leading-relaxed">
              Selamat menjalankan amanah pengabdian sebagai pendidik. Integrasikan iman, ilmu, dan amal untuk melahirkan generasi robbani yang cakap, cerdas, dan bertaqwa.
            </p>
          </div>

          <div className="relative z-10 mt-6 pt-4 border-t border-brand-green-800 flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <span className="text-xl">📅</span>
              <div className="text-left">
                <p className="text-[10px] text-emerald-300 font-bold uppercase tracking-wider leading-none">Tahun Pelajaran</p>
                <p className="text-xs font-bold mt-0.5">2026/2027 (Kuartal Ganjil)</p>
              </div>
            </div>
            
            <div className="flex items-center gap-3">
              <span className="text-xl">🔖</span>
              <div className="text-left">
                <p className="text-[10px] text-emerald-300 font-bold uppercase tracking-wider leading-none">Semester Aktif</p>
                <p className="text-xs font-bold mt-0.5">Semester Ganjil (Aktif Sesi)</p>
              </div>
            </div>

            <div className="bg-white/10 px-3 py-1.5 rounded text-xs backdrop-blur-xs font-semibold">
              Rabu, 17 Juni 2026
            </div>
          </div>
        </div>

        {/* M2: DETAIL IDENTITAS GURU & FOTO PROFIL CARD */}
        <div className="bg-white border border-gray-200 rounded p-6 shadow-sm flex flex-col justify-between">
          <div className="flex items-start gap-4">
            {/* Foto profil with active shadow glow */}
            <div className="relative">
              <div className="h-16 w-16 bg-emerald-100 rounded flex items-center justify-center text-emerald-800 font-bold text-2xl border-2 border-emerald-700 shadow-sm overflow-hidden shrink-0">
                {activeUser.name.includes('Siti') ? (
                  <span className="text-3xl">🧕</span>
                ) : activeUser.name.includes('Ahmad') ? (
                  <span className="text-3xl">👨‍💼</span>
                ) : (
                  <span className="text-3xl">🎓</span>
                )}
              </div>
              <span className="absolute bottom-0 right-0 h-4.5 w-4.5 bg-emerald-500 border-2 border-white rounded-full flex items-center justify-center text-[8px] text-white font-bold" title="Verified Session">
                ✓
              </span>
            </div>
            
            {/* Identitas guru */}
            <div className="min-w-0 flex-1">
              <p className="text-[10px] font-bold text-emerald-700 uppercase tracking-wider leading-none">IDENTITAS UTAMA GURU</p>
              <h2 className="text-sm font-bold text-gray-800 mt-1 truncate">{activeUser.name}</h2>
              <p className="text-xxs text-gray-400 font-medium mt-0.5">NIP. {currentTeacher.nip || '19951012 202311 2 004'}</p>
              
              <div className="flex flex-wrap items-center gap-1.5 mt-2">
                <span className="text-xxxxs bg-brand-green-50 text-brand-green-700 px-2 py-0.5 rounded uppercase font-bold border border-emerald-100">
                  {activeUser.role}
                </span>
                <span className="text-xxxxs bg-blue-50 text-blue-700 px-2 py-0.5 rounded uppercase font-bold border border-blue-100">
                  {currentTeacher.classroomAssigned || 'Kelas 4-A'}
                </span>
              </div>
            </div>
          </div>

          <div className="mt-4 pt-4 border-t border-gray-100 space-y-3">
            {/* Persentase administrasi yang telah selesai */}
            <div>
              <div className="flex justify-between items-center text-xxs mb-1">
                <span className="font-bold text-gray-500 uppercase tracking-widest">KELENGKAPAN ADMINISTRASI</span>
                <span className="text-brand-green-700 font-extrabold">{adminCompletion}% Selesai</span>
              </div>
              <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
                <div 
                  className="bg-brand-green-600 h-full rounded-full transition-all duration-500" 
                  style={{ width: `${adminCompletion}%` }} 
                />
              </div>
              <span className="text-[9px] text-gray-400 mt-1 block">RPP, Presensi Harian, log Sync G-Sheet</span>
            </div>

            <div className="text-xxs text-gray-500 flex flex-col gap-1">
              <div className="flex justify-between">
                <span>Email resmi:</span>
                <span className="font-medium text-gray-700">{activeUser.email}</span>
              </div>
              <div className="flex justify-between">
                <span>Kontak WA:</span>
                <span className="font-medium text-gray-700">{currentTeacher.phone || '0812-7744-8902'}</span>
              </div>
            </div>
          </div>
        </div>

      </div>

      {/* 2. CORE KPI SUMMARIES */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {/* KPI 1: Siswa */}
        <div id="kpi-siswa" className="bg-white p-5 rounded border border-gray-200 border-b-4 border-b-emerald-600 shadow-sm flex items-center justify-between hover:scale-101 hover:shadow-md transition-all">
          <div>
            <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest block mb-1">Total Siswa Binaan</span>
            <h3 className="text-3xl font-extrabold text-gray-800 leading-none">{totalStudents} <span className="text-xs font-medium text-slate-400">Santri</span></h3>
            <span className="text-xxs text-emerald-600 font-semibold flex items-center gap-1 mt-2">
              <ArrowUpRight className="h-3 w-3" />
              100% Data Lengkap
            </span>
          </div>
          <div className="p-3 bg-emerald-50 text-emerald-700 rounded-lg">
            <Users className="h-6 w-6" />
          </div>
        </div>

        {/* KPI 2: Guru */}
        <div id="kpi-guru" className="bg-white p-5 rounded border border-gray-200 border-b-4 border-b-blue-600 shadow-sm flex items-center justify-between hover:scale-101 hover:shadow-md transition-all">
          <div>
            <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest block mb-1">Dewan Asatidzah</span>
            <h3 className="text-3xl font-extrabold text-gray-800 leading-none">{totalTeachers} <span className="text-xs font-medium text-slate-400">Ustadz/ah</span></h3>
            <span className="text-xxs text-blue-600 font-semibold flex items-center gap-1 mt-2">
              Wali Kelas Assigned
            </span>
          </div>
          <div className="p-3 bg-blue-50 text-blue-700 rounded-lg">
            <BookOpen className="h-6 w-6" />
          </div>
        </div>

        {/* KPI 3: Mutu Shalat */}
        <div id="kpi-mutu-shalat" className="bg-white p-5 rounded border border-gray-200 border-b-4 border-b-amber-500 shadow-sm flex items-center justify-between hover:scale-101 hover:shadow-md transition-all">
          <div>
            <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest block mb-1">Rerata Nilai Shalat</span>
            <h3 className="text-3xl font-extrabold text-gray-800 leading-none">{avgShalatPoin}% <span className="text-xs font-medium text-slate-400">Disiplin</span></h3>
            <span className="text-xxs text-amber-600 font-semibold flex items-center gap-1 mt-2">
              <TrendingUp className="h-3 w-3" />
              Indikator Sangat Baik
            </span>
          </div>
          <div className="p-3 bg-amber-50 text-amber-700 rounded-lg">
            <Award className="h-6 w-6" />
          </div>
        </div>

        {/* KPI 4: Perangkat RPP */}
        <div id="kpi-rpp" className="bg-white p-5 rounded border border-gray-200 border-b-4 border-b-purple-600 shadow-sm flex items-center justify-between hover:scale-101 hover:shadow-md transition-all">
          <div>
            <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest block mb-1">Perangkat Ajar RPP</span>
            <h3 className="text-3xl font-extrabold text-gray-800 leading-none">{rppCount} <span className="text-xs font-medium text-slate-400">Modul</span></h3>
            <span className="text-xxs text-purple-600 font-semibold flex items-center gap-1 mt-2">
              Terintegrasi Nilai Islam
            </span>
          </div>
          <div className="p-3 bg-purple-50 text-purple-700 rounded-lg">
            <Clock className="h-6 w-6" />
          </div>
        </div>
      </div>

      {/* 3. CORE MANAGEMENT ROWS: TEACHING SCHEDULE, AGENDA, ADMINISTRATIVE NOTIFICATIONS & CALENDAR */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* M2: JADWAL MENGAJAR HARI INI */}
        <div className="bg-white border border-gray-200 rounded p-6 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4 border-b pb-3 border-gray-100">
              <h3 className="text-sm font-bold text-gray-800 school-display flex items-center gap-2">
                <span>📅</span> Jadwal Mengajar Hari Ini
              </h3>
              <span className="text-[9px] bg-brand-green-50 text-brand-green-800 font-bold px-2 py-0.5 rounded border border-emerald-100">
                {roleSchedule.length} Kelas
              </span>
            </div>

            <div className="space-y-4">
              {roleSchedule.map((sch, idx) => (
                <div key={idx} className="flex gap-3 hover:bg-slate-50 p-2 rounded transition-colors text-xs">
                  <div className="text-xl shrink-0 mt-0.5">{sch.icon}</div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between">
                      <span className="font-extrabold text-brand-green-800">{sch.class}</span>
                      <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded ${
                        sch.status === 'Selesai' 
                          ? 'bg-emerald-50 text-emerald-700 border border-emerald-100'
                          : sch.status === 'Berlangsung'
                          ? 'bg-amber-50 text-amber-700 border border-amber-200 animate-pulse'
                          : 'bg-slate-100 text-gray-500'
                      }`}>
                        {sch.status}
                      </span>
                    </div>
                    <p className="font-bold text-gray-800 mt-0.5 truncate">{sch.subject}</p>
                    <p className="text-xxs text-gray-400 mt-0.5">{sch.time}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-slate-100 flex items-center justify-between text-xs">
            <span className="text-slate-400 font-medium">Buku agenda mengajar digital</span>
            <button
              onClick={() => onNavigateTo('Administrasi Kelas')}
              className="text-brand-green-700 font-bold hover:underline cursor-pointer text-xxs"
            >
              Isi Jurnal Kelas &rarr;
            </button>
          </div>
        </div>

        {/* M2: AGENDA PEMBELAJARAN */}
        <div className="bg-white border border-gray-200 rounded p-6 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4 border-b pb-3 border-gray-100">
              <h3 className="text-sm font-bold text-gray-800 school-display flex items-center gap-2">
                <span>📖</span> Agenda Pembelajaran
              </h3>
              <Sparkles className="h-4 w-4 text-amber-500 animate-bounce" />
            </div>

            <div className="space-y-3">
              {roleAgenda.map((agnd, idx) => (
                <div key={idx} className="p-2.5 rounded border border-gray-100 hover:border-emerald-200 transition-colors text-xs bg-slate-50/50">
                  <div className="flex justify-between items-center text-[10px] pb-1.5 border-b border-dashed border-gray-100">
                    <span className="font-bold text-brand-green-700">{agnd.class} ({agnd.time})</span>
                    <span className="text-gray-400 font-semibold">{agnd.date}</span>
                  </div>
                  <p className="font-bold text-gray-800 mt-1.5 leading-tight">{agnd.target}</p>
                  <p className="text-xxs text-gray-500 mt-0.5 leading-relaxed">{agnd.desc}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 flex justify-between items-center">
            <span className="text-[10px] text-gray-400">Tersusun dalam modul ajar</span>
            <button
              onClick={() => onNavigateTo('Administrasi Pembelajaran')}
              className="text-indigo-600 font-bold hover:underline text-xxs"
            >
              Kelola RPP &rarr;
            </button>
          </div>
        </div>

        {/* M2: NOTIFIKASI TUGAS ADMINISTRASI & ACADEMIC CALENDAR */}
        <div className="bg-white border border-gray-200 rounded p-6 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4 border-b pb-3 border-gray-100">
              <h3 className="text-sm font-bold text-gray-800 school-display flex items-center gap-1.5">
                <Bell className="h-4 w-4 text-amber-500" />
                Notifikasi Tugas Administrasi
              </h3>
              <span className="text-[9px] bg-red-100 text-red-700 font-bold px-2 py-0.5 rounded">
                Mendesak
              </span>
            </div>

            <div className="space-y-3">
              {roleNotifications.map((notif) => {
                let colorClass = 'border-l-amber-500 text-amber-800 bg-amber-50/50';
                if (notif.level === 'danger') colorClass = 'border-l-red-500 text-red-800 bg-red-50/30';
                if (notif.level === 'info') colorClass = 'border-l-blue-500 text-blue-800 bg-blue-50/30';

                return (
                  <div key={notif.id} className={`text-xxs p-2 rounded border border-gray-100 border-l-4 ${colorClass}`}>
                    <div className="flex justify-between font-bold">
                      <span className="truncate">{notif.title}</span>
                      <span className="text-[8px] opacity-75 whitespace-nowrap">{notif.date}</span>
                    </div>
                    <p className="opacity-90 mt-0.5 leading-relaxed">{notif.desc}</p>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
            <div className="text-[10px] text-gray-400">Daftar tugas tertunda</div>
            <button
              onClick={() => onNavigateTo('Administrasi Kelas')}
              className="px-2 py-1 bg-brand-green-700 hover:bg-brand-green-800 text-white rounded text-[9px] font-bold cursor-pointer"
            >
              Lihat Semua Tugas
            </button>
          </div>
        </div>

      </div>

      {/* 4. VISUALIZATION ROW: ACADEMIC CALENDAR & GRAPHS AND CHARTS */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* M2: KALENDER AKADEMIK TIMELINE */}
        <div className="bg-white border border-gray-200 rounded p-6 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4 border-b pb-3 border-gray-100">
              <h3 className="text-sm font-bold text-gray-800 school-display flex items-center gap-1.5">
                <CalendarIcon className="h-4 w-4 text-emerald-600" />
                Kalender Akademik Terkini
              </h3>
              <span className="text-[10px] text-gray-400 font-semibold">Semester Genap 2026</span>
            </div>

            <div className="space-y-3.5">
              {academicCalendar.map((cal, idx) => (
                <div key={idx} className="flex gap-3 text-xs leading-none">
                  <div className="flex-none w-11 h-11 bg-emerald-50 text-emerald-700 rounded flex flex-col items-center justify-center font-bold border border-emerald-100">
                    <span className="text-[13px] leading-tight font-extrabold">{cal.date.split(' ')[0]}</span>
                    <span className="text-[8px] uppercase">{cal.date.split(' ')[1]}</span>
                  </div>
                  <div className="flex-1 min-w-0 flex flex-col justify-center">
                    <p className="font-extrabold text-gray-800 line-clamp-1">{cal.event}</p>
                    <p className="text-[10px] text-gray-400 font-semibold mt-1 uppercase tracking-wider">{cal.type}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <button 
            onClick={() => onNavigateTo('Penilaian')}
            className="mt-6 w-full py-2 bg-slate-100 hover:bg-slate-200 rounded text-[10px] font-bold text-gray-600 transition-colors uppercase tracking-widest cursor-pointer"
          >
            Buka Rincian Semester &rarr;
          </button>
        </div>

        {/* M2: GRAFIK NILAI (Grafik Perkembangan Nilai Holistik) */}
        <div className="bg-white border border-gray-200 rounded p-6 shadow-sm lg:col-span-2 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-sm font-bold text-slate-800 school-display">Grafik Perkembangan Nilai Holistik (Grafik Nilai)</h3>
                <p className="text-xxs text-slate-500">Rerata materi pembelajaran, akhlak, dan kedisiplinan beribadah santri</p>
              </div>
              <div className="flex gap-3 text-xxs font-semibold">
                <span className="flex items-center gap-1"><span className="h-2 w-2 rounded-full bg-indigo-500" /> Akademik</span>
                <span className="flex items-center gap-1"><span className="h-2 w-2 rounded-full bg-emerald-500" /> Akhlak</span>
                <span className="flex items-center gap-1"><span className="h-2 w-2 rounded-full bg-amber-500" /> Shalat</span>
              </div>
            </div>
            <div className="h-48 mt-2">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={monthlyData} margin={{ top: 10, right: 10, left: -25, bottom: 0 }}>
                  <defs>
                    <linearGradient id="colorAkademik" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#6366f1" stopOpacity={0.2}/>
                      <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
                    </linearGradient>
                    <linearGradient id="colorAkhlak" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#10b981" stopOpacity={0.2}/>
                      <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                  <XAxis dataKey="bulan" stroke="#94a3b8" fontSize={10} tickLine={false} />
                  <YAxis stroke="#94a3b8" fontSize={10} domain={[60, 100]} tickLine={false} />
                  <Tooltip />
                  <Area type="monotone" dataKey="Akademik" stroke="#6366f1" strokeWidth={2} fillOpacity={1} fill="url(#colorAkademik)" />
                  <Area type="monotone" dataKey="Akhlak" stroke="#10b981" strokeWidth={2} fillOpacity={1} fill="url(#colorAkhlak)" />
                  <Area type="monotone" dataKey="Shalat" stroke="#f59e0b" strokeWidth={2} fill="none" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>
          <div className="mt-4 p-3 bg-brand-green-50 rounded border border-emerald-100 text-xxs text-brand-green-900 flex justify-between items-center text-left">
            <span><strong>Catatan Mutu:</strong> Ketaatan shalat fardhu dan ibadah dhuha secara umum meningkat sejak pembiasaan harian.</span>
            <button 
              onClick={() => onNavigateTo('Penilaian')}
              className="text-brand-green-700 font-bold hover:underline cursor-pointer flex-shrink-0 ml-4 whitespace-nowrap"
            >
              Evaluasi Santri &rarr;
            </button>
          </div>
        </div>

      </div>

      {/* 5. VISUALIZATION ROW: PRESENSI / ATTENDANCE GRAPH */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* M2: GRAFIK KEHADIRAN (Tingkat Absensi Santri) */}
        <div className="bg-white border border-gray-200 rounded p-6 shadow-sm lg:col-span-2">
          <h3 className="text-sm font-bold text-slate-800 school-display mb-1">Grafik Kehadiran / Absensi Santri per Kelas</h3>
          <p className="text-xxs text-slate-500 mb-4">Pemantauan persentase (%) kehadiran, persentase sakit, dan izin harian di seluruh kelas</p>
          <div className="h-56">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={classMatesData} margin={{ top: 10, right: 10, left: -25, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="name" stroke="#94a3b8" fontSize={10} tickLine={false} />
                <YAxis stroke="#94a3b8" fontSize={10} domain={[85, 100]} tickLine={false} />
                <Tooltip />
                <Legend iconSize={8} wrapperStyle={{ fontSize: 10 }} />
                <Bar dataKey="Hadir" fill="#10b981" radius={[4, 4, 0, 0]} />
                <Bar dataKey="Sakit" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                <Bar dataKey="Izin" fill="#f59e0b" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Target Tarbiyah Goal Progress Tracker */}
        <div className="bg-white border border-gray-200 rounded p-6 shadow-sm flex flex-col justify-between">
          <div>
            <h3 className="text-sm font-bold text-slate-800 school-display flex items-center gap-2">
              <Star className="h-4 w-4 text-brand-gold-500 fill-brand-gold-500" />
              Fokus Utama Tarbiyah & Adab
            </h3>
            <p className="text-xxs text-slate-500 mt-0.5">Penetapan target mutu semester ganjil</p>
            
            <div className="mt-4 space-y-4">
              <div>
                <div className="flex justify-between items-center text-xs mb-1">
                  <span className="font-semibold text-slate-700">Tuntas Hafalan Juz 30</span>
                  <span className="text-brand-green-700 font-bold">8 dari 10 santri</span>
                </div>
                <div className="w-full bg-slate-100 rounded-full h-1.5 overflow-hidden">
                  <div className="bg-brand-green-600 h-full rounded-full" style={{ width: '80%' }} />
                </div>
              </div>

              <div>
                <div className="flex justify-between items-center text-xs mb-1">
                  <span className="font-semibold text-slate-700">Ketaatan Berdzikir Pagi</span>
                  <span className="text-brand-green-700 font-bold">75% Kehadiran</span>
                </div>
                <div className="w-full bg-slate-100 rounded-full h-1.5 overflow-hidden">
                  <div className="bg-brand-gold-500 h-full rounded-full" style={{ width: '75%' }} />
                </div>
              </div>

              <div>
                <div className="flex justify-between items-center text-xs mb-1">
                  <span className="font-semibold text-slate-700">Adab Sopan Santun</span>
                  <span className="text-brand-green-700 font-bold">Tercapai 90%</span>
                </div>
                <div className="w-full bg-slate-100 rounded-full h-1.5 overflow-hidden">
                  <div className="bg-indigo-600 h-full rounded-full" style={{ width: '90%' }} />
                </div>
              </div>
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-slate-100 flex items-center justify-between text-xs">
            <span className="text-slate-500">Program Penilaian Karakter</span>
            <button
              onClick={() => onNavigateTo('Administrasi Kelas')}
              className="text-brand-green-700 font-bold hover:underline flex items-center gap-0.5 cursor-pointer text-xxs"
            >
              Ubah Log Adab &rarr;
            </button>
          </div>
        </div>

      </div>

      {/* QUICK ACTIONS FOOTER */}
      <div className="h-20 bg-brand-green-800 rounded-lg flex items-center justify-between px-8 text-white shadow-lg">
        <div className="flex items-center space-x-4">
          <div className="bg-brand-green-700 p-2 rounded">
            <span className="text-xl">⚡</span>
          </div>
          <div>
            <p className="text-sm font-bold">Aksi Cepat</p>
            <p className="text-[10px] text-emerald-300">Buat dokumen administrasi dalam hitungan detik</p>
          </div>
        </div>
        <div className="space-x-4 hidden md:flex">
          <button
            onClick={() => onNavigateTo('Administrasi Pembelajaran')}
            className="px-4 py-2 bg-white text-emerald-900 rounded text-xs font-bold shadow-sm hover:bg-emerald-50 transition-colors cursor-pointer"
          >
            + RPP Baru
          </button>
          <button
            onClick={() => onNavigateTo('Administrasi Kelas')}
            className="px-4 py-2 bg-brand-green-600 text-white border border-emerald-400 rounded text-xs font-bold shadow-sm hover:bg-emerald-500 transition-colors cursor-pointer"
          >
            + Absensi Siswa
          </button>
          <button
            onClick={() => onNavigateTo('Administrasi Kelas')}
            className="px-4 py-2 bg-brand-green-600 text-white border border-emerald-400 rounded text-xs font-bold shadow-sm hover:bg-emerald-500 transition-colors cursor-pointer"
          >
            + Jurnal Kelas
          </button>
        </div>
      </div>
    </div>
  );
}
