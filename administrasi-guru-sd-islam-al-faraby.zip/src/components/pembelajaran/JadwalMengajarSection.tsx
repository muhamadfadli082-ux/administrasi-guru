/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Plus, Edit, Trash2, Printer, CheckCircle, HelpCircle, Move, RotateCw, X
} from 'lucide-react';
import { JadwalMengajar } from '../../types';

export default function JadwalMengajarSection() {
  const [schedule, setSchedule] = useState<JadwalMengajar[]>([
    { id: '1', teacherName: 'Ustadz Syamil Baswedan', subjectName: 'Fikih', classroomName: 'Kelas 4A', day: 'Senin', periodStart: 1, periodEnd: 2, timeRange: '07:30 - 08:40' },
    { id: '2', teacherName: 'Ustadzah Marwah Hasan', subjectName: 'Aqidah Akhlak', classroomName: 'Kelas 4B', day: 'Senin', periodStart: 3, periodEnd: 4, timeRange: '08:40 - 09:50' },
    { id: '3', teacherName: 'Ustadz Syamil Baswedan', subjectName: 'Al-Qur\'an Hadist', classroomName: 'Kelas 4A', day: 'Selasa', periodStart: 2, periodEnd: 3, timeRange: '08:05 - 09:15' },
    { id: '4', teacherName: 'Ustadzh. Fatimah', subjectName: 'Bahasa Arab', classroomName: 'Kelas 5A', day: 'Rabu', periodStart: 1, periodEnd: 2, timeRange: '07:30 - 08:40' },
    { id: '5', teacherName: 'Ustadzah Marwah Hasan', subjectName: 'Aqidah Akhlak', classroomName: 'Kelas 4A', day: 'Kamis', periodStart: 5, periodEnd: 6, timeRange: '10:15 - 11:25' }
  ]);

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedBlockId, setSelectedBlockId] = useState<string | null>(null);

  // Form states
  const [teacherName, setTeacherName] = useState('Ustadzah Marwah Hasan');
  const [subjectName, setSubjectName] = useState('Aqidah Akhlak');
  const [classroomName, setClassroomName] = useState('Kelas 4A');
  const [day, setDay] = useState<'Senin'|'Selasa'|'Rabu'|'Kamis'|'Jumat'|'Sabtu'>('Senin');
  const [periodStart, setPeriodStart] = useState<number>(1);
  const [periodEnd, setPeriodEnd] = useState<number>(2);

  // Swap State (for modular drag & drop simulation)
  const [swapSourceId, setSwapSourceId] = useState<string | null>(null);
  const [notification, setNotification] = useState('');

  const DAYS: Array<'Senin'|'Selasa'|'Rabu'|'Kamis'|'Jumat'|'Sabtu'> = ['Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
  const PERIODS = [1, 2, 3, 4, 5, 6, 7];

  const getPeriodTime = (p: number) => {
    switch(p) {
      case 1: return '07:30 - 08:05';
      case 2: return '08:05 - 08:40';
      case 3: return '08:40 - 09:15';
      case 4: return '09:15 - 09:50';
      case 5: return '10:15 - 10:50'; // Istirahat 09:50 - 10:15
      case 6: return '10:50 - 11:25';
      case 7: return '11:25 - 12:00';
      default: return '13:00 - 13:35';
    }
  };

  const handleOpenAdd = () => {
    setSelectedBlockId(null);
    setIsModalOpen(true);
  };

  const handleOpenEdit = (block: JadwalMengajar) => {
    setSelectedBlockId(block.id);
    setTeacherName(block.teacherName);
    setSubjectName(block.subjectName);
    setClassroomName(block.classroomName);
    setDay(block.day);
    setPeriodStart(block.periodStart);
    setPeriodEnd(block.periodEnd);
    setIsModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();

    const data: JadwalMengajar = {
      id: selectedBlockId || Math.floor(Math.random() * 1000).toString(),
      teacherName,
      subjectName,
      classroomName,
      day,
      periodStart,
      periodEnd,
      timeRange: `${getPeriodTime(periodStart).split(' - ')[0]} - ${getPeriodTime(periodEnd).split(' - ')[1] || getPeriodTime(periodStart).split(' - ')[1]}`
    };

    if (selectedBlockId) {
      setSchedule(schedule.map(s => s.id === selectedBlockId ? data : s));
    } else {
      setSchedule([...schedule, data]);
    }
    setIsModalOpen(false);
  };

  const handleDelete = (id: string) => {
    if(confirm('Apakah Anda yakin ingin menghapus jadwal ajar ini?')) {
      setSchedule(schedule.filter(s => s.id !== id));
    }
  };

  // Reschedule swap simulation handler (acting as the drag and drop behavior)
  const handleSwapTrigger = (id: string) => {
    if (!swapSourceId) {
      setSwapSourceId(id);
      setNotification('Mode Pemindahan Aktif: Klik tombol "Pindah" pada jadwal lain untuk menukar jam mengajar!');
    } else {
      // Swap properties of the two
      const updated = [...schedule];
      const sourceIdx = updated.findIndex(u => u.id === swapSourceId);
      const destIdx = updated.findIndex(u => u.id === id);

      if (sourceIdx !== -1 && destIdx !== -1) {
        const sourceDay = updated[sourceIdx].day;
        const sourceStart = updated[sourceIdx].periodStart;
        const sourceEnd = updated[sourceIdx].periodEnd;
        const sourceTime = updated[sourceIdx].timeRange;

        updated[sourceIdx].day = updated[destIdx].day;
        updated[sourceIdx].periodStart = updated[destIdx].periodStart;
        updated[sourceIdx].periodEnd = updated[destIdx].periodEnd;
        updated[sourceIdx].timeRange = updated[destIdx].timeRange;

        updated[destIdx].day = sourceDay;
        updated[destIdx].periodStart = sourceStart;
        updated[destIdx].periodEnd = sourceEnd;
        updated[destIdx].timeRange = sourceTime;

        setSchedule(updated);
        setNotification('Sukses Menukar Jadwal Mengajar (Drag & Drop Rescheduled)!');
        setTimeout(() => setNotification(''), 3500);
      }
      setSwapSourceId(null);
    }
  };

  const handlePrint = () => {
    const win = window.open('', '_blank');
    if (!win) return;

    win.document.write(`
      <html>
        <head>
          <title>Jadwal Mengajar Ust / Ustdzh - SD Islam Al Faraby</title>
          <style>
            body { font-family: sans-serif; padding: 30px; font-size:11px; color:#1e293b;}
            table { width: 100%; border-collapse: collapse; margin-top: 15px; }
            th, td { border: 1px solid #cbd5e1; padding: 8px; text-align: center; }
            th { background-color: #0f766e; color: white; font-weight: bold; }
            .day-col { font-weight: bold; background-color: #f8fafc; text-align: left; }
            .card-grid { font-weight: 500; font-size: 10px; background-color: #ecfdf5; border: 1px solid #a7f3d0; border-radius: 4px; padding: 4px; }
          </style>
        </head>
        <body>
          <h2 style="text-align:center; color:#0f766e;">JADWAL MENGAJAR GURU & STAFF PENGAJAR</h2>
          <h3 style="text-align:center; margin-top:-5px; color:#64748b;">SD Islam Al Faraby &bull; Tahun Pelajaran 2026/2027</h3>

          <table>
            <thead>
              <tr>
                <th style="width:12%">Jam Ke</th>
                <th style="width:15%">Waktu</th>
                ${DAYS.map(day => `<th>${day}</th>`).join('')}
              </tr>
            </thead>
            <tbody>
              ${PERIODS.map(p => {
                return `
                  <tr>
                    <td style="font-weight:bold; background-color:#f1f5f9;">${p}</td>
                    <td style="font-family:monospace; font-size:9.5px; background-color:#f1f5f9;">${getPeriodTime(p).split(' - ')[0]}</td>
                    ${DAYS.map(day => {
                      const found = schedule.find(s => s.day === day && s.periodStart <= p && s.periodEnd >= p);
                      if (found) {
                        return `
                          <td>
                            <div class="card-grid">
                              <strong>${found.subjectName}</strong><br/>
                              ${found.classroomName} <br/>
                              <span style="font-size:8px; color:#64748b;">${found.teacherName.split(' ')[1] || found.teacherName}</span>
                            </div>
                          </td>
                        `;
                      }
                      return `<td>-</td>`;
                    }).join('')}
                  </tr>
                `;
              }).join('')}
            </tbody>
          </table>
        </body>
      </html>
    `);
    win.document.close();
    win.print();
  };

  return (
    <div className="space-y-4 animate-in fade-in duration-200">
      
      {/* Control Actions Header */}
      <div className="bg-white border border-slate-100 rounded-2xl p-4.5 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="text-xxxxs font-bold text-slate-405 uppercase tracking-widest block">Plotting Jam Belajar</span>
          <h3 className="text-xs font-bold text-slate-800 uppercase tracking-tight flex items-center gap-1.5">
            <RotateCw className={`h-4 w-4 text-emerald-700 ${swapSourceId ? 'animate-spin' : ''}`} />
            Jadwal Mengajar Mingguan &amp; Swap Planner
          </h3>
          <p className="text-xxxxs text-slate-400 font-semibold leading-relaxed mt-1">
            Visualisasikan beban jam mengajar pendidik. Klik icon panah pemindah pada suatu jadwal untuk memprogram pertukaran waktu ajar (Drag-Swap) secara langsung.
          </p>
        </div>

        <div className="flex items-center gap-2.5 shrink-0 self-start md:self-center">
          <button
            onClick={handlePrint}
            className="flex items-center gap-1 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xxxxs px-3.5 py-2.5 rounded-lg border-0 cursor-pointer"
          >
            <Printer className="h-3.5 w-3.5" />
            Cetak Timetable
          </button>
          <button
            onClick={handleOpenAdd}
            className="flex items-center gap-1.5 bg-brand-green-700 hover:bg-brand-green-800 text-white font-bold text-xxxxs px-3.5 py-2.5 rounded-lg border-0 cursor-pointer"
          >
            <Plus className="h-3 w-3" />
            Tambah Jadwal
          </button>
        </div>
      </div>

      {notification && (
        <div className="bg-emerald-50 text-emerald-800 border-l-4 border-emerald-500 p-3.5 rounded-r-xl flex justify-between items-center text-xxs font-bold animate-pulse shadow-sm">
          <div className="flex items-center gap-2">
            <CheckCircle className="h-4.5 w-4.5 text-emerald-600 shrink-0" />
            <span>{notification}</span>
          </div>
          {swapSourceId && (
            <button 
              onClick={() => { setSwapSourceId(null); setNotification(''); }}
              className="text-amber-900 bg-amber-100 hover:bg-amber-200 px-2 py-1 rounded text-xxxxs cursor-pointer"
            >
              Batalkan Swap
            </button>
          )}
        </div>
      )}

      {/* Main visual Table timetable */}
      <div className="bg-white border border-slate-100 rounded-2xl p-4.5 overflow-x-auto shadow-xs">
        <table className="w-full text-center border-collapse text-xxs table-fixed" style={{ minWidth: "900px" }}>
          <thead>
            <tr className="bg-slate-50 border-b border-slate-100 text-slate-550 font-bold uppercase tracking-wider text-xxxxs">
              <th className="p-3 w-20 border border-slate-100">Jam Ke</th>
              <th className="p-3 w-28 border border-slate-100">Waktu</th>
              {DAYS.map(day => (
                <th key={day} className="p-3 border border-slate-100 bg-slate-50/50 text-slate-800 font-extrabold text-[10px]">
                  {day}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 text-slate-705 font-medium">
            {PERIODS.map(p => (
              <tr key={p} className="hover:bg-slate-50/30 text-[11px] h-20">
                <td className="p-2 border border-slate-100 bg-slate-50/40 font-bold text-brand-green-800 text-center">
                  {p}
                </td>
                <td className="p-2 border border-slate-100 bg-slate-50/20 font-mono text-xxxxs text-slate-450 font-bold text-center">
                  {getPeriodTime(p)}
                </td>

                {DAYS.map(day => {
                  const items = schedule.filter(s => s.day === day && s.periodStart <= p && s.periodEnd >= p);
                  
                  return (
                    <td key={day} className="p-1 border border-slate-100 relative group">
                      {items.map(item => {
                        const isPrimaryCell = item.periodStart === p;
                        if (!isPrimaryCell) return null; // let rowSpan effect span it
                        
                        const rowSpanCount = item.periodEnd - item.periodStart + 1;
                        const isSource = item.id === swapSourceId;

                        return (
                          <div 
                            key={item.id} 
                            style={{ height: `${rowSpanCount * 70}px` }}
                            className={`w-full rounded-xl p-2.5 text-left border flex flex-col justify-between transition-all absolute inset-x-1 top-1 z-10 ${
                              isSource 
                                ? 'bg-amber-50 border-amber-400 ring-2 ring-amber-400 text-amber-900 shadow-sm animate-pulse' 
                                : 'bg-emerald-50/65 hover:bg-emerald-50 border-emerald-200 hover:border-emerald-305'
                            }`}
                          >
                            <div className="min-w-0">
                              <div className="flex items-center justify-between gap-1.5">
                                <span className="bg-white/90 text-brand-green-900 py-0.2 px-1.5 rounded-md font-bold text-[8.5px] truncate max-w-[55px] shadow-2xs">
                                  {item.classroomName}
                                </span>
                                <span className="text-[8.5px] font-bold text-slate-450 font-mono truncate">{item.timeRange.split(' - ')[0]}</span>
                              </div>
                              <h5 className="text-[10px] font-black text-slate-850 truncate mt-1.5 leading-snug">{item.subjectName}</h5>
                              <p className="text-[9px] text-slate-500 font-semibold truncate mt-0.5">{item.teacherName.split(' ')[1] || item.teacherName}</p>
                            </div>

                            <div className="flex items-center justify-end gap-1.5 border-t border-slate-50 mt-1 pt-1 opacity-0 group-hover:opacity-100 transition-opacity">
                              <button
                                onClick={() => handleSwapTrigger(item.id)}
                                title="Swap/Pindahkan jam mengajar"
                                className="p-1 hover:bg-brand-gold-100 text-brand-gold-800 rounded cursor-pointer"
                              >
                                <Move className="h-3 w-3" />
                              </button>
                              <button
                                onClick={() => handleOpenEdit(item)}
                                className="p-1 hover:bg-emerald-100 text-brand-green-700 rounded cursor-pointer"
                              >
                                <Edit className="h-3 w-3" />
                              </button>
                              <button
                                onClick={() => handleDelete(item.id)}
                                className="p-1 hover:bg-rose-100 text-rose-600 rounded cursor-pointer"
                              >
                                <Trash2 className="h-3 w-3" />
                              </button>
                            </div>
                          </div>
                        );
                      })}
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* --- ADD/EDIT JADWAL MODAL --- */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl border border-slate-200 w-full max-w-sm shadow-xl overflow-hidden animate-in zoom-in-95 duration-155">
            <div className="bg-brand-green-700 p-4 text-white flex justify-between items-center">
              <h4 className="font-bold text-xs">
                {selectedBlockId ? 'Edit Jadwal KBM' : 'Tambah Jadwal Mengajar'}
              </h4>
              <button onClick={() => setIsModalOpen(false)} className="text-white hover:text-emerald-100 transition">
                <X className="h-4 w-4" />
              </button>
            </div>
            
            <form onSubmit={handleSave} className="p-5 space-y-4 text-xxs">
              <div>
                <label className="block font-bold text-slate-500 uppercase">Nama Pendidik (Ustadz/ah)</label>
                <input
                  type="text"
                  required
                  className="w-full mt-1 border border-slate-200 p-2.5 rounded-lg focus:outline-none"
                  value={teacherName}
                  onChange={e => setTeacherName(e.target.value)}
                />
              </div>

              <div className="grid grid-cols-2 gap-3 text-xxs">
                <div>
                  <label className="block font-bold text-slate-500 uppercase">Mata Pelajaran</label>
                  <input
                    type="text"
                    required
                    className="w-full mt-1 border border-slate-200 p-2.5 rounded-lg focus:outline-none"
                    value={subjectName}
                    onChange={e => setSubjectName(e.target.value)}
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-500 uppercase">Ruang Kelas</label>
                  <input
                    type="text"
                    required
                    className="w-full mt-1 border border-slate-200 p-2.5 rounded-lg focus:outline-none"
                    value={classroomName}
                    onChange={e => setClassroomName(e.target.value)}
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block font-bold text-slate-500 uppercase">Hari</label>
                  <select
                    value={day}
                    onChange={e => setDay(e.target.value as any)}
                    className="w-full mt-1 border border-slate-200 p-2 rounded-lg bg-white"
                  >
                    {DAYS.map(d => <option key={d} value={d}>{d}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block font-bold text-slate-500 uppercase">Mulai Jam</label>
                  <select
                    value={periodStart}
                    onChange={e => setPeriodStart(parseInt(e.target.value))}
                    className="w-full mt-1 border border-slate-200 p-2 rounded-lg bg-white"
                  >
                    {PERIODS.map(p => <option key={p} value={p}>{p}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block font-bold text-slate-500 uppercase">Akhir Jam</label>
                  <select
                    value={periodEnd}
                    onChange={e => setPeriodEnd(parseInt(e.target.value))}
                    className="w-full mt-1 border border-slate-200 p-2 rounded-lg bg-white"
                  >
                    {PERIODS.map(p => <option key={p} value={p}>{p}</option>)}
                  </select>
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-3.5 py-1.5 text-slate-500 hover:bg-slate-100 rounded-lg"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-brand-green-700 hover:bg-brand-green-800 text-white font-bold rounded-lg"
                >
                  Simpan Jadwal
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
