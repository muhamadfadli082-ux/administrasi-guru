/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Plus, Sparkles, RefreshCw, Layers, Printer, Calendar, BookOpen, Clock, PlayCircle, HelpCircle
} from 'lucide-react';
import { CapaianPembelajaran, TujuanPembelajaran, AlurTujuanPembelajaran, Subject } from '../../types';

interface AlurTujuanPembelajaranSectionProps {
  subjects: Subject[];
  cpList: CapaianPembelajaran[];
  tpList: TujuanPembelajaran[];
}

export default function AlurTujuanPembelajaranSection({
  subjects,
  cpList,
  tpList
}: AlurTujuanPembelajaranSectionProps) {
  const [selectedSubject, setSelectedSubject] = useState(subjects[0]?.name || 'Aqidah Akhlak');
  const [isGenerating, setIsGenerating] = useState(false);
  
  // Local active ATP map container
  const [activeAtp, setActiveAtp] = useState<AlurTujuanPembelajaran | null>({
    id: 'ATP-AA-01',
    code: 'ATP-AA-FaseB',
    subjectName: 'Aqidah Akhlak',
    fase: 'Fase B',
    gradeLevel: 'Kelas 4',
    steps: [
      {
        stepNumber: 1,
        tpCode: 'TP-AA-01.1',
        tpDescription: 'Menyebutkan dan mengklasifikasikan 20 sifat wajib Allah SWT beserta dalil akli dan naqli dengan benar.',
        materialSummary: '20 Sifat Wajib Allah SWT (Nafsiyah, Salbiyah, Ma’ani, dan Ma’nawiyah)',
        hoursAllocation: '6 JP (3 Pertemuan)',
        assessments: 'Tes Tertulis & Hafalan Sifat-sifat Wajib'
      },
      {
        stepNumber: 2,
        tpCode: 'TP-AA-01.2',
        tpDescription: 'Menjelaskan fenomena alam sebagai bukti nyata kekuasaan Allah SWT sesuai sifat Jaiz-Nya.',
        materialSummary: 'Tafakur Alam: Membaca kebesaran Allah melalui keteraturan ciptaan tata surya',
        hoursAllocation: '4 JP (2 Pertemuan)',
        assessments: 'Presentasi Kelompok & Rubrik Jurnal Pengamatan Alam'
      }
    ]
  });

  // Dynamic automatic sequences generation based on selected Subject name
  const handleAutoGenerate = () => {
    setIsGenerating(true);
    setTimeout(() => {
      // Find matching CPs and TPs
      const matchingCps = cpList.filter(cp => cp.subjectName === selectedSubject);
      const matchingTps = tpList.filter(tp => tp.subjectName === selectedSubject);

      if (matchingTps.length === 0) {
        // Fallback placeholder data if nothing matches
        setActiveAtp({
          id: 'ATP-' + selectedSubject.substring(0,2).toUpperCase() + '-' + Math.floor(Math.random() * 100),
          code: 'ATP-' + selectedSubject.substring(0,2).toUpperCase() + '-FaseB',
          subjectName: selectedSubject,
          fase: 'Fase B',
          gradeLevel: 'Kelas 4',
          steps: [
            {
              stepNumber: 1,
              tpCode: 'TP-' + selectedSubject.substring(0,2).toUpperCase() + '-01.1',
              tpDescription: `Melakukan identifikasi teoretis mendasar atas muatan utama bahasan ${selectedSubject} secara menyeluruh.`,
              materialSummary: `Teori Pengenalan Awal & Prinsip Dasar Kurikulum ${selectedSubject}`,
              hoursAllocation: '4 JP',
              assessments: 'Tes Sikap & Kuis Kognitif Singkat'
            },
            {
              stepNumber: 2,
              tpCode: 'TP-' + selectedSubject.substring(0,2).toUpperCase() + '-01.2',
              tpDescription: `Mengaplikasikan prinsip bimbingan merdeka belajar dalam penulisan rangkuman pelajaran ${selectedSubject}.`,
              materialSummary: `Aplikasi Praktek, Bimbingan Kasus, & Refleksi Islam Relevan`,
              hoursAllocation: '6 JP',
              assessments: 'Porfolio Tulisan Santri & Penilaian Praktik Lapangan'
            }
          ]
        });
      } else {
        // Sequence the matched ones!
        const generatedSteps = matchingTps.map((tp, index) => {
          // Infer materials and assessments based on indicators
          let materialSummary = `Pendalaman materi inti ${tp.description.split(' ').slice(0, 3).join(' ')}`;
          let hoursAllocation = '4 JP';
          let assessments = 'Uji Kompetensi Soal Tematik';

          if (tp.subjectName.toLowerCase().includes('qur\'an')) {
            hoursAllocation = '6 JP';
            assessments = 'Uji Tajwid Setoran Hafalan Santri';
            materialSummary = `Studi Makharijul Huruf, Tafsir Ringkas, & Setoran Lancar`;
          } else if (tp.subjectName.toLowerCase().includes('akhlak')) {
            hoursAllocation = '4 JP';
            assessments = 'Lembar Pengamatan Praktik Adab & Akhlak Santri';
            materialSummary = `Diskusi Akhlak Mahmudah vs Mazmumah, Roleplay Simulasi`;
          }

          return {
            stepNumber: index + 1,
            tpCode: tp.code,
            tpDescription: tp.description,
            materialSummary,
            hoursAllocation,
            assessments
          };
        });

        setActiveAtp({
          id: 'ATP-' + selectedSubject.substring(0,2).toUpperCase() + '-' + Math.floor(Math.random() * 100),
          code: 'ATP-' + selectedSubject.substring(0,2).toUpperCase() + '-FaseB',
          subjectName: selectedSubject,
          fase: matchingCps[0]?.fase || 'Fase B',
          gradeLevel: matchingCps[0]?.gradeLevel || 'Kelas 4',
          steps: generatedSteps
        });
      }
      setIsGenerating(false);
    }, 1200);
  };

  const handlePrintAtp = () => {
    if (!activeAtp) return;
    const win = window.open('', '_blank');
    if (!win) return;

    win.document.write(`
      <html>
        <head>
          <title>Alur Tujuan Pembelajaran (ATP) - ${activeAtp.subjectName}</title>
          <style>
            body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; padding: 40px; font-size: 11px; color:#334155; }
            .header { border-bottom: 3px double #0d9488; padding-bottom: 12px; margin-bottom: 24px; }
            .title { color:#0f766e; font-size: 16px; font-weight:bold; margin:0; }
            .meta { margin-top:5px; color:#475569; font-size:10px; }
            table { width:100%; border-collapse:collapse; margin-top:15px; }
            th, td { border:1px solid #cbd5e1; padding:10px; text-align:left; vertical-align:top; }
            th { background-color:#f1f5f9; font-weight:bold; color:#0f766e; font-size:9px; text-transform:uppercase; }
            .step-num { font-size:12px; font-weight:bold; color:#0d9488; text-align:center; }
            .tp-code { font-family:monospace; background-color:#fef3c7; color:#92400e; padding:2px 4px; border-radius:3px; font-weight:bold; }
          </style>
        </head>
        <body>
          <div class="header">
            <h1 class="title">ALUR TUJUAN PEMBELAJARAN (ATP)</h1>
            <div class="meta">
              <strong>Satuan Pendidikan:</strong> SD Islam Al Faraby &bull; 
              <strong>Mata Pelajaran:</strong> ${activeAtp.subjectName} &bull; 
              <strong>Fase / Kelas:</strong> ${activeAtp.fase} / ${activeAtp.gradeLevel}
            </div>
          </div>

          <h3>SISTEM DAN SKEMA PENGURUTAN SELESAI AJAR (TIMELINE TIMING):</h3>
          
          <table>
            <thead>
              <tr>
                <th style="width:7%; text-align:center;">Langkah</th>
                <th style="width:15%;">Kode TP</th>
                <th style="width:30%;">Tujuan Pembelajaran (TP)</th>
                <th>Ruang Lingkup Materi Pokok</th>
                <th style="width:12%;">Alokasi JP</th>
                <th style="width:18%;">Rekomendasi Asesmen</th>
              </tr>
            </thead>
            <tbody>
              ${activeAtp.steps.map(step => `
                <tr>
                  <td class="step-num">${step.stepNumber}</td>
                  <td><span class="tp-code">${step.tpCode}</span></td>
                  <td style="font-weight:600; font-size:10.5px;">${step.tpDescription}</td>
                  <td>${step.materialSummary}</td>
                  <td style="font-weight:bold; color:#0f766e;">${step.hoursAllocation}</td>
                  <td style="font-size:10px; italic">${step.assessments}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>

          <div style="margin-top:40px; float:right; text-align:center; width:220px;">
            <p>Bogor, ${new Date().toLocaleDateString('id-ID', { year: 'numeric', month: 'long', day: 'numeric' })}</p>
            <p style="font-weight:bold;">Wali Kurikulum Madrasah Al Faraby</p>
            <div style="height:55px;"></div>
            <p style="text-decoration:underline; font-weight:bold;">Ustadzah Marwah Hasan, S.Pd.I</p>
          </div>
        </body>
      </html>
    `);
    win.document.close();
    win.print();
  };

  return (
    <div className="space-y-5 animate-in fade-in duration-200">
      {/* Subject selector and Generator header card */}
      <div className="bg-white rounded-2xl border border-slate-100 p-5 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-5">
        <div className="space-y-1">
          <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
            <Layers className="h-4 w-4 text-emerald-700" />
            Automatic ATP Generator (Rasionalisasi Alur)
          </h3>
          <p className="text-xxxxs text-slate-400 font-semibold leading-relaxed max-w-xl">
            Sistem cerdas menyusun urutan materi ajar berdasarkan keterkaitan kognitif (genealogi logis) antara CP dan TP terdaftar untuk kelancaran Rapor Pendidikan.
          </p>
        </div>

        <div className="flex bg-slate-50 p-3 rounded-xl border border-slate-200 items-center gap-3 self-start md:self-center shrink-0">
          <span className="text-xxxxs font-bold text-slate-500 uppercase tracking-wider">Mata Pelajaran:</span>
          <select
            value={selectedSubject}
            onChange={e => setSelectedSubject(e.target.value)}
            className="text-xxs px-2.5 py-1.5 bg-white border border-slate-200 rounded-lg cursor-pointer font-bold focus:outline-none"
          >
            {subjects.map(s => (
              <option key={s.id} value={s.name}>{s.name}</option>
            ))}
          </select>
          <button
            onClick={handleAutoGenerate}
            disabled={isGenerating}
            className="flex items-center gap-1 bg-gradient-to-r from-emerald-700 to-emerald-800 hover:from-emerald-800 hover:to-emerald-900 text-white font-bold text-xxxxs px-3.5 py-2.5 rounded-lg cursor-pointer border-0 shadow-sm"
          >
            {isGenerating ? (
              <RefreshCw className="h-3 w-3 animate-spin" />
            ) : (
              <Sparkles className="h-3.5 w-3.5 text-brand-gold-300" />
            )}
            {isGenerating ? 'Generasi Alur...' : 'Buat Struktur ATP'}
          </button>
        </div>
      </div>

      {activeAtp ? (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left panel: Info summary of generated ATP */}
          <div className="bg-white border border-slate-100 rounded-2xl p-5 space-y-4">
            <span className="bg-emerald-50 text-brand-green-800 px-2 py-0.5 rounded-full text-[10px] font-extrabold uppercase border border-emerald-100">
              HASIL GENERATOR DRAFT
            </span>
            <div className="space-y-1">
              <h4 className="text-sm font-extrabold text-slate-900">Alur Ajar: {activeAtp.subjectName}</h4>
              <p className="text-xxs text-slate-400">Kode Dokumen: <span className="font-mono font-bold text-slate-600">{activeAtp.code}</span></p>
            </div>

            <div className="text-xxs space-y-2 border-t border-dashed border-slate-100 pt-3 text-slate-600 font-medium">
              <div className="flex justify-between">
                <span>Sasaran Jenjang:</span>
                <span className="font-bold text-slate-800">{activeAtp.gradeLevel} - {activeAtp.fase}</span>
              </div>
              <div className="flex justify-between">
                <span>Total Langkah Terpeta:</span>
                <span className="font-bold text-slate-800">{activeAtp.steps.length} Seq Pembelajaran</span>
              </div>
              <div className="flex justify-between">
                <span>Curatorial Method:</span>
                <span className="font-bold text-brand-green-700">Hierarchical Sequence</span>
              </div>
            </div>

            <button
              onClick={handlePrintAtp}
              className="w-full flex items-center justify-center gap-1.5 border border-slate-200 bg-slate-50 hover:bg-slate-100 text-slate-700 font-bold text-xxs py-2.5 rounded-xl transition cursor-pointer"
            >
              <Printer className="h-3.5 w-3.5 text-slate-500" />
              Cetak Dokumen ATP Resmi
            </button>
          </div>

          {/* Right panel: Timeline of learning sequence stepper */}
          <div className="lg:col-span-2 bg-white border border-slate-100 rounded-2xl p-5 space-y-5">
            <h4 className="text-xxs font-bold text-slate-500 uppercase tracking-widest">
              Visualisasi Sekuensial Urutan Kegiatan Ajar (Garis Waktu Pekanan)
            </h4>

            <div className="relative border-l border-slate-200 pl-4 py-1.5 space-y-6">
              {activeAtp.steps.map((step, idx) => (
                <div key={idx} className="relative animate-in slide-in-from-left duration-200" style={{ animationDelay: `${idx * 100}ms` }}>
                  {/* Timeline bullet badge */}
                  <span className="absolute -left-[25px] top-0.5 h-4.5 w-4.5 rounded-full bg-brand-green-700 text-white flex items-center justify-center font-bold text-[9px] border-4 border-white shadow-xs">
                    {step.stepNumber}
                  </span>

                  <div className="space-y-2 bg-slate-50/50 hover:bg-slate-50 border border-slate-100 rounded-xl p-4 transition-all">
                    <div className="flex flex-wrap items-center justify-between gap-1.5 border-b border-dashed border-slate-200 pb-2">
                      <div className="flex items-center gap-1.5 text-xxxxs uppercase tracking-wider font-bold">
                        <PlayCircle className="h-3 w-3 text-emerald-700 animate-pulse" />
                        <span className="text-slate-400">Sasaran Inti</span>
                        <span className="bg-brand-gold-100 text-brand-gold-800 px-2 py-0.5 rounded font-mono font-black">{step.tpCode}</span>
                      </div>
                      <div className="flex items-center gap-1 text-xxxxs text-emerald-800 font-bold bg-emerald-50 px-2 py-0.5 rounded">
                        <Clock className="h-3 w-3 text-emerald-700" />
                        {step.hoursAllocation}
                      </div>
                    </div>

                    <div className="text-xxs font-bold text-slate-800">{step.tpDescription}</div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xxxxs pt-1">
                      <div>
                        <span className="block font-bold text-slate-400 uppercase">Materi Pokok Binaan</span>
                        <p className="text-slate-600 font-semibold mt-0.5 leading-normal">{step.materialSummary}</p>
                      </div>
                      <div>
                        <span className="block font-bold text-slate-400 uppercase">Perencanaan Model Evaluasi</span>
                        <p className="text-slate-600 font-semibold mt-0.5 leading-normal">{step.assessments}</p>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      ) : (
        <div className="bg-white border border-slate-100 rounded-2xl p-8 text-center text-slate-400">
          <BookOpen className="h-10 w-10 text-slate-300 mx-auto mb-2" />
          <p className="text-xxs">Silakan pilih Mata Pelajaran di atas lalu tekan tombol "Buat Struktur ATP" untuk merintis rancangan sekuens.</p>
        </div>
      )}
    </div>
  );
}
