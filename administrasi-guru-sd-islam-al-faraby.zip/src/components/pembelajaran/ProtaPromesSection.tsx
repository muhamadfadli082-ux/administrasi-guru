/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Sparkles, RefreshCw, Printer, Calendar, CalendarDays, Check, FileSpreadsheet, Eye
} from 'lucide-react';
import { ProgramTahunan, ProgramSemester, TujuanPembelajaran, Subject } from '../../types';

interface ProtaPromesSectionProps {
  subjects: Subject[];
  tpList: TujuanPembelajaran[];
}

export default function ProtaPromesSection({
  subjects,
  tpList
}: ProtaPromesSectionProps) {
  const [activeSubTab, setActiveSubTab] = useState<'prota' | 'promes'>('prota');
  const [selectedSubject, setSelectedSubject] = useState(subjects[0]?.name || 'Aqidah Akhlak');
  const [isGenerating, setIsGenerating] = useState(false);

  // --- STATE 1: PROTA (Program Tahunan) ---
  const [protaData, setProtaData] = useState<ProgramTahunan | null>({
    id: 'PROTA-01',
    subjectName: 'Aqidah Akhlak',
    gradeLevel: 'Kelas 4',
    academicYear: '2026/2027',
    elements: [
      { id: '1', semester: 'Ganjil', tpCode: 'TP-AA-01.1', tpDescription: 'Menyebutkan dan mengklasifikasikan 20 sifat wajib Allah SWT beserta dalil akli dan naqli dengan benar.', allocatedHours: '6 JP', targetMonth: 'Agustus' },
      { id: '2', semester: 'Ganjil', tpCode: 'TP-AA-01.2', tpDescription: 'Menjelaskan fenomena alam sebagai bukti nyata kekuasaan Allah SWT sesuai sifat Jaiz-Nya.', allocatedHours: '4 JP', targetMonth: 'September' },
      { id: '3', semester: 'Ganjil', tpCode: 'TP-AA-02.1', tpDescription: 'Mendemonstrasikan tata krama takzim (sopan santun) berinteraksi dengan guru di lingkungan madrasah.', allocatedHours: '6 JP', targetMonth: 'Oktober' }
    ]
  });

  // --- STATE 2: PROMES (Program Semester) ---
  const [promesData, setPromesData] = useState<ProgramSemester | null>({
    id: 'PROMES-01',
    subjectName: 'Aqidah Akhlak',
    gradeLevel: 'Kelas 4',
    academicYear: '2026/2027',
    semester: 'Ganjil',
    elements: [
      { 
        id: '1', 
        tpCode: 'TP-AA-01.1', 
        tpDescription: 'Menyebutkan 20 Sifat Wajib Allah', 
        allocatedHours: '6 JP', 
        monthlySchedule: {
          'Juli': ['', '', '', ''],
          'Agustus': ['4 JP', '2 JP', '', ''],
          'September': ['', '', '', ''],
          'Oktober': ['', '', '', ''],
          'November': ['', '', '', ''],
          'Desember': ['', '', '', '']
        } 
      },
      { 
        id: '2', 
        tpCode: 'TP-AA-01.2', 
        tpDescription: 'Menjelaskan sifat Jaiz Allah SWT', 
        allocatedHours: '4 JP', 
        monthlySchedule: {
          'Juli': ['', '', '', ''],
          'Agustus': ['', '', '', ''],
          'September': ['2 JP', '2 JP', '', ''],
          'Oktober': ['', '', '', ''],
          'November': ['', '', '', ''],
          'Desember': ['', '', '', '']
        } 
      },
      { 
        id: '3', 
        tpCode: 'TP-AA-02.1', 
        tpDescription: 'Khidmah takzim kepada Guru di madrasah', 
        allocatedHours: '6 JP', 
        monthlySchedule: {
          'Juli': ['', '', '', ''],
          'Agustus': ['', '', '', ''],
          'September': ['', '', '', ''],
          'Oktober': ['', '4 JP', '2 JP', ''],
          'November': ['', '', '', ''],
          'Desember': ['', '', '', '']
        } 
      }
    ]
  });

  const MONTHS_GANJIL = ['Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];

  // Automatic Prota & Promes Auto-Calculator Generator
  const handleAutoGenerate = () => {
    setIsGenerating(true);
    setTimeout(() => {
      // Pull target TPs
      const matchingTps = tpList.filter(tp => tp.subjectName === selectedSubject);
      
      const targetMonths = ['Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];

      // Generate Prota
      const elementsProta = matchingTps.map((tp, idx) => ({
        id: (idx + 1).toString(),
        semester: idx % 2 === 0 ? 'Ganjil' as const : 'Genap' as const,
        tpCode: tp.code,
        tpDescription: tp.description,
        allocatedHours: idx % 2 === 0 ? '6 JP' : '4 JP',
        targetMonth: targetMonths[idx % targetMonths.length]
      }));

      setProtaData({
        id: 'PROTA-' + Math.floor(Math.random() * 90) + 10,
        subjectName: selectedSubject,
        gradeLevel: 'Kelas 4',
        academicYear: '2026/2027',
        elements: elementsProta.length > 0 ? elementsProta : [
          { id: '1', semester: 'Ganjil', tpCode: 'TP-GEN-01', tpDescription: `Materi Pengantar Komprehensif: ${selectedSubject}`, allocatedHours: '6 JP', targetMonth: 'Agustus' },
          { id: '2', semester: 'Ganjil', tpCode: 'TP-GEN-02', tpDescription: `Praktik Terapan & Aplikasi nilai Islami ${selectedSubject}`, allocatedHours: '4 JP', targetMonth: 'September' }
        ]
      });

      // Generate Promes
      const elementsPromes = matchingTps.map((tp, idx) => {
        const assignedMonth = targetMonths[idx % targetMonths.length];
        
        // build empty schedule matrix
        const sched: { [m: string]: string[] } = {};
        targetMonths.forEach(m => {
          sched[m] = ['', '', '', '', ''];
        });

        // Set JP inside the targeted week
        if (sched[assignedMonth]) {
          sched[assignedMonth][1] = '4 JP';
          sched[assignedMonth][2] = '2 JP';
        }

        return {
          id: (idx + 1).toString(),
          tpCode: tp.code,
          tpDescription: tp.description.length > 40 ? tp.description.slice(0, 40) + '...' : tp.description,
          allocatedHours: idx % 2 === 0 ? '6 JP' : '4 JP',
          monthlySchedule: sched
        };
      });

      setPromesData({
        id: 'PROMES-' + Math.floor(Math.random() * 90) + 10,
        subjectName: selectedSubject,
        gradeLevel: 'Kelas 4',
        academicYear: '2026/2027',
        semester: 'Ganjil',
        elements: elementsPromes.length > 0 ? elementsPromes : [
          { 
            id: '1', 
            tpCode: 'TP-GEN-01', 
            tpDescription: `Pengantar Komprehensif: ${selectedSubject}`, 
            allocatedHours: '6 JP', 
            monthlySchedule: {
              'Juli': ['', '', '', ''],
              'Agustus': ['4 JP', '2 JP', '', ''],
              'September': ['', '', '', ''],
              'Oktober': ['', '', '', ''],
              'November': ['', '', '', ''],
              'Desember': ['', '', '', '']
            } 
          },
          { 
            id: '2', 
            tpCode: 'TP-GEN-02', 
            tpDescription: `Aplikasi nilai Islami ${selectedSubject}`, 
            allocatedHours: '4 JP', 
            monthlySchedule: {
              'Juli': ['', '', '', ''],
              'Agustus': ['', '', '', ''],
              'September': ['2 JP', '2 JP', '', ''],
              'Oktober': ['', '', '', ''],
              'November': ['', '', '', ''],
              'Desember': ['', '', '', '']
            } 
          }
        ]
      });

      setIsGenerating(false);
    }, 1000);
  };

  const handlePrint = () => {
    const win = window.open('', '_blank');
    if (!win) return;

    if (activeSubTab === 'prota' && protaData) {
      win.document.write(`
        <html>
          <head>
            <title>Program Tahunan (PROTA) - ${protaData.subjectName}</title>
            <style>
              body { font-family: sans-serif; padding: 40px; color: #1e293b; font-size:11px; }
              table { width: 100%; border-collapse: collapse; margin-top:20px; }
              th, td { border: 1px solid #cbd5e1; padding: 8px; text-align: left; }
              th { background-color: #f1f5f9; color: #0f766e; }
              h1 { color: #0f766e; text-align:center; }
            </style>
          </head>
          <body>
            <h1>PROGRAM TAHUNAN (PROTA)</h1>
            <h3 style="text-align:center;">Mata Pelajaran: ${protaData.subjectName} | TA: ${protaData.academicYear}</h3>
            
            <table>
              <thead>
                <tr>
                  <th style="width:10%">Semester</th>
                  <th style="width:12%">Kode TP</th>
                  <th>Uraian Kompetensi / Tujuan Pembelajaran (TP)</th>
                  <th style="width:15%">Alokasi Waktu (JP)</th>
                  <th style="width:15%">Rencana Bulan</th>
                </tr>
              </thead>
              <tbody>
                ${protaData.elements.map(el => `
                  <tr>
                    <td style="font-weight:bold;">${el.semester}</td>
                    <td style="font-family:monospace; font-weight:bold;">${el.tpCode}</td>
                    <td>${el.tpDescription}</td>
                    <td style="font-weight:bold;">${el.allocatedHours}</td>
                    <td>${el.targetMonth}</td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </body>
        </html>
      `);
    } else if (promesData) {
      win.document.write(`
        <html>
          <head>
            <title>Program Semester (PROMES) - Ganjil</title>
            <style>
              body { font-family: sans-serif; padding: 20px; color: #1e293b; font-size:10px; }
              table { width: 100%; border-collapse: collapse; margin-top:15px; }
              th, td { border: 1px solid #cbd5e1; padding: 4px; text-align: center; }
              th { background-color: #f1f5f9; color:#0f766e; font-size:9px;}
              h1 { color: #0f766e; text-align:center; font-size:16px; }
            </style>
          </head>
          <body>
            <h1>PROGRAM SEMESTER (PROMES) SEMESTER GANJIL</h1>
            <h3 style="text-align:center; margin-top:2px;">Mata Pelajaran: ${promesData.subjectName} | TA: ${promesData.academicYear}</h3>
            
            <table>
              <thead>
                <tr>
                  <th rowspan="2" style="width:8%">Kode TP</th>
                  <th rowspan="2" style="width:25%; text-align:left;">Uraian Tujuan Pembelajaran</th>
                  <th rowspan="2" style="width:5%">JP</th>
                  ${MONTHS_GANJIL.map(m => `<th colspan="4">${m}</th>`).join('')}
                </tr>
                <tr>
                  ${MONTHS_GANJIL.map(() => `<th>1</th><th>2</th><th>3</th><th>4</th>`).join('')}
                </tr>
              </thead>
              <tbody>
                ${promesData.elements.map(el => `
                  <tr>
                    <td style="font-family:monospace; font-weight:bold; font-size:8.5px;">${el.tpCode}</td>
                    <td style="text-align:left; font-size:9px;">${el.tpDescription}</td>
                    <td style="font-weight:bold;">${el.allocatedHours}</td>
                    ${MONTHS_GANJIL.map(m => {
                      const weeks = el.monthlySchedule[m] || ['', '', '', ''];
                      return weeks.slice(0, 4).map(w => `<td style="font-weight:bold; background-color:${w ? '#d1fae5' : 'transparent'}">${w || ''}</td>`).join('');
                    }).join('')}
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </body>
        </html>
      `);
    }
    win.document.close();
    win.print();
  };

  return (
    <div className="space-y-4 animate-in fade-in duration-200">
      
      {/* Selector & Generator Header */}
      <div className="bg-white rounded-2xl border border-slate-100 p-4.5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <span className="text-xxxxs font-bold text-slate-400 uppercase tracking-widest">AKTA DISTRIBUSI BULANAN</span>
          <div className="flex bg-slate-100 p-1 rounded-lg border border-slate-200 mt-2">
            <button
              onClick={() => setActiveSubTab('prota')}
              className={`px-3 py-1.5 font-bold text-xxxxs uppercase tracking-wider rounded-md cursor-pointer ${activeSubTab === 'prota' ? 'bg-white text-brand-green-800 shadow-sm' : 'text-slate-500 hover:text-slate-800'}`}
            >
              📖 Program Tahunan (Prota)
            </button>
            <button
              onClick={() => setActiveSubTab('promes')}
              className={`px-3 py-1.5 font-bold text-xxxxs uppercase tracking-wider rounded-md cursor-pointer ${activeSubTab === 'promes' ? 'bg-white text-brand-green-800 shadow-sm' : 'text-slate-500 hover:text-slate-800'}`}
            >
              📊 Program Semester (Promes)
            </button>
          </div>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-center">
          <select
            value={selectedSubject}
            onChange={e => setSelectedSubject(e.target.value)}
            className="text-xxs px-2.5 py-1.5 bg-white border border-slate-200 rounded-lg cursor-pointer font-bold focus:outline-none"
          >
            {subjects.map(s => (
              <option key={s.id} value={s.name}>{s.name}</option>
            ))}
          </select>
          <button
            onClick={handleAutoGenerate}
            disabled={isGenerating}
            className="flex items-center gap-1.5 bg-brand-green-700 hover:bg-brand-green-800 text-white font-bold text-xxxxs px-3 py-2.5 rounded-lg border-0 cursor-pointer shadow-xs"
          >
            {isGenerating ? <RefreshCw className="h-3.5 w-3.5 animate-spin" /> : <Sparkles className="h-3.5 w-3.5 text-brand-gold-300" />}
            Otomatis Generate
          </button>
          <button
            onClick={handlePrint}
            className="flex items-center gap-1 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xxxxs px-3.5 py-2.5 rounded-lg border-0 cursor-pointer"
          >
            <Printer className="h-3.5 w-3.5" />
            Cetak
          </button>
        </div>
      </div>

      {/* --- RENDER 1: PROGRAM TAHUNAN AREA --- */}
      {activeSubTab === 'prota' && protaData && (
        <div className="bg-white border border-slate-100 rounded-2xl p-4.5 space-y-4">
          <div className="flex justify-between items-center bg-slate-50 p-2.5 rounded-lg text-xxs">
            <span className="font-bold text-slate-700">Draf Program Tahunan &bull; TA {protaData.academicYear}</span>
            <span className="font-mono bg-emerald-50 text-emerald-800 px-2 py-0.5 rounded font-extrabold">{protaData.subjectName}</span>
          </div>

          <div className="overflow-hidden border border-slate-100 rounded-xl">
            <table className="w-full text-left text-xxs border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-100 font-bold text-slate-500 uppercase tracking-wider text-xxxxs">
                  <th className="p-3 w-24">Semester</th>
                  <th className="p-3 w-28">Kode TP</th>
                  <th className="p-3">Rencana Uraian Tujuan Pembelajaran (TP)</th>
                  <th className="p-3 w-28">Alokasi JP</th>
                  <th className="p-3 w-32">Sasaran Bulan</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-705 font-medium">
                {protaData.elements.map(el => (
                  <tr key={el.id} className="hover:bg-slate-50/40">
                    <td className="p-3 font-bold text-brand-green-800">{el.semester}</td>
                    <td className="p-3 font-mono text-xxxxs font-bold text-emerald-700">{el.tpCode}</td>
                    <td className="p-3 text-slate-800 font-bold">{el.tpDescription}</td>
                    <td className="p-3 font-extrabold text-blue-600">{el.allocatedHours}</td>
                    <td className="p-3">
                      <span className="bg-brand-gold-50 border border-brand-gold-150 text-brand-gold-800 px-2.5 py-0.5 rounded-md font-bold text-[10px]">
                        {el.targetMonth}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* --- RENDER 2: PROGRAM SEMESTER AREA (MATRIX MATRIX) --- */}
      {activeSubTab === 'promes' && promesData && (
        <div className="bg-white border border-slate-100 rounded-2xl p-4.5 space-y-4 overflow-x-auto">
          <div className="flex justify-between items-center bg-slate-50 p-2.5 rounded-lg text-xxs shrink-0">
            <span className="font-bold text-slate-700">Draf Matriks Program Semester &bull; Semester Ganjil</span>
            <span className="font-mono bg-emerald-50 text-emerald-850 px-2 py-0.5 rounded font-extrabold">{promesData.subjectName}</span>
          </div>

          <table className="w-full text-center border-collapse text-xxs shrink-0" style={{ minWidth: "900px" }}>
            <thead>
              <tr className="bg-slate-50 border-b border-slate-100 font-bold text-slate-600 uppercase text-[10px]">
                <th className="p-2 border border-slate-100 text-left w-24" rowSpan={2}>Kode TP</th>
                <th className="p-2 border border-slate-100 text-left" rowSpan={2}>Pokok Bahasan / Kompetensi TP</th>
                <th className="p-2 border border-slate-100 w-16" rowSpan={2}>Alokasi</th>
                {MONTHS_GANJIL.map(month => (
                  <th key={month} className="p-2 border border-slate-100 text-[10px] font-extrabold bg-slate-100/50 text-brand-green-800" colSpan={4}>
                    {month}
                  </th>
                ))}
              </tr>
              <tr className="bg-slate-50/70 border-b border-slate-200 text-[9px] font-bold text-slate-400">
                {MONTHS_GANJIL.map(month => (
                  <React.Fragment key={month + '-sub'}>
                    <th className="p-1 border border-slate-100">1</th>
                    <th className="p-1 border border-slate-100">2</th>
                    <th className="p-1 border border-slate-100">3</th>
                    <th className="p-1 border border-slate-100">4</th>
                  </React.Fragment>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700 font-medium">
              {promesData.elements.map(el => (
                <tr key={el.id} className="hover:bg-slate-50/40 text-[11px]">
                  <td className="p-2 border border-slate-100 font-mono font-bold text-emerald-700 text-left">{el.tpCode}</td>
                  <td className="p-2 border border-slate-100 font-bold text-left text-slate-900 truncate" style={{ maxWidth: '240px' }} title={el.tpDescription}>
                    {el.tpDescription}
                  </td>
                  <td className="p-2 border border-slate-100 font-extrabold text-blue-600">{el.allocatedHours}</td>
                  
                  {MONTHS_GANJIL.map(month => {
                    const weeks = el.monthlySchedule[month] || ['', '', '', ''];
                    return weeks.slice(0, 4).map((w, wIdx) => (
                      <td 
                        key={`${month}-${wIdx}`} 
                        className={`p-1.5 border border-slate-100 font-bold text-[10px] text-center ${w ? 'bg-emerald-50 text-emerald-800' : ''}`}
                      >
                        {w ? (
                          <span className="bg-emerald-250 text-emerald-900 py-0.5 px-1 rounded block">{w}</span>
                        ) : ''}
                      </td>
                    ));
                  })}
                </tr>
              ))}
            </tbody>
          </table>
          
          <div className="bg-amber-50 rounded-xl border border-amber-100 p-3.5 flex items-start gap-2.5 text-xxxxs mt-3">
            <span className="font-extrabold text-amber-800 uppercase tracking-widest bg-amber-200/50 px-1.5 py-0.5 rounded shrink-0">KETERANGAN:</span>
            <p className="text-amber-700 font-semibold leading-relaxed">
              Matriks di atas menjabarkan minggu aktif KBM per bulan. Jam pelajaran (misal: "4 JP") terdistribusikan otomatis ke pekan-pekan efektif ajar sesuai sinkronisasi Kalender Akademik.
            </p>
          </div>
        </div>
      )}

    </div>
  );
}
