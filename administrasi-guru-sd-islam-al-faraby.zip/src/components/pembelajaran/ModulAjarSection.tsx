/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Plus, Edit, Trash, Download, FileText, Printer, Check, Eye, HelpCircle, Save, Sparkles, FolderSync
} from 'lucide-react';
import { ModulAjarModel, LessonPlan, Subject } from '../../types';

interface ModulAjarSectionProps {
  subjects: Subject[];
  lessonPlans: LessonPlan[];
  onAddLessonPlan: (plan: LessonPlan) => void;
  onDeleteLessonPlan: (id: string) => void;
  onUpdateLessonPlanSync: (id: string, state: boolean) => void;
}

export default function ModulAjarSection({
  subjects,
  lessonPlans,
  onAddLessonPlan,
  onDeleteLessonPlan,
  onUpdateLessonPlanSync
}: ModulAjarSectionProps) {
  const [selectedPlanId, setSelectedPlanId] = useState<string | null>(lessonPlans[0]?.id || null);

  // Edit / Add Form Status
  const [isEditing, setIsEditing] = useState(false);
  const [activeFormTab, setActiveFormTab] = useState<'info' | 'materi' | 'langkah' | 'eval'>('info');

  // Sync state
  const [isSyncing, setIsSyncing] = useState<string | null>(null);

  // Deep 18-in-1 state
  const [editModel, setEditModel] = useState<ModulAjarModel>({
    id: 'MA-01',
    title: 'Keimanan Kepada Sifat-Sifat Allah SWT',
    subjectName: 'Aqidah Akhlak',
    gradeLevel: 'Kelas 4',
    phase: 'Fase B',
    identitas: {
      namaPenyusun: 'Ustadzah Marwah Hasan, S.Pd.I',
      institusi: 'SD Islam Al Faraby Bogor',
      tahunPenyusunan: '2026',
      jenjang: 'SD Islam',
      kelas: 'Kelas IV (Empat)',
      alokasiWaktu: '4 JP (2 x Pertemuan)'
    },
    kompetensiAwal: 'Siswa telah mengetahui rukun iman ke-1 yaitu iman kepada Allah, namun belum mendalami sifat-sifat wajib dan mustahil Allah secara kontekstual.',
    profilPelajarPancasila: 'Beriman, bertakwa kepada Tuhan YME, berakhlak mulia, Mandiri, dan Bernalar Kritis.',
    saranaPrasarana: 'Proyektor multimedia, LCD Screen, Kit Sifat Wajib Allah, Al-Qur\'an Juz Amma, Mushalla Sekolah.',
    targetPesertaDidik: 'Reguler/Tipikal (28 Santri)',
    modelPembelajaran: 'Problem Based Learning (PBL) Terpadu',
    metodePembelajaran: 'Ceramah Interaktif, Games Kartu Sifat, dan Diskusi Kelompok Tadabur Alam.',
    materi: 'Materi pokok meliputi dalil naqli sifat Wajib Allah SWT, klasifikasi sifat Nafsiyah, Salbiyah, Ma\'ani, dan Ma\'nawiyah.',
    tujuanPembelajaran: 'Siswa dapat menguraikan keterkaitan dalil dengan 20 Sifat Wajib Allah SWT secara tepat dan berakhlak berserah diri.',
    pemahamanBermakna: 'Memahami penciptaan alam semesta menguatkan rasa cinta dan ketaatan ibadah kita kepada Sang Pencipta.',
    pertanyaanPemantik: 'Apabila sebuah lukisan yang indah membutuhkan pelukis, bagaimana dengan keteraturan matahari dan bumi kita? Siapa yang mengaturnya?',
    kegiatanPendahuluan: '1. Guru masuk dengan salam Islami, menyapa santri dan memimpin tilawah Al-Fatihah.\n2. Guru memeriksa kehadiran santri rukun kelas.\n3. Guru meluncurkan pre-tes lisan berupa tebak sifat Allah.',
    kegiatanInti: 'Perpustakaan Mini / Pembagian Kelompok:\n1. Santri dibagi menjadi 4 kelompok utama (Nafis, Salibi, Maani, Manawi).\n2. Tiap kelompok memegang kartu sifat mustahil dan mencocokkannya.\n3. Guru membimbing penelaahan dalil naqli QS. Al-Ikhlas.',
    kegiatanPenutup: '1. Santri menyimpulkan bersama hikmah mempelajari Sifat Wajib Allah.\n2. Guru menutup dengan doa kafaratul majelis, salam akhir, serta pembagian tantangan adab rumah.',
    asesmen: 'Asesmen Formatif: Observasi adab berdiskusi kelompok & kuis lisan.\nAsesmen Sumatif: Lembar Kerja Santri (LKS) tertulis.',
    refleksiGuru: 'Apakah alokasi waktu pencarian dalil kelompok sudah pas atau perlu bimbingan individu lebih intensif?',
    refleksiPesertaDidik: 'Bagian apa dari rukun sifat Allah yang paling membekas di hati ananda?',
    lampiran: '1. Glosarium istilah: Nafsiyah, Salbiyah, Jaiz.\n2. Lembar kerja santri mandiri.\n3. Lembar penilaian unjuk kerja kelompok.'
  });

  const activePlan = lessonPlans.find(plan => plan.id === selectedPlanId);

  // Trigger form open for a new Modul Ajar
  const handleOpenCreate = () => {
    const newId = 'MA-' + Math.floor(Math.random() * 900 + 100);
    setEditModel({
      id: newId,
      title: 'Modul Pembelajaran Baru',
      subjectName: 'Al-Qur\'an Hadist',
      gradeLevel: 'Kelas 4',
      phase: 'Fase B',
      identitas: {
        namaPenyusun: 'Ustadz Syamil Baswedan, M.Pd',
        institusi: 'SD Islam Al Faraby Bogor',
        tahunPenyusunan: '2026',
        jenjang: 'SD Islam',
        kelas: 'Kelas IV',
        alokasiWaktu: '2 JP (1 Pertemuan)'
      },
      kompetensiAwal: 'Siswa dasar membaca Iqra tingkat lanjut.',
      profilPelajarPancasila: 'Berakhlak mulia, Mandiri, Kreatif.',
      saranaPrasarana: 'Buku Tajwid Praktis, Al-Qur\'an, Speaker Audio Qur\'an.',
      targetPesertaDidik: 'Reguler (26 Santri)',
      modelPembelajaran: 'Direct Instruction',
      metodePembelajaran: 'Talaqqi dan Tikrar (Pengulangan)',
      materi: 'Pelafalan Tartil Surat Pilihan',
      tujuanPembelajaran: 'Melafalkan dan menghafal surat pendek sasaran.',
      pemahamanBermakna: 'Membaca Kitabullah mengalirkan pahala kebaikan melimpah.',
      pertanyaanPemantik: 'Mengapa surat dihafal harus ditashih (diverifikasi) makhrajalnya terlebih dahulu?',
      kegiatanPendahuluan: 'Doa pembuka, motivasi keutamaan hafal Quran hafizh.',
      kegiatanInti: 'Guru membacakan ayat per ayat, murid menirukan secara serempak lalu menyetor hafalan individual.',
      kegiatanPenutup: 'Pesan moral menjaga hafalan (muraja\'ah), doa penutup.',
      asesmen: 'Tes unjuk kerja setoran talaqqi tajwid makhraj.',
      refleksiGuru: 'Berapa persen siswa yang mencapai kelancaran target?',
      refleksiPesertaDidik: 'Apakah surat ajar di atas terasa mudah dihafalkan?',
      lampiran: 'Rubrik skor penilaian tajwid.'
    });
    setIsEditing(true);
  };

  const handleEditSelect = () => {
    if (activePlan) {
      // populate from current lesson plan Markdown text or pre-seed
      setEditModel({
        ...editModel,
        id: activePlan.id,
        title: activePlan.title,
        subjectName: activePlan.subject,
        gradeLevel: activePlan.grade,
        tujuanPembelajaran: activePlan.topic || 'Siswa menguasai materi terpadu',
        identitas: {
          ...editModel.identitas,
          alokasiWaktu: activePlan.duration,
          kelas: activePlan.grade
        },
        materi: activePlan.content?.substring(0, 500) || '',
        kompetensiAwal: activePlan.topic || '',
        lampiran: activePlan.islamicIntegration || ''
      });
    }
    setIsEditing(true);
  };

  const handleSaveModel = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Create equivalent LessonPlan node to update app state
    const newLessonPlan: LessonPlan = {
      id: editModel.id,
      title: editModel.title,
      subject: editModel.subjectName,
      grade: editModel.gradeLevel,
      topic: editModel.tujuanPembelajaran,
      duration: editModel.identitas.alokasiWaktu,
      content: `### MODUL AJAR KURIKULUM MERDEKA\n\n#### I. IDENTITAS\n* Nama: ${editModel.identitas.namaPenyusun}\n* Institusi: ${editModel.identitas.institusi}\n* Waktu: ${editModel.identitas.alokasiWaktu}\n\n#### II. METODE AJAR\n* Kompetensi Awal: ${editModel.kompetensiAwal}\n* Model: ${editModel.modelPembelajaran}\n\n#### III. LANGKAH AJAR\n* Pendahuluan: ${editModel.kegiatanPendahuluan}\n* Inti: ${editModel.kegiatanInti}\n* Penutup: ${editModel.kegiatanPenutup}\n\n#### IV. ASESMEN\n* Asesmen: ${editModel.asesmen}`,
      islamicIntegration: editModel.profilPelajarPancasila + " | " + editModel.pemahamanBermakna,
      createdAt: new Date().toLocaleDateString('id-ID'),
      syncedToDocs: false
    };

    onAddLessonPlan(newLessonPlan);
    setSelectedPlanId(editModel.id);
    setIsEditing(false);
  };

  // Export as Word Document (simulated raw downloadable HTML output wrapping compatible with MS Word)
  const handleWordExport = () => {
    const rawHTML = `
      <html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns="http://www.w3.org/TR/REC-html40">
        <head>
          <title>${editModel.title}</title>
          <style>
            body { font-family: Arial, sans-serif; padding: 2in; line-height: 1.5; }
            h1 { text-align: center; color: #1e3a8a; }
            h2 { color: #0d9488; border-bottom: 1px solid #ddd; margin-top: 20px; }
            .meta-table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
            .meta-table td { border: 1px solid #cbd5e1; padding: 6px; }
          </style>
        </head>
        <body>
          <h1>MODUL AJAR KURIKULUM MERDEKA 18 KOMPONEN</h1>
          <p style="text-align: center; font-weight: bold; font-size: 14pt;">${editModel.title}</p>
          
          <h2>1. IDENTITAS MODUL</h2>
          <table class="meta-table">
            <tr><td>Nama Penyusun</td><td>${editModel.identitas.namaPenyusun}</td></tr>
            <tr><td>Institusi</td><td>${editModel.identitas.institusi}</td></tr>
            <tr><td>Tahun / Jenjang</td><td>${editModel.identitas.tahunPenyusunan} / ${editModel.identitas.jenjang}</td></tr>
            <tr><td>Alokasi Waktu</td><td>${editModel.identitas.alokasiWaktu}</td></tr>
          </table>

          <h2>2. KOMPETENSI AWAL</h2>
          <p>${editModel.kompetensiAwal}</p>

          <h2>3. PROFIL PELAJAR PANCASILA</h2>
          <p>${editModel.profilPelajarPancasila}</p>

          <h2>4. SARANA & PRASARANA GENERAL</h2>
          <p>${editModel.saranaPrasarana}</p>

          <h2>5. TARGET PESERTA DIDIK</h2>
          <p>${editModel.targetPesertaDidik}</p>

          <h2>6. MODEL PEMBELAJARAN</h2>
          <p>${editModel.modelPembelajaran}</p>

          <h2>7. METODE PEMBELAJARAN INDIVIDUAL</h2>
          <p>${editModel.metodePembelajaran}</p>

          <h2>8. UTAMA MATERI AJAR PENDUKUNG</h2>
          <p>${editModel.materi}</p>

          <h2>9. TUJUAN PEMBELAJARAN DETAIL</h2>
          <p>${editModel.tujuanPembelajaran}</p>

          <h2>10. PEMAHAMAN BERMAKNA (SPIRITUAL)</h2>
          <p>${editModel.pemahamanBermakna}</p>

          <h2>11. PERTANYAAN PEMANTIK UTAMA</h2>
          <p>${editModel.pertanyaanPemantik}</p>

          <h2>12. KEGIATAN PENDAHULUAN (APRESIASI)</h2>
          <p style="white-space: pre-line;">${editModel.kegiatanPendahuluan}</p>

          <h2>13. KEGIATAN INTI PEMBELAJARAN AKTIF</h2>
          <p style="white-space: pre-line;">${editModel.kegiatanInti}</p>

          <h2>14. KEGIATAN PENUTUP & SIMPULAN</h2>
          <p style="white-space: pre-line;">${editModel.kegiatanPenutup}</p>

          <h2>15. ASESMEN & EVALUASI SIKAP/KOGNITIF</h2>
          <p>${editModel.asesmen}</p>

          <h2>16. REFLEKSI GURU PEMBIMBING</h2>
          <p>${editModel.refleksiGuru}</p>

          <h2>17. REFLEKSI PESERTA DIDIK (SANTRI)</h2>
          <p>${editModel.refleksiPesertaDidik}</p>

          <h2>18. LAMPIRAN LKPD, GLOSARIUM, BAHAN BACAAN</h2>
          <p style="white-space: pre-line;">${editModel.lampiran}</p>
        </body>
      </html>
    `;

    const blob = new Blob(['\ufeff' + rawHTML], { type: 'application/msword' });
    const url = URL.createObjectURL(blob);
    const downloadLink = document.createElement('a');
    downloadLink.href = url;
    downloadLink.download = `${editModel.title.replace(/\s+/g, "_")}_Modul_Ajar.doc`;
    document.body.appendChild(downloadLink);
    downloadLink.click();
    document.body.removeChild(downloadLink);
  };

  // Google Docs synchronization process simulator
  const handleGoogleDocsSync = (id: string) => {
    setIsSyncing(id);
    setTimeout(() => {
      onUpdateLessonPlanSync(id, true);
      setIsSyncing(null);
    }, 1500);
  };

  const handlePrint = () => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;

    printWindow.document.write(`
      <html>
        <head>
          <title>${editModel.title} - PDF Print</title>
          <style>
            body { font-family: 'Inter', sans-serif; padding: 40px; font-size: 11px; line-height: 1.6; color:#1e293b; }
            h1 { text-align: center; color: #0f766e; font-size:18px; margin-bottom: 20px; text-transform:uppercase; border-bottom: 4px solid #0f766e; padding-bottom:10px; }
            h3 { color: #059669; font-size: 12px; margin-top:25px; border-left: 3px solid #059669; padding-left: 8px; }
            table { width:100%; border-collapse:collapse; margin-top:10px; }
            td { border:1px solid #e2e8f0; padding:8px; vertical-align:top; }
            .val-col { font-weight:bold; }
          </style>
        </head>
        <body>
          <h1>MODUL AJAR KURIKULUM MERDEKA - MASTER FILE</h1>
          <h2 style="text-align:center; color:#475569;">Topik Bahasan: ${editModel.title}</h2>

          <h3>I. INDENTITAS UMUM & AKADEMIK</h3>
          <table>
            <tr><td style="width:25%">Nama Penyusun</td><td class="val-col">${editModel.identitas.namaPenyusun}</td></tr>
            <tr><td>Lembaga / Institusi</td><td class="val-col">${editModel.identitas.institusi}</td></tr>
            <tr><td>Jenjang / Kelas</td><td class="val-col">${editModel.identitas.jenjang} / ${editModel.identitas.kelas}</td></tr>
            <tr><td>Tahun / Alokasi Waktu</td><td class="val-col">${editModel.identitas.tahunPenyusunan} / ${editModel.identitas.alokasiWaktu}</td></tr>
          </table>

          <h3>II. KOMPETENSI AWAL & PROFIL</h3>
          <p><strong>Kompetensi Awal:</strong> ${editModel.kompetensiAwal}</p>
          <p><strong>Profil Pelajar Pancasila:</strong> ${editModel.profilPelajarPancasila}</p>

          <h3>III. SARANA PRASARANA & TARGET SISWA</h3>
          <p><strong>Fasilitas / Sarpras:</strong> ${editModel.saranaPrasarana}</p>
          <p><strong>Target Siswa:</strong> ${editModel.targetPesertaDidik}</p>

          <h3>IV. STRATEGI PEMBELAJARAN</h3>
          <p><strong>Model:</strong> ${editModel.modelPembelajaran} | <strong>Metode:</strong> ${editModel.metodePembelajaran}</p>
          <p><strong>Pokok Pembahasan Materi:</strong> ${editModel.materi}</p>

          <h3>V. TUJUAN & PERTANYAAN PEMANTIK</h3>
          <p><strong>Tujuan Ajar:</strong> ${editModel.tujuanPembelajaran}</p>
          <p><strong>Pemahaman Bermakna:</strong> ${editModel.pemahamanBermakna}</p>
          <p><strong>Pemantik Pikir:</strong> ${editModel.pertanyaanPemantik}</p>

          <h3>VI. MEKANISME KEGIATAN LENGKAP</h3>
          <p><strong>A. Pendahuluan:</strong><br/>${editModel.kegiatanPendahuluan.replace(/\n/g, '<br/>')}</p>
          <p><strong>B. Kegiatan Inti:</strong><br/>${editModel.kegiatanInti.replace(/\n/g, '<br/>')}</p>
          <p><strong>C. Penutup-Simpulan:</strong><br/>${editModel.kegiatanPenutup.replace(/\n/g, '<br/>')}</p>

          <h3>VII. EVALUASI DAN LAMPIRAN AKHIR</h3>
          <p><strong>Model Asesmen:</strong> ${editModel.asesmen}</p>
          <p><strong>Refleksi Guru:</strong> ${editModel.refleksiGuru}</p>
          <p><strong>Refleksi Siswa:</strong> ${editModel.refleksiPesertaDidik}</p>
          <p><strong>Lampiran LKPD/Glosarium:</strong><br/>${editModel.lampiran.replace(/\n/g, '<br/>')}</p>

          <div style="margin-top:50px; text-align:right;">
            <p>Disetujui Oleh,</p>
            <p style="font-weight:bold; margin-top:40px;">Kepala Sekolah SD Islam Al Faraby</p>
          </div>
        </body>
      </html>
    `);
    printWindow.document.close();
    printWindow.print();
  };

  return (
    <div className="space-y-4 animate-in fade-in duration-200">
      
      {!isEditing ? (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Sidebar: Modul List Menu */}
          <div className="bg-white border border-slate-100 rounded-2xl p-4.5 space-y-4.5">
            <div className="flex justify-between items-center">
              <h4 className="text-xxs font-bold text-slate-500 uppercase tracking-widest">Draf Modul Kurikulum (KTSP)</h4>
              <button
                onClick={handleOpenCreate}
                className="flex items-center gap-1.5 bg-brand-green-700 hover:bg-brand-green-800 text-white font-bold text-xxxxs px-2.5 py-1.5 rounded-lg cursor-pointer transition border-0 block"
              >
                <Plus className="h-3 w-3" />
                Buat Modul
              </button>
            </div>

            <div className="space-y-2 max-h-96 overflow-y-auto pr-1">
              {lessonPlans.map(plan => {
                const isSelected = plan.id === selectedPlanId;
                return (
                  <div
                    key={plan.id}
                    onClick={() => setSelectedPlanId(plan.id)}
                    className={`p-3 rounded-xl border text-left cursor-pointer transition flex items-center justify-between ${
                      isSelected 
                        ? 'bg-emerald-50/55 border-emerald-400 shadow-xs' 
                        : 'border-slate-100 hover:bg-slate-50'
                    }`}
                  >
                    <div className="min-w-0 pr-2">
                      <div className="flex items-center gap-1.5 text-[10px]">
                        <span className="bg-emerald-100 text-emerald-800 px-1.5 rounded font-bold">{plan.subject}</span>
                        <span className="text-slate-400 font-bold">{plan.grade}</span>
                      </div>
                      <h5 className="text-xxs font-extrabold text-slate-800 truncate mt-1.5">{plan.title}</h5>
                      <span className="text-[10px] text-slate-400 block mt-1">{plan.createdAt || 'Penyusunan Baru'}</span>
                    </div>

                    <div className="flex flex-col items-end gap-1.5 shrink-0">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          if(confirm('Hapus draf Modul Ajar ini dari database?')) {
                            onDeleteLessonPlan(plan.id);
                          }
                        }}
                        className="text-slate-350 hover:text-rose-600 transition p-1 hover:bg-slate-100/10 rounded"
                      >
                        <Trash className="h-3 w-3" />
                      </button>
                      
                      {plan.syncedToDocs ? (
                        <span className="text-[9px] bg-sky-50 text-sky-700 font-extrabold px-1 py-0.5 rounded flex items-center gap-0.5">
                          Synced
                        </span>
                      ) : (
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleGoogleDocsSync(plan.id);
                          }}
                          disabled={isSyncing === plan.id}
                          className="text-[9px] bg-slate-100 hover:bg-emerald-50 text-slate-500 hover:text-emerald-700 font-extrabold px-1.5 py-0.5 rounded transition cursor-pointer"
                        >
                          {isSyncing === plan.id ? '...' : 'Sync GDoc'}
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Right Area: Dynamic 18-in-1 Preview Cards */}
          <div className="lg:col-span-2 bg-white border border-slate-100 rounded-2xl p-5 space-y-4">
            {activePlan ? (
              <div className="space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-3">
                  <div>
                    <h3 className="text-xs font-bold text-slate-800 leading-tight flex items-center gap-1.5">
                      <FileText className="h-4.5 w-4.5 text-brand-green-700" />
                      {activePlan.title}
                    </h3>
                    <p className="text-xxxxs text-slate-400 font-semibold mt-0.5">Target: {activePlan.grade} - Mapel {activePlan.subject} / Alokasi {activePlan.duration}</p>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={handleWordExport}
                      className="flex items-center gap-1 border border-slate-200 bg-white hover:bg-slate-50 text-slate-600 font-bold text-xxxxs px-3 py-2 rounded-lg cursor-pointer"
                    >
                      <Download className="h-3 w-3 text-slate-400" />
                      Ekspor Word (.doc)
                    </button>
                    <button
                      onClick={handlePrint}
                      className="flex items-center gap-1 border border-slate-200 bg-white hover:bg-slate-50 text-slate-600 font-bold text-xxxxs px-3 py-2 rounded-lg cursor-pointer"
                    >
                      <Printer className="h-3 w-3 text-slate-400" />
                      Cetak PDF
                    </button>
                    <button
                      onClick={handleEditSelect}
                      className="flex items-center gap-1.5 bg-brand-green-700 hover:bg-brand-green-800 text-white font-bold text-xxxxs px-3.5 py-2 rounded-lg cursor-pointer shadow-xs border-0"
                    >
                      <Edit className="h-3.5 w-3.5" />
                      Edit 18 Elemen
                    </button>
                  </div>
                </div>

                {/* 18-In-1 Styled Showcase */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xxxxs">
                  {/* Item 1: Identitas */}
                  <div className="border border-slate-100 rounded-xl p-3 bg-slate-50/50 space-y-2">
                    <span className="font-bold text-slate-400 uppercase tracking-widest block">1. Identitas Penyusun</span>
                    <div className="text-xxs text-slate-600 font-semibold space-y-1">
                      <div>Guru: <span className="text-slate-800 font-bold">{editModel.identitas.namaPenyusun}</span></div>
                      <div>Institusi: {editModel.identitas.institusi}</div>
                      <div>Tahun: {editModel.identitas.tahunPenyusunan}</div>
                      <div>Sasaran: {editModel.identitas.kelas}</div>
                    </div>
                  </div>

                  {/* Item 2: Kompetensi Awal */}
                  <div className="border border-slate-100 rounded-xl p-3 bg-slate-50/50 space-y-1">
                    <span className="font-bold text-slate-400 uppercase tracking-widest block">2. Kompetensi Awal Murid</span>
                    <p className="text-xxs text-slate-700 font-semibold italic">"{editModel.kompetensiAwal}"</p>
                  </div>

                  {/* Item 3: Profil Pancasila */}
                  <div className="border border-slate-100 rounded-xl p-3 bg-slate-50/50 space-y-1">
                    <span className="font-bold text-slate-400 uppercase tracking-widest block">3. Profil Pelajar Pancasila</span>
                    <p className="text-xxs text-slate-700 font-semibold">{editModel.profilPelajarPancasila}</p>
                  </div>

                  {/* Item 4: Sarana Prasarana */}
                  <div className="border border-slate-100 rounded-xl p-3 bg-slate-50/50 space-y-1">
                    <span className="font-bold text-slate-400 uppercase tracking-widest block">4. Sarana dan Prasarana (Sarpras)</span>
                    <p className="text-xxs text-slate-700 font-semibold">{editModel.saranaPrasarana}</p>
                  </div>

                  {/* Item 5: Target Peserta Didik */}
                  <div className="border border-slate-100 rounded-xl p-3 bg-slate-50/50 space-y-1">
                    <span className="font-bold text-slate-400 uppercase tracking-widest block">5. Target Peserta Didik</span>
                    <p className="text-xxs text-slate-700 font-semibold">{editModel.targetPesertaDidik}</p>
                  </div>

                  {/* Item 6 & 7: Model & Metode */}
                  <div className="border border-slate-100 rounded-xl p-3 bg-slate-50/50 space-y-1">
                    <span className="font-bold text-slate-400 uppercase tracking-widest block">6 & 7. Model & Metode Ajar</span>
                    <p className="text-xxs text-slate-700 font-medium">
                      <strong>Model:</strong> {editModel.modelPembelajaran}<br/>
                      <strong>Metode:</strong> {editModel.metodePembelajaran}
                    </p>
                  </div>

                  {/* Item 8 & 9: Materi & TP */}
                  <div className="border border-slate-100 rounded-xl p-3 bg-emerald-50/20 md:col-span-2 space-y-1">
                    <span className="font-bold text-emerald-800 uppercase tracking-widest block">8 & 9. Materi Pokok & Tujuan Pembelajaran</span>
                    <p className="text-xxs text-slate-800 font-bold">{editModel.tujuanPembelajaran}</p>
                    <p className="text-xxs text-slate-600 font-medium italic mt-1">"{editModel.materi}"</p>
                  </div>

                  {/* Item 10 & 11: Pemahaman Bermakna & Pemantik */}
                  <div className="border border-slate-100 rounded-xl p-3 bg-brand-gold-50/15 md:col-span-2 space-y-1">
                    <span className="font-bold text-brand-gold-800 uppercase tracking-widest block">10 & 11. Kebenaran Bermakna & Pertanyaan Pemantik</span>
                    <p className="text-xxs text-slate-700 font-semibold">Bermakna: {editModel.pemahamanBermakna}</p>
                    <p className="text-xxs text-brand-green-800 font-bold mt-1">💡 Tanya Pemantik: '{editModel.pertanyaanPemantik}'</p>
                  </div>

                  {/* Item 12, 13, 14: Langkah Kegiatan */}
                  <div className="border border-slate-100 rounded-xl p-3.5 md:col-span-2 space-y-2">
                    <span className="font-bold text-slate-400 uppercase tracking-widest block">12, 13, 14. Detail Aktivitas Langkah Pembelajaran</span>
                    <div className="space-y-2 text-xxs text-slate-700">
                      <div><strong className="text-emerald-700">A. Pendahuluan:</strong><p className="whitespace-pre-line text-slate-600">{editModel.kegiatanPendahuluan}</p></div>
                      <div><strong className="text-brand-green-800">B. Kegiatan Inti:</strong><p className="whitespace-pre-line text-slate-600 font-medium">{editModel.kegiatanInti}</p></div>
                      <div><strong className="text-brand-gold-700">C. Penutup:</strong><p className="whitespace-pre-line text-slate-600">{editModel.kegiatanPenutup}</p></div>
                    </div>
                  </div>

                  {/* Item 15, 16, 17, 18: Asesmen, Refleksi, Lampiran */}
                  <div className="border border-slate-100 rounded-xl p-3.5 md:col-span-2 bg-slate-50/20 space-y-3">
                    <span className="font-bold text-slate-400 uppercase tracking-widest block">15 s.d 18. Evaluasi & Lampiran Pendukung</span>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xxs text-slate-700 font-medium">
                      <div>
                        <strong>15. Asesmen Penilaian:</strong>
                        <p className="text-slate-600 leading-normal mt-0.5">{editModel.asesmen}</p>
                      </div>
                      <div>
                        <strong>16. Refleksi Guru:</strong>
                        <p className="text-slate-600 leading-normal mt-0.5">{editModel.refleksiGuru}</p>
                      </div>
                      <div>
                        <strong>17. Refleksi Murid:</strong>
                        <p className="text-slate-600 leading-normal mt-0.5">{editModel.refleksiPesertaDidik}</p>
                      </div>
                      <div>
                        <strong>18. Lampiran Pendukung / LKPD:</strong>
                        <p className="text-slate-600 leading-normal mt-0.5 whitespace-pre-line">{editModel.lampiran}</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-center text-slate-400 italic py-16 text-xxs">
                Silakan buat atau pilih draf modul ajar di menu samping untuk menelaah isian 18 elemen kurikulum merdeka.
              </div>
            )}
          </div>
        </div>
      ) : (
        /* --- 18 ELEMEN COMPREHENSIVE EDITOR FORM --- */
        <form onSubmit={handleSaveModel} className="bg-white rounded-2xl border border-slate-100 overflow-hidden text-xxs animate-in zoom-in-95">
          <div className="bg-brand-green-700 p-4.5 text-white flex justify-between items-center">
            <div>
              <h4 className="font-bold text-xs">Penulisan Sempurna Modul Ajar Kurikulum Merdeka (18 Elemen)</h4>
              <p className="text-xxxxs text-emerald-100 opacity-90 leading-none mt-1">Setiap rincian yang disimpan akan otomatis tersinkron ke draf RPP.</p>
            </div>
            <button
              type="button"
              onClick={() => setIsEditing(false)}
              className="font-bold bg-brand-green-800 text-emerald-100 px-3 py-1.5 rounded-lg border-0 cursor-pointer"
            >
              Kembali
            </button>
          </div>

          {/* Form Tabs */}
          <div className="flex border-b border-slate-100 bg-slate-50 text-xxs overflow-x-auto">
            <button
              type="button"
              onClick={() => setActiveFormTab('info')}
              className={`px-4.5 py-3 font-bold border-b-2 text-xxxxs uppercase tracking-wider cursor-pointer ${activeFormTab === 'info' ? 'border-brand-green-700 text-brand-green-800 font-extrabold' : 'border-transparent text-slate-450 hover:text-slate-600'}`}
            >
              Part A: Info & Sarpras (1-7)
            </button>
            <button
              type="button"
              onClick={() => setActiveFormTab('materi')}
              className={`px-4.5 py-3 font-bold border-b-2 text-xxxxs uppercase tracking-wider cursor-pointer ${activeFormTab === 'materi' ? 'border-brand-green-700 text-brand-green-800 font-extrabold' : 'border-transparent text-slate-450 hover:text-slate-600'}`}
            >
              Part B: Materi & Pemuji (8-11)
            </button>
            <button
              type="button"
              onClick={() => setActiveFormTab('langkah')}
              className={`px-4.5 py-3 font-bold border-b-2 text-xxxxs uppercase tracking-wider cursor-pointer ${activeFormTab === 'langkah' ? 'border-brand-green-700 text-brand-green-800 font-extrabold' : 'border-transparent text-slate-450 hover:text-slate-600'}`}
            >
              Part C: Skenario Urut (12-14)
            </button>
            <button
              type="button"
              onClick={() => setActiveFormTab('eval')}
              className={`px-4.5 py-3 font-bold border-b-2 text-xxxxs uppercase tracking-wider cursor-pointer ${activeFormTab === 'eval' ? 'border-brand-green-700 text-brand-green-800 font-extrabold' : 'border-transparent text-slate-450 hover:text-slate-600'}`}
            >
              Part D: Asesmen & Refleksi (15-18)
            </button>
          </div>

          <div className="p-5 space-y-4 max-h-[480px] overflow-y-auto">
            
            {activeFormTab === 'info' && (
              <div className="space-y-4 animate-in fade-in duration-100">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block font-bold text-slate-500 uppercase">Nama Dokumen Modul</label>
                    <input
                      type="text"
                      className="w-full mt-1 border border-slate-200 p-2.5 rounded-lg focus:outline-none"
                      value={editModel.title}
                      onChange={e => setEditModel({...editModel, title: e.target.value})}
                    />
                  </div>
                  <div>
                    <label className="block font-bold text-slate-500 uppercase">Penyusun (Ustadz/ah)</label>
                    <input
                      type="text"
                      className="w-full mt-1 border border-slate-200 p-2.5 rounded-lg focus:outline-none"
                      value={editModel.identitas.namaPenyusun}
                      onChange={e => setEditModel({...editModel, identitas: {...editModel.identitas, namaPenyusun: e.target.value}})}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  <div>
                    <label className="block font-bold text-slate-500 uppercase">Institusi</label>
                    <input
                      type="text"
                      className="w-full mt-1 border border-slate-200 p-2.5 rounded-lg text-slate-600"
                      value={editModel.identitas.institusi}
                      onChange={e => setEditModel({...editModel, identitas: {...editModel.identitas, institusi: e.target.value}})}
                    />
                  </div>
                  <div>
                    <label className="block font-bold text-slate-500 uppercase">Tahun</label>
                    <input
                      type="text"
                      className="w-full mt-1 border border-slate-200 p-2.5 rounded-lg focus:outline-none"
                      value={editModel.identitas.tahunPenyusunan}
                      onChange={e => setEditModel({...editModel, identitas: {...editModel.identitas, tahunPenyusunan: e.target.value}})}
                    />
                  </div>
                  <div>
                    <label className="block font-bold text-slate-500 uppercase">Alokasi Waktu (JP)</label>
                    <input
                      type="text"
                      className="w-full mt-1 border border-slate-200 p-2.5 rounded-lg focus:outline-none"
                      value={editModel.identitas.alokasiWaktu}
                      onChange={e => setEditModel({...editModel, identitas: {...editModel.identitas, alokasiWaktu: e.target.value}})}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div>
                    <label className="block font-bold text-slate-500 uppercase">2. Kompetensi Awal Murid</label>
                    <textarea
                      rows={2}
                      className="w-full mt-1 border border-slate-200 p-2.5 rounded-lg focus:outline-none"
                      value={editModel.kompetensiAwal}
                      onChange={e => setEditModel({...editModel, kompetensiAwal: e.target.value})}
                    />
                  </div>
                  <div>
                    <label className="block font-bold text-slate-500 uppercase">3. Profil Pelajar Pancasila (+Rahmatan Lil Alamin)</label>
                    <textarea
                      rows={2}
                      className="w-full mt-1 border border-slate-200 p-2.5 rounded-lg focus:outline-none"
                      value={editModel.profilPelajarPancasila}
                      onChange={e => setEditModel({...editModel, profilPelajarPancasila: e.target.value})}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xxs">
                  <div>
                    <label className="block font-bold text-slate-500 uppercase">4. Sarana dan Prasarana (Sarpras)</label>
                    <input
                      type="text"
                      className="w-full mt-1 border border-slate-200 p-2.5 rounded-lg focus:outline-none"
                      value={editModel.saranaPrasarana}
                      onChange={e => setEditModel({...editModel, saranaPrasarana: e.target.value})}
                    />
                  </div>
                  <div>
                    <label className="block font-bold text-slate-500 uppercase">5. Target Peserta Didik</label>
                    <input
                      type="text"
                      className="w-full mt-1 border border-slate-200 p-2.5 rounded-lg focus:outline-none"
                      value={editModel.targetPesertaDidik}
                      onChange={e => setEditModel({...editModel, targetPesertaDidik: e.target.value})}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div>
                    <label className="block font-bold text-slate-500 uppercase">6. Model Pembelajaran</label>
                    <input
                      type="text"
                      className="w-full mt-1 border border-slate-200 p-2.5 rounded-lg focus:outline-none"
                      value={editModel.modelPembelajaran}
                      onChange={e => setEditModel({...editModel, modelPembelajaran: e.target.value})}
                    />
                  </div>
                  <div>
                    <label className="block font-bold text-slate-500 uppercase">7. Metode Pembelajaran</label>
                    <input
                      type="text"
                      className="w-full mt-1 border border-slate-200 p-2.5 rounded-lg focus:outline-none"
                      value={editModel.metodePembelajaran}
                      onChange={e => setEditModel({...editModel, metodePembelajaran: e.target.value})}
                    />
                  </div>
                </div>
              </div>
            )}

            {activeFormTab === 'materi' && (
              <div className="space-y-4 animate-in fade-in duration-100">
                <div>
                  <label className="block font-bold text-slate-500 uppercase">8. Ruang Lingkup Materi Pokok</label>
                  <textarea
                    rows={3}
                    className="w-full mt-1 border border-slate-200 p-2.5 rounded-lg focus:outline-none"
                    value={editModel.materi}
                    onChange={e => setEditModel({...editModel, materi: e.target.value})}
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-500 uppercase">9. Tujuan Pembelajaran (TP) Spesifik</label>
                  <textarea
                    rows={3}
                    className="w-full mt-1 border border-slate-200 p-2.5 rounded-lg focus:outline-none"
                    value={editModel.tujuanPembelajaran}
                    onChange={e => setEditModel({...editModel, tujuanPembelajaran: e.target.value})}
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-500 uppercase">10. Pemahaman Bermakna</label>
                  <input
                    type="text"
                    className="w-full mt-1 border border-slate-200 p-2.5 rounded-lg focus:outline-none"
                    value={editModel.pemahamanBermakna}
                    onChange={e => setEditModel({...editModel, pemahamanBermakna: e.target.value})}
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-500 uppercase">11. Pertanyaan Pemantik</label>
                  <input
                    type="text"
                    className="w-full mt-1 border border-slate-200 p-2.5 rounded-lg focus:outline-none"
                    value={editModel.pertanyaanPemantik}
                    onChange={e => setEditModel({...editModel, pertanyaanPemantik: e.target.value})}
                  />
                </div>
              </div>
            )}

            {activeFormTab === 'langkah' && (
              <div className="space-y-4 animate-in fade-in duration-100">
                <div>
                  <label className="block font-bold text-slate-500 uppercase">12. Kegiatan Pendahuluan (Sapaan & Apersepsi)</label>
                  <textarea
                    rows={3}
                    className="w-full mt-1 border border-slate-200 p-2.5 rounded-lg focus:outline-none font-sans"
                    value={editModel.kegiatanPendahuluan}
                    onChange={e => setEditModel({...editModel, kegiatanPendahuluan: e.target.value})}
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-500 uppercase">13. Kegiatan Inti Pembelajaran (Langkah PBL/Talaqqi)</label>
                  <textarea
                    rows={5}
                    className="w-full mt-1 border border-slate-200 p-2.5 rounded-lg focus:outline-none font-sans"
                    value={editModel.kegiatanInti}
                    onChange={e => setEditModel({...editModel, kegiatanInti: e.target.value})}
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-500 uppercase">14. Kegiatan Penutup (Umpan Balik & Doa)</label>
                  <textarea
                    rows={3}
                    className="w-full mt-1 border border-slate-200 p-2.5 rounded-lg focus:outline-none font-sans"
                    value={editModel.kegiatanPenutup}
                    onChange={e => setEditModel({...editModel, kegiatanPenutup: e.target.value})}
                  />
                </div>
              </div>
            )}

            {activeFormTab === 'eval' && (
              <div className="space-y-4 animate-in fade-in duration-100">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block font-bold text-slate-500 uppercase">15. Model Asesmen Penjurusan</label>
                    <textarea
                      rows={3}
                      className="w-full mt-1 border border-slate-200 p-2.5 rounded-lg focus:outline-none"
                      value={editModel.asesmen}
                      onChange={e => setEditModel({...editModel, asesmen: e.target.value})}
                    />
                  </div>
                  <div>
                    <label className="block font-bold text-slate-500 uppercase">16. Refleksi Guru Binaan</label>
                    <textarea
                      rows={3}
                      className="w-full mt-1 border border-slate-200 p-2.5 rounded-lg focus:outline-none"
                      value={editModel.refleksiGuru}
                      onChange={e => setEditModel({...editModel, refleksiGuru: e.target.value})}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block font-bold text-slate-500 uppercase">17. Refleksi Peserta Didik (Santri)</label>
                    <textarea
                      rows={3}
                      className="w-full mt-1 border border-slate-200 p-2.5 rounded-lg focus:outline-none"
                      value={editModel.refleksiPesertaDidik}
                      onChange={e => setEditModel({...editModel, refleksiPesertaDidik: e.target.value})}
                    />
                  </div>
                  <div>
                    <label className="block font-bold text-slate-500 uppercase">18. Lampiran (Glosarium, LKPD Mandiri)</label>
                    <textarea
                      rows={3}
                      className="w-full mt-1 border border-slate-200 p-2.5 rounded-lg focus:outline-none"
                      value={editModel.lampiran}
                      onChange={e => setEditModel({...editModel, lampiran: e.target.value})}
                    />
                  </div>
                </div>
              </div>
            )}

          </div>

          <div className="flex justify-end gap-2 p-4.5 bg-slate-50 border-t border-slate-100">
            <button
              type="button"
              onClick={() => setIsEditing(false)}
              className="px-4 py-2 font-bold text-slate-500 hover:bg-slate-200 rounded-lg cursor-pointer"
            >
              Batal
            </button>
            <button
              type="submit"
              className="flex items-center gap-1 bg-brand-green-700 hover:bg-brand-green-800 text-white font-bold px-5 py-2 rounded-lg cursor-pointer transition shadow-xs border-0"
            >
              <Save className="h-3.5 w-3.5" />
              Simpan 18 Elemen Modul
            </button>
          </div>
        </form>
      )}

    </div>
  );
}
