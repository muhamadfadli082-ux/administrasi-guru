/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  CalendarDays, Plus, RefreshCw, CheckCircle, Trash2, Calendar, LayoutGrid, ListTodo, HelpCircle, X
} from 'lucide-react';
import { GoogleCalendarEvent } from '../../types';

export default function KalenderPendidikanSection() {
  const [events, setEvents] = useState<GoogleCalendarEvent[]>([
    { id: '1', title: 'Hari Pertama Masuk Sekolah TA 2026/2027', startDate: '2026-07-13', endDate: '2026-07-13', type: 'Akademik', color: 'emerald' },
    { id: '2', title: 'Masa Taaruf Santri Baru (MATSAMA)', startDate: '2026-07-14', endDate: '2026-07-16', type: 'Akademik', color: 'emerald' },
    { id: '3', title: 'Tahun Baru Hijriah 1448 H', startDate: '2026-08-01', endDate: '2026-08-01', type: 'Keagamaan', color: 'amber' },
    { id: '4', title: 'Asesmen Tengah Semester Ganjil', startDate: '2026-09-21', endDate: '2026-09-26', type: 'Ujian', color: 'blue' },
    { id: '5', title: 'Maulid Nabi Muhammad SAW', startDate: '2026-09-16', endDate: '2026-09-16', type: 'Keagamaan', color: 'amber' }
  ]);

  const [isSyncing, setIsSyncing] = useState(false);
  const [syncStatus, setSyncStatus] = useState<'idle' | 'success'>('idle');
  
  // Modal for new Event
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [title, setTitle] = useState('');
  const [startDate, setStartDate] = useState('2026-07-20');
  const [type, setType] = useState<'Akademik' | 'Keagamaan' | 'Libur' | 'Ujian'>('Akademik');

  const handleSyncGoogle = () => {
    setIsSyncing(true);
    setSyncStatus('idle');
    setTimeout(() => {
      setIsSyncing(false);
      setSyncStatus('success');
      setTimeout(() => setSyncStatus('idle'), 4000);
    }, 1800);
  };

  const handleAddEvent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title) return;

    let color = 'emerald';
    if (type === 'Keagamaan') color = 'amber';
    else if (type === 'Libur') color = 'rose';
    else if (type === 'Ujian') color = 'blue';

    const newEvent: GoogleCalendarEvent = {
      id: Math.floor(Math.random() * 1000).toString(),
      title,
      startDate,
      endDate: startDate,
      type,
      color
    };

    setEvents([newEvent, ...events]);
    setIsModalOpen(false);
    setTitle('');
  };

  const handleDelete = (id: string) => {
    setEvents(events.filter(ev => ev.id !== id));
  };

  return (
    <div className="space-y-4 animate-in fade-in duration-200">
      
      {/* Header Panel with GCal action */}
      <div className="bg-white border border-slate-100 rounded-2xl p-4.5 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="text-xxxxs font-bold text-slate-405 uppercase tracking-widest block">Google Workspace Integration</span>
          <h3 className="text-xs font-bold text-slate-800 uppercase tracking-tight flex items-center gap-1.5">
            <CalendarDays className="h-4 w-4 text-emerald-700" />
            Kalender Akademik Terintegrasi (G-Suite)
          </h3>
          <p className="text-xxxxs text-slate-450 font-semibold leading-relaxed mt-1">
            Modul ini mensinkronisasi agenda hari kerja efektif madrasah secara 2-arah ke Google Calendar SD Islam Al Faraby Bogor.
          </p>
        </div>

        <div className="flex items-center gap-2.5 self-start md:self-center shrink-0">
          <button
            onClick={handleSyncGoogle}
            disabled={isSyncing}
            className={`flex items-center gap-1.5 text-xxxxs font-bold py-2.5 px-4.5 rounded-xl border-0 cursor-pointer transition ${
              syncStatus === 'success' ? 'bg-sky-50 text-sky-800' : 'bg-emerald-700 hover:bg-emerald-800 text-white'
            }`}
          >
            {isSyncing ? (
              <RefreshCw className="h-3 w-3 animate-spin" />
            ) : syncStatus === 'success' ? (
              <CheckCircle className="h-3.5 w-3.5" />
            ) : (
              <Calendar className="h-3.5 w-3.5" />
            )}
            {isSyncing ? 'Menghubungkan API...' : syncStatus === 'success' ? 'Sukses Sinkron GCal!' : 'Sinkron Google Calendar'}
          </button>

          <button
            onClick={() => setIsModalOpen(true)}
            className="flex items-center gap-1 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xxxxs px-3.5 py-2.5 rounded-lg border-0 cursor-pointer"
          >
            <Plus className="h-3 w-3" />
            Tambah Agenda
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        
        {/* Left Side: Categories indicators list */}
        <div className="bg-white border border-slate-100 rounded-2xl p-4.5 space-y-4">
          <h4 className="text-xxs font-extrabold text-slate-400 uppercase tracking-widest border-b border-slate-50 pb-2">
            Kategori Agenda
          </h4>

          <div className="space-y-2 text-xxxxs">
            <div className="flex items-center justify-between p-2.5 bg-emerald-50 text-emerald-800 rounded-xl">
              <span className="font-bold flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-emerald-500" />
                Sifat Akademis (KBM)
              </span>
              <span className="font-extrabold text-right">Mulai Sekolah</span>
            </div>

            <div className="flex items-center justify-between p-2.5 bg-amber-50 text-amber-805 rounded-xl">
              <span className="font-bold flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-amber-500" />
                Hari Besar Keagamaan
              </span>
              <span className="font-extrabold text-right">PHBI / Shalat</span>
            </div>

            <div className="flex items-center justify-between p-2.5 bg-blue-50/80 text-blue-800 rounded-xl">
              <span className="font-bold flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-blue-500" />
                Penilaian Dan Ujian
              </span>
              <span className="font-extrabold text-right">ATS / SAS</span>
            </div>

            <div className="flex items-center justify-between p-2.5 bg-red-50 text-red-800 rounded-xl">
              <span className="font-bold flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-red-500" />
                Hari Libur Nasional
              </span>
              <span className="font-extrabold text-right">Cuti Bersama</span>
            </div>
          </div>
        </div>

        {/* Right Side: Agenda Chronological Timestamps list */}
        <div className="md:col-span-2 bg-white border border-slate-100 rounded-2xl p-4.5 space-y-3">
          <h4 className="text-xxs font-extrabold text-slate-400 uppercase tracking-widest border-b border-slate-50 pb-2">
            Timeline Kejadian Terdaftar ({events.length} Agenda)
          </h4>

          <div className="space-y-2.5 max-h-96 overflow-y-auto pr-1 text-xxs">
            {events.map(ev => (
              <div 
                key={ev.id} 
                className={`p-3 rounded-xl border flex items-center justify-between hover:scale-[1.006] transition-all bg-white hover:shadow-xs ${
                  ev.color === 'emerald' ? 'border-emerald-100 bg-emerald-50/10' :
                  ev.color === 'amber' ? 'border-amber-100 bg-amber-50/10' :
                  ev.color === 'blue' ? 'border-blue-100 bg-blue-50/10' : 'border-rose-100 bg-rose-50/10'
                }`}
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className={`text-[9px] font-black uppercase px-2 py-0.5 rounded ${
                      ev.color === 'emerald' ? 'bg-emerald-100 text-emerald-800' :
                      ev.color === 'amber' ? 'bg-amber-100 text-amber-800' :
                      ev.color === 'blue' ? 'bg-blue-100 text-blue-850' : 'bg-rose-100 text-rose-800'
                    }`}>
                      {ev.type}
                    </span>
                    <span className="font-mono text-xxxxs text-slate-400 font-bold">{ev.startDate}</span>
                  </div>
                  <h5 className="text-xxs font-extrabold text-slate-800 mt-2 leading-snug">{ev.title}</h5>
                </div>

                <button
                  onClick={() => handleDelete(ev.id)}
                  className="p-1.5 hover:bg-rose-50 hover:text-rose-600 text-slate-300 rounded transition cursor-pointer"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* --- ADD EVENT TRIGGER MODAL --- */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl border border-slate-200 w-full max-w-sm shadow-xl overflow-hidden animate-in zoom-in-95 duration-155">
            <div className="bg-brand-green-700 p-4 text-white flex justify-between items-center">
              <h4 className="font-bold text-xs">Tambah Agenda Baru</h4>
              <button onClick={() => setIsModalOpen(false)} className="text-white hover:text-emerald-100 transition">
                <X className="h-4 w-4" />
              </button>
            </div>
            
            <form onSubmit={handleAddEvent} className="p-5 space-y-4 text-xxs">
              <div>
                <label className="block font-bold text-slate-500 uppercase">Uraian / Judul Agenda</label>
                <input
                  type="text"
                  required
                  className="w-full mt-1 border border-slate-200 p-2 rounded-lg focus:outline-none focus:border-brand-green-750"
                  placeholder="Misal: Penilaian Akhir Semester (PAS) Ganjil"
                  value={title}
                  onChange={e => setTitle(e.target.value)}
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-500 uppercase">Tanggal</label>
                  <input
                    type="date"
                    required
                    className="w-full mt-1 border border-slate-200 p-2 rounded-lg text-xxs font-mono focus:outline-none"
                    value={startDate}
                    onChange={e => setStartDate(e.target.value)}
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-500 uppercase">Kelompok Kategori</label>
                  <select
                    value={type}
                    onChange={e => setType(e.target.value as any)}
                    className="w-full mt-1 border border-slate-200 p-2 rounded-lg bg-white"
                  >
                    <option value="Akademik">Akademik (KBM)</option>
                    <option value="Keagamaan">Keagamaan</option>
                    <option value="Libur">Hari Libur</option>
                    <option value="Ujian">SAS / UTS / Pas</option>
                  </select>
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-3.5 py-1.5 text-slate-500 hover:bg-slate-100 rounded-lg"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-brand-green-700 hover:bg-brand-green-800 text-white font-bold rounded-lg"
                >
                  Tambahkan
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
