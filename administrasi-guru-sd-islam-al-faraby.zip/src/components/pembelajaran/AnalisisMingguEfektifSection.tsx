/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Sliders, ArrowUpRight, HelpCircle, Save, Printer, CheckCircle
} from 'lucide-react';
import { AnalisisMingguEfektif } from '../../types';

export default function AnalisisMingguEfektifSection() {
  const [alokasiJpPerMinggu, setAlokasiJpPerMinggu] = useState<number>(4);
  const [academicYear, setAcademicYear] = useState('2026/2027');
  const [semester, setSemester] = useState<'Ganjil' | 'Genap'>('Ganjil');

  // State carrying monthly rows
  const [analysis, setAnalysis] = useState<AnalisisMingguEfektif>({
    id: 'ME-01',
    academicYear: '2026/2027',
    semester: 'Ganjil',
    months: [
      { name: 'Juli', totalWeeks: 4, effectiveWeeks: 2, nonEffectiveWeeks: 2, remarks: 'Libur Akhir TA Masuk Baru' },
      { name: 'Agustus', totalWeeks: 5, effectiveWeeks: 4, nonEffectiveWeeks: 1, remarks: 'HUT RI Ke-81' },
      { name: 'September', totalWeeks: 4, effectiveWeeks: 3, nonEffectiveWeeks: 1, remarks: 'Asesmen Tengah Semester (ATS)' },
      { name: 'Oktober', totalWeeks: 4, effectiveWeeks: 4, nonEffectiveWeeks: 0, remarks: 'KBM Efektif Penuh' },
      { name: 'November', totalWeeks: 5, effectiveWeeks: 5, nonEffectiveWeeks: 0, remarks: 'KBM Efektif Penuh' },
      { name: 'Desember', totalWeeks: 4, effectiveWeeks: 1, nonEffectiveWeeks: 3, remarks: 'Akan SAS, Pembagian Rapor, Libur Smt' }
    ]
  });

  const [notification, setNotification] = useState('');

  // Update cell calculations
  const handleCellChange = (index: number, field: 'totalWeeks' | 'effectiveWeeks' | 'nonEffectiveWeeks' | 'remarks', value: any) => {
    const updatedMonths = [...analysis.months];
    
    if (field === 'remarks') {
      updatedMonths[index].remarks = value;
    } else {
      const numVal = parseInt(value) || 0;
      updatedMonths[index][field] = numVal;
      
      // Keep equation aligned: effective + nonEffective = total
      if (field === 'effectiveWeeks') {
        const potentialNonEffective = updatedMonths[index].totalWeeks - numVal;
        updatedMonths[index].nonEffectiveWeeks = potentialNonEffective >= 0 ? potentialNonEffective : 0;
      } else if (field === 'nonEffectiveWeeks') {
        const potentialEffective = updatedMonths[index].totalWeeks - numVal;
        updatedMonths[index].effectiveWeeks = potentialEffective >= 0 ? potentialEffective : 0;
      }
    }

    setAnalysis({
      ...analysis,
      months: updatedMonths
    });
  };

  // Re-run totals calculation
  const totalWeeksSum = analysis.months.reduce((acc, m) => acc + m.totalWeeks, 0);
  const effectiveWeeksSum = analysis.months.reduce((acc, m) => acc + m.effectiveWeeks, 0);
  const nonEffectiveWeeksSum = analysis.months.reduce((acc, m) => acc + m.nonEffectiveWeeks, 0);
  
  // Computes Total JP = Effective Weeks * JP per week
  const totalJPHours = effectiveWeeksSum * alokasiJpPerMinggu;

  const handleSave = () => {
    setNotification('Tabel Analisis Minggu Efektif berhasil dicalonkan dan disimpan!');
    setTimeout(() => setNotification(''), 3000);
  };

  const handlePrint = () => {
    const win = window.open('', '_blank');
    if (!win) return;

    win.document.write(`
      <html>
        <head>
          <title>Analisis Minggu Efektif - TA ${academicYear}</title>
          <style>
            body { font-family: sans-serif; padding: 40px; color:#1e293b; font-size:11px; }
            table { width:100%; border-collapse:collapse; margin-top:15px; }
            th, td { border:1px solid #cbd5e1; padding:10px; text-align:center; }
            th { background-color:#f1f5f9; color:#0f766e; font-weight:bold; }
            .total-row { font-weight:bold; background-color:#e2e8f0; }
            h1 { color:#0f766e; text-align:center; }
          </style>
        </head>
        <body>
          <h1>ANALISIS MINGGU EFEKTIF SEMESTER ${semester.toUpperCase()}</h1>
          <h3 style="text-align:center;">Tahun Pelajaran: ${academicYear} &bull; Alokasi Jp MInggu: ${alokasiJpPerMinggu} JP</h3>
          
          <table>
            <thead>
              <tr>
                <th>No</th>
                <th style="text-align:left;">Nama Bulan</th>
                <th>Jumlah Minggu</th>
                <th>Minggu Efektif</th>
                <th>Minggu Tidak Efektif</th>
                <th style="text-align:left; width:35%;">Keterangan / Agenda</th>
              </tr>
            </thead>
            <tbody>
              ${analysis.months.map((m, idx) => `
                <tr>
                  <td>${idx + 1}</td>
                  <td style="text-align:left; font-weight:bold;">${m.name}</td>
                  <td>${m.totalWeeks} pekan</td>
                  <td style="font-weight:bold; color:#0f766e;">${m.effectiveWeeks} pekan</td>
                  <td style="color:#e11d48;">${m.nonEffectiveWeeks} pekan</td>
                  <td style="text-align:left;">${m.remarks}</td>
                </tr>
              `).join('')}
              <tr class="total-row">
                <td colspan="2" style="text-align:left;">JUMLAH MUTLAK</td>
                <td>${totalWeeksSum} pekan</td>
                <td style="color:#0f766e;">${effectiveWeeksSum} pekan</td>
                <td style="color:#e11d48;">${nonEffectiveWeeksSum} pekan</td>
                <td style="text-align:left;">Jam Pembelajaran Efektif: ${totalJPHours} JP</td>
              </tr>
            </tbody>
          </table>
        </body>
      </html>
    `);
    win.document.close();
    win.print();
  };

  return (
    <div className="space-y-4 animate-in fade-in duration-200">
      
      {/* Configuration Header Card */}
      <div className="bg-white border border-slate-100 rounded-2xl p-5 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <span className="text-xxxxs font-bold text-slate-405 uppercase tracking-widest block">RUMUS DANA MASUK</span>
          <h3 className="text-xs font-bold text-slate-800 uppercase tracking-tight">Kalkulator Minggu Efektif Ajar</h3>
          <p className="text-xxxxs text-slate-400 font-semibold leading-relaxed">
            Sesuaikan minggu tidak-efektif (libur semester, ujian penilaian) untuk mendapatkan hitungan alokasi Jam Pelajaran (JP) murni di kurikulum Merdeka.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3 bg-slate-50 border border-slate-200 p-2.5 rounded-xl shrink-0">
          <div className="flex items-center gap-1">
            <span className="text-xxxxs font-bold text-slate-500 uppercase">Beban Mapel:</span>
            <input
              type="number"
              min="1"
              max="12"
              className="w-12 text-xxs p-1 text-center font-bold border border-slate-200 rounded-md bg-white focus:outline-none"
              value={alokasiJpPerMinggu}
              onChange={e => setAlokasiJpPerMinggu(Math.max(1, parseInt(e.target.value) || 1))}
            />
            <span className="text-[10px] text-slate-400 font-bold">JP/Minggu</span>
          </div>

          <button
            onClick={handlePrint}
            className="text-xxxxs font-bold bg-slate-100 hover:bg-slate-200 text-slate-700 py-1.5 px-3 rounded-lg border-0 cursor-pointer"
          >
            <Printer className="h-3 w-3 inline mr-1" />
            Cetak Analisis
          </button>
        </div>
      </div>

      {notification && (
        <div className="bg-emerald-50 text-emerald-800 border border-emerald-100 p-3 rounded-xl flex items-center gap-2 text-xxs font-bold animate-pulse">
          <CheckCircle className="h-4 w-4 text-emerald-600" />
          {notification}
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-5">
        {/* Left Side: Summary indicators block */}
        <div className="bg-white border border-slate-100 rounded-2xl p-5 space-y-4">
          <h4 className="text-xxs font-extrabold text-slate-400 uppercase tracking-widest border-b border-slate-50 pb-2">
            Ikhtisar Perhitungan
          </h4>

          <div className="grid grid-cols-2 lg:grid-cols-1 gap-3.5 text-xxs">
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
              <span className="text-xxxxs text-slate-400 font-bold uppercase tracking-wide">Semester</span>
              <p className="text-xs font-black text-slate-800 uppercase mt-0.5">{semester} &bull; {academicYear}</p>
            </div>

            <div className="p-3 bg-emerald-50/40 rounded-xl border border-emerald-150">
              <span className="text-xxxxs text-emerald-800 font-bold uppercase tracking-wide">Minggu Efektif</span>
              <p className="text-xs font-black text-brand-green-800 mt-0.5">{effectiveWeeksSum} Pekan Ajar</p>
            </div>

            <div className="p-3 bg-rose-50/50 rounded-xl border border-rose-100">
              <span className="text-xxxxs text-rose-800 font-bold uppercase tracking-wide">Minggu Tidak Efektif</span>
              <p className="text-xs font-black text-rose-600 mt-0.5">{nonEffectiveWeeksSum} Pekan Libur/Ujian</p>
            </div>

            <div className="p-3 bg-gradient-to-br from-brand-green-700 to-brand-green-800 rounded-xl text-white">
              <span className="text-xxxxs text-emerald-250 font-bold uppercase tracking-wide flex items-center justify-between">
                Total Alokasi Waktu
                <ArrowUpRight className="h-4.5 w-4.5 text-brand-gold-300" />
              </span>
              <p className="text-sm font-extrabold text-brand-gold-300 tracking-tight mt-1">
                {totalJPHours} Jam Pelajaran (JP)
              </p>
            </div>
          </div>
        </div>

        {/* Right Side: Editable Monthly Grid Table */}
        <div className="lg:col-span-3 bg-white border border-slate-100 rounded-2xl p-4.5">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xxs border-collapse">
              <thead>
                <tr className="bg-slate-50/80 border-b border-slate-100 text-slate-500 font-bold uppercase text-xxxxs tracking-wider">
                  <th className="p-3">Bulan</th>
                  <th className="p-3 w-28 text-center">Jumlah Minggu (A)</th>
                  <th className="p-3 w-28 text-center">Minggu Efektif (B)</th>
                  <th className="p-3 w-28 text-center">Minggu Tidak Efektif (A - B)</th>
                  <th className="p-3">Agenda / Keterangan Alasan</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-705 font-semibold">
                {analysis.months.map((m, idx) => (
                  <tr key={m.name} className="hover:bg-slate-50/20 text-[11px]">
                    <td className="p-3 font-bold text-slate-850">{m.name}</td>
                    <td className="p-3">
                      <input
                        type="number"
                        min="2"
                        max="6"
                        className="w-16 mx-auto text-center border border-slate-200 p-1.5 rounded-lg focus:outline-none focus:border-brand-green-700 text-xxs bg-white"
                        value={m.totalWeeks}
                        onChange={e => handleCellChange(idx, 'totalWeeks', Math.max(1, parseInt(e.target.value) || 1))}
                      />
                    </td>
                    <td className="p-3">
                      <input
                        type="number"
                        min="0"
                        max={m.totalWeeks}
                        className="w-16 mx-auto text-center border border-emerald-300 p-1.5 rounded-lg focus:outline-none text-xxs bg-emerald-50 text-emerald-800 font-bold"
                        value={m.effectiveWeeks}
                        onChange={e => handleCellChange(idx, 'effectiveWeeks', parseInt(e.target.value) || 0)}
                      />
                    </td>
                    <td className="p-3 text-center">
                      <span className="font-mono font-bold text-slate-500 bg-slate-100/60 py-1.5 px-3 rounded-lg text-xxs inline-block">
                        {m.nonEffectiveWeeks}
                      </span>
                    </td>
                    <td className="p-3">
                      <input
                        type="text"
                        className="w-full border border-slate-200 p-1.5 rounded-lg text-xxs focus:outline-none"
                        value={m.remarks}
                        onChange={e => handleCellChange(idx, 'remarks', e.target.value)}
                        placeholder="Agenda..."
                      />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="flex justify-end p-3 border-t border-slate-50 mt-4.5">
            <button
              onClick={handleSave}
              className="flex items-center gap-1.5 bg-brand-green-700 hover:bg-brand-green-800 text-white font-bold text-xxxxs px-4 py-2 rounded-lg border-0 cursor-pointer shadow-xs transition"
            >
              <Save className="h-3.5 w-3.5 text-emerald-200" />
              Simpan Hitungan Analisis
            </button>
          </div>
        </div>
      </div>

    </div>
  );
}
