/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Search, Plus, Edit, Trash, Printer, Link, Tag, Eye, X, Check, ArrowRight, Award
} from 'lucide-react';
import { TujuanPembelajaran, CapaianPembelajaran, Subject } from '../../types';

interface TujuanPembelajaranSectionProps {
  subjects: Subject[];
  cpList: CapaianPembelajaran[];
  tpList: TujuanPembelajaran[];
  onAddTp: (tp: TujuanPembelajaran) => void;
  onEditTp: (tp: TujuanPembelajaran) => void;
  onDeleteTp: (id: string) => void;
}

export default function TujuanPembelajaranSection({
  subjects,
  cpList,
  tpList,
  onAddTp,
  onEditTp,
  onDeleteTp
}: TujuanPembelajaranSectionProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSubject, setSelectedSubject] = useState('Semua');

  // Modal control
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);

  // Form states
  const [code, setCode] = useState('');
  const [cpId, setCpId] = useState(cpList[0]?.id || '');
  const [subjName, setSubjName] = useState(subjects[0]?.name || 'Aqidah Akhlak');
  const [gradeLevel, setGradeLevel] = useState('Kelas 4');
  const [description, setDescription] = useState('');

  const resetForm = () => {
    setEditingId(null);
    setCode(`TP-${subjName.substring(0,2).toUpperCase()}-${Math.floor(Math.random() * 90) + 10}.1`);
    setDescription('');
    if (cpList.length > 0) {
      const filteredCps = cpList.filter(cp => cp.subjectName === subjName);
      setCpId(filteredCps[0]?.id || cpList[0]?.id);
    }
  };

  const handleOpenAdd = () => {
    resetForm();
    setIsModalOpen(true);
  };

  const handleOpenEdit = (tp: TujuanPembelajaran) => {
    setEditingId(tp.id);
    setCode(tp.code);
    setCpId(tp.cpId);
    setSubjName(tp.subjectName);
    setGradeLevel(tp.gradeLevel);
    setDescription(tp.description);
    setIsModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!code || !description || !cpId) return;

    // Find linked CP code
    const linkedCp = cpList.find(c => c.id === cpId);

    const data: TujuanPembelajaran = {
      id: editingId || 'TP' + Math.floor(Math.random() * 1000).toString().padStart(3, '0'),
      code,
      cpId,
      cpCode: linkedCp?.code || 'CP-UNK',
      subjectName: subjName,
      gradeLevel,
      description
    };

    if (editingId) {
      onEditTp(data);
    } else {
      onAddTp(data);
    }
    setIsModalOpen(false);
  };

  // Generate Styled Printed Report
  const handlePrint = () => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;

    const filteredRows = tpList.filter(tp => selectedSubject === 'Semua' || tp.subjectName === selectedSubject);

    const htmlString = `
      <html>
        <head>
          <title>Pemetaan Tujuan Pembelajaran (TP) - SD Islam Al Faraby</title>
          <style>
            body { font-family: 'Inter', sans-serif; padding: 40px; color: #1e293b; font-size: 11px; }
            .header-table { width: 100%; border-bottom: 2px solid #0f766e; padding-bottom: 15px; margin-bottom: 20px; }
            .title { font-size: 16px; font-weight: bold; color: #0f766e; text-transform: uppercase; margin: 0; }
            .sub { font-size: 10px; color: #64748b; margin-top: 4px; }
            table.data { width: 100%; border-collapse: collapse; margin-top: 15px; }
            table.data th { background: #f1f5f9; border: 1px solid #cbd5e1; padding: 8px; font-weight: bold; text-align: left; text-transform: uppercase; font-size: 9px; }
            table.data td { border: 1px solid #cbd5e1; padding: 8px; vertical-align: top; }
            .cp-box { background: #f8fafc; font-size: 10px; padding: 4px; border-radius: 4px; color: #475569; }
            .badge { display: inline-block; background: #e2e8f0; font-family: monospace; font-weight: bold; padding: 2px 5px; border-radius: 3px; font-size: 10px; }
            .badge-cp { background: #d1fae5; color: #065f46; }
            .badge-tp { background: #fef3c7; color: #92400e; }
          </style>
        </head>
        <body>
          <table class="header-table">
            <tr>
              <td>
                <h1 class="title">SD ISLAM AL FARABY BOGOR</h1>
                <div class="sub">Kurikulum Merdeka Belajar &bull; Dokumen KTSP Administrasi Pembelajaran Mapel: ${selectedSubject}</div>
              </td>
              <td style="text-align: right; font-weight: bold; color: #64748b;">DOKUMEN UTAMA TP</td>
            </tr>
          </table>

          <h3 style="color:#0f766e; font-size: 12px; margin-top:10px;">REKAPITULASI DRAF TUJUAN PEMBELAJARAN (TP)</h3>
          
          <table class="data">
            <thead>
              <tr>
                <th style="width: 12%">Kode TP</th>
                <th style="width: 15%">Hubungan CP</th>
                <th style="width: 18%">Mata Pelajaran</th>
                <th style="width: 10%">Kelas</th>
                <th>Rincian Deskripsi Tujuan Pembelajaran (TP)</th>
              </tr>
            </thead>
            <tbody>
              ${filteredRows.map(tp => {
                const matchedCP = cpList.find(c => c.id === tp.cpId);
                return `
                  <tr>
                    <td><span class="badge badge-tp">${tp.code}</span></td>
                    <td>
                      <span class="badge badge-cp">${tp.cpCode || matchedCP?.code || 'Terhubung'}</span>
                      <div style="font-size:8px; color:#94a3b8; margin-top:3px;">Elemen: ${matchedCP?.element || '-'}</div>
                    </td>
                    <td style="font-weight:600;">${tp.subjectName}</td>
                    <td>${tp.gradeLevel}</td>
                    <td style="line-height:1.5;">
                      <div>${tp.description}</div>
                      ${matchedCP ? `<div class="cp-box" style="margin-top:6px;"><strong>Kompetensi CP:</strong> ${matchedCP.description}</div>` : ''}
                    </td>
                  </tr>
                `;
              }).join('')}
            </tbody>
          </table>

          <div style="margin-top:40px; float:right; text-align:center; width:200px;">
            <p>Bogor, ${new Date().toLocaleDateString('id-ID', { year: 'numeric', month: 'long', day: 'numeric' })}</p>
            <p style="margin-top:5px; font-weight:bold;">Kepala Kurikulum SD Al Faraby</p>
            <div style="height:60px;"></div>
            <p style="text-decoration:underline; font-weight:bold;">Ustadz Syamil Baswedan, M.Pd</p>
            <p style="font-size:9px; color:#94a3b8;">NIP. 19880415 201309 1 002</p>
          </div>
        </body>
      </html>
    `;

    printWindow.document.write(htmlString);
    printWindow.document.close();
    printWindow.print();
  };

  const filtered = tpList.filter(tp => {
    const matchesSearch = tp.description.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          tp.code.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          (tp.cpCode && tp.cpCode.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesSubject = selectedSubject === 'Semua' || tp.subjectName === selectedSubject;
    return matchesSearch && matchesSubject;
  });

  return (
    <div className="space-y-4 animate-in fade-in duration-200">
      {/* Top Banner Control */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-slate-50 p-4 rounded-xl border border-slate-100">
        <div>
          <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider">Modul Tujuan Pembelajaran (TP)</h3>
          <p className="text-xxxxs text-slate-400 font-semibold mt-0.5">Turunkan Capaian Umum (CP) menjadi capaian-capaian detail bersasaran kognitif harian.</p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={handlePrint}
            className="flex items-center gap-1.5 border border-slate-200 bg-white hover:bg-slate-50 text-slate-600 font-bold text-xxxxs px-3 py-2 rounded-lg cursor-pointer"
          >
            <Printer className="h-3.5 w-3.5" />
            Cetak Peta TP
          </button>
          <button
            onClick={handleOpenAdd}
            className="flex items-center gap-1.5 bg-brand-green-700 hover:bg-brand-green-800 text-white font-bold text-xxxxs px-3 py-2 rounded-lg shadow-xs cursor-pointer"
          >
            <Plus className="h-3 w-3" />
            Tambah TP
          </button>
        </div>
      </div>

      {/* Filter and search bar */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3 bg-white p-3 rounded-xl border border-slate-100">
        <div className="md:col-span-2 relative">
          <Search className="absolute left-2.5 top-2.5 h-3.5 w-3.5 text-slate-400" />
          <input
            type="text"
            className="w-full pl-8 pr-3 py-2 text-xxs border border-slate-200 rounded-lg focus:outline-none"
            placeholder="Cari Tujuan Pembelajaran, Kode TP, Kode CP terhubung..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
          />
        </div>
        <div>
          <select
            value={selectedSubject}
            onChange={e => setSelectedSubject(e.target.value)}
            className="w-full text-xxs border border-slate-200 p-2 rounded-lg bg-white"
          >
            <option value="Semua">Semua Mapel</option>
            {subjects.map(s => (
              <option key={s.id} value={s.name}>{s.name}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Main Grid View */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filtered.length > 0 ? (
          filtered.map(tp => {
            const linkedCP = cpList.find(c => c.id === tp.cpId);
            return (
              <div 
                key={tp.id} 
                className="bg-white border border-slate-100 rounded-2xl p-4 shadow-xs relative hover:border-emerald-200 transition-all flex flex-col justify-between"
              >
                <div>
                  <div className="flex justify-between items-start gap-2 border-b border-slate-50 pb-2.5">
                    <span className="font-mono text-xxxxs font-black text-brand-gold-800 bg-brand-gold-50 border border-brand-gold-200 rounded px-2 py-0.5">
                      {tp.code}
                    </span>
                    <span className="bg-emerald-50 text-brand-green-900 border border-emerald-100 px-2 py-0.5 rounded text-[10px] font-bold">
                      {tp.subjectName}
                    </span>
                  </div>

                  <p className="text-xs font-bold text-slate-800 leading-relaxed mt-3">{tp.description}</p>
                  
                  {/* CP Connection Indicator */}
                  {linkedCP ? (
                    <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-100 mt-4 text-[10px] space-y-1">
                      <span className="text-xxxxs font-extrabold text-slate-400 uppercase tracking-widest flex items-center gap-1">
                        <Link className="h-3 w-3 text-emerald-600" />
                        CP Terhubung: {linkedCP.code} ({linkedCP.element})
                      </span>
                      <p className="text-slate-500 font-semibold italic truncate">"{linkedCP.description}"</p>
                    </div>
                  ) : (
                    <div className="bg-rose-50 border border-rose-100 text-rose-700 p-2.5 rounded-xl text-xxxxs mt-4 font-bold flex items-center gap-1">
                      <Award className="h-3 w-3" />
                      CP link belum terverifikasi / butuh pemetaan ulang
                    </div>
                  )}
                </div>

                <div className="flex items-center justify-end gap-1 border-t border-slate-50 mt-4.5 pt-2">
                  <span className="text-xxxxs text-slate-400 font-semibold uppercase mr-auto">{tp.gradeLevel}</span>
                  <button
                    onClick={() => handleOpenEdit(tp)}
                    className="p-1 hover:bg-slate-100 text-slate-500 hover:text-brand-green-700 rounded transition"
                  >
                    <Edit className="h-3.5 w-3.5" />
                  </button>
                  <button
                    onClick={() => {
                      if(confirm('Yakin ingin menghapus TP ini dari database?')) {
                        onDeleteTp(tp.id);
                      }
                    }}
                    className="p-1 hover:bg-rose-50 text-slate-400 hover:text-rose-600 rounded transition"
                  >
                    <Trash className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>
            );
          })
        ) : (
          <div className="bg-white border border-slate-100 rounded-2xl p-8 text-center text-slate-400 col-span-2 italic text-xxs">
            Belum ada draf Tujuan Pembelajaran (TP) yang sesuai kriteria.
          </div>
        )}
      </div>

      {/* --- TP ENTRY MODAL --- */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl border border-slate-200 w-full max-w-lg shadow-xl overflow-hidden animate-in zoom-in-95 duration-155">
            <div className="bg-brand-green-700 p-4 text-white flex justify-between items-center">
              <h4 className="font-bold text-xs school-display">
                {editingId ? 'Edit Tujuan Pembelajaran' : 'Rancang Tujuan Pembelajaran (TP) Baru'}
              </h4>
              <button onClick={() => setIsModalOpen(false)} className="text-white hover:text-emerald-100 transition">
                <X className="h-4 w-4" />
              </button>
            </div>
            
            <form onSubmit={handleSave} className="p-5 space-y-4 text-xxs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-500 uppercase">Kode TP</label>
                  <input
                    type="text"
                    required
                    className="w-full mt-1 border border-slate-200 p-2 rounded-lg font-mono focus:outline-none"
                    placeholder="e.g. TP-AA-01.1"
                    value={code}
                    onChange={e => setCode(e.target.value)}
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-500 uppercase">Sasaran Kelas</label>
                  <input
                    type="text"
                    required
                    className="w-full mt-1 border border-slate-200 p-2 rounded-lg focus:outline-none"
                    placeholder="e.g. Kelas 4"
                    value={gradeLevel}
                    onChange={e => setGradeLevel(e.target.value)}
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-500 uppercase">Hubungkan ke Capaian Pembelajaran (CP)</label>
                <select
                  value={cpId}
                  onChange={e => setCpId(e.target.value)}
                  className="w-full mt-1 border border-slate-200 p-2 rounded-lg bg-white"
                >
                  {cpList.map(cp => (
                    <option key={cp.id} value={cp.id}>
                      [{cp.code}] Element: {cp.element} - {cp.subjectName} ({cp.fase})
                    </option>
                  ))}
                </select>
                <span className="text-[9px] text-slate-400 mt-1 block leading-normal">
                  TP akan terkait secara genealogis ke dalil kompetensi CP terpilih untuk pengurutan kurikulum di modul ATP.
                </span>
              </div>

              <div>
                <label className="block font-bold text-slate-500 uppercase">Mata Pelajaran Pasangan</label>
                <select
                  value={subjName}
                  onChange={e => setSubjName(e.target.value)}
                  className="w-full mt-1 border border-slate-200 p-2 rounded-lg bg-white"
                >
                  {subjects.map(s => (
                    <option key={s.id} value={s.name}>{s.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-500 uppercase">Deskripsi Tujuan Pembelajaran</label>
                <textarea
                  rows={4}
                  required
                  className="w-full mt-1 border border-slate-200 p-2 rounded-lg focus:outline-none focus:border-brand-green-600"
                  placeholder="Ketik target spesifik pembelajaran siswa (Misal: Melafalkan arti surat Al-Ma'un dengan tartil sesuai hukum tajwid)..."
                  value={description}
                  onChange={e => setDescription(e.target.value)}
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-3.5 py-2 text-slate-500 hover:bg-slate-100 font-bold rounded-lg"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-brand-green-700 hover:bg-brand-green-800 text-white font-bold rounded-lg"
                >
                  Simpan TP
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
