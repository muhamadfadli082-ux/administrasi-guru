/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Search, Plus, Edit, Trash, Download, Upload, Eye, Check, X, FileSpreadsheet, Info
} from 'lucide-react';
import { CapaianPembelajaran, Subject } from '../../types';

interface CapaianPembelajaranSectionProps {
  subjects: Subject[];
  cpList: CapaianPembelajaran[];
  onAddCp: (cp: CapaianPembelajaran) => void;
  onEditCp: (cp: CapaianPembelajaran) => void;
  onDeleteCp: (id: string) => void;
}

export default function CapaianPembelajaranSection({
  subjects,
  cpList,
  onAddCp,
  onEditCp,
  onDeleteCp
}: CapaianPembelajaranSectionProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSubject, setSelectedSubject] = useState('Semua');
  const [selectedFase, setSelectedFase] = useState('Semua');

  // Modal Control
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [isImportOpen, setIsImportOpen] = useState(false);
  const [isImportSuccess, setIsImportSuccess] = useState(false);

  // Form Inputs
  const [code, setCode] = useState('');
  const [subjName, setSubjName] = useState(subjects[0]?.name || 'Aqidah Akhlak');
  const [fase, setFase] = useState('Fase B');
  const [gradeLevel, setGradeLevel] = useState('Kelas 4');
  const [element, setElement] = useState('Aqidah');
  const [description, setDescription] = useState('');

  // Reset Form
  const resetForm = () => {
    setEditingId(null);
    setCode(`CP-${subjName.substring(0,2).toUpperCase()}-${Math.floor(Math.random() * 90) + 10}`);
    setDescription('');
    setElement('Umum');
  };

  const handleOpenAdd = () => {
    resetForm();
    setIsModalOpen(true);
  };

  const handleOpenEdit = (cp: CapaianPembelajaran) => {
    setEditingId(cp.id);
    setCode(cp.code);
    setSubjName(cp.subjectName);
    setFase(cp.fase);
    setGradeLevel(cp.gradeLevel);
    setElement(cp.element);
    setDescription(cp.description);
    setIsModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!code || !description) return;

    const data: CapaianPembelajaran = {
      id: editingId || 'CP' + Math.floor(Math.random() * 1000).toString().padStart(3, '0'),
      code,
      subjectName: subjName,
      fase,
      gradeLevel,
      element,
      description
    };

    if (editingId) {
      onEditCp(data);
    } else {
      onAddCp(data);
    }
    setIsModalOpen(false);
  };

  const handleExport = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(cpList, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", "capaian_pembelajaran_al_faraby.json");
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const handleImportSimulate = () => {
    setIsImportSuccess(true);
    setTimeout(() => {
      // Add simulated import record
      onAddCp({
        id: 'CP-IMP-01',
        code: 'CP-FIK-03',
        subjectName: 'Fikih',
        fase: 'Fase B',
        gradeLevel: 'Kelas 4',
        element: 'Ibadah',
        description: 'Peserta didik mampu memahami tata cara mandi wajib bagi remaja usia baligh, rukun-rukunnya, syarat sah, serta sunnah-sunnah mandi wajib sesuai fiqih Syafi\'i.'
      });
      setIsImportSuccess(false);
      setIsImportOpen(false);
    }, 1500);
  };

  const filtered = cpList.filter(cp => {
    const matchesSearch = cp.description.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          cp.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          cp.element.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesSubject = selectedSubject === 'Semua' || cp.subjectName === selectedSubject;
    const matchesFase = selectedFase === 'Semua' || cp.fase === selectedFase;
    return matchesSearch && matchesSubject && matchesFase;
  });

  return (
    <div className="space-y-4 animate-in fade-in duration-200">
      {/* Action Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-slate-50 p-4 rounded-xl border border-slate-100">
        <div>
          <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider">Modul Capaian Pembelajaran (CP)</h3>
          <p className="text-xxxxs text-slate-400 font-semibold mt-0.5">Definisikan kompetensi minimum yang harus dicapai santri di akhir tiap fase bimbingan.</p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsImportOpen(true)}
            className="flex items-center gap-1.5 border border-slate-200 bg-white hover:bg-slate-50 text-slate-600 font-bold text-xxxxs px-3 py-2 rounded-lg cursor-pointer"
          >
            <Upload className="h-3 w-3" />
            Import CP
          </button>
          <button
            onClick={handleExport}
            className="flex items-center gap-1.5 border border-slate-200 bg-white hover:bg-slate-50 text-slate-600 font-bold text-xxxxs px-3 py-2 rounded-lg cursor-pointer"
          >
            <Download className="h-3 w-3" />
            Export
          </button>
          <button
            onClick={handleOpenAdd}
            className="flex items-center gap-1.5 bg-brand-green-700 hover:bg-brand-green-800 text-white font-bold text-xxxxs px-3 py-2 rounded-lg shadow-xs cursor-pointer"
          >
            <Plus className="h-3 w-3" />
            Tambah CP
          </button>
        </div>
      </div>

      {/* Filters & Search */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-3 bg-white p-3 rounded-xl border border-slate-100">
        <div className="md:col-span-2 relative">
          <Search className="absolute left-2.5 top-2.5 h-3.5 w-3.5 text-slate-400" />
          <input
            type="text"
            className="w-full pl-8 pr-3 py-2 text-xxs border border-slate-200 rounded-lg focus:outline-none"
            placeholder="Cari kata kunci atau Kode CP..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
          />
        </div>
        <div>
          <select
            value={selectedSubject}
            onChange={e => setSelectedSubject(e.target.value)}
            className="w-full text-xxs border border-slate-200 p-2 rounded-lg bg-white"
          >
            <option value="Semua">Semua Mapel</option>
            {subjects.map(s => (
              <option key={s.id} value={s.name}>{s.name}</option>
            ))}
          </select>
        </div>
        <div>
          <select
            value={selectedFase}
            onChange={e => setSelectedFase(e.target.value)}
            className="w-full text-xxs border border-slate-200 p-2 rounded-lg bg-white"
          >
            <option value="Semua">Semua Fase</option>
            <option value="Fase A">Fase A (Kls 1-2)</option>
            <option value="Fase B">Fase B (Kls 3-4)</option>
            <option value="Fase C">Fase C (Kls 5-6)</option>
          </select>
        </div>
      </div>

      {/* CP Table List */}
      <div className="bg-white rounded-xl border border-slate-100 overflow-hidden shadow-xs">
        <table className="w-full text-left border-collapse text-xxs">
          <thead>
            <tr className="bg-slate-50/70 border-b border-slate-100 text-slate-500 font-bold uppercase tracking-wider">
              <th className="p-3 w-28">Kode CP</th>
              <th className="p-3">Mata Pelajaran</th>
              <th className="p-3 w-20">Fase</th>
              <th className="p-3 w-24">Elemen</th>
              <th className="p-3">Deskripsi Capaian Pembelajaran</th>
              <th className="p-3 text-right w-20">Aksi</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 text-slate-700">
            {filtered.length > 0 ? (
              filtered.map(cp => (
                <tr key={cp.id} className="hover:bg-slate-50/40">
                  <td className="p-3 font-mono font-bold text-brand-green-800">{cp.code}</td>
                  <td className="p-3 font-semibold text-slate-800">{cp.subjectName}</td>
                  <td className="p-3">
                    <span className="bg-blue-50 text-blue-700 px-2 py-0.5 rounded font-extrabold text-[10px]">
                      {cp.fase}
                    </span>
                  </td>
                  <td className="p-3">
                    <span className="bg-brand-gold-50 text-brand-gold-800 border border-brand-gold-100 px-2 py-0.5 rounded font-bold text-[10px]">
                      {cp.element}
                    </span>
                  </td>
                  <td className="p-3 leading-relaxed text-slate-600 max-w-sm font-medium">{cp.description}</td>
                  <td className="p-3 text-right">
                    <div className="flex items-center justify-end gap-1">
                      <button
                        onClick={() => handleOpenEdit(cp)}
                        className="p-1 hover:bg-slate-100 text-slate-500 hover:text-brand-green-700 rounded transition"
                      >
                        <Edit className="h-3.5 w-3.5" />
                      </button>
                      <button
                        onClick={() => {
                          if(confirm('Apakah Anda yakin mau menghapus data Capaian Pembelajaran ini?')) {
                            onDeleteCp(cp.id);
                          }
                        }}
                        className="p-1 hover:bg-rose-50 text-slate-400 hover:text-rose-600 rounded transition"
                      >
                        <Trash className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={6} className="p-8 text-center text-slate-400 italic">
                  Tidak ada Capaian Pembelajaran (CP) ditemukan yang sesuai kriteria.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* --- FORM MODAL --- */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl border border-slate-200 w-full max-w-lg shadow-xl overflow-hidden animate-in zoom-in-95 duration-155">
            <div className="bg-brand-green-700 p-4 text-white flex justify-between items-center">
              <h4 className="font-bold text-xs school-display">
                {editingId ? 'Edit Capaian Pembelajaran' : 'Daftarkan Capaian Pembelajaran Baru'}
              </h4>
              <button onClick={() => setIsModalOpen(false)} className="text-white hover:text-emerald-100 transition">
                <X className="h-4 w-4" />
              </button>
            </div>
            <form onSubmit={handleSave} className="p-5 space-y-4 text-xxs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-500 uppercase">Kode CP</label>
                  <input
                    type="text"
                    required
                    className="w-full mt-1 border border-slate-200 p-2 rounded-lg font-mono focus:outline-none focus:border-brand-green-600"
                    placeholder="e.g. CP-AA-01"
                    value={code}
                    onChange={e => setCode(e.target.value)}
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-500 uppercase">Elemen CP</label>
                  <input
                    type="text"
                    required
                    className="w-full mt-1 border border-slate-200 p-2 rounded-lg focus:outline-none focus:border-brand-green-600"
                    placeholder="e.g. Aqidah, Fikih, Akhlak"
                    value={element}
                    onChange={e => setElement(e.target.value)}
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div className="col-span-2">
                  <label className="block font-bold text-slate-500 uppercase">Mata Pelajaran</label>
                  <select
                    value={subjName}
                    onChange={e => setSubjName(e.target.value)}
                    className="w-full mt-1 border border-slate-200 p-2 rounded-lg bg-white"
                  >
                    {subjects.map(s => (
                      <option key={s.id} value={s.name}>{s.name}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block font-bold text-slate-500 uppercase">Fase</label>
                  <select
                    value={fase}
                    onChange={e => setFase(e.target.value)}
                    className="w-full mt-1 border border-slate-200 p-2 rounded-lg bg-white"
                  >
                    <option value="Fase A">Fase A</option>
                    <option value="Fase B">Fase B</option>
                    <option value="Fase C">Fase C</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-500 uppercase">Sasaran Tingkat Kelas</label>
                <input
                  type="text"
                  required
                  className="w-full mt-1 border border-slate-200 p-2 rounded-lg focus:outline-none"
                  placeholder="e.g. Kelas 4"
                  value={gradeLevel}
                  onChange={e => setGradeLevel(e.target.value)}
                />
              </div>

              <div>
                <label className="block font-bold text-slate-500 uppercase">Deskripsi Capaian Pembelajaran</label>
                <textarea
                  rows={4}
                  required
                  className="w-full mt-1 border border-slate-200 p-2 rounded-lg focus:outline-none focus:border-brand-green-600"
                  placeholder="Masukkan rincian kompetensi dan kemampuan minimum..."
                  value={description}
                  onChange={e => setDescription(e.target.value)}
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-3.5 py-2 text-slate-500 hover:bg-slate-100 font-bold rounded-lg"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-brand-green-700 hover:bg-brand-green-800 text-white font-bold rounded-lg"
                >
                  Simpan CP
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* --- IMPORT SIMULATION DIALOG --- */}
      {isImportOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl border border-slate-200 w-full max-w-sm shadow-xl p-5 animate-in zoom-in-95 duration-155">
            <h4 className="font-bold text-xs text-slate-850 flex items-center gap-2">
              <FileSpreadsheet className="h-4 w-4 text-emerald-600" />
              Sistem Import Spreadsheet CP
            </h4>
            <p className="text-xxxxs text-slate-400 mt-1 leading-relaxed">
              Anda dapat mengimpor dokumen struktur capaian pembelajaran berformat Excel/CSV ke dalam sistem database kurikulum merdeka Al Faraby.
            </p>
            
            <div className="mt-4 border-2 border-dashed border-slate-200 rounded-xl p-6 text-center bg-slate-50 flex flex-col items-center justify-center">
              <Upload className="h-8 w-8 text-slate-300 animate-pulse mb-2" />
              <div className="font-bold text-slate-600 text-xxxxs">Tarik & Letakkan file Excel Anda disini</div>
              <span className="text-[10px] text-slate-400 mt-1">Atau format CSV (Max 2MB)</span>
            </div>

            <div className="flex justify-end gap-2 mt-4 pt-3 border-t border-slate-100 text-xxs">
              <button
                onClick={() => setIsImportOpen(false)}
                className="px-3 py-1.5 text-slate-500"
              >
                Batal
              </button>
              <button
                onClick={handleImportSimulate}
                className="px-3.5 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-lg"
              >
                {isImportSuccess ? 'Memproses Doc...' : 'Simulasikan Import'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
