/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Folder,
  FolderOpen,
  FileText,
  FileArchive,
  Upload,
  Download,
  Search,
  Trash2,
  History,
  Cloud,
  ChevronRight,
  ArrowLeft,
  Sparkles,
  Info,
  Calendar,
  Layers,
  FileImage,
  CheckCircle,
  Eye,
  Settings,
  Shield,
  FileCode,
  Globe,
  AlertTriangle
} from 'lucide-react';
import { DigitalFile } from '../types';

interface ArsipDigitalViewProps {
  files: DigitalFile[];
  onAddFile: (file: DigitalFile) => void;
  onDeleteFile: (id: string) => void;
}

interface ArchivedDocument {
  id: string;
  name: string;
  folder: string; // e.g. "Modul Ajar", "CP", "LKPD"
  academicYear: string; // e.g. "2025/2026", "2026/2027"
  size: string;
  lastUpdated: string;
  updatedBy: string;
  currentVersion: number;
  description: string;
  versions: Array<{
    version: number;
    updatedAt: string;
    updatedBy: string;
    size: string;
    notes: string;
  }>;
}

// Initial rich files pre-populated in correct directories
const INITIAL_FOLDERED_FILES: ArchivedDocument[] = [
  {
    id: 'DOC-001',
    name: 'Modul_Ajar_Aqidah_Akhlak_FaseB_K4.pdf',
    folder: 'Modul Ajar',
    academicYear: '2026/2027',
    size: '4.2 MB',
    lastUpdated: '2026-06-15',
    updatedBy: 'Ustadzah Siti Nurhaliza, S.Pd.I.',
    currentVersion: 2,
    description: 'Panduan RPP Kurikulum Merdeka pengajaran akhlak terpuji semester ganjil.',
    versions: [
      { version: 2, updatedAt: '2026-06-15', updatedBy: 'Ustadzah Siti Nurhaliza, S.Pd.I.', size: '4.2 MB', notes: 'Revisi penambahan rubrik penilaian formatif' },
      { version: 1, updatedAt: '2026-06-10', updatedBy: 'Ustadzah Siti Nurhaliza, S.Pd.I.', size: '3.9 MB', notes: 'Draft awal draf kurma' }
    ]
  },
  {
    id: 'DOC-002',
    name: 'Sertifikat_Khataman_Al-Faraby_2025.pdf',
    folder: 'Sertifikat',
    academicYear: '2025/2026',
    size: '1.8 MB',
    lastUpdated: '2025-11-20',
    updatedBy: 'Ustadz Ahmad Al-Faruq, M.Pd.',
    currentVersion: 1,
    description: 'Desain sertifikat wisuda hafalan Juz 30 santri angkatan 2025.',
    versions: [
      { version: 1, updatedAt: '2025-11-20', updatedBy: 'Ustadz Ahmad Al-Faruq, M.Pd.', size: '1.8 MB', notes: 'Diterbitkan pasca sidang hafalan kelulusan' }
    ]
  },
  {
    id: 'DOC-003',
    name: 'Program_Tahunan_Alquran_Hadits_K4.xlsx',
    folder: 'Program Tahunan',
    academicYear: '2026/2027',
    size: '2.4 MB',
    lastUpdated: '2026-06-12',
    updatedBy: 'Ustadz Hanif Al-Hafiz',
    currentVersion: 3,
    description: 'Alokasi pokok materi pembelajaran membaca dan menerjemahkan surah pendek.',
    versions: [
      { version: 3, updatedAt: '2026-06-12', updatedBy: 'Ustadz Hanif Al-Hafiz', size: '2.4 MB', notes: 'Sesuai dengan rapat guru kurikulum merdeka' },
      { version: 2, updatedAt: '2026-06-05', updatedBy: 'Ustadz Hanif Al-Hafiz', size: '2.3 MB', notes: 'Perbaikan jam pelajaran terjadwal' },
      { version: 1, updatedAt: '2026-05-28', updatedBy: 'Ustadz Hanif Al-Hafiz', size: '2.0 MB', notes: 'Inisialisasi draf' }
    ]
  },
  {
    id: 'DOC-004',
    name: 'CP_Alquran_Hadits_Fase_B.pdf',
    folder: 'CP',
    academicYear: '2026/2027',
    size: '3.1 MB',
    lastUpdated: '2026-06-02',
    updatedBy: 'Ustadz Ahmad Al-Faruq, M.Pd.',
    currentVersion: 1,
    description: 'Salinan resmi Capaian Pembelajaran Kemenag RI untuk Madrasah Ibtidaiyah.',
    versions: [
      { version: 1, updatedAt: '2026-06-02', updatedBy: 'Ustadz Ahmad Al-Faruq, M.Pd.', size: '3.1 MB', notes: 'Salinan asli Kementerian Agama' }
    ]
  },
  {
    id: 'DOC-005',
    name: 'LKPD_Hukum_Tajwid_Nun_Mati.pdf',
    folder: 'LKPD',
    academicYear: '2026/2027',
    size: '1.5 MB',
    lastUpdated: '2026-06-16',
    updatedBy: 'Ustadzah Siti Nurhaliza, S.Pd.I.',
    currentVersion: 1,
    description: 'Lembar Kerja Peserta Didik untuk latihan klasifikasi lafal Idzhar dan Idgham.',
    versions: [
      { version: 1, updatedAt: '2026-06-16', updatedBy: 'Ustadzah Siti Nurhaliza, S.Pd.I.', size: '1.5 MB', notes: 'Siap dicetak untuk tugas evaluasi harian santri' }
    ]
  },
  {
    id: 'DOC-006',
    name: 'Foto_Kegiatan_Idul_Adha_1447H.jpg',
    folder: 'Foto',
    academicYear: '2025/2026',
    size: '8.4 MB',
    lastUpdated: '2026-05-30',
    updatedBy: 'Operator Yayasan',
    currentVersion: 1,
    description: 'Dokumentasi penyembelihan hewan kurban bersama santri SD Islam Al Faraby.',
    versions: [
      { version: 1, updatedAt: '2026-05-30', updatedBy: 'Operator Yayasan', size: '8.4 MB', notes: 'Aset dokumentasi Humas madrasah' }
    ]
  }
];

export default function ArsipDigitalView({ files, onAddFile, onDeleteFile }: ArsipDigitalViewProps) {
  // Folder list structure based on "Administrasi Guru" parent requirement
  const SUB_FOLDERS = [
    'Modul Ajar',
    'Program Tahunan',
    'Program Semester',
    'ATP',
    'CP',
    'TP',
    'LKPD',
    'Penilaian',
    'Laporan',
    'Sertifikat',
    'Foto',
    'Dokumen Pendukung'
  ];

  // Archive & Google Drive states
  const [currentFolder, setCurrentFolder] = useState<string | null>(null); // null means root of Administrasi Guru
  const [academicYearFilter, setAcademicYearFilter] = useState<string>('2026/2027'); // "Arsip otomatis berdasarkan tahun pelajaran"
  const [searchTerm, setSearchTerm] = useState('');
  
  // Storage source simulation
  const [driveConnected, setDriveConnected] = useState(true);
  
  // Selected Document Detail preview state
  const [selectedDoc, setSelectedDoc] = useState<ArchivedDocument | null>(INITIAL_FOLDERED_FILES[0]);
  const [documents, setDocuments] = useState<ArchivedDocument[]>(INITIAL_FOLDERED_FILES);

  // Upload States
  const [inputFileName, setInputFileName] = useState('');
  const [inputDescription, setInputDescription] = useState('');
  const [inputTargetFolder, setInputTargetFolder] = useState('Modul Ajar');
  const [inputAcademicYear, setInputAcademicYear] = useState('2026/2027');
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [uploadState, setUploadState] = useState<'idle' | 'uploading' | 'completed'>('idle');

  // Multi-step safety delete
  const [docToDelete, setDocToDelete] = useState<ArchivedDocument | null>(null);
  const [deleteConfirmationPhrase, setDeleteConfirmationPhrase] = useState('');

  // Auto Archive trigger - Archive Old files based on year!
  const triggerAutoArchive = () => {
    alert('Sistem mendeteksi 2 dokumen versi draf lama sukses diarsipkan dan ditandai ke kategori Tahun Pelajaran lalu dengan aman!');
  };

  // Submit file upload
  const handleUploadSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputFileName.trim()) return;

    setUploadState('uploading');
    
    // Simulate short Google Drive uploading latency
    setTimeout(() => {
      const newDoc: ArchivedDocument = {
        id: 'DOC-' + Date.now().toString().slice(-4),
        name: inputFileName.includes('.') ? inputFileName : `${inputFileName}.pdf`,
        folder: currentFolder || inputTargetFolder,
        academicYear: inputAcademicYear,
        size: (Math.random() * 4 + 1).toFixed(1) + ' MB',
        lastUpdated: new Date().toISOString().split('T')[0],
        updatedBy: 'Ustadzah Siti Nurhaliza, S.Pd.I.',
        currentVersion: 1,
        description: inputDescription || 'Dokumen administrasi baru madrasah Al Faraby.',
        versions: [
          {
            version: 1,
            updatedAt: new Date().toISOString().split('T')[0],
            updatedBy: 'Ustadzah Siti Nurhaliza, S.Pd.I.',
            size: '2.5 MB',
            notes: 'Mula unggah versi 1 reguler.'
          }
        ]
      };

      setDocuments(prev => [newDoc, ...prev]);
      setSelectedDoc(newDoc);
      setUploadState('completed');
      
      setTimeout(() => {
        setShowUploadModal(false);
        setUploadState('idle');
        setInputFileName('');
        setInputDescription('');
        
        // Also add to global app context files
        const mappedFile: DigitalFile = {
          id: newDoc.id,
          name: newDoc.name,
          type: 'PDF',
          url: '#',
          lastUpdated: newDoc.lastUpdated,
          size: newDoc.size
        };
        onAddFile(mappedFile);
      }, 500);

    }, 1200);
  };

  const handleCreateNewVersion = () => {
    if (!selectedDoc) return;
    const newNote = prompt('Masukkan catatan pembaruan untuk Versi Baru (v' + (selectedDoc.currentVersion + 1) + '):');
    if (newNote === null) return;

    const currentYear = new Date().toISOString().split('T')[0];
    const newSize = (parseFloat(selectedDoc.size) + (Math.random() * 0.4 - 0.2)).toFixed(1) + ' MB';
    
    const updatedDocs = documents.map(d => {
      if (d.id === selectedDoc.id) {
        const nextVer = d.currentVersion + 1;
        const newVerList = [
          {
            version: nextVer,
            updatedAt: currentYear,
            updatedBy: 'Ustadzah Siti Nurhaliza, S.Pd.I.',
            size: newSize,
            notes: newNote || 'Penyesuaian bab materi baru.'
          },
          ...d.versions
        ];
        return {
          ...d,
          size: newSize,
          lastUpdated: currentYear,
          currentVersion: nextVer,
          versions: newVerList
        };
      }
      return d;
    });

    setDocuments(updatedDocs);
    const updatedSingle = updatedDocs.find(d => d.id === selectedDoc.id);
    if (updatedSingle) setSelectedDoc(updatedSingle);
    alert(`Sukses memperbarui dokumen ke Versi ${selectedDoc.currentVersion + 1}! Sinkron berkas aman.`);
  };

  // Safe delete document
  const triggerDeleteDoc = (doc: ArchivedDocument) => {
    setDocToDelete(doc);
    setDeleteConfirmationPhrase('');
  };

  const executeDeleteDoc = () => {
    if (!docToDelete) return;
    if (deleteConfirmationPhrase.toUpperCase() !== 'SINKRON') {
      alert('Gagal memverifikasi. Silakan ketik string pengaman "SINKRON".');
      return;
    }

    setDocuments(prev => prev.filter(d => d.id !== docToDelete.id));
    if (selectedDoc?.id === docToDelete.id) {
      setSelectedDoc(null);
    }
    onDeleteFile(docToDelete.id);
    setDocToDelete(null);
    alert('Dokumen berhasil dihapus dari cloud Google Drive.');
  };

  // Filters logic
  const filteredList = documents.filter(doc => {
    const inCurrentFolder = currentFolder === null || doc.folder === currentFolder;
    const matchesYear = doc.academicYear === academicYearFilter;
    const matchesSearch = doc.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          doc.description.toLowerCase().includes(searchTerm.toLowerCase());
    return inCurrentFolder && matchesYear && matchesSearch;
  });

  return (
    <div id="arsip-digital-premium-wrapper" className="space-y-6 text-xxs">
      
      {/* HEADER SECTION WITH CLOUD INTEGRATION INDICATOR */}
      <div className="flex flex-col xl:flex-row xl:items-center justify-between pb-4 border-b border-slate-200 gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="bg-blue-150 text-blue-800 text-xxxxs uppercase font-extrabold px-2.5 py-1 rounded-full">
              Modul 11 Terproteksi
            </span>
            <h2 className="text-xl font-bold text-slate-800 school-display">
              Administrasi & Arsip Digital Terpadu
            </h2>
          </div>
          <p className="text-xxs text-slate-500 mt-1">
            Repositori pemberkasan yang dipetakan langsung dengan folder Google Drive sekolah. Dilengkapi pelacakan versi berkas, pencarian dinamis, dan kategori tahun pelajaran.
          </p>
        </div>

        {/* DRIVE SYNC TRAY METRICS */}
        <div className="flex items-center gap-3 bg-slate-50 border border-slate-150 p-2.5 rounded-2xl">
          <div className="flex items-center gap-2 pr-3 border-r border-slate-200">
            <Cloud className={`h-4.5 w-4.5 ${driveConnected ? 'text-emerald-600 animate-pulse' : 'text-slate-400'}`} />
            <div>
              <div className="text-[10px] font-extrabold text-slate-700 leading-none">Status Google Drive</div>
              <p className="text-[8px] text-slate-440 font-semibold mt-0.5">Terkoneksi (al-faraby-cloud@gmail.com)</p>
            </div>
          </div>

          <button
            onClick={() => {
              setDriveConnected(!driveConnected);
              alert(driveConnected ? 'Google Drive Dinonaktifkan.' : 'Google Drive sukses Tersinkronisasi Ulang!');
            }}
            className="bg-white hover:bg-slate-100 text-slate-600 font-bold px-3 py-1.5 rounded-lg border border-slate-200 cursor-pointer text-[9px]"
          >
            Sambut Ulang Koneksi
          </button>
        </div>
      </div>

      {/* TOP FILTERS AND ACTION BUTTONS */}
      <div className="bg-white p-4 rounded-2xl border border-slate-150 shadow-xxs flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3 flex-wrap">
          
          {/* SEARCH FIELD */}
          <div className="relative w-64">
            <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
            <input
              type="text"
              placeholder="Cari berkas modul bimbingan..."
              className="w-full text-xs pl-9 pr-4 py-2 rounded-xl bg-slate-50 border border-slate-200 focus:outline-none focus:border-brand-green-600 focus:bg-white text-slate-800"
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
            />
          </div>

          {/* DYNAMIC ACADEMIC YEAR FILE ARCHIVER SELECTOR */}
          <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200 px-3 py-1.5 rounded-xl">
            <Calendar className="h-4 w-4 text-blue-700" />
            <span className="font-extrabold text-slate-600 text-[10px]">Tahun Pelajaran (Arsip):</span>
            <select
              value={academicYearFilter}
              onChange={e => setAcademicYearFilter(e.target.value)}
              className="bg-transparent border-none text-[10px] font-bold text-slate-800 focus:outline-none cursor-pointer"
            >
              <option value="2026/2027">2026/2027 (Berjalan)</option>
              <option value="2025/2026">2025/2026 (Arsip Lama)</option>
              <option value="2024/2025">2024/2025 (Arsip Lama)</option>
            </select>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* AUTOMATED YEARLY ARCHIVE BUTTON */}
          <button
            onClick={triggerAutoArchive}
            className="bg-slate-50 hover:bg-slate-100 text-slate-600 font-bold px-3.5 py-2 rounded-xl border border-slate-200 flex items-center gap-1.5 cursor-pointer transition text-[10px]"
            title="Arsip otomatis berdasarkan tahun pelajaran"
          >
            <Layers className="h-3.5 w-3.5" />
            Arsip Otomatis Dokumen Lama
          </button>

          {/* UPLOAD FILE TRIGGER */}
          <button
            onClick={() => setShowUploadModal(true)}
            className="bg-brand-green-700 hover:bg-brand-green-800 text-white font-bold px-4 py-2 rounded-xl shadow-xs transition flex items-center gap-1.5 cursor-pointer text-[10px]"
          >
            <Upload className="h-4 w-4" />
            Unggah Berkas Baru
          </button>
        </div>
      </div>

      {/* CORE WORKSPACE SCREEN: PATH NAVIGATOR, FOLDERS TREE, AND FILES */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        
        {/* FOLDERS GRID SYSTEM (1 col) */}
        <div className="bg-white rounded-2xl border border-slate-150 shadow-xxs p-4 space-y-4">
          <div className="pb-2.5 border-b border-slate-100 flex items-center justify-between">
            <span className="font-extrabold text-[10px] text-slate-500 uppercase tracking-wider flex items-center gap-1">
              <Folder className="h-4 w-4 text-indigo-700" />
              Folder Administrasi Guru
            </span>
            {currentFolder && (
              <button
                onClick={() => setCurrentFolder(null)}
                className="text-brand-green-700 hover:underline font-bold text-[9px] flex items-center gap-0.5"
              >
                <ArrowLeft className="h-3 w-3" /> Beranda
              </button>
            )}
          </div>

          <div className="space-y-1 max-h-120 overflow-y-auto">
            {/* Root item representation */}
            <div
              onClick={() => setCurrentFolder(null)}
              className={`p-2 rounded-xl border cursor-pointer transition flex items-center justify-between ${
                currentFolder === null ? 'border-brand-green-600 bg-brand-green-50/20 font-bold text-brand-green-900' : 'border-slate-100 bg-slate-50/30 hover:bg-slate-50'
              }`}
            >
              <div className="flex items-center gap-2">
                <span className="p-1 rounded bg-white border border-slate-200">
                  <FolderOpen className="h-3.5 w-3.5 text-brand-green-700" />
                </span>
                <span>Semua Dokumen</span>
              </div>
              <ChevronRight className="h-3.5 w-3.5 text-slate-400" />
            </div>

            {/* Folder tree maps */}
            {SUB_FOLDERS.map(f => {
              const isSelected = currentFolder === f;
              const documentCount = documents.filter(d => d.folder === f && d.academicYear === academicYearFilter).length;
              return (
                <div
                  key={f}
                  onClick={() => setCurrentFolder(f)}
                  className={`p-2 rounded-xl border cursor-pointer transition flex items-center justify-between ${
                    isSelected ? 'border-brand-green-600 bg-brand-green-50/20 font-bold text-brand-green-900' : 'border-slate-100 bg-slate-50/30 hover:bg-slate-50'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <span className="p-1 rounded bg-white border border-slate-200">
                      <Folder className={`h-3.5 w-3.5 ${isSelected ? 'text-brand-green-700 fill-brand-green-100' : 'text-slate-400'}`} />
                    </span>
                    <span className="line-clamp-1">{f}</span>
                  </div>
                  <span className="bg-slate-100 text-slate-500 font-mono text-[9px] px-1.5 py-0.2 rounded font-extrabold ml-2 shrink-0">
                    {documentCount}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* DOCUMENTS LIST & VIEW DETAILS (3 cols partitioned) */}
        <div className="lg:col-span-3 grid grid-cols-1 md:grid-cols-2 gap-6">
          
          {/* MIDDLE COLUMN: ACTUAL FILES (1.5 cols) */}
          <div className="bg-white rounded-2xl border border-slate-150 shadow-xxs p-4 space-y-4">
            <div className="pb-2 border-b border-slate-100 flex items-center justify-between">
              <span className="font-extrabold text-[10px] text-slate-500 uppercase tracking-widest leading-none">
                File di {currentFolder || 'Root / Administrasi Guru'} ({filteredList.length})
              </span>
            </div>

            <div className="space-y-1.5 max-h-120 overflow-y-auto pr-1">
              {filteredList.length === 0 ? (
                <div className="py-20 text-center text-slate-400 flex flex-col items-center justify-center space-y-2">
                  <Folder open={false} className="h-10 w-10 text-slate-200" />
                  <div>
                    <h5 className="font-bold text-slate-600 text-xxs">Folder Kosong</h5>
                    <p className="text-[10px] mt-0.5">Belum ada berkas pada Tahun Pelajaran {academicYearFilter} di folder ini.</p>
                  </div>
                </div>
              ) : (
                filteredList.map(item => {
                  const isActive = selectedDoc?.id === item.id;
                  return (
                    <div
                      key={item.id}
                      onClick={() => setSelectedDoc(item)}
                      className={`p-3 rounded-xl border text-left cursor-pointer transition flex items-center justify-between gap-3 ${
                        isActive ? 'border-brand-green-600 bg-brand-green-50/20' : 'border-slate-150 bg-slate-50/10 hover:bg-slate-50'
                      }`}
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <div className="p-2 bg-white border border-slate-200 text-blue-700 rounded-lg shrink-0">
                          <FileText className="h-4.5 w-4.5" />
                        </div>
                        <div className="min-w-0">
                          <h4 className="font-bold text-slate-850 line-clamp-1">{item.name}</h4>
                          <div className="text-[10px] text-slate-400 mt-0.5 font-semibold flex items-center gap-1.5 flex-wrap">
                            <span className="bg-slate-100 text-slate-600 px-1 py-0.2 rounded text-[8px] font-bold">{item.folder}</span>
                            <span>&bull; {item.size}</span>
                            <span>&bull; v{item.currentVersion}</span>
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-1 shrink-0">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            alert(`Unduh berkas "${item.name}" sukses.`);
                          }}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-indigo-800 hover:bg-slate-100"
                          title="Unduh Berkas"
                        >
                          <Download className="h-3.5 w-3.5" />
                        </button>
                        <button
                          onClick={(e) => { e.stopPropagation(); triggerDeleteDoc(item); }}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50"
                          title="Hapus permanen"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>

          {/* RIGHT COLUMN: PREVIEW & DOCUMENT VERSION TIMELINE (1.5 cols) */}
          <div className="space-y-4">
            {selectedDoc ? (
              <div className="bg-white rounded-2xl border border-slate-150 shadow-xxs p-5 space-y-4">
                
                {/* File heading meta */}
                <div className="pb-3 border-b border-slate-100 flex items-start justify-between gap-3">
                  <div className="space-y-0.25">
                    <span className="bg-indigo-50 text-indigo-800 px-2 py-0.5 rounded font-extrabold text-[8.5px]">
                      Folder: {selectedDoc.folder} &bull; TA {selectedDoc.academicYear}
                    </span>
                    <h3 className="font-bold text-[11px] text-slate-800 leading-snug pt-1">
                      {selectedDoc.name}
                    </h3>
                  </div>

                  <button
                    onClick={handleCreateNewVersion}
                    className="p-1 px-2.5 rounded bg-brand-green-700 text-white font-bold hover:bg-brand-green-800 cursor-pointer text-[9px] flex items-center gap-1 transition"
                  >
                    <History className="h-3 w-3" /> Revisi Baru
                  </button>
                </div>

                {/* Description of file */}
                <div className="p-3 bg-slate-50 border border-slate-100 text-[10px]/relaxed text-slate-600 rounded-xl">
                  <span className="font-bold text-slate-850 block mb-0.5">Ringkasan Deskripsi Dokumen:</span>
                  <p>{selectedDoc.description || 'Tidak ada catatan tambahan bagi berkas ini.'}</p>
                </div>

                {/* FILE PREVIEW WINDOW SIMULATION */}
                <div className="bg-slate-900 text-white p-4 rounded-xl min-h-[160px] flex flex-col justify-between border border-slate-950 font-mono text-[9px]">
                  <div className="flex justify-between items-center pb-2 border-b border-slate-800 text-[8.5px] font-bold text-slate-400">
                    <span>LIVE DOCUMENT PRATINJAU SECURE G-DRIVE</span>
                    <Eye className="h-3.5 w-3.5 text-emerald-500 fill-emerald-400" />
                  </div>

                  <div className="flex-grow my-4 space-y-2 text-slate-200">
                    <p className="font-bold text-white border-b border-slate-850 pb-1 uppercase tracking-wider text-[9.5px]">
                      === Dokumen Pendidikan Al Faraby ===
                    </p>
                    <p>Status: v{selectedDoc.currentVersion} Disetujui Wali Kelas</p>
                    <p>Ukuran: {selectedDoc.size} &bull; Penulis: {selectedDoc.updatedBy}</p>
                    <p className="text-slate-400 italic">"Memajukan budi kultural pembiasaan tarbiyah."</p>
                  </div>

                  <div className="text-[8px] text-slate-400 text-center">
                    G-Suite Integrasi Terotentikasi &bull; ID: {selectedDoc.id}
                  </div>
                </div>

                {/* DOCUMENT VERSION HISTORY TRACKER (Pelacakan versi berkas) */}
                <div className="space-y-3.5">
                  <div className="flex items-center gap-1 border-b border-slate-100 pb-1.5">
                    <History className="h-4.5 w-4.5 text-blue-700" />
                    <span className="font-extrabold text-[10px] text-slate-500 uppercase tracking-wider">Histori Kegiatanan & Versi Dokumen</span>
                  </div>

                  <div className="space-y-2.5">
                    {selectedDoc.versions.map((ver, vIdx) => (
                      <div key={vIdx} className="bg-slate-50/50 p-2.5 rounded-xl border border-slate-150 flex items-start gap-2.5">
                        <span className="px-1.5 py-0.5 bg-blue-105 text-blue-800 font-extrabold font-mono rounded text-[8px] border border-blue-200 shrink-0">
                          v{ver.version}
                        </span>
                        <div className="min-w-0 text-[10px]">
                          <div className="font-bold text-slate-750">{ver.notes}</div>
                          <div className="text-[8.5px] text-slate-450 mt-1 font-semibold flex items-center gap-1.5">
                            <span>Oleh: {ver.updatedBy}</span>
                            <span>&bull;</span>
                            <span>Tanggal: {ver.updatedAt}</span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

              </div>
            ) : (
              <div className="bg-white rounded-2xl border border-slate-150 p-12 text-center text-slate-400">
                <Info className="h-10 w-10 text-slate-200 mx-auto mb-2" />
                <p className="font-bold">Silakan pilih berkas di sebelah kiri untuk melihat rincian versi berkas & pratinjau digital.</p>
              </div>
            )}
          </div>

        </div>

      </div>

      {/* 1. COMPREHENSIVE UPLOAD MODAL DRAWERS */}
      {showUploadModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <form onSubmit={handleUploadSubmit} className="bg-white rounded-2xl w-full max-w-md shadow-xl p-6 border border-slate-100 animate-in fade-in zoom-in-95 duration-200 space-y-4">
            <div className="pb-2 border-b border-slate-150 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Upload className="h-5 w-5 text-brand-green-700" />
                <h3 className="font-bold text-sm text-slate-800 school-display">Formulir Kirim Berkas Cloud G-Drive</h3>
              </div>
              <button
                type="button"
                onClick={() => setShowUploadModal(false)}
                className="text-slate-400 hover:text-slate-700 font-bold"
              >
                Tutup
              </button>
            </div>

            <div className="space-y-3.5">
              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Nama Berkas Pendidikan</label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: Modul_Ajar_Aqidah_Akhlak_V3.pdf"
                  className="w-full text-xs px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:bg-white focus:border-brand-green-600 text-slate-800 font-medium"
                  value={inputFileName}
                  onChange={e => setInputFileName(e.target.value)}
                />
              </div>

              {!currentFolder && (
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Pilih Folder Tujuan</label>
                  <select
                    value={inputTargetFolder}
                    onChange={e => setInputTargetFolder(e.target.value)}
                    className="w-full text-xs px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-bold text-slate-800 focus:outline-none"
                  >
                    {SUB_FOLDERS.map(f => (
                      <option key={f} value={f}>{f}</option>
                    ))}
                  </select>
                </div>
              )}

              <div className="grid grid-cols-2 gap-3.5">
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Tahun Pelajaran</label>
                  <select
                    value={inputAcademicYear}
                    onChange={e => setInputAcademicYear(e.target.value)}
                    className="w-full text-xs px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:bg-white text-slate-700"
                  >
                    <option value="2026/2027">2026/2027 (Berjalan)</option>
                    <option value="2025/2026">2025/2026</option>
                    <option value="2024/2025">2024/2025</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Hak Otentikasi Akses</label>
                  <div className="flex items-center gap-1 bg-slate-50 border border-slate-200 px-3 py-2 rounded-xl text-slate-500 font-bold">
                    <Settings className="h-4 w-4" /> Guru Terdaftar Only
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Deskripsi & Catatan Singkat</label>
                <textarea
                  rows={2}
                  placeholder="Keterangan isi berkas atau catatan perbaikan..."
                  className="w-full text-xs p-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:bg-white focus:border-brand-green-600 text-slate-800 leading-normal"
                  value={inputDescription}
                  onChange={e => setInputDescription(e.target.value)}
                />
              </div>
            </div>

            {uploadState === 'uploading' ? (
              <div className="space-y-2 pt-2">
                <div className="w-full bg-slate-100 rounded-full h-1.5 overflow-hidden">
                  <div className="bg-brand-green-600 h-full rounded-full animate-pulse" style={{ width: '70%' }} />
                </div>
                <p className="text-center text-[9px] font-bold text-brand-green-800 animate-pulse">Mengunggah ke Folder Google Drive Al Faraby...</p>
              </div>
            ) : uploadState === 'completed' ? (
              <div className="py-2 text-center text-brand-green-800 font-bold rounded-lg bg-brand-green-50 flex items-center justify-center gap-1 text-[10px]">
                <CheckCircle className="h-4.5 w-4.5" /> Berkas Sukses Diunggah!
              </div>
            ) : (
              <div className="flex justify-end gap-2 text-xxs pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowUploadModal(false)}
                  className="px-4 py-2 font-bold text-slate-500 hover:text-slate-800 cursor-pointer"
                >
                  Batalkan
                </button>
                <button
                  type="submit"
                  className="bg-brand-green-700 hover:bg-brand-green-800 text-white font-bold px-5 py-2 rounded-xl transition cursor-pointer"
                >
                  Mulai Unggah
                </button>
              </div>
            )}
          </form>
        </div>
      )}

      {/* 2. SAFETY DESTRUCTIVE ACTION CONFIRMATION MODAL */}
      {docToDelete && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl w-full max-w-sm shadow-xl p-6 border border-slate-100 animate-in fade-in zoom-in-95 duration-200">
            <div className="flex items-center gap-3 text-rose-700">
              <div className="p-2 rounded-full bg-rose-50">
                <AlertTriangle className="h-6 w-6 stroke-rose-600" />
              </div>
              <div>
                <h3 className="font-bold text-sm school-display text-slate-800">Konfirmasi Penghapusan Permanen</h3>
                <p className="text-xxs text-slate-500">Menghapus file digital dari server sekolah.</p>
              </div>
            </div>

            <div className="bg-rose-50 border border-rose-100 p-3 rounded-lg text-xxs text-rose-800 mt-4 leading-normal">
              <strong>PERINGATAN SEKURITAS:</strong> Anda berniat menghapus permanen dokumen "<strong>{docToDelete.name}</strong>". Tindakan ini akan menghapusnya dari struktur berkas Google Drive guru sekolah.
            </div>

            <div className="space-y-3 mt-4 text-xs">
              <label className="block text-xxs font-bold text-slate-500 uppercase">
                Ketik Kata Kunci Pengaman "<span className="text-rose-600 font-bold">SINKRON</span>" Untuk Konfirmasi:
              </label>
              <input
                type="text"
                value={deleteConfirmationPhrase}
                onChange={e => setDeleteConfirmationPhrase(e.target.value)}
                placeholder="Ketik SINKRON"
                className="w-full text-xs p-2 border border-slate-200 rounded focus:ring-1 focus:ring-rose-500 focus:outline-none uppercase font-bold"
              />
            </div>

            <div className="flex items-center justify-end gap-2 mt-5 pt-3 border-t border-slate-150">
              <button
                onClick={() => { setDocToDelete(null); setDeleteConfirmationPhrase(''); }}
                className="px-4 py-2 text-xs font-semibold text-slate-500 hover:text-slate-800 cursor-pointer"
              >
                Batalkan
              </button>
              <button
                disabled={deleteConfirmationPhrase.toUpperCase() !== 'SINKRON'}
                onClick={executeDeleteDoc}
                className="bg-rose-600 hover:bg-rose-700 disabled:opacity-30 text-white font-bold text-xs px-4 py-2 rounded shadow-xs cursor-pointer"
              >
                Hapus Selamanya
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
