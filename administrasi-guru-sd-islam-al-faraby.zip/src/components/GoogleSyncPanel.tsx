/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Cloud, CheckCircle2, RefreshCw, Layers, FileSpreadsheet, Calendar, Mail, FileText, ExternalLink } from 'lucide-react';
import { motion } from 'motion/react';

interface GoogleSyncPanelProps {
  lastSynced: {
    sheets: string | null;
    drive: string | null;
    calendar: string | null;
    gmail: string | null;
  };
  onTriggerSync: (type: 'sheets' | 'drive' | 'calendar' | 'gmail') => void;
}

export default function GoogleSyncPanel({ lastSynced, onTriggerSync }: GoogleSyncPanelProps) {
  const [syncingStates, setSyncingStates] = useState<Record<string, boolean>>({});

  const handleSyncClick = (type: 'sheets' | 'drive' | 'calendar' | 'gmail') => {
    setSyncingStates(prev => ({ ...prev, [type]: true }));
    setTimeout(() => {
      onTriggerSync(type);
      setSyncingStates(prev => ({ ...prev, [type]: false }));
    }, 1200);
  };

  const syncDetails = [
    {
      type: 'sheets' as const,
      name: 'Google Sheets DB',
      desc: 'Pemetaan data siswa & catatan absensi real-time',
      lastTime: lastSynced.sheets,
      icon: FileSpreadsheet,
      color: 'text-emerald-600',
      bgColor: 'bg-emerald-50',
      borderColor: 'border-emerald-200'
    },
    {
      type: 'drive' as const,
      name: 'Google Docs & Drive',
      desc: 'Ekspor berkas RPP, modul ajar, & transkrip raport',
      lastTime: lastSynced.drive,
      icon: FileText,
      color: 'text-blue-600',
      bgColor: 'bg-blue-50',
      borderColor: 'border-blue-200'
    },
    {
      type: 'calendar' as const,
      name: 'Google Calendar',
      desc: 'Jadwal tatap muka, rapat guru, & kalender akademik',
      lastTime: lastSynced.calendar,
      icon: Calendar,
      color: 'text-rose-600',
      bgColor: 'bg-rose-50',
      borderColor: 'border-rose-200'
    },
    {
      type: 'gmail' as const,
      name: 'Gmail SMTP',
      desc: 'Pengiriman notifikasi berkala otomatis ke orang tua',
      lastTime: lastSynced.gmail,
      icon: Mail,
      color: 'text-amber-600',
      bgColor: 'bg-amber-50',
      borderColor: 'border-amber-200'
    }
  ];

  return (
    <div id="google-sync-panel-container" className="bg-white rounded-2xl p-6 border border-slate-100 shadow-xs">
      <div className="flex items-center justify-between mb-6 pb-4 border-b border-slate-100">
        <div>
          <h2 className="text-lg font-bold text-slate-800 school-display flex items-center gap-2">
            <Cloud className="h-5 w-5 text-brand-green-600" />
            Integrasi Cloud Google Workspace
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Kelola sinkronisasi Google Apps Script dengan spreadsheet & dokumen pusat.
          </p>
        </div>
        <div className="flex items-center gap-2 bg-emerald-50 text-emerald-800 px-3 py-1.5 rounded-full text-xs font-semibold">
          <span className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />
          Koneksi Aktif
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {syncDetails.map((item) => {
          const Icon = item.icon;
          const isSyncing = syncingStates[item.type];
          return (
            <div
              key={item.type}
              className={`p-4 rounded-xl border ${item.borderColor} ${item.bgColor} transition-all duration-300 flex flex-col justify-between`}
            >
              <div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className={`p-2 rounded-lg bg-white shadow-xs ${item.color}`}>
                      <Icon className="h-5 w-5" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-sm text-slate-800 school-display">{item.name}</h4>
                      <p className="text-xxs text-slate-500 mt-0.5 leading-relaxed">{item.desc}</p>
                    </div>
                  </div>
                </div>
                
                <div className="mt-4 flex items-center gap-1.5 text-xs text-slate-600">
                  <CheckCircle2 className="h-3.5 w-3.5 text-emerald-500" />
                  <span>Tersinkron: </span>
                  <span className="font-semibold text-slate-800">
                    {item.lastTime ? item.lastTime : 'Sedang Menunggu'}
                  </span>
                </div>
              </div>

              <div className="mt-4 flex items-center justify-end gap-2">
                {item.type === 'sheets' && (
                  <a
                    href="https://docs.google.com/spreadsheets"
                    target="_blank"
                    rel="noreferrer"
                    className="text-xxs text-slate-500 hover:text-slate-800 flex items-center gap-1 mr-auto transition-colors"
                  >
                    Buka Sheet <ExternalLink className="h-2.5 w-2.5" />
                  </a>
                )}
                <button
                  id={`sync-btn-${item.type}`}
                  disabled={isSyncing}
                  onClick={() => handleSyncClick(item.type)}
                  className="bg-white hover:bg-slate-50 text-slate-700 disabled:text-slate-400 font-semibold text-xs px-3 py-1.5 rounded-lg border border-slate-200 transition-all shadow-xs flex items-center gap-1.5 cursor-pointer"
                >
                  <RefreshCw className={`h-3 w-3 ${isSyncing ? 'animate-spin text-brand-green-600' : ''}`} />
                  {isSyncing ? 'Menyinkronkan...' : 'Sinkronkan'}
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
