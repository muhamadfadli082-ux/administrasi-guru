/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef } from 'react';
import {
  Database,
  Plus,
  PlusCircle,
  FileQuestion,
  FileText,
  FileSpreadsheet,
  Layers,
  Image as ImageIcon,
  BookOpen,
  Settings,
  Sparkles,
  Download,
  Trash2,
  Edit2,
  CheckCircle,
  Upload,
  Search,
  Filter,
  Eye,
  ArrowRight,
  ClipboardList,
  RefreshCw,
  Printer,
  ChevronRight,
  Bookmark,
  Shuffle,
  GitCommit,
  Share2,
  X,
  FileDown
} from 'lucide-react';
import { Student, Subject } from '../types';

interface BankSoalViewProps {
  subjects: Subject[];
}

export interface Question {
  id: string;
  type: 'Pilihan Ganda' | 'Isian' | 'Menjodohkan' | 'Uraian';
  subjectId: string;
  subjectName: string;
  grade: string; // e.g. "Kelas 4", "Kelas 5"
  topic: string;
  difficulty: 'Mudah' | 'Sedang' | 'Sulit';
  cognitiveLevel: 'C1' | 'C2' | 'C3' | 'C4' | 'C5' | 'C6';
  questionText: string;
  imageUrl?: string;
  // For Pilihan Ganda:
  options?: string[];
  correctOptionIndex?: number;
  // For Isian:
  correctShortAnswer?: string;
  // For Menjodohkan:
  pairsLeft?: string[];
  pairsRight?: string[];
  correctPairs?: Record<string, string>; // left key -> right matched value
  // For Uraian:
  essayRubric?: string;
  points: number;
}

// Initial mockup data of Bank Soal
const INITIAL_BANK_SOAL: Question[] = [
  {
    id: 'Q001',
    type: 'Pilihan Ganda',
    subjectId: 'MAPEL01',
    subjectName: 'Aqidah Akhlak',
    grade: 'Kelas 4A',
    topic: 'Asmaul Husna',
    difficulty: 'Mudah',
    cognitiveLevel: 'C1',
    questionText: 'Allah SWT memiliki nama mulia Al-Bashir. Arti dari Asmaul Husna Al-Bashir adalah Maha...',
    options: ['Mendengar', 'Melihat', 'Mengetahui', 'Menguasai'],
    correctOptionIndex: 1,
    points: 10
  },
  {
    id: 'Q002',
    type: 'Pilihan Ganda',
    subjectId: 'MAPEL01',
    subjectName: 'Aqidah Akhlak',
    grade: 'Kelas 4A',
    topic: 'Adab Islami',
    difficulty: 'Sedang',
    cognitiveLevel: 'C2',
    questionText: 'Ketika mendengar kabar duka cita atau ditimpa musibah, lafadz thayyibah yang sebaiknya diucapkan oleh seorang mukmin adalah...',
    options: ['Subhanallah', 'Alhamdulillah', 'Tarji\' (Innalillahi wa inna ilaihi raji\'un)', 'Tahlil (Laa ilaha illallah)'],
    correctOptionIndex: 2,
    points: 10
  },
  {
    id: 'Q003',
    type: 'Isian',
    subjectId: 'MAPEL01',
    subjectName: 'Aqidah Akhlak',
    grade: 'Kelas 4A',
    topic: 'Rukun Iman',
    difficulty: 'Mudah',
    cognitiveLevel: 'C1',
    questionText: 'Kitab suci Zabur diturunkan oleh Allah SWT kepada Nabi...',
    correctShortAnswer: 'Daud',
    points: 15
  },
  {
    id: 'Q004',
    type: 'Menjodohkan',
    subjectId: 'MAPEL01',
    subjectName: 'Aqidah Akhlak',
    grade: 'Kelas 4A',
    topic: 'Sifat Allah',
    difficulty: 'Sedang',
    cognitiveLevel: 'C3',
    questionText: 'Jodohkanlah sifat-sifat wajib Allah berikut dengan artinya yang benar!',
    pairsLeft: ['Wujud', 'Qidam', 'Baqa', 'Wahdaniyah'],
    pairsRight: ['Kekal', 'Terdahulu', 'Ada', 'Maha Esa'],
    correctPairs: {
      'Wujud': 'Ada',
      'Qidam': 'Terdahulu',
      'Baqa': 'Kekal',
      'Wahdaniyah': 'Maha Esa'
    },
    points: 20
  },
  {
    id: 'Q005',
    type: 'Uraian',
    subjectId: 'MAPEL01',
    subjectName: 'Aqidah Akhlak',
    grade: 'Kelas 4A',
    topic: 'Adab Kepada Orang Tua',
    difficulty: 'Sulit',
    cognitiveLevel: 'C4',
    questionText: 'Uraikanlah sekurang-kurangnya 3 (tiga) contoh konkret perilaku bakti kepada kedua orang tua (birrul walidain) yang dapat dilakukan anak dalam kehidupan sehari-hari di rumah beserta landasan keuntungannya!',
    essayRubric: 'Skor 15: Menyebutkan 3 contoh lengkap dengan penjelasan logis.\nSkor 10: Menyebutkan 2 contoh dengan penjelasan baik.\nSkor 5: Hanya menyebutkan contoh tanpa deskripsi.\nSkor 0: Tidak menjawab.',
    points: 25
  },
  {
    id: 'Q006',
    type: 'Pilihan Ganda',
    subjectId: 'MAPEL02',
    subjectName: 'Al-Qur\'an Hadits',
    grade: 'Kelas 4A',
    topic: 'Hukum Tajwid',
    difficulty: 'Sedang',
    cognitiveLevel: 'C2',
    questionText: 'Apabila ada nun mati atau tanwin bertemu dengan huruf Ba (ب), maka hukum bacaan tajwid tersebut dinamakan...',
    options: ['Ikhfa Syafawi', 'Idzhar Halqi', 'Iqlab', 'Idgham Bighunnah'],
    correctOptionIndex: 2,
    points: 10
  }
];

// Preloaded Bank Gambar
const PRELOADED_IMAGES = [
  { id: 'img-sholat', name: 'Gerakan Ruku Sholat', url: 'https://images.unsplash.com/photo-1590073844006-33379778ae09?auto=format&fit=crop&q=80&w=200' },
  { id: 'img-quran', name: 'Mushaf Al-Quran Terbuka', url: 'https://images.unsplash.com/photo-1609599006353-e629bcab006d?auto=format&fit=crop&q=80&w=200' },
  { id: 'img-kabah', name: 'Masjidil Haram Ka\'bah', url: 'https://images.unsplash.com/photo-1542856391-010fb87dcfed?auto=format&fit=crop&q=80&w=200' },
  { id: 'img-masjid', name: 'Kubah Masjid Hijau', url: 'https://images.unsplash.com/photo-1564507592333-c60657eea523?auto=format&fit=crop&q=80&w=200' },
  { id: 'img-kaligrafi', name: 'Kaligrafi Bismillah', url: 'https://images.unsplash.com/photo-1582845512747-e421d1ec9fa8?auto=format&fit=crop&q=80&w=200' }
];

export default function BankSoalView({ subjects }: BankSoalViewProps) {
  const [bankSoal, setBankSoal] = useState<Question[]>(INITIAL_BANK_SOAL);
  const [selectedSubTab, setSelectedSubTab] = useState<'Daftar' | 'Input' | 'Import' | 'Gambar' | 'KisiKisi' | 'Generator'>('Daftar');

  // Search & Filters state
  const [searchQuery, setSearchQuery] = useState('');
  const [filterSubject, setFilterSubject] = useState('Semua');
  const [filterGrade, setFilterGrade] = useState('Semua');
  const [filterDifficulty, setFilterDifficulty] = useState('Semua');
  const [filterType, setFilterType] = useState('Semua');

  // Interactive Matcher state (Daftar preview)
  const [matchingSelections, setMatchingSelections] = useState<Record<string, string>>({});

  // Question Creator States
  const [creatorType, setCreatorType] = useState<'Pilihan Ganda' | 'Isian' | 'Menjodohkan' | 'Uraian'>('Pilihan Ganda');
  const [creatorSubjectId, setCreatorSubjectId] = useState(subjects[0]?.id || 'MAPEL01');
  const [creatorGrade, setCreatorGrade] = useState('Kelas 4A');
  const [creatorTopic, setCreatorTopic] = useState('');
  const [creatorDifficulty, setCreatorDifficulty] = useState<'Mudah' | 'Sedang' | 'Sulit'>('Sedang');
  const [creatorCognitive, setCreatorCognitive] = useState<'C1' | 'C2' | 'C3' | 'C4' | 'C5' | 'C6'>('C2');
  const [creatorText, setCreatorText] = useState('');
  const [creatorImageUrl, setCreatorImageUrl] = useState('');
  const [creatorPoints, setCreatorPoints] = useState<number>(10);

  // PG Creator inputs
  const [pgOptions, setPgOptions] = useState<string[]>(['Option A', 'Option B', 'Option C', 'Option D']);
  const [pgCorrectIndex, setPgCorrectIndex] = useState<number>(0);

  // Isian Creator inputs
  const [isianAnswer, setIsianAnswer] = useState('');

  // Menjodohkan Creator inputs
  const [pairsLeftInput, setPairsLeftInput] = useState<string>('As-Sami, Al-Bashir, Al-Lathif');
  const [pairsRightInput, setPairsRightInput] = useState<string>('Maha Mendengar, Maha Melihat, Maha Lembut');

  // Uraian Creator inputs
  const [essayRubricText, setEssayRubricText] = useState('');

  // Import Simulators
  const [importTextContent, setImportTextContent] = useState('');
  const [excelFileMockName, setExcelFileMockName] = useState('');
  const [excelFileSelected, setExcelFileSelected] = useState(false);
  const [isImportLoading, setIsImportLoading] = useState(false);
  const [importLog, setImportLog] = useState<string[]>([]);

  // Bank Gambar States
  const [uploadedImages, setUploadedImages] = useState(PRELOADED_IMAGES);
  const [imageUploadName, setImageUploadName] = useState('');
  const [imageUploadUrl, setImageUploadUrl] = useState('');

  // Kisi-Kisi States
  const [kisiGrade, setKisiGrade] = useState('Kelas 4A');
  const [kisiSubjectId, setKisiSubjectId] = useState(subjects[0]?.id || 'MAPEL01');
  const [kisiSemester, setKisiSemester] = useState<'Ganjil' | 'Genap'>('Ganjil');

  // Auto-generator States
  const [genSubjectId, setGenSubjectId] = useState(subjects[0]?.id || 'MAPEL01');
  const [genGrade, setGenGrade] = useState('Kelas 4A');
  const [genTotalQuestions, setGenTotalQuestions] = useState(10);
  const [genPGRatio, setGenPGRatio] = useState(50); // percentage
  const [genIsianRatio, setGenIsianRatio] = useState(20);
  const [genMenjodohkanRatio, setGenMenjodohkanRatio] = useState(10);
  const [genUraianRatio, setGenUraianRatio] = useState(20);
  const [generatedPaper, setGeneratedPaper] = useState<Question[] | null>(null);
  const [isCompiling, setIsCompiling] = useState(false);

  // Filter Logic
  const filteredQuestions = bankSoal.filter(q => {
    const matchesSearch = q.questionText.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          q.topic.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          q.id.toLowerCase().includes(searchQuery.toLowerCase());
    
    const targetSubject = subjects.find(s => s.id === q.subjectId);
    const matchesSubject = filterSubject === 'Semua' || q.subjectId === filterSubject;
    const matchesGrade = filterGrade === 'Semua' || q.grade === filterGrade;
    const matchesDifficulty = filterDifficulty === 'Semua' || q.difficulty === filterDifficulty;
    const matchesType = filterType === 'Semua' || q.type === filterType;
    
    return matchesSearch && matchesSubject && matchesGrade && matchesDifficulty && matchesType;
  });

  // Handle Input PG Option change
  const handleOptionEdit = (index: number, val: string) => {
    const next = [...pgOptions];
    next[index] = val;
    setPgOptions(next);
  };

  const addOptionField = () => {
    if (pgOptions.length < 5) {
      setPgOptions([...pgOptions, `Opsi Baru ${String.fromCharCode(65 + pgOptions.length)}`]);
    }
  };

  const removeOptionField = (index: number) => {
    if (pgOptions.length > 2) {
      const next = pgOptions.filter((_, i) => i !== index);
      setPgOptions(next);
      if (pgCorrectIndex >= next.length) {
        setPgCorrectIndex(0);
      }
    }
  };

  // Submit Interactive Question Creator
  const handleSubmitQuestion = (e: React.FormEvent) => {
    e.preventDefault();
    if (!creatorText.trim()) return;

    const actualSubjectObj = subjects.find(s => s.id === creatorSubjectId);
    const subjectName = actualSubjectObj ? actualSubjectObj.name : 'Mata Pelajaran';

    const newQuestion: Question = {
      id: 'Q' + (bankSoal.length + 1).toString().padStart(3, '0'),
      type: creatorType,
      subjectId: creatorSubjectId,
      subjectName: subjectName,
      grade: creatorGrade,
      topic: creatorTopic || 'Umum',
      difficulty: creatorDifficulty,
      cognitiveLevel: creatorCognitive,
      questionText: creatorText,
      imageUrl: creatorImageUrl || undefined,
      points: creatorPoints
    };

    if (creatorType === 'Pilihan Ganda') {
      newQuestion.options = pgOptions;
      newQuestion.correctOptionIndex = pgCorrectIndex;
    } else if (creatorType === 'Isian') {
      newQuestion.correctShortAnswer = isianAnswer || 'Kunci Jawaban';
    } else if (creatorType === 'Menjodohkan') {
      const itemsLeft = pairsLeftInput.split(',').map(s => s.trim()).filter(Boolean);
      const itemsRight = pairsRightInput.split(',').map(s => s.trim()).filter(Boolean);
      newQuestion.pairsLeft = itemsLeft;
      newQuestion.pairsRight = itemsRight;
      
      const parsedMatches: Record<string, string> = {};
      itemsLeft.forEach((left, index) => {
        if (itemsRight[index]) {
          parsedMatches[left] = itemsRight[index];
        }
      });
      newQuestion.correctPairs = parsedMatches;
    } else if (creatorType === 'Uraian') {
      newQuestion.essayRubric = essayRubricText || 'Petunjuk kriteria penilaian lengkap.';
    }

    setBankSoal(prev => [...prev, newQuestion]);
    alert('Alhamdulillah! Soal berhasil ditambahkan dengan klasifikasi adab dan kognitif terpadu.');
    
    // Clear Form fields
    setCreatorText('');
    setCreatorTopic('');
    setCreatorImageUrl('');
    setIsianAnswer('');
    setEssayRubricText('');
    setSelectedSubTab('Daftar');
  };

  // Simulated Importers
  const handleImportWordText = () => {
    if (!importTextContent.trim()) {
      alert('Tulis atau paste konten teks/soal terlebih dahulu!');
      return;
    }

    setIsImportLoading(true);
    setImportLog([]);

    setTimeout(() => {
      // Basic split simulator
      const lines = importTextContent.split('\n').filter(l => l.trim().length > 3);
      const newImported: Question[] = [];
      let tempLogs: string[] = ['Memulai ekstraksi format Microsoft Word (*.docx)...'];

      let counter = 0;
      lines.forEach((line, idx) => {
        // Simple search pattern: "1. text" or "Sebutkan..."
        if (/^\d+[\s.]/.test(line.trim())) {
          counter++;
          const cleanText = line.replace(/^\d+[\s.]/, '').trim();
          const isPG = cleanText.includes('?') && lines[idx + 1]?.toLowerCase().startsWith('a.');
          
          const subjectObj = subjects.find(s => s.id === creatorSubjectId);
          const subjName = subjectObj ? subjectObj.name : 'Mata Pelajaran';

          const item: Question = {
            id: 'Q-WD' + Math.floor(Math.random() * 1000).toString(),
            type: isPG ? 'Pilihan Ganda' : 'Uraian',
            subjectId: creatorSubjectId,
            subjectName: subjName,
            grade: creatorGrade,
            topic: creatorTopic || 'Import Word',
            difficulty: 'Sedang',
            cognitiveLevel: 'C2',
            questionText: cleanText,
            points: isPG ? 10 : 20
          };

          if (isPG) {
            const options: string[] = [];
            for (let i = 1; i <= 4; i++) {
              const optLine = lines[idx + i];
              if (optLine && /^[a-d][.\s]/i.test(optLine.trim())) {
                options.push(optLine.replace(/^[a-d][.\s]/i, '').trim());
              }
            }
            item.options = options.length ? options : ['A', 'B', 'C', 'D'];
            item.correctOptionIndex = 0; // default
          }

          newImported.push(item);
          tempLogs.push(`[Sukses] Baris ke-${idx + 1}: Terdeteksi sebagai Soal ${item.type} ("${cleanText.substring(0, 30)}...")`);
        }
      });

      if (!newImported.length) {
        tempLogs.push('[Umpan Balik] Gagal mendeteksi butir soal dengan penomoran standar. Diimpor sebagai 1 Soal Uraian tunggal.');
        const subjectObj = subjects.find(s => s.id === creatorSubjectId);
        newImported.push({
          id: 'Q-WD' + Math.floor(Math.random() * 1000).toString(),
          type: 'Uraian',
          subjectId: creatorSubjectId,
          subjectName: subjectObj ? subjectObj.name : 'Umum',
          grade: creatorGrade,
          topic: 'Import Word',
          difficulty: 'Sedang',
          cognitiveLevel: 'C2',
          questionText: importTextContent,
          points: 20
        });
      }

      setBankSoal(prev => [...prev, ...newImported]);
      tempLogs.push(`[Selesai] Total berhasil mengekstrak & mendaftarkan ${newImported.length} butir soal baru ke database.`);
      setImportLog(tempLogs);
      setIsImportLoading(false);
      setImportTextContent('');
    }, 1500);
  };

  const handleImportExcelDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const files = e.dataTransfer.files;
    if (files.length > 0) {
      setExcelFileMockName(files[0].name);
      setExcelFileSelected(true);
    }
  };

  const executeExcelImportSim = () => {
    if (!excelFileSelected) return;
    setIsImportLoading(true);
    setImportLog(['Meluncurkan mesin penyaring data Excel (*.xlsx)...']);

    setTimeout(() => {
      const subjectObj = subjects.find(s => s.id === creatorSubjectId);
      const subjName = subjectObj ? subjectObj.name : 'Mata Pelajaran';

      const mockExcelQuestions: Question[] = [
        {
          id: 'Q-EX' + Math.floor(Math.random() * 1000).toString(),
          type: 'Pilihan Ganda',
          subjectId: creatorSubjectId,
          subjectName: subjName,
          grade: creatorGrade,
          topic: 'Hasil Import Excel',
          difficulty: 'Mudah',
          cognitiveLevel: 'C1',
          questionText: 'Siapakah nama khalifah pertama dari Khulafaur Rasyidin dari baris 2 Excel?',
          options: ['Abu Bakar Ash-Shiddiq', 'Umar bin Khattab', 'Utsman bin Affan', 'Ali bin Abi Thalib'],
          correctOptionIndex: 0,
          points: 10
        },
        {
          id: 'Q-EX' + Math.floor(Math.random() * 1000).toString(),
          type: 'Isian',
          subjectId: creatorSubjectId,
          subjectName: subjName,
          grade: creatorGrade,
          topic: 'Hasil Import Excel',
          difficulty: 'Sedang',
          cognitiveLevel: 'C3',
          questionText: 'Berapakah jumlah rakaat shalat fardhu dalam sehari semalam bagi umat Islam?',
          correctShortAnswer: '17',
          points: 10
        }
      ];

      setBankSoal(prev => [...prev, ...mockExcelQuestions]);
      setImportLog([
        'Membaca Workbook Excel "Template_Bank_Soal.xlsx"...',
        '[Meneliti] Menemukan Sheet "Daftar_Soal"',
        '[Validasi] Baris 2: Sukses memuat tipe PG.',
        '[Validasi] Baris 3: Sukses memuat tipe Isian.',
        'Alhamdulillah, sinkronisasi 2 butir soal dari Excel selesai dilakukan!'
      ]);
      setIsImportLoading(false);
      setExcelFileSelected(false);
      setExcelFileMockName('');
    }, 1200);
  };

  // Image Upload Simulated Action
  const handleAddImageToBank = (e: React.FormEvent) => {
    e.preventDefault();
    if (!imageUploadName || !imageUploadUrl) return;

    setUploadedImages(prev => [
      ...prev,
      {
        id: 'img-' + Date.now().toString(),
        name: imageUploadName,
        url: imageUploadUrl
      }
    ]);
    setImageUploadName('');
    setImageUploadUrl('');
    alert('Gambar ilustrasi sukses ditambahkan ke media gallery Bank Gambar!');
  };

  // Exam Auto-Generator Engine
  const handleAutoGeneratePaper = () => {
    setIsCompiling(true);
    setGeneratedPaper(null);

    setTimeout(() => {
      const subjectPool = bankSoal.filter(q => q.subjectId === genSubjectId);
      
      if (subjectPool.length === 0) {
        alert('Maaf, bank soal mata pelajaran tersebut masih kosong di database! Silakan tambah soal atau ganti mapel.');
        setIsCompiling(false);
        return;
      }

      // Proportional sampling simulation
      // We will shuffle the pool and take matching quantity
      const shuffled = [...subjectPool].sort(() => 0.5 - Math.random());
      const selected = shuffled.slice(0, Math.min(genTotalQuestions, shuffled.length));

      setGeneratedPaper(selected);
      setIsCompiling(false);
      alert(`Alhamdulillah master ujian sukses dirakit! Ditemukan ${selected.length} butir soal yang sesuai.`);
    }, 1500);
  };

  const handleDeleteQuestion = (id: string) => {
    if (confirm('Apakah Anda yakin akan menghapus butir soal ini dari bank?')) {
      setBankSoal(prev => prev.filter(q => q.id !== id));
    }
  };

  // Kisi-Kisi matrix calculations
  const kisiSubjectObj = subjects.find(s => s.id === kisiSubjectId);
  const kisiQuestions = bankSoal.filter(q => q.subjectId === kisiSubjectId);

  return (
    <div id="bank-soal-wrapper" className="space-y-6">
      
      {/* HEADER SECTION */}
      <div className="flex flex-col xl:flex-row xl:items-center justify-between pb-4 border-b border-slate-200 gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="bg-emerald-100 text-emerald-800 text-xxxxs uppercase font-extrabold px-2.5 py-1 rounded-full">
              Modul 7
            </span>
            <h2 className="text-lg font-bold text-slate-800 school-display">
              Bank Soal Madrasah & Kisi-Kisi Evaluasi
            </h2>
          </div>
          <p className="text-xxs text-slate-500 mt-1">
            Manajemen bank soal adab & akademik, import dokumen Word/Excel, pustaka ilustrasi gambar, penyusunan kisi-kisi terpadu, dan generator lembar ujian otomatis.
          </p>
        </div>

        {/* Global actions */}
        <div className="flex gap-2">
          <button
            onClick={() => {
              setCreatorType('Pilihan Ganda');
              setCreatorText('');
              setSelectedSubTab('Input');
            }}
            className="bg-brand-green-700 hover:bg-brand-green-800 text-white font-bold text-xxs px-4 py-2 rounded-xl shadow-xs transition flex items-center gap-1.5 cursor-pointer"
          >
            <Plus className="h-4 w-4" />
            Tulis Soal Baru
          </button>
        </div>
      </div>

      {/* HORIZONTAL MINI-NAVBAR */}
      <div className="flex items-center gap-1 overflow-x-auto border-b border-slate-200 pb-1">
        <button
          onClick={() => setSelectedSubTab('Daftar')}
          className={`px-4 py-2 text-xs font-bold transition flex items-center gap-1.5 border-b-2 whitespace-nowrap ${
            selectedSubTab === 'Daftar'
              ? 'border-brand-green-700 text-brand-green-800'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Database className="h-4 w-4" />
          Semua Bank Soal ({bankSoal.length})
        </button>

        <button
          onClick={() => setSelectedSubTab('Input')}
          className={`px-4 py-2 text-xs font-bold transition flex items-center gap-1.5 border-b-2 whitespace-nowrap ${
            selectedSubTab === 'Input'
              ? 'border-brand-green-700 text-brand-green-800'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <PlusCircle className="h-4 w-4" />
          Input Klasifikasi Soal
        </button>

        <button
          onClick={() => setSelectedSubTab('Import')}
          className={`px-4 py-2 text-xs font-bold transition flex items-center gap-1.5 border-b-2 whitespace-nowrap ${
            selectedSubTab === 'Import'
              ? 'border-brand-green-700 text-brand-green-800'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Upload className="h-4 w-4" />
          Import Word & Excel
        </button>

        <button
          onClick={() => setSelectedSubTab('Gambar')}
          className={`px-4 py-2 text-xs font-bold transition flex items-center gap-1.5 border-b-2 whitespace-nowrap ${
            selectedSubTab === 'Gambar'
              ? 'border-brand-green-700 text-brand-green-800'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <ImageIcon className="h-4 w-4" />
          Bank Gambar Utama
        </button>

        <button
          onClick={() => setSelectedSubTab('KisiKisi')}
          className={`px-4 py-2 text-xs font-bold transition flex items-center gap-1.5 border-b-2 whitespace-nowrap ${
            selectedSubTab === 'KisiKisi'
              ? 'border-brand-green-700 text-brand-green-800'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Layers className="h-4 w-4" />
          Kisi-Kisi Kisi
        </button>

        <button
          onClick={() => setSelectedSubTab('Generator')}
          className={`px-4 py-2 text-xs font-bold transition flex items-center gap-1.5 border-b-2 whitespace-nowrap ${
            selectedSubTab === 'Generator'
              ? 'border-brand-green-700 text-brand-green-800'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Sparkles className="h-4 w-4 text-brand-gold-600 fill-brand-gold-200" />
          Generator Soal Otomatis
        </button>
      </div>

      {/* ======================= TAB 1: LIST DATABASE SOAL ======================= */}
      {selectedSubTab === 'Daftar' && (
        <div className="space-y-4 animate-in fade-in duration-100">
          
          {/* SEARCH & FILTERS ROW */}
          <div className="bg-white p-4 rounded-2xl border border-slate-100 shadow-xxs grid grid-cols-1 md:grid-cols-5 gap-3">
            <div className="relative md:col-span-1">
              <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
              <input
                type="text"
                placeholder="Cari materi / teks..."
                className="w-full text-xs pl-9 pr-4 py-2 rounded-xl bg-slate-50 border border-slate-200 focus:outline-none focus:border-brand-green-600 focus:bg-white"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
              />
            </div>

            <div>
              <select
                value={filterSubject}
                onChange={e => setFilterSubject(e.target.value)}
                className="w-full text-xs px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none text-slate-700 focus:bg-white focus:border-brand-green-600 cursor-pointer"
              >
                <option value="Semua">Semua Mapel</option>
                {subjects.map(s => (
                  <option key={s.id} value={s.id}>{s.name}</option>
                ))}
              </select>
            </div>

            <div>
              <select
                value={filterGrade}
                onChange={e => setFilterGrade(e.target.value)}
                className="w-full text-xs px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none text-slate-700 focus:bg-white focus:border-brand-green-600 cursor-pointer"
              >
                <option value="Semua">Semua Tingkat</option>
                <option value="Kelas 4A">Kelas 4A</option>
                <option value="Kelas 4B">Kelas 4B</option>
                <option value="Kelas 5">Kelas 5</option>
                <option value="Kelas 6">Kelas 6</option>
              </select>
            </div>

            <div>
              <select
                value={filterType}
                onChange={e => setFilterType(e.target.value)}
                className="w-full text-xs px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none text-slate-700 focus:bg-white focus:border-brand-green-600 cursor-pointer"
              >
                <option value="Semua">Semua Jenis Soal</option>
                <option value="Pilihan Ganda">Pilihan Ganda</option>
                <option value="Isian">Isian</option>
                <option value="Menjodohkan">Menjodohkan</option>
                <option value="Uraian">Uraian</option>
              </select>
            </div>

            <div>
              <select
                value={filterDifficulty}
                onChange={e => setFilterDifficulty(e.target.value)}
                className="w-full text-xs px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none text-slate-700 focus:bg-white focus:border-brand-green-600 cursor-pointer"
              >
                <option value="Semua">Semua Kesulitan</option>
                <option value="Mudah">Mudah</option>
                <option value="Sedang">Sedang</option>
                <option value="Sulit">Sulit</option>
              </select>
            </div>
          </div>

          {/* QUESTIONS LISTING */}
          <div className="space-y-4">
            {filteredQuestions.length === 0 ? (
              <div className="bg-white rounded-2xl border border-slate-100 p-16 text-center text-slate-400">
                <FileQuestion className="h-12 w-12 text-slate-200 mx-auto mb-3" />
                <p className="text-xs font-semibold">Tidak ditemukan butir soal yang sesuai filter pencarian.</p>
                <button
                  onClick={() => { setSearchQuery(''); setFilterSubject('Semua'); setFilterGrade('Semua'); }}
                  className="mt-3 text-brand-green-700 text-xxs font-bold hover:underline cursor-pointer"
                >
                  Reset Filter
                </button>
              </div>
            ) : (
              filteredQuestions.map((q, idx) => (
                <div key={q.id} className="bg-white rounded-2xl border border-slate-100 shadow-xxs p-5 hover:border-slate-200 hover:shadow-xs transition relative">
                  
                  {/* TOP CLASSIFICATION PILLS */}
                  <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="bg-slate-100 text-slate-700 text-[9px] font-bold px-2 py-0.5 rounded-md uppercase">
                        {q.id}
                      </span>
                      <span className="bg-emerald-50 text-emerald-800 text-[9px] font-bold px-2.5 py-0.5 rounded-md">
                        {q.subjectName}
                      </span>
                      <span className="bg-emerald-50 text-emerald-800 text-[9px] font-bold px-2 py-0.5 rounded-md">
                        {q.grade}
                      </span>
                      <span className="bg-blue-50 text-blue-800 text-[9px] font-bold px-2 py-0.5 rounded-md">
                        Topic: {q.topic}
                      </span>
                      <span className={`text-[9px] font-extrabold px-2 py-0.5 rounded-md ${
                        q.difficulty === 'Mudah' ? 'bg-teal-50 text-teal-800' :
                        q.difficulty === 'Sedang' ? 'bg-amber-50 text-amber-800' :
                        'bg-red-50 text-red-800'
                      }`}>
                        {q.difficulty}
                      </span>
                      <span className="bg-purple-100 text-purple-900 text-[9px] font-extrabold px-2 py-0.5 rounded-md">
                        Level: {q.cognitiveLevel}
                      </span>
                      <span className="bg-slate-100 text-slate-800 text-[9px] font-bold px-2 py-0.5 rounded-md">
                        Bobot: {q.points} Poin
                      </span>
                    </div>

                    <div className="flex gap-2">
                      <button
                        onClick={() => handleDeleteQuestion(q.id)}
                        className="text-slate-400 hover:text-red-600 transition p-1 cursor-pointer"
                        title="Hapus Soal"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </div>

                  {/* QUESTION CORE TEXT */}
                  <div className="space-y-3">
                    <div className="text-xs font-semibold text-slate-800 leading-relaxed gap-2">
                      <span className="text-slate-400"># {idx + 1}.</span> {q.questionText}
                    </div>

                    {q.imageUrl && (
                      <div className="border border-slate-200 rounded-xl overflow-hidden max-w-xs bg-slate-50 my-2">
                        <img src={q.imageUrl} alt="Ilustrasi" className="w-full h-32 object-cover" referrerPolicy="no-referrer" />
                        <span className="text-[9px] text-slate-400 block px-3 py-1 font-mono uppercase bg-white">Ilustrasi Terpilih</span>
                      </div>
                    )}

                    {/* RENDER ACCORDING TO TYPE */}
                    {q.type === 'Pilihan Ganda' && q.options && (
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-2 max-w-2xl pl-4">
                        {q.options.map((opt, oIdx) => {
                          const charLabel = String.fromCharCode(65 + oIdx);
                          const isCorrect = oIdx === q.correctOptionIndex;
                          return (
                            <div
                              key={oIdx}
                              className={`p-2.5 rounded-xl border text-xxs flex items-center gap-2.5 transition ${
                                isCorrect
                                  ? 'border-emerald-300 bg-emerald-50/50 text-emerald-900 font-bold'
                                  : 'border-slate-1 w-full bg-slate-50 text-slate-600'
                              }`}
                            >
                              <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold shrink-0 ${
                                isCorrect ? 'bg-emerald-600 text-white' : 'bg-white text-slate-500 border border-slate-200'
                              }`}>
                                {charLabel}
                              </span>
                              <span>{opt}</span>
                            </div>
                          );
                        })}
                      </div>
                    )}

                    {q.type === 'Isian' && (
                      <div className="mt-2 pl-4">
                        <span className="text-[10px] text-slate-400 font-bold uppercase block tracking-wider mb-1">Kunci Isian Singkat:</span>
                        <div className="inline-block bg-teal-50 border border-teal-200 text-teal-800 font-mono font-bold px-4 py-1.5 rounded-xl text-xxs">
                          {q.correctShortAnswer}
                        </div>
                      </div>
                    )}

                    {q.type === 'Menjodohkan' && q.pairsLeft && q.pairsRight && (
                      <div className="mt-2 pl-4 space-y-3">
                        <span className="text-[10px] text-slate-400 font-bold uppercase block tracking-wider">Hubungkan Pasangan (Simulasi Interaktif):</span>
                        <div className="grid grid-cols-2 gap-4 max-w-xl">
                          <div className="space-y-1.5">
                            {q.pairsLeft.map((leftItem, lIdx) => (
                              <div
                                key={lIdx}
                                className="p-2.5 border border-slate-150 bg-slate-50 rounded-lg text-xxs flex items-center justify-between font-semibold"
                              >
                                <span>{leftItem}</span>
                                <div className="h-2 w-2 rounded-full bg-emerald-600 shrink-0" />
                              </div>
                            ))}
                          </div>

                          <div className="space-y-1.5">
                            {q.pairsRight.map((rightItem, rIdx) => (
                              <div
                                key={rIdx}
                                className="p-2.5 border border-slate-150 bg-white rounded-lg text-xxs flex items-center justify-between text-slate-600"
                              >
                                <div className="h-2 w-2 rounded-full bg-emerald-600 shrink-0" />
                                <span>{rightItem}</span>
                              </div>
                            ))}
                          </div>
                        </div>

                        {/* Interactive toggle of actual keys */}
                        <details className="mt-2 text-xxs text-slate-500 bg-slate-50/50 p-2.5 rounded-xl border border-slate-100 max-w-xl">
                          <summary className="cursor-pointer font-bold select-none text-emerald-800">Tampilkan Kunci Jodohkan</summary>
                          <div className="mt-2 space-y-1 font-mono">
                            {Object.entries(q.correctPairs || {}).map(([cLeft, cRight]) => (
                              <div key={cLeft} className="flex items-center gap-1.5 pl-3">
                                <span>&bull; {cLeft}</span>
                                <ArrowRight className="h-3 w-3 text-slate-400" />
                                <span className="font-bold text-slate-700">{cRight}</span>
                              </div>
                            ))}
                          </div>
                        </details>
                      </div>
                    )}

                    {q.type === 'Uraian' && q.essayRubric && (
                      <div className="mt-2 pl-4">
                        <span className="text-[10px] text-slate-400 font-bold uppercase block tracking-wider mb-1">Pedoman Penskoran / Rubrik:</span>
                        <div className="bg-amber-50/50 text-amber-900 text-xxs p-3.5 rounded-xl border border-amber-100 leading-relaxed font-mono whitespace-pre-line">
                          {q.essayRubric}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* ======================= TAB 2: INTERACTIVE CREATOR ======================= */}
      {selectedSubTab === 'Input' && (
        <form onSubmit={handleSubmitQuestion} className="bg-white p-6 rounded-2xl border border-slate-100 shadow-xxs space-y-6 animate-in duration-100">
          <div className="pb-3 border-b border-slate-100 flex items-center gap-1.5">
            <PlusCircle className="h-5 w-5 text-brand-green-700" />
            <span className="font-bold text-slate-800 text-xs">Penulisan Formulir Pembuatan Butir Soal Baru</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            
            {/* TIPE SOAL */}
            <div>
              <label className="block text-xxs font-bold text-slate-500 uppercase tracking-wide mb-1">Tipe / Jenis Soal</label>
              <select
                value={creatorType}
                onChange={e => setCreatorType(e.target.value as any)}
                className="w-full text-xs px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:bg-white focus:border-brand-green-600 font-bold"
              >
                <option value="Pilihan Ganda">Pilihan Ganda</option>
                <option value="Isian">Isian Singkat</option>
                <option value="Menjodohkan">Menjodohkan (Matching)</option>
                <option value="Uraian">Uraian / Essay</option>
              </select>
            </div>

            {/* SUBJECT */}
            <div>
              <label className="block text-xxs font-bold text-slate-500 uppercase tracking-wide mb-1">Mata Pelajaran</label>
              <select
                value={creatorSubjectId}
                onChange={e => setCreatorSubjectId(e.target.value)}
                className="w-full text-xs px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:bg-white focus:border-brand-green-600"
              >
                {subjects.map(s => (
                  <option key={s.id} value={s.id}>{s.name} ({s.code})</option>
                ))}
              </select>
            </div>

            {/* CLASS/GRADE */}
            <div>
              <label className="block text-xxs font-bold text-slate-500 uppercase tracking-wide mb-1">Tingkat Kelas</label>
              <select
                value={creatorGrade}
                onChange={e => setCreatorGrade(e.target.value)}
                className="w-full text-xs px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:bg-white focus:border-brand-green-600"
              >
                <option value="Kelas 4A">Kelas 4A</option>
                <option value="Kelas 4B">Kelas 4B</option>
                <option value="Kelas 5">Kelas 5</option>
                <option value="Kelas 6">Kelas 6</option>
              </select>
            </div>

            {/* TOPIC / BAB */}
            <div>
              <label className="block text-xxs font-bold text-slate-500 uppercase tracking-wide mb-1">Topik Bahasan / Bab</label>
              <input
                type="text"
                placeholder="Contoh: Akhlak terpuji terhadap tetangga"
                required
                className="w-full text-xs px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:bg-white focus:border-brand-green-600 text-slate-800"
                value={creatorTopic}
                onChange={e => setCreatorTopic(e.target.value)}
              />
            </div>

            {/* DIFFICULTY */}
            <div>
              <label className="block text-xxs font-bold text-slate-500 uppercase tracking-wide mb-1">Klasifikasi Kesulitan</label>
              <div className="flex gap-2">
                {['Mudah', 'Sedang', 'Sulit'].map((level) => (
                  <button
                    key={level}
                    type="button"
                    onClick={() => setCreatorDifficulty(level as any)}
                    className={`flex-1 text-center py-1.5 rounded-xl text-xxs font-bold cursor-pointer border ${
                      creatorDifficulty === level
                        ? 'bg-brand-green-700 border-brand-green-700 text-white shadow-xs'
                        : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    {level}
                  </button>
                ))}
              </div>
            </div>

            {/* COGNITIVE DOMAIN */}
            <div>
              <label className="block text-xxs font-bold text-slate-500 uppercase tracking-wide mb-1">Sifat Domain Kognitif</label>
              <select
                value={creatorCognitive}
                onChange={e => setCreatorCognitive(e.target.value as any)}
                className="w-full text-xs px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:bg-white focus:border-brand-green-600"
              >
                <option value="C1">C1 - Mengingat (Knowledge)</option>
                <option value="C2">C2 - Memahami (Comprehension)</option>
                <option value="C3">C3 - Menerapkan (Application)</option>
                <option value="C4">C4 - Menganalisis (Analysis)</option>
                <option value="C5">C5 - Mengevaluasi (Evaluation)</option>
                <option value="C6">C6 - Mencipta (Creation)</option>
              </select>
            </div>

            {/* POINT WEIGHT */}
            <div>
              <label className="block text-xxs font-bold text-slate-500 uppercase tracking-wide mb-1">Bobot Angka Nilai Soal (Points)</label>
              <input
                type="number"
                min={1}
                max={100}
                className="w-full text-xs px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:bg-white focus:border-brand-green-600 text-slate-800"
                value={creatorPoints}
                onChange={e => setCreatorPoints(parseInt(e.target.value) || 10)}
              />
            </div>

            {/* OPTIONAL IMAGE ILLUSTRATION */}
            <div>
              <label className="block text-xxs font-bold text-slate-500 uppercase tracking-wide mb-1">Gambar Pendukung / Ilustrasi (Pustaka atau URL)</label>
              <select
                value={creatorImageUrl}
                onChange={e => setCreatorImageUrl(e.target.value)}
                className="w-full text-xs px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:bg-white focus:border-brand-green-600 text-slate-700"
              >
                <option value="">-- Tanpa Gambar (Kosong) --</option>
                {uploadedImages.map(img => (
                  <option key={img.id} value={img.url}>{img.name}</option>
                ))}
              </select>
            </div>
          </div>

          {/* MAIN QUESTION BODY */}
          <div>
            <label className="block text-xxs font-bold text-slate-500 uppercase tracking-wide mb-1">Butir Kalimat Soal / Teks Utama</label>
            <textarea
              required
              rows={4}
              placeholder="Tuliskan kalimat soal secara lengkap dan terstruktur. Gunakan kaidah bahasa yang sopan dan mudah dipahami."
              className="w-full text-xs p-3.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:bg-white focus:border-brand-green-600 text-slate-800 font-medium leading-relaxed"
              value={creatorText}
              onChange={e => setCreatorText(e.target.value)}
            />
          </div>

          {/* DYNAMIC LAYOUT BASED ON QUESTION TYPE */}
          {creatorType === 'Pilihan Ganda' && (
            <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100 space-y-4">
              <span className="text-[10px] text-slate-500 font-bold block uppercase tracking-wide">Penyunting Opsi Pilihan Ganda (A s.d D/E)</span>
              <div className="space-y-3">
                {pgOptions.map((opt, oIdx) => {
                  const charLabel = String.fromCharCode(65 + oIdx);
                  return (
                    <div key={oIdx} className="flex items-center gap-3">
                      <span className="w-6 h-6 rounded-lg bg-brand-green-700 text-white flex items-center justify-center font-bold text-xs shrink-0">{charLabel}</span>
                      <input
                        type="text"
                        required
                        className="flex-grow text-xs px-3 py-2 border border-slate-200 bg-white rounded-xl focus:outline-none focus:border-emerald-600"
                        value={opt}
                        onChange={e => handleOptionEdit(oIdx, e.target.value)}
                      />
                      <input
                        type="radio"
                        name="correctPgIndex"
                        checked={pgCorrectIndex === oIdx}
                        onChange={() => setPgCorrectIndex(oIdx)}
                        className="h-4 w-4 text-brand-green-700 focus:ring-brand-green-600"
                        title="Tandai sebagai Kunci Jawaban Benar"
                      />
                      <button
                        type="button"
                        onClick={() => removeOptionField(oIdx)}
                        className="text-slate-400 hover:text-red-500 p-1 cursor-pointer"
                        title="Hapus Opsi"
                      >
                        <X className="h-4 w-4" />
                      </button>
                    </div>
                  );
                })}
              </div>
              <div className="pt-2 flex items-center justify-between">
                <button
                  type="button"
                  onClick={addOptionField}
                  disabled={pgOptions.length >= 5}
                  className="bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 font-bold text-xxs px-3.5 py-1.5 rounded-xl transition cursor-pointer flex items-center gap-1.5 disabled:opacity-50"
                >
                  <Plus className="h-3 w-3" /> Tambahkan Pilihan E (Opsi)
                </button>
                <span className="text-[10px] text-slate-400 font-mono italic">Pilih radio button di kanan untuk kunci jawaban benar.</span>
              </div>
            </div>
          )}

          {creatorType === 'Isian' && (
            <div className="bg-slate-50 p-4 rounded-xl border border-slate-100">
              <label className="block text-xxs font-bold text-slate-500 uppercase tracking-wide mb-1">Jawaban Singkat Benar (Case-Insensitive)</label>
              <input
                type="text"
                required
                placeholder="Petunjuk kata kunci yang tepat, misal: Daud"
                className="w-full text-xs px-3 py-2 border border-slate-200 bg-white rounded-xl focus:outline-none focus:border-emerald-600 font-mono font-bold"
                value={isianAnswer}
                onChange={e => setIsianAnswer(e.target.value)}
              />
            </div>
          )}

          {creatorType === 'Menjodohkan' && (
            <div className="bg-slate-50 p-4 rounded-xl border border-slate-100 space-y-4">
              <span className="text-[10px] text-slate-500 font-bold block uppercase tracking-wide">Penyusun Baris Pasangan (Pisahkan dengan tanda koma)</span>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 mb-1">Daftar Kiri (Pertanyaan / Konsep)</label>
                  <textarea
                    rows={3}
                    className="w-full text-xs p-2.5 bg-white border border-slate-200 rounded-xl focus:outline-none focus:border-emerald-600 text-slate-800 font-medium"
                    placeholder="Wujud, Qidam, Baqa"
                    value={pairsLeftInput}
                    onChange={e => setPairsLeftInput(e.target.value)}
                  />
                </div>
                
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 mb-1">Daftar Kanan (Jawaban Pasangan yang sinkron)</label>
                  <textarea
                    rows={3}
                    className="w-full text-xs p-2.5 bg-white border border-slate-200 rounded-xl focus:outline-none focus:border-emerald-600 text-slate-800 font-medium"
                    placeholder="Ada, Terdahulu, Kekal"
                    value={pairsRightInput}
                    onChange={e => setPairsRightInput(e.target.value)}
                  />
                </div>
              </div>
              <p className="text-[9px] text-slate-400 leading-normal italic">
                * Pastikan urutan baris kiri dan kanan sudah sesuai sejajar (Sistem akan mengacaknya secara mekanis di lembar siswa namun mencatat relasi di database secara tepat).
              </p>
            </div>
          )}

          {creatorType === 'Uraian' && (
            <div className="bg-slate-50 p-4 rounded-xl border border-slate-100">
              <label className="block text-xxs font-bold text-slate-500 uppercase tracking-wide mb-1">Pedoman & Bobot Rubrik Penskoran Detail</label>
              <textarea
                rows={4}
                className="w-full text-xs p-2.5 bg-white border border-slate-200 rounded-xl focus:outline-none focus:border-emerald-600 font-mono text-slate-700"
                placeholder="Skor 10: Menyebutkan rukun iman secara runut...\nSkor 5: dst."
                value={essayRubricText}
                onChange={e => setEssayRubricText(e.target.value)}
              />
            </div>
          )}

          <div className="pt-4 border-t border-slate-100 flex items-center justify-end gap-2 text-xs">
            <button
              type="button"
              onClick={() => setSelectedSubTab('Daftar')}
              className="px-4 py-2 font-bold text-slate-500 hover:text-slate-800 cursor-pointer"
            >
              Batalkan
            </button>
            <button
              type="submit"
              className="bg-brand-green-700 hover:bg-brand-green-800 text-white font-bold px-6 py-2.5 rounded-xl shadow-xs cursor-pointer transition flex items-center gap-1.5"
            >
              <CheckCircle className="h-4.5 w-4.5" />
              Simpan Ke Bank Soal
            </button>
          </div>
        </form>
      )}

      {/* ======================= TAB 3: WORD & EXCEL IMPORTERS ======================= */}
      {selectedSubTab === 'Import' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 animate-in duration-100">
          
          {/* WORD IMPORTER */}
          <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-xxs space-y-5">
            <div className="flex items-center gap-2 pb-3 border-b border-indigo-50">
              <FileText className="h-5 w-5 text-indigo-700" />
              <div>
                <h4 className="font-bold text-xs text-slate-800 uppercase tracking-wider">Butir Soal Importer Microsoft Word</h4>
                <p className="text-[10px] text-slate-400 mt-0.5">Ekstrak penomoran otomatis dengan cerdas dari naskah dokumentasi.</p>
              </div>
            </div>

            <div className="space-y-4">
              <div className="text-xxs text-slate-600 leading-normal p-3 bg-indigo-50 rounded-xl border border-indigo-100">
                <strong>Format Penomoran Standar yang Didukung:</strong><br/>
                1. Pertanyaan contoh? (diikuti baris baru opsi)<br/>
                a. Opsi jawaban 1<br/>
                b. Opsi jawaban 2<br/>
                c. dst.
              </div>

              <div>
                <label className="block text-xxs font-bold text-slate-500 uppercase tracking-wide mb-1">Paste Teks Naskah Word disini:</label>
                <textarea
                  rows={8}
                  className="w-full text-xs p-3.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:bg-white focus:border-indigo-600 font-medium text-slate-700"
                  placeholder="Paste soal-soal Anda dari Word disini..."
                  value={importTextContent}
                  onChange={e => setImportTextContent(e.target.value)}
                />
              </div>

              <div className="flex justify-end">
                <button
                  type="button"
                  onClick={handleImportWordText}
                  disabled={isImportLoading || !importTextContent.trim()}
                  className="bg-indigo-700 hover:bg-indigo-800 disabled:opacity-50 text-white font-extrabold text-xxs px-5 py-2.5 rounded-xl transition cursor-pointer flex items-center gap-2 shadow-xs"
                >
                  {isImportLoading ? <RefreshCw className="h-4 w-4 animate-spin" /> : <Upload className="h-4 w-4" />}
                  Luncurkan Ekstraksi Butir Soal
                </button>
              </div>
            </div>
          </div>

          {/* EXCEL IMPORTER */}
          <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-xxs space-y-5">
            <div className="flex items-center gap-2 pb-3 border-b border-teal-50">
              <FileSpreadsheet className="h-5 w-5 text-teal-700" />
              <div>
                <h4 className="font-bold text-xs text-slate-800 uppercase tracking-wider">Import Template Lembar Kerja Excel</h4>
                <p className="text-[10px] text-slate-400 mt-0.5">Unggah data butir soal massal dalam tabel spreadsheet terstandarisasi.</p>
              </div>
            </div>

            <div className="space-y-4">
              <div className="p-3.5 bg-emerald-50 rounded-xl border border-emerald-100 flex items-center justify-between">
                <div className="text-xxs text-emerald-950">
                  <span className="font-extrabold block">Butuh Struktur Kolom?</span>
                  Unduh template xlsx yang bersih untuk panduan Anda.
                </div>
                <a
                  href="#"
                  onClick={(e) => { e.preventDefault(); alert('Template berhasil diunduh ke folder Downloads Anda.'); }}
                  className="bg-emerald-700 hover:bg-emerald-800 text-white font-extrabold text-[10px] px-3 py-1.5 rounded-lg flex items-center gap-1.5 shadow-xxs transition"
                >
                  <FileDown className="h-3 w-3" /> Unduh Template
                </a>
              </div>

              {/* Drag drop mockup */}
              <div
                onDragOver={e => e.preventDefault()}
                onDrop={handleImportExcelDrop}
                onClick={() => {
                  setExcelFileMockName('Template_Bank_Soal_Aqidah_Akhlak.xlsx');
                  setExcelFileSelected(true);
                }}
                className={`border-2 border-dashed rounded-2xl p-10 text-center cursor-pointer transition ${
                  excelFileSelected
                    ? 'border-emerald-500 bg-emerald-50/20'
                    : 'border-slate-300 hover:border-emerald-600 bg-slate-50'
                }`}
              >
                <Upload className="h-10 w-10 text-slate-400 mx-auto mb-2.5" />
                <span className="font-extrabold text-xs block text-slate-700 mb-1">
                  {excelFileSelected ? excelFileMockName : 'Seret file Excel Anda atau Klik disini untuk mengunggah'}
                </span>
                <span className="text-[10px] text-slate-400 block max-w-xs mx-auto leading-relaxed">
                  Format files: .xlsx, .xls atau data ekspor CSV kurikulum.
                </span>
              </div>

              {excelFileSelected && (
                <div className="flex items-center justify-end gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => { setExcelFileSelected(false); setExcelFileMockName(''); }}
                    className="text-xxs font-bold text-slate-500 hover:text-slate-800 cursor-pointer"
                  >
                    Batal
                  </button>
                  <button
                    type="button"
                    onClick={executeExcelImportSim}
                    className="bg-brand-green-700 hover:bg-brand-green-800 text-white font-bold text-xxs px-4 py-2 rounded-xl shadow-xxs transition-all cursor-pointer"
                  >
                    Mulai Impor Excel
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* SPREADSHEET FEEDBACK LOGS PANEL */}
          {importLog.length > 0 && (
            <div className="lg:col-span-2 bg-slate-900 text-slate-200 p-5 rounded-2xl border border-slate-850 font-mono text-[10px] space-y-2 leading-relaxed shadow-lg">
              <div className="flex items-center justify-between text-slate-400 pb-2 border-b border-slate-800 text-[11px] font-bold mb-2">
                <span>TERMINAL LOG SISTEM INTEGRASI NASKAH</span>
                <button onClick={() => setImportLog([])} className="hover:text-white cursor-pointer">[Hapus Log]</button>
              </div>
              {importLog.map((logStr, lIdx) => (
                <div key={lIdx} className="flex gap-2">
                  <span className="text-emerald-500 font-bold">&gt;</span>
                  <span>{logStr}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* ======================= TAB 4: FILE ATTACHMENTS IMAGES ======================= */}
      {selectedSubTab === 'Gambar' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 animate-in duration-100">
          
          {/* Left panel upload widget */}
          <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-xxs space-y-4">
            <div className="pb-3 border-b border-slate-100 flex items-center gap-1.5">
              <ImageIcon className="h-4.5 w-4.5 text-brand-green-700" />
              <span className="font-extrabold text-xs text-slate-800 uppercase tracking-wide">Penerimaan Berkas Ilustrasi</span>
            </div>

            <form onSubmit={handleAddImageToBank} className="space-y-4">
              <div>
                <label className="block text-xxs font-bold text-slate-500 uppercase tracking-wide mb-1">Judul Gambar / Deskripsi Objek</label>
                <input
                  type="text"
                  placeholder="Misal: Denah Peta Kiblat"
                  required
                  className="w-full text-xs px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:bg-white focus:border-brand-green-600"
                  value={imageUploadName}
                  onChange={e => setImageUploadName(e.target.value)}
                />
              </div>

              <div>
                <label className="block text-xxs font-bold text-slate-500 uppercase tracking-wide mb-1">URL Link Gambar (atau dummy URL mockup)</label>
                <input
                  type="text"
                  placeholder="https://images.unsplash.com/... atau tautan penyimpanan"
                  required
                  className="w-full text-xs px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:bg-white focus:border-brand-green-600"
                  value={imageUploadUrl}
                  onChange={e => setImageUploadUrl(e.target.value)}
                />
                <button
                  type="button"
                  onClick={() => setImageUploadUrl('https://images.unsplash.com/photo-1542856391-010fb87dcfed?auto=format&fit=crop&q=80&w=350')}
                  className="text-xxxxs text-emerald-800 font-bold hover:underline block mt-1 cursor-pointer"
                >
                  Bantu isi dengan contoh gambar Ka'bah Al Faraby
                </button>
              </div>

              <button
                type="submit"
                className="w-full bg-brand-green-700 hover:bg-brand-green-800 text-white font-extrabold text-xxs py-2.5 rounded-xl shadow-xxs transition-colors cursor-pointer"
              >
                Tambahkan Berkas Gambar
              </button>
            </form>
          </div>

          {/* Right listing gallery */}
          <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-xxs lg:col-span-2 space-y-4">
            <span className="font-bold text-xs text-slate-800 block uppercase tracking-wide">Gallery Visual Ilustrasi Soal Aktif</span>
            
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
              {uploadedImages.map(img => (
                <div key={img.id} className="border border-slate-150 rounded-2xl overflow-hidden hover:border-emerald-600 group transition relative">
                  <img src={img.url} alt={img.name} className="w-full h-24 object-cover" referrerPolicy="no-referrer" />
                  <div className="p-2.5 bg-slate-50 text-xxs font-semibold text-slate-800 truncate" title={img.name}>
                    {img.name}
                  </div>
                  
                  {/* Delete button option */}
                  <button
                    type="button"
                    onClick={() => {
                      if (confirm('Keluarkan gambar ini dari pustaka?')) {
                        setUploadedImages(prev => prev.filter(i => i.id !== img.id));
                      }
                    }}
                    className="absolute top-2 right-2 bg-rose-600 hover:bg-rose-700 text-white p-1 rounded-full shadow-md opacity-0 group-hover:opacity-100 transition cursor-pointer"
                    title="Keluarkan Gambar"
                  >
                    <X className="h-3 w-3" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ======================= TAB 5: GRID KISI-KISI MATRIX ======================= */}
      {selectedSubTab === 'KisiKisi' && (
        <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-xxs space-y-6 animate-in duration-100">
          
          <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-slate-100 gap-3">
            <div className="flex items-center gap-1.5">
              <Layers className="h-5 w-5 text-brand-green-700" />
              <span className="font-extrabold text-slate-800 text-sm">Penyusunan Format Kisi-Kisi Ujian Madrasah Al Faraby</span>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <select
                value={kisiSubjectId}
                onChange={e => setKisiSubjectId(e.target.value)}
                className="text-xs px-2 py-1.5 bg-slate-100 border border-slate-200 rounded-lg text-slate-700 cursor-pointer"
              >
                {subjects.map(s => (
                  <option key={s.id} value={s.id}>{s.name}</option>
                ))}
              </select>

              <select
                value={kisiGrade}
                onChange={e => setKisiGrade(e.target.value)}
                className="text-xs px-2 py-1.5 bg-slate-100 border border-slate-200 rounded-lg text-slate-700 cursor-pointer"
              >
                <option value="Kelas 4A">Kelas 4A</option>
                <option value="Kelas 4B">Kelas 4B</option>
                <option value="Kelas 5">Kelas 5</option>
                <option value="Kelas 6">Kelas 6</option>
              </select>

              <button
                onClick={() => {
                  window.print();
                }}
                className="bg-brand-green-700 hover:bg-brand-green-800 text-white font-bold text-xxs px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition cursor-pointer shadow-xxs"
              >
                <Printer className="h-3.5 w-3.5" /> Cetak Kisi-Kisi
              </button>
            </div>
          </div>

          <div className="overflow-x-auto print-grid-matrix">
            <table className="w-full text-left border-collapse text-xs border border-slate-200">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50 text-slate-600 font-extrabold">
                  <th className="p-3 border-r border-slate-200">No</th>
                  <th className="p-3 border-r border-slate-200">ID / Kode Soal</th>
                  <th className="p-3 border-r border-slate-200">Materi Pokok / Bab</th>
                  <th className="p-3 border-r border-slate-200">Indikator Kompetensi Akhlak / Kognitif</th>
                  <th className="p-3 border-r border-slate-200 text-center">Level Kognitif</th>
                  <th className="p-3 border-r border-slate-200 text-center">Bentuk Instumen</th>
                  <th className="p-3 border-r border-slate-200 text-center">Bobot</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 text-slate-700">
                {kisiQuestions.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="p-8 text-center text-slate-400">
                      Belum ada butir soal yang tercatat pada mapel tersemat di database.
                    </td>
                  </tr>
                ) : (
                  kisiQuestions.map((kq, kIdx) => (
                    <tr key={kq.id} className="hover:bg-slate-50/40">
                      <td className="p-3 border-r border-slate-200 text-center font-bold">{kIdx + 1}</td>
                      <td className="p-3 border-r border-slate-200 font-mono text-xxxxs font-bold text-emerald-800">{kq.id}</td>
                      <td className="p-3 border-r border-slate-200 font-bold">{kq.topic}</td>
                      <td className="p-3 border-r border-slate-200 font-medium">
                        Peserta didik dapat memahami konsep dan menerapkan implementasi dari {kq.topic.toLowerCase()} dengan standar kebaikan akhlak madrasah Al Faraby.
                      </td>
                      <td className="p-3 border-r border-slate-200 text-center font-extrabold text-blue-800">{kq.cognitiveLevel}</td>
                      <td className="p-3 border-r border-slate-200 text-center font-bold text-slate-500">{kq.type}</td>
                      <td className="p-3 border-r border-slate-200 text-center font-display font-bold text-teal-850 bg-teal-50/10">{kq.points} Poin</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>

          <div className="pt-3 flex flex-col md:flex-row md:items-center justify-between text-xxs text-slate-400 leading-normal gap-2">
            <span>* Dokumen Kisi-Kisi ini diolah otomatis menyesuaikan pemaparan butir-butir soal di master database Al Faraby.</span>
            <span className="font-bold text-brand-green-800">Sekolah Dasar Islam Terpadu Al-Faraby, Bogor Kelembagaan Kurikulum Merdeka Terpadu Basmalah.</span>
          </div>
        </div>
      )}

      {/* ======================= TAB 6: AUTO GENERATOR ENGINE ======================= */}
      {selectedSubTab === 'Generator' && (
        <div className="space-y-6 animate-in duration-100">
          
          <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-xxs space-y-6">
            <div className="pb-3 border-b border-slate-100 flex items-center justify-between">
              <div className="flex items-center gap-1.5">
                <Sparkles className="h-5 w-5 text-brand-gold-500 fill-brand-gold-500" />
                <span className="font-extrabold text-slate-800 text-xs uppercase tracking-wider">Perakit Lembar Ujian Madrasah Otomatis</span>
              </div>
              <span className="text-xxs text-slate-400 italic">Mesin AI & Kriteria Distribusi</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              
              <div className="space-y-4">
                <div>
                  <label className="block text-xxs font-bold text-slate-500 uppercase tracking-wide mb-1">Mata Pelajaran Target</label>
                  <select
                    value={genSubjectId}
                    onChange={e => setGenSubjectId(e.target.value)}
                    className="w-full text-xs px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:bg-white focus:border-brand-green-600"
                  >
                    {subjects.map(s => (
                      <option key={s.id} value={s.id}>{s.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xxs font-bold text-slate-500 uppercase tracking-wide mb-1">Target Kelas</label>
                  <select
                    value={genGrade}
                    onChange={e => setGenGrade(e.target.value)}
                    className="w-full text-xs px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:bg-white focus:border-brand-green-600"
                  >
                    <option value="Kelas 4A">Kelas 4A</option>
                    <option value="Kelas 4B">Kelas 4B</option>
                    <option value="Kelas 5">Kelas 5</option>
                    <option value="Kelas 6">Kelas 6</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xxs font-bold text-slate-500 uppercase tracking-wide mb-1">Target Jumlah Butir Soal</label>
                  <input
                    type="number"
                    min={2}
                    max={50}
                    className="w-full text-xs px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:bg-white focus:border-brand-green-600 text-slate-700"
                    value={genTotalQuestions}
                    onChange={e => setGenTotalQuestions(parseInt(e.target.value) || 10)}
                  />
                  <p className="text-[9px] text-slate-450 italic mt-1 leading-normal">* Jumlah menyesuaikan ketersediaan data butir soal.</p>
                </div>
              </div>

              {/* RATIO RATINGS COGNITIVE DISTRIBUTION */}
              <div className="md:col-span-2 space-y-4 bg-slate-50 p-4 rounded-2xl border border-slate-100">
                <span className="text-[10px] text-slate-500 font-bold block uppercase tracking-wide mb-2">Penyeimbang Proporsional Jenis Soal (Total 100%)</span>
                
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between text-[11px] mb-1">
                      <span className="font-bold text-slate-600">Pilihan Ganda Ratio</span>
                      <span className="font-extrabold text-emerald-800">{genPGRatio}%</span>
                    </div>
                    <input
                      type="range"
                      min="0"
                      max="100"
                      value={genPGRatio}
                      onChange={e => {
                        const val = parseInt(e.target.value);
                        setGenPGRatio(val);
                        // Balance remaining
                        const rem = 100 - val;
                        setGenIsianRatio(Math.round(rem * 0.4));
                        setGenMenjodohkanRatio(Math.round(rem * 0.2));
                        setGenUraianRatio(Math.round(rem * 0.4));
                      }}
                      className="w-full h-1.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-brand-green-700"
                    />
                  </div>

                  <div className="grid grid-cols-3 gap-4">
                    <div>
                      <label className="block text-[10px] text-slate-400 font-bold mb-1">Isian ({genIsianRatio}%)</label>
                      <input
                        type="number"
                        className="w-full text-xs p-1.5 bg-white border border-slate-205 rounded-xl font-bold text-center"
                        value={genIsianRatio}
                        disabled
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] text-slate-400 font-bold mb-1">Jodohkan ({genMenjodohkanRatio}%)</label>
                      <input
                        type="number"
                        className="w-full text-xs p-1.5 bg-white border border-slate-205 rounded-xl font-bold text-center"
                        value={genMenjodohkanRatio}
                        disabled
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] text-slate-400 font-bold mb-1">Uraian ({genUraianRatio}%)</label>
                      <input
                        type="number"
                        className="w-full text-xs p-1.5 bg-white border border-slate-205 rounded-xl font-bold text-center"
                        value={genUraianRatio}
                        disabled
                      />
                    </div>
                  </div>
                </div>

                <div className="pt-2">
                  <button
                    type="button"
                    onClick={handleAutoGeneratePaper}
                    disabled={isCompiling}
                    className="w-full bg-brand-green-700 hover:bg-brand-green-800 text-white font-extrabold text-xxs py-3 rounded-xl shadow-md cursor-pointer transition flex items-center justify-center gap-1.5"
                  >
                    {isCompiling ? (
                      <>
                        <RefreshCw className="h-4 w-4 animate-spin" /> Merakit naskah ujian syariah...
                      </>
                    ) : (
                      <>
                        <Shuffle className="h-4 w-4" /> Kompilasi Lembar Soal Otomatis
                      </>
                    )}
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* ACTIVE PAPER LAYOUT VIEW FOR PRINTING */}
          {generatedPaper && (
            <div className="bg-white p-8 rounded-2xl border border-slate-200 shadow-sm space-y-6">
              
              {/* PRINT BTN CONTROLLER */}
              <div className="flex items-center justify-between pb-3 border-b border-slate-100 print:hidden">
                <span className="text-xxs text-emerald-800 font-bold flex items-center gap-1">
                  <CheckCircle className="h-4 w-4 text-emerald-600" />
                  Alhamdulillah, Master Naskah Ujian Berhasil Dihasilkan!
                </span>
                <button
                  onClick={() => window.print()}
                  className="bg-brand-green-700 hover:bg-brand-green-800 text-white font-extrabold text-xxs px-4 py-2 rounded-xl shadow-xxs cursor-pointer transition flex items-center gap-1.5"
                >
                  <Printer className="h-4 w-4" /> Cetak Naskah Ujian (PDF)
                </button>
              </div>

              {/* SHEET BODY WITH MADRASAH HEADER COOP */}
              <div className="space-y-6 text-slate-950 p-4 border border-slate-100 rounded-2xl">
                
                {/* OFFICIAL MADRASAH KOP DOKUMEN */}
                <div className="flex items-center gap-4 border-b-3 border-double border-slate-800 pb-2 text-center relative justify-center">
                  <div className="h-16 w-16 bg-brand-green-905 flex items-center justify-center font-bold text-slate-850 shrink-0 text-3xl border border-slate-800 absolute left-4 hidden md:flex rounded-xl">
                    🕌
                  </div>
                  <div className="text-center">
                    <h2 className="font-extrabold text-sm uppercase tracking-wide leading-tight text-slate-900">SD ISLAM INTEGRASI AL-FARABY BOGOR</h2>
                    <h3 className="font-black text-xs uppercase text-slate-850 mt-0.5 tracking-wider">EVALUASI AKHIR TA 2026/2027 GANJIL</h3>
                    <p className="text-[10px] text-slate-500 italic mt-0.5 font-medium">Jl. Raya Hijrah No. 45, Kecamatan Ciawi, Bogor Jawa Barat — Telp (0251) Al-Faraby</p>
                  </div>
                </div>

                {/* STUDENT NAME GRID RECORD */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-xxs border-b border-slate-350 pb-4">
                  <div>
                    <span className="text-slate-520 block font-bold mb-0.5 text-[9px] uppercase">Nama Lengkap Santri :</span>
                    <span className="border-b-2 border-dotted border-slate-400 block pb-1 h-5 text-slate-400 italic">...................................................</span>
                  </div>
                  <div>
                    <span className="text-slate-520 block font-bold mb-0.5 text-[9px] uppercase">Rombel Kelas / NIS :</span>
                    <span className="font-extrabold text-slate-800 block border-b-2 border-dotted border-slate-400 pb-1 h-5">{genGrade} / ...........</span>
                  </div>
                  <div>
                    <span className="text-slate-520 block font-bold mb-0.5 text-[9px] uppercase font-mono">MAPEL UJIAN :</span>
                    <span className="font-black text-slate-900 block border-b-2 border-dotted border-slate-400 pb-1 h-5">
                      {subjects.find(s => s.id === genSubjectId)?.name || 'Mata Pelajaran'}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-520 block font-bold mb-0.5 text-[9px] uppercase">Hari / Tanggal Ujian :</span>
                    <span className="font-bold text-slate-700 block border-b-2 border-dotted border-slate-400 pb-1 h-5">
                      {new Date().toLocaleDateString('id-ID', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}
                    </span>
                  </div>
                </div>

                {/* INTRO DIRECTIONS INSTRUCTIONS */}
                <div className="text-xxxxs text-slate-600 bg-slate-50 p-3 rounded-xl border border-slate-200 leading-normal font-sans space-y-1">
                  <span className="font-extrabold text-slate-800 block text-[9px] uppercase">Tata Tertib Pengisian Lembar Soal :</span>
                  <span>1. Bacalah basmalah sebelum memulai menjawab dan berdoa kelancaran hidayah fikiran Anda.</span>
                  <span>2. Daftarkan identitas Anda pada tempat kosong yang telah disediakan di atas lembar jawaban.</span>
                  <span>3. Tulis jawaban Anda secara jelas, rapi, santun serta menjaga akhlak birrul walidain kejujuran mutlak.</span>
                </div>

                {/* QUESTIONS RECURSION PRINT */}
                <div className="space-y-6 pt-4 text-xs font-sans">
                  {generatedPaper.map((q, idx) => (
                    <div key={idx} className="space-y-2">
                      <div className="font-semibold text-slate-850 leading-relaxed">
                        <span>{idx + 1}.</span> {q.questionText} <span className="text-slate-400 font-mono text-[10px] italic">({q.points} Poin &bull; Level {q.cognitiveLevel})</span>
                      </div>

                      {q.imageUrl && (
                        <div className="max-w-xs border border-slate-300 rounded-lg overflow-hidden my-3">
                          <img src={q.imageUrl} alt="Ilustrasi" className="w-full h-24 object-cover" referrerPolicy="no-referrer" />
                        </div>
                      )}

                      {/* Options or Answer Lines */}
                      {q.type === 'Pilihan Ganda' && q.options && (
                        <div className="grid grid-cols-2 gap-2 pl-4 text-xxxxs font-medium text-slate-700">
                          {q.options.map((opt, oIdx) => (
                            <div key={oIdx} className="flex items-center gap-1.5">
                              <span className="w-4 h-4 rounded-full border border-slate-400 flex items-center justify-center text-[9px] font-bold text-slate-500">{String.fromCharCode(65 + oIdx)}</span>
                              <span>{opt}</span>
                            </div>
                          ))}
                        </div>
                      )}

                      {q.type === 'Isian' && (
                        <div className="pl-4 pt-1">
                          <span className="text-[10px] text-slate-400">Jawaban Singkat Anda: </span>
                          <span className="border-b border-slate-350 w-full max-w-sm inline-block h-4"></span>
                        </div>
                      )}

                      {q.type === 'Menjodohkan' && q.pairsLeft && q.pairsRight && (
                        <div className="pl-4 grid grid-cols-2 gap-6 max-w-lg pt-1">
                          <div className="space-y-2">
                            {q.pairsLeft.map((left, lIdx) => (
                              <div key={lIdx} className="flex items-center justify-between text-xxxxs border-b border-dashed border-slate-200 pb-1">
                                <span>{idx + 1}.{String.fromCharCode(97 + lIdx)}. {left}</span>
                                <span className="h-2 w-2 rounded-full border border-slate-500"></span>
                              </div>
                            ))}
                          </div>
                          <div className="space-y-2">
                            {q.pairsRight.map((right, rIdx) => (
                              <div key={rIdx} className="flex items-center gap-2 text-xxxxs border-b border-dashed border-slate-200 pb-1">
                                <span className="h-2 w-2 rounded-full border border-slate-500"></span>
                                <span>({String.fromCharCode(65 + rIdx)}). {right}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {q.type === 'Uraian' && (
                        <div className="pl-4 pt-2 space-y-1.5">
                          <div className="border border-slate-200 border-dotted h-20 w-full rounded-xl bg-slate-50/20" />
                          <span className="text-[9px] text-slate-400 italic block">* Gunakan tinta hitam dalam menulis jawaban deskriptif yang rapi.</span>
                        </div>
                      )}
                    </div>
                  ))}
                </div>

                {/* FOOTER SIGNATURE PANEL */}
                <div className="pt-12 grid grid-cols-2 text-center text-xxxxs text-slate-800 font-medium">
                  <div>
                    <p>Mengetahui,</p>
                    <p className="font-bold">Kepala Madrasah Al Faraby</p>
                    <br/><br/><br/>
                    <p className="font-extrabold underline">Ustadz Ahmad Al-Faruq, M.Pd.</p>
                    <p>NUPTK. 198205142010011005</p>
                  </div>
                  <div>
                    <p>Bogor, ........................... 2026</p>
                    <p className="font-bold">Guru Mata Pelajaran</p>
                    <br/><br/><br/>
                    <p className="font-extrabold underline">Siti Nurhaliza, S.Pd.I.</p>
                    <p>Mata Pelajaran: {subjects.find(s => s.id === genSubjectId)?.name}</p>
                  </div>
                </div>

              </div>
            </div>
          )}
        </div>
      )}

    </div>
  );
}
