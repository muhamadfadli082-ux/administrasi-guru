/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  ClipboardCheck, 
  BookOpen, 
  Heart, 
  User, 
  Check, 
  AlertCircle, 
  Plus, 
  Smile, 
  Award, 
  Sparkles, 
  Send, 
  Trash,
  Calendar,
  BookMarked,
  Layers,
  FileCheck2,
  Users2,
  FileSpreadsheet,
  Boxes
} from 'lucide-react';
import { Student, AttendanceLog, TeachingJournal, CharacterLog } from '../types';

// Import newly created Modul 5 sub-sections
import AbsensiSection from './kelas/AbsensiSection';
import BukuAgendaSection from './kelas/BukuAgendaSection';
import JurnalMengajarSection from './kelas/JurnalMengajarSection';
import CatatanPerkembanganSection from './kelas/CatatanPerkembanganSection';
import BukuTamuSection from './kelas/BukuTamuSection';
import InventarisKelasSection from './kelas/InventarisKelasSection';

interface AdministrasiKelasViewProps {
  students: Student[];
  attendanceLogs: AttendanceLog[];
  teachingJournals: TeachingJournal[];
  characterLogs: CharacterLog[];
  onAddAttendance: (logs: AttendanceLog[]) => void;
  onAddJournal: (journal: TeachingJournal) => void;
  onAddCharacterLog: (log: CharacterLog) => void;
  onDeleteJournal: (id: string) => void;
  onDeleteCharacterLog: (id: string) => void;
}

type SubTabType = 'absensi' | 'agenda' | 'jurnal' | 'perkembangan' | 'buku-tamu' | 'inventaris';

export default function AdministrasiKelasView({
  students,
  attendanceLogs,
  teachingJournals,
  characterLogs,
  onAddAttendance,
  onAddJournal,
  onAddCharacterLog,
  onDeleteJournal,
  onDeleteCharacterLog
}: AdministrasiKelasViewProps) {
  const [activeSubTab, setActiveSubTab] = useState<SubTabType>('absensi');
  const [selectedClass, setSelectedClass] = useState('Kelas 4A');
  const [selectedDate, setSelectedDate] = useState('2026-06-17');

  return (
    <div id="administrasi-kelas-container" className="space-y-6">
      
      {/* Header Block with Context Selector */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-gray-200 gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-800 school-display">Modul V: Administrasi Kelas</h2>
          <p className="text-xs text-slate-500">Log kehadiran terpadu, agenda, jurnal harian, catatan perkembangan adab, buku tamu, serta inventaris kelas.</p>
        </div>

        {/* Global Context Selector */}
        <div className="flex items-center gap-2 bg-white px-3 py-1.5 rounded-xl border border-slate-200 shadow-xs ring-1 ring-slate-100 self-start sm:self-auto">
          <span className="text-xxxxs font-bold text-slate-400 uppercase tracking-widest px-1">Konteks Kelas</span>
          <select
            value={selectedClass}
            onChange={e => setSelectedClass(e.target.value)}
            className="text-xs font-semibold text-slate-700 focus:outline-none bg-transparent cursor-pointer"
          >
            <option value="Kelas 4A">Kelas 4A</option>
            <option value="Kelas 4B">Kelas 4B</option>
            <option value="Kelas 5">Kelas 5</option>
            <option value="Kelas 6">Kelas 6</option>
          </select>
          <span className="h-4 w-px bg-slate-200" />
          <input
            type="date"
            value={selectedDate}
            onChange={e => setSelectedDate(e.target.value)}
            className="text-xs font-semibold text-slate-700 bg-transparent border-0 focus:outline-none focus:ring-0 w-32 cursor-pointer"
          />
        </div>
      </div>

      {/* Navigation Sub-Tabs Grid bar */}
      <div className="flex bg-slate-100/80 p-1 rounded-2xl w-full md:w-auto overflow-x-auto justify-start border border-slate-200/50 gap-1.5 scrollbar-thin">
        {[
          { key: 'absensi', label: 'Absensi & Rekap', icon: ClipboardCheck },
          { key: 'agenda', label: 'Buku Agenda Mengajar', icon: BookMarked },
          { key: 'jurnal', label: 'Jurnal Mengajar', icon: BookOpen },
          { key: 'perkembangan', label: 'Catatan Perkembangan', icon: FileCheck2 },
          { key: 'buku-tamu', label: 'Buku Tamu Digital', icon: Users2 },
          { key: 'inventaris', label: 'Inventaris Kelas', icon: Boxes }
        ].map(tab => {
          const TabIcon = tab.icon;
          const isSelected = activeSubTab === tab.key;
          return (
            <button
              key={tab.key}
              onClick={() => setActiveSubTab(tab.key as SubTabType)}
              className={`flex items-center gap-2 px-4 py-2 text-xs font-bold rounded-xl transition cursor-pointer shrink-0 ${
                isSelected 
                  ? 'bg-white shadow-xs text-brand-green-700 ring-1 ring-slate-100' 
                  : 'text-slate-600 hover:text-slate-800 hover:bg-white/40'
              }`}
            >
              <TabIcon className={`h-4.5 w-4.5 ${isSelected ? 'text-brand-green-700' : 'text-slate-500'}`} />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Active Rendering Sub-Section Panel Container with fade transition effect */}
      <div className="animate-in fade-in duration-150">
        
        {activeSubTab === 'absensi' && (
          <AbsensiSection 
            students={students}
            classroom={selectedClass}
            selectedDate={selectedDate}
          />
        )}

        {activeSubTab === 'agenda' && (
          <BukuAgendaSection 
            classroom={selectedClass}
            selectedDate={selectedDate}
          />
        )}

        {activeSubTab === 'jurnal' && (
          <JurnalMengajarSection 
            classroom={selectedClass}
            selectedDate={selectedDate}
          />
        )}

        {activeSubTab === 'perkembangan' && (
          <CatatanPerkembanganSection 
            students={students}
            classroom={selectedClass}
            selectedDate={selectedDate}
          />
        )}

        {activeSubTab === 'buku-tamu' && (
          <BukuTamuSection 
            classroom={selectedClass}
            selectedDate={selectedDate}
          />
        )}

        {activeSubTab === 'inventaris' && (
          <InventarisKelasSection 
            classroom={selectedClass}
          />
        )}

      </div>

    </div>
  );
}
