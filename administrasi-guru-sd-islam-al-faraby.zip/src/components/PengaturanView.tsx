/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import {
  Settings,
  Lock,
  CheckCircle,
  Save,
  Building,
  ShieldAlert,
  Calendar,
  Layers,
  Palette,
  Database,
  Bell,
  Upload,
  Download,
  RotateCcw,
  Sparkles,
  Info,
  PenTool,
  Check,
  AlertTriangle,
  RefreshCw
} from 'lucide-react';
import { SchoolProfile } from '../types';

interface PengaturanViewProps {
  schoolProfile: SchoolProfile;
  onUpdateProfile: (p: SchoolProfile) => void;
}

export default function PengaturanView({ schoolProfile, onUpdateProfile }: PengaturanViewProps) {
  // Rich active configurations matching user requirements
  const [activeTab, setActiveTab] = useState<'identitas' | 'akademik' | 'tema' | 'pemeliharaan' | 'notifikasi' | 'keamanan'>('identitas');

  // Identitas sekolah & Data Kepala Sekolah
  const [schoolName, setSchoolName] = useState(schoolProfile.name);
  const [npsn, setNpsn] = useState(schoolProfile.npsn);
  const [accreditation, setAccreditation] = useState(schoolProfile.accreditation);
  const [address, setAddress] = useState(schoolProfile.address);
  const [principal, setPrincipal] = useState(schoolProfile.headmaster);
  const [phone, setPhone] = useState(schoolProfile.phone);
  const [nipHeadmaster, setNipHeadmaster] = useState('197804152002121003');

  // Logo sekolah simulation
  const [schoolLogo, setSchoolLogo] = useState<string | null>(null);
  
  // Tanda tangan digital
  const [signatureImage, setSignatureImage] = useState<string | null>(null);
  const sigCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const [isDrawing, setIsDrawing] = useState(false);

  // Akademik aktif
  const [activeAcademicYear, setActiveAcademicYear] = useState('2026/2027');
  const [activeSemester, setActiveSemester] = useState<'Ganjil' | 'Genap'>('Ganjil');

  // Tema Aplikasi (Preset themes selection)
  const [appTheme, setAppTheme] = useState<'hijau_madrasah' | 'biru_modern' | 'warna_emas' | 'indigo_soft'>('hijau_madrasah');

  // Pengaturan notifikasi
  const [notifWhatsapp, setNotifWhatsapp] = useState(true);
  const [notifEmail, setNotifEmail] = useState(true);
  const [notifTelegram, setNotifTelegram] = useState(false);
  const [notifSmsAlerts, setNotifSmsAlerts] = useState(false);

  // Keamanan Sandi
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  // Handle Canvas Digital Signature Drawing
  useEffect(() => {
    if (activeTab === 'identitas' && sigCanvasRef.current) {
      const canvas = sigCanvasRef.current;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.strokeStyle = '#064e3b';
        ctx.lineWidth = 3;
        ctx.lineCap = 'round';
      }
    }
  }, [activeTab]);

  const startDrawing = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!sigCanvasRef.current) return;
    const canvas = sigCanvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    ctx.beginPath();
    ctx.moveTo(e.clientX - rect.left, e.clientY - rect.top);
    setIsDrawing(true);
  };

  const draw = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDrawing || !sigCanvasRef.current) return;
    const canvas = sigCanvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    ctx.lineTo(e.clientX - rect.left, e.clientY - rect.top);
    ctx.stroke();
  };

  const stopDrawing = () => {
    setIsDrawing(false);
  };

  const clearSignature = () => {
    if (!sigCanvasRef.current) return;
    const canvas = sigCanvasRef.current;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      setSignatureImage(null);
    }
  };

  const saveSignatureFromCanvas = () => {
    if (!sigCanvasRef.current) return;
    const dataUrl = sigCanvasRef.current.toDataURL();
    setSignatureImage(dataUrl);
    alert('Tanda tangan digital Kepala Sekolah berhasil direkam ke memori sistem!');
  };

  // Logo file selection simulation
  const handleLogoUploadSimulate = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const reader = new FileReader();
      reader.onload = () => {
        setSchoolLogo(reader.result as string);
        alert('Logo sekolah berhasil diperbarui dan dipasang di kop surat digital!');
      };
      reader.readAsDataURL(e.target.files[0]);
    }
  };

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateProfile({
      name: schoolName,
      npsn: npsn,
      accreditation: accreditation,
      address: address,
      headmaster: principal,
      phone: phone
    });
    alert('Sukses menyimpan perubahan identitas sekolah serta rincian Kepala Sekolah!');
  };

  const handleSaveAcademic = (e: React.FormEvent) => {
    e.preventDefault();
    alert(`Konfigurasi Kalender Akademik sukses diubah ke Tahun: ${activeAcademicYear}, Semester: ${activeSemester}!`);
  };

  const handleBackupDatabase = () => {
    // Generate actual backup of active variables
    const backupObj = {
      schoolProfile: {
        name: schoolName,
        npsn,
        accreditation,
        address,
        headmaster: principal,
        phone,
        nipHeadmaster
      },
      activeAcademicYear,
      activeSemester,
      appTheme,
      notifSettings: {
        whatsapp: notifWhatsapp,
        email: notifEmail,
        telegram: notifTelegram
      },
      backupDate: new Date().toISOString()
    };

    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(backupObj, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `Al_Faraby_Database_Backup_${new Date().toISOString().split('T')[0]}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();

    alert('DATABASE BACKUP GENERATED: File backup (.json) berhasil diunduh secara aman.');
  };

  const handleRestoreDatabase = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const reader = new FileReader();
      reader.onload = () => {
        try {
          const parsed = JSON.parse(reader.result as string);
          if (parsed.schoolProfile) {
            setSchoolName(parsed.schoolProfile.name || schoolName);
            setNpsn(parsed.schoolProfile.npsn || npsn);
            setPrincipal(parsed.schoolProfile.headmaster || principal);
            if (parsed.activeAcademicYear) setActiveAcademicYear(parsed.activeAcademicYear);
            if (parsed.activeSemester) setActiveSemester(parsed.activeSemester);
            alert('ALHAMDULILLAH! Pemulihan restore database eksternal berhasil diimpor dengan sempurna.');
          } else {
            alert('Format berkas backup tidak valid.');
          }
        } catch {
          alert('Gagal mendeteksi JSON backup. Pastikan file dalam keadaan utuh.');
        }
      };
      reader.readAsText(e.target.files[0]);
    }
  };

  const handleUpdatePassword = (e: React.FormEvent) => {
    e.preventDefault();
    if (newPassword !== confirmPassword) {
      alert('Sandi baru tidak cocok dengan konfirmasi sandi!');
      return;
    }
    alert('Sandi asatidzah berhasil diperbarui secara terenkripsi.');
    setCurrentPassword('');
    setNewPassword('');
    setConfirmPassword('');
  };

  return (
    <div id="pengaturan-multi-panel" className="space-y-6">
      
      {/* TITLE BLOCK WITH MULTI-TABS GRID */}
      <div className="flex flex-col xl:flex-row xl:items-center justify-between pb-3 border-b border-slate-200 gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="bg-emerald-150 text-emerald-800 text-xxxxs uppercase font-extrabold px-2.5 py-1 rounded-full">
              Modul 12 Pusat
            </span>
            <h2 className="text-xl font-bold text-slate-800 school-display">Pengaturan & Konfigurasi Sistem</h2>
          </div>
          <p className="text-xxs text-slate-500 mt-1">Konfigurasikan database madrasah, tanda tangan digital, identitas sekolah, penyesuaian tema, serta notifikasi.</p>
        </div>

        {/* TABS OPTION BAR */}
        <div className="flex flex-wrap bg-slate-100 p-1 rounded-xl gap-0.5 shrink-0">
          {[
            { id: 'identitas', label: 'Identitas & Logo', icon: Building },
            { id: 'akademik', label: 'Tahun & Semester', icon: Calendar },
            { id: 'tema', label: 'Tema Aplikasi', icon: Palette },
            { id: 'pemeliharaan', label: 'Backup & Restore', icon: Database },
            { id: 'notifikasi', label: 'Notifikasi', icon: Bell },
            { id: 'keamanan', label: 'Keamanan Sandi', icon: Lock }
          ].map(t => (
            <button
              key={t.id}
              onClick={() => setActiveTab(t.id as any)}
              className={`px-3 py-1.5 text-xxs font-bold rounded-lg transition-all cursor-pointer flex items-center gap-1 ${
                activeTab === t.id ? 'bg-white shadow-xs text-brand-green-700' : 'text-slate-500 hover:text-slate-850'
              }`}
            >
              <t.icon className="h-3.5 w-3.5" />
              {t.label}
            </button>
          ))}
        </div>
      </div>

      {/* ===================== TAB 1: IDENTITAS SEKOLAH, LOGO, KEPSEK & SIGNATURE ===================== */}
      {activeTab === 'identitas' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* Identity input Fields (2 cols) */}
          <div className="bg-white rounded-2xl border border-slate-150 shadow-xxs p-6 lg:col-span-2 space-y-5">
            <div className="pb-3 border-b border-slate-100 flex items-center gap-2">
              <Building className="h-4.5 w-4.5 text-brand-green-700" />
              <span className="text-xs font-bold text-slate-800 school-display">Profil Satuan Pendidikan Negeri/Swasta</span>
            </div>

            <form onSubmit={handleSaveProfile} className="space-y-4 text-xxs">
              <div className="grid grid-cols-2 gap-4">
                <div className="col-span-2">
                  <label className="block text-[10px] font-bold text-slate-450 uppercase mb-1">Nama Madrasah / Satuan</label>
                  <input
                    type="text"
                    required
                    value={schoolName}
                    onChange={e => setSchoolName(e.target.value)}
                    className="w-full text-xs px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:border-brand-green-600 focus:bg-slate-50/20 font-semibold text-slate-800"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-450 uppercase mb-1">NPSN Resmi</label>
                  <input
                    type="text"
                    required
                    value={npsn}
                    onChange={e => setNpsn(e.target.value)}
                    className="w-full text-xs px-3 py-2 border border-slate-200 rounded-lg focus:outline-none text-slate-700 font-semibold"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-450 uppercase mb-1">Akreditasi Lembaga</label>
                  <select
                    value={accreditation}
                    onChange={e => setAccreditation(e.target.value)}
                    className="w-full text-xs px-3 py-2 border border-slate-200 rounded-lg bg-white font-semibold text-slate-800"
                  >
                    <option value="A (Unggul)">A (Unggul)</option>
                    <option value="B (Baik)">B (Baik)</option>
                    <option value="C (Cukup)">C (Cukup)</option>
                  </select>
                </div>

                <div className="col-span-2 border-t border-dashed border-slate-100 pt-3">
                  <label className="block text-[10px] font-bold text-amber-800 uppercase tracking-wide mb-1">Data Kepala Sekolah / Mudir Utama</label>
                  <div className="grid grid-cols-2 gap-3.5">
                    <div>
                      <label className="block text-[9px] font-bold text-slate-400 mb-0.5">Nama Lengkap Kepala</label>
                      <input
                        type="text"
                        value={principal}
                        onChange={e => setPrincipal(e.target.value)}
                        className="w-full text-xs px-3 py-2 border border-slate-200 rounded-lg focus:outline-none font-semibold text-slate-800"
                        placeholder="Dr. KH. Maimun Zubair, M.A."
                      />
                    </div>
                    <div>
                      <label className="block text-[9px] font-bold text-slate-400 mb-0.5">NIP / NUPTK Kepala</label>
                      <input
                        type="text"
                        value={nipHeadmaster}
                        onChange={e => setNipHeadmaster(e.target.value)}
                        className="w-full text-xs px-3 py-2 border border-slate-200 rounded-lg focus:outline-none font-semibold text-slate-800"
                        placeholder="NIP Kepala Sekolah"
                      />
                    </div>
                  </div>
                </div>

                <div className="col-span-2">
                  <label className="block text-[10px] font-bold text-slate-450 uppercase mb-1">Kontak Telepon Instansi</label>
                  <input
                    type="text"
                    value={phone}
                    onChange={e => setPhone(e.target.value)}
                    className="w-full text-xs px-3 py-2 border border-slate-200 rounded-lg focus:outline-none text-slate-850 font-semibold"
                  />
                </div>

                <div className="col-span-2">
                  <label className="block text-[10px] font-bold text-slate-450 uppercase mb-1">Alamat Geografis Satuan</label>
                  <textarea
                    rows={2}
                    value={address}
                    onChange={e => setAddress(e.target.value)}
                    className="w-full text-xs p-3 border border-slate-200 rounded-lg focus:outline-none leading-normal text-slate-750 font-medium"
                  />
                </div>
              </div>

              <div className="flex justify-end pt-3 border-t border-slate-100">
                <button
                  type="submit"
                  className="flex items-center gap-1.5 bg-brand-green-700 hover:bg-brand-green-800 text-white font-bold px-4 py-2 rounded-xl transition cursor-pointer text-[10px]"
                >
                  <Save className="h-4 w-4" />
                  Simpan Profil Setup
                </button>
              </div>
            </form>
          </div>

          {/* LOGO & DIGITAL SIGNATURE UPLOAD (1 col) */}
          <div className="space-y-6">
            
            {/* Logo Upload Box (Logo Sekolah) */}
            <div className="bg-white rounded-2xl border border-slate-150 shadow-xxs p-5 text-center space-y-3">
              <span className="font-extrabold text-[10px] text-slate-500 uppercase tracking-widest block text-left">
                Logo Sekolah Resmi
              </span>
              
              <div className="flex flex-col items-center justify-center p-4 bg-slate-50 rounded-xl border border-dashed border-slate-200">
                {schoolLogo ? (
                  <img src={schoolLogo} alt="Logo" className="h-20 w-20 object-contain mb-2 rounded" />
                ) : (
                  <div className="h-20 w-20 bg-slate-200 rounded-full flex items-center justify-center font-bold text-slate-500 mb-2">
                    LOGO
                  </div>
                )}
                
                <span className="text-[9px] text-slate-400 font-semibold mb-2">Max detail resolusi PNG 2MB.</span>
                
                <label className="bg-white border border-slate-200 text-slate-600 font-bold px-3 py-1.5 rounded-lg text-[9px] hover:bg-slate-100 cursor-pointer block text-center min-w-[120px]">
                  Unggah File Logo
                  <input type="file" accept="image/*" className="hidden" onChange={handleLogoUploadSimulate} />
                </label>
              </div>
            </div>

            {/* Signature Draw / Upload Box (Tanda Tangan Digital) */}
            <div className="bg-white rounded-2xl border border-slate-150 shadow-xxs p-5 text-center space-y-3">
              <span className="font-extrabold text-[10px] text-slate-500 uppercase tracking-widest block text-left">
                Tanda Tangan Digital Kepala
              </span>

              <div className="space-y-3 text-left">
                {/* Signature canvas draw area */}
                <div className="bg-slate-50 rounded-xl border border-slate-250 overflow-hidden">
                  <div className="p-1.5 bg-slate-100 text-[8px] text-slate-450 font-bold text-center border-b border-slate-250">
                    Sapu jari / kursor di pad abu-abu untuk menulis
                  </div>
                  <canvas
                    ref={sigCanvasRef}
                    width={240}
                    height={100}
                    onMouseDown={startDrawing}
                    onMouseMove={draw}
                    onMouseUp={stopDrawing}
                    onMouseLeave={stopDrawing}
                    className="w-full bg-slate-50 cursor-crosshair min-h-[100px] block"
                  />
                </div>

                <div className="flex items-center justify-between gap-2">
                  <button
                    type="button"
                    onClick={clearSignature}
                    className="text-slate-500 hover:text-slate-800 font-bold text-[8.5px] cursor-pointer"
                  >
                    Batal Coretan
                  </button>
                  <button
                    type="button"
                    onClick={saveSignatureFromCanvas}
                    className="bg-brand-green-700 hover:bg-brand-green-800 text-white font-bold px-2.5 py-1 rounded text-[8.5px] cursor-pointer flex items-center gap-1"
                  >
                    <PenTool className="h-3 w-3" /> Gunakan Coretan
                  </button>
                </div>

                {signatureImage && (
                  <div className="pt-2 border-t border-slate-100 flex items-center gap-2">
                    <span className="bg-emerald-50 text-emerald-800 px-1 py-0.2 rounded font-extrabold text-[8px]">Aktif</span>
                    <img src={signatureImage} alt="Signature Preview" className="h-8 object-contain bg-white border rounded border-slate-150" />
                  </div>
                )}
              </div>
            </div>

          </div>

        </div>
      )}

      {/* ===================== TAB 2: KALENDER & KONFIGURASI AKADEMIK ===================== */}
      {activeTab === 'akademik' && (
        <div className="bg-white rounded-2xl border border-slate-150 shadow-xxs p-6 max-w-xl">
          <div className="pb-3 border-b border-slate-100 flex items-center gap-2 mb-4">
            <Calendar className="h-4.5 w-4.5 text-blue-700" />
            <span className="text-xs font-bold text-slate-800 school-display">Konfigurasi Tahun Pelajaran & Semester Berjalan</span>
          </div>

          <form onSubmit={handleSaveAcademic} className="space-y-4 text-xxs">
            <div className="p-3.5 bg-yellow-50 border border-yellow-200/85 rounded-xl text-yellow-900 leading-normal mb-2 flex items-start gap-2.5">
              <Info className="h-4.5 w-4.5 text-amber-700 shrink-0 mt-0.5" />
              <p>
                <strong>Peringatan Kalender:</strong> Mengganti Tahun Pelajaran Aktif atau Semester akan menyesuaikan visibilitas default log kehadiran harian serta penginputan Rapor UTS/UAS asatidzah sekolah secara otomatis.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-[10px] font-bold text-slate-450 uppercase mb-1">Tahun Pelajaran Berjalan</label>
                <select
                  value={activeAcademicYear}
                  onChange={e => setActiveAcademicYear(e.target.value)}
                  className="w-full text-xs px-3 py-2 border border-slate-200 rounded-lg bg-white font-semibold text-slate-800 focus:outline-none"
                >
                  <option value="2026/2027">2026/2027 (Aktif)</option>
                  <option value="2027/2028">2027/2028</option>
                  <option value="2025/2026">2025/2026</option>
                </select>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-450 uppercase mb-1">Semester Aktif</label>
                <select
                  value={activeSemester}
                  onChange={e => setActiveSemester(e.target.value as any)}
                  className="w-full text-xs px-3 py-2 border border-slate-200 rounded-lg bg-white font-semibold text-slate-800 focus:outline-none"
                >
                  <option value="Ganjil">Semester Ganjil (Gasal)</option>
                  <option value="Genap">Semester Genap</option>
                </select>
              </div>
            </div>

            <div className="flex justify-end pt-3 border-t border-slate-100">
              <button
                type="submit"
                className="flex items-center gap-1.5 bg-brand-green-700 hover:bg-brand-green-800 text-white font-bold px-4 py-2 rounded-xl transition cursor-pointer text-[10px]"
              >
                Terapkan Sesi Akademik
              </button>
            </div>
          </form>
        </div>
      )}

      {/* ===================== TAB 3: TEMA WARNA APLIKASI PRESETS ===================== */}
      {activeTab === 'tema' && (
        <div className="bg-white rounded-2xl border border-slate-150 shadow-xxs p-6 max-w-2xl">
          <div className="pb-3 border-b border-slate-100 flex items-center gap-2 mb-4">
            <Palette className="h-4.5 w-4.5 text-pink-700" />
            <span className="text-xs font-bold text-slate-800 school-display">Personalisasi & Tema Aplikasi Al Faraby</span>
          </div>

          <div className="space-y-4">
            <p className="text-[10px] text-slate-500 leading-relaxed font-semibold">
              Pilih identitas warna aplikasi utama yang merefleksikan karakter madrasah Anda. Perubahaan visual ini langsung tersinkron secara meluas.
            </p>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-2">
              {[
                { id: 'hijau_madrasah', name: 'Hijau Klasik Madrasah', desc: 'Warna Al Faraby Alami', primary: 'bg-emerald-800', secondary: 'bg-amber-600' },
                { id: 'biru_modern', name: 'Biru Digital Quran', desc: 'Eksklusif IT Pendidikan', primary: 'bg-blue-800', secondary: 'bg-cyan-600' },
                { id: 'warna_emas', name: 'Al-Faraby Emas Tarbiyah', desc: 'Elegansi Pesantren Mulia', primary: 'bg-amber-800', secondary: 'bg-amber-500' },
                { id: 'indigo_soft', name: 'Kalam Indigo Pendidik', desc: 'Modern & Nyaman Mata', primary: 'bg-indigo-805', secondary: 'bg-pink-600' }
              ].map(t => {
                const isActive = appTheme === t.id;
                return (
                  <div
                    key={t.id}
                    onClick={() => {
                      setAppTheme(t.id as any);
                      alert(`Sukses mengubah preferensi visual madrasah ke skema: ${t.name}!`);
                    }}
                    className={`border-2 p-3.5 rounded-2xl cursor-pointer transition flex flex-col justify-between space-y-3 ${
                      isActive ? 'border-brand-green-600 bg-emerald-55/10 ring-2 ring-emerald-500/10' : 'border-slate-150 bg-slate-50 hover:bg-slate-100'
                    }`}
                  >
                    <div className="space-y-0.5">
                      <div className="font-extrabold text-[10px] text-slate-800">{t.name}</div>
                      <p className="text-[8px] text-slate-400 font-medium">{t.desc}</p>
                    </div>

                    <div className="flex items-center gap-1.5">
                      <span className={`h-4.5 w-4.5 rounded-full ${t.primary} inline-block`} />
                      <span className={`h-4.5 w-4.5 rounded-full ${t.secondary} inline-block`} />
                      {isActive && <Check className="h-3 w-3 text-emerald-800 ml-auto font-black" />}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* ===================== TAB 4: DATABASE BACKUP & RESTORE MONALISA ===================== */}
      {activeTab === 'pemeliharaan' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-3xl">
          
          {/* Backup Block */}
          <div className="bg-white rounded-2xl border border-slate-150 shadow-xxs p-5 space-y-4">
            <div className="pb-2.5 border-b border-slate-100 flex items-center justify-between">
              <span className="font-bold text-xs text-slate-800 school-display flex items-center gap-1.5">
                <Database className="h-4.5 w-4.5 text-brand-green-700" />
                Ekspor Backup Database (.JSON)
              </span>
            </div>

            <p className="text-[10px] text-slate-500 leading-normal font-semibold">
              Amankan salinan semua log kehadiran, skor raport kelulusan harian, hingga profil asatidzah sekolah ke dalam satu berkas terenkripsi ringan.
            </p>

            <button
              onClick={handleBackupDatabase}
              className="bg-brand-green-700 hover:bg-brand-green-800 text-white font-bold py-2 px-4 rounded-xl shadow-xs transition flex items-center gap-2 cursor-pointer text-[10px]"
            >
              <Download className="h-3.5 w-3.5" />
              Download Database Backup
            </button>
          </div>

          {/* Restore Block */}
          <div className="bg-white rounded-2xl border border-slate-150 shadow-xxs p-5 space-y-4">
            <div className="pb-2.5 border-b border-slate-100 flex items-center justify-between">
              <span className="font-bold text-xs text-slate-800 school-display flex items-center gap-1.5">
                <RefreshCw className="h-4.5 w-4.5 text-blue-700" />
                Impor Pemulihan Restore (.JSON)
              </span>
            </div>

            <p className="text-[10px] text-slate-500 leading-normal font-semibold">
              Kirimkan dokumen eksternal backup madrasah Al Faraby (.json) ke pemroses di bawah ini untuk memuat ulang seluruh state sekolah.
            </p>

            <label className="bg-slate-100 hover:bg-slate-200 text-slate-650 border border-slate-200 font-bold py-2 px-4 rounded-xl shadow-xs transition flex items-center justify-center gap-2 cursor-pointer text-[10px] text-center max-w-[200px]">
              <Upload className="h-3.5 w-3.5" />
              Impor File Backup
              <input type="file" accept=".json" className="hidden" onChange={handleRestoreDatabase} />
            </label>
          </div>

        </div>
      )}

      {/* ===================== TAB 5: SISTEM NOTIFIKASI ALERTS ===================== */}
      {activeTab === 'notifikasi' && (
        <div className="bg-white rounded-2xl border border-slate-150 shadow-xxs p-6 max-w-xl space-y-5">
          <div className="pb-3 border-b border-slate-100 flex items-center gap-2">
            <Bell className="h-4.5 w-4.5 text-amber-700 font-bold" />
            <span className="text-xs font-bold text-slate-800 school-display">Pengaturan Kanal Peringatan Notifikasi</span>
          </div>

          <p className="text-[10px] text-slate-500 leading-relaxed font-semibold">
            Tentukan media alarm yang aktif bila terdapat pencatatan ketuntasan nilai rapuh, pencerahan karakter murid oleh wali kelas, atau rekapitulasi kehadiran dinamis.
          </p>

          <div className="space-y-4 pt-1">
            <div className="flex items-center justify-between p-3.5 bg-slate-50 rounded-xl border border-slate-150">
              <div>
                <span className="font-bold text-[10px] text-slate-805 block">Alert WhatsApp Orang Tua Wali</span>
                <p className="text-[8.5px] text-slate-450 mt-0.5">Kirim pengingat bolos harian ke nomor WA bapak/ibu santri.</p>
              </div>
              <input
                type="checkbox"
                checked={notifWhatsapp}
                onChange={() => setNotifWhatsapp(!notifWhatsapp)}
                className="h-4 w-4 text-brand-green-600 focus:ring-0 cursor-pointer"
              />
            </div>

            <div className="flex items-center justify-between p-3.5 bg-slate-50 rounded-xl border border-slate-150">
              <div>
                <span className="font-bold text-[10px] text-slate-805 block">Integrasi Email Gmail Otomatis</span>
                <p className="text-[8.5px] text-slate-450 mt-0.5">Kirim transkrip Rapor UTS/UAS santri langsung ke Gmail terdaftar.</p>
              </div>
              <input
                type="checkbox"
                checked={notifEmail}
                onChange={() => setNotifEmail(!notifEmail)}
                className="h-4 w-4 text-brand-green-600 focus:ring-0 cursor-pointer"
              />
            </div>

            <div className="flex items-center justify-between p-3.5 bg-slate-50 rounded-xl border border-slate-150">
              <div>
                <span className="font-bold text-[10px] text-slate-805 block">Kanal Telegram Bot Sekolah</span>
                <p className="text-[8.5px] text-slate-450 mt-0.5">Sandi monitoring admin yayasan ke log grup internal asatidzah.</p>
              </div>
              <input
                type="checkbox"
                checked={notifTelegram}
                onChange={() => setNotifTelegram(!notifTelegram)}
                className="h-4 w-4 text-brand-green-600 focus:ring-0 cursor-pointer"
              />
            </div>
          </div>
        </div>
      )}

      {/* ===================== TAB 6: SECURITY PASSWORDS ===================== */}
      {activeTab === 'keamanan' && (
        <div className="bg-white rounded-2xl border border-slate-150 shadow-xxs p-6 max-w-md">
          <div className="pb-3 border-b border-slate-100 flex items-center gap-2 mb-4">
            <Lock className="h-4.5 w-4.5 text-indigo-700" />
            <span className="text-xs font-bold text-slate-800 school-display">Keamanan Sandi Forum Wali Kelas</span>
          </div>

          <form onSubmit={handleUpdatePassword} className="space-y-4 text-xxs">
            <div>
              <label className="block text-[10px] font-bold text-slate-450 uppercase mb-1">Kata Sandi Saat Ini</label>
              <input
                type="password"
                required
                value={currentPassword}
                onChange={e => setCurrentPassword(e.target.value)}
                className="w-full text-xs px-3 py-2 border border-slate-200 rounded-lg focus:outline-none"
                placeholder="••••••••"
              />
            </div>

            <div>
              <label className="block text-[10px] font-bold text-slate-455 uppercase mb-1">Kata Sandi Keamanan Baru</label>
              <input
                type="password"
                required
                value={newPassword}
                onChange={e => setNewPassword(e.target.value)}
                className="w-full text-xs px-3 py-2 border border-slate-200 rounded-lg focus:outline-none"
                placeholder="Minimal 6 karakter"
              />
            </div>

            <div>
              <label className="block text-[10px] font-bold text-slate-455 uppercase mb-1">Ketik Ulang Sandi Keamanan Baru</label>
              <input
                type="password"
                required
                value={confirmPassword}
                onChange={e => setConfirmPassword(e.target.value)}
                className="w-full text-xs px-3 py-2 border border-slate-200 rounded-lg focus:outline-none"
                placeholder="Sandi baru harus cocok"
              />
            </div>

            <div className="flex justify-end pt-3 border-t border-slate-100">
              <button
                type="submit"
                className="flex items-center gap-1.5 bg-brand-green-700 hover:bg-brand-green-800 text-white font-bold px-4 py-2 rounded-xl transition cursor-pointer text-[10px]"
              >
                Ganti Kata Sandi
              </button>
            </div>
          </form>
        </div>
      )}

    </div>
  );
}
