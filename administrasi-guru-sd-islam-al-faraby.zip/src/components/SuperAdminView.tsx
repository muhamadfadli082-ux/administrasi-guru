/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Shield,
  Eye,
  Trash,
  UserCheck,
  HelpCircle,
  HardDrive,
  ToggleLeft,
  ToggleRight,
  ListTodo,
  Activity,
  Plus,
  UserX,
  Edit,
  Check,
  X,
  Search,
  Database,
  FileText,
  Key,
  Download,
  AlertTriangle,
  RefreshCw,
  Sliders,
  CheckSquare,
  Lock,
  Unlock,
  Menu,
  Sparkles,
  Users
} from 'lucide-react';
import { ActivityLog, UserRole, SystemUser } from '../types';

interface SuperAdminViewProps {
  activityLogs: ActivityLog[];
  currentRole: string;
  onRoleChange: (role: string) => void;
  onClearLogs: () => void;
  
  // Real users state
  users: SystemUser[];
  onAddUser: (user: SystemUser) => void;
  onUpdateUser: (user: SystemUser) => void;
  onDeleteUser: (id: string) => void;
  
  // Custom sidebar menus
  enabledMenus: Record<string, boolean>;
  onToggleMenu: (menuName: string) => void;
  onResetMenus: () => void;
  
  // Database control
  onDatabaseSeeding: () => void;
  onDatabaseReset: () => void;
}

export default function SuperAdminView({
  activityLogs,
  currentRole,
  onRoleChange,
  onClearLogs,
  users,
  onAddUser,
  onUpdateUser,
  onDeleteUser,
  enabledMenus,
  onToggleMenu,
  onResetMenus,
  onDatabaseSeeding,
  onDatabaseReset
}: SuperAdminViewProps) {
  const [activeTab, setActiveTab] = useState<'users' | 'permissions' | 'logs' | 'database'>('users');
  
  // Create / Edit User State
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<SystemUser | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    role: 'Guru',
    phone: '',
    isActive: true
  });

  // Search & Filter state
  const [userSearch, setUserSearch] = useState('');
  const [userRoleFilter, setUserRoleFilter] = useState('ALL');
  const [logSearch, setLogSearch] = useState('');
  const [logLevelFilter, setLogLevelFilter] = useState('ALL');

  // Database simulator states
  const [dbStatusText, setDbStatusText] = useState('Database Siap & Stabil (Normal)');
  const [isProcessingDb, setIsProcessingDb] = useState(false);
  const [dbProgress, setDbProgress] = useState(0);

  // Simulated Matrix configuration
  const [permissionMatrix, setPermissionMatrix] = useState<Record<string, Record<string, boolean>>>({
    'Administrator': { cp_rpp: true, grades: true, master: true, media: true, print: true, ai_gemini: true },
    'Kepala Sekolah': { cp_rpp: true, grades: false, master: false, media: true, print: true, ai_gemini: true },
    'Guru': { cp_rpp: true, grades: true, master: false, media: true, print: false, ai_gemini: true },
    'Operator': { cp_rpp: false, grades: false, master: true, media: true, print: true, ai_gemini: false }
  });

  const toggleMatrixPermission = (role: string, perm: string) => {
    setPermissionMatrix(prev => ({
      ...prev,
      [role]: {
        ...prev[role],
        [perm]: !prev[role][perm]
      }
    }));
  };

  const handleOpenAddForm = () => {
    setEditingUser(null);
    setFormData({
      name: '',
      email: '',
      role: 'Guru',
      phone: '',
      isActive: true
    });
    setIsFormOpen(true);
  };

  const handleOpenEditForm = (user: SystemUser) => {
    setEditingUser(user);
    setFormData({
      name: user.name,
      email: user.email,
      role: user.role,
      phone: user.phone || '',
      isActive: user.isActive
    });
    setIsFormOpen(true);
  };

  const handleSubmitUser = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.email) {
      alert('Nama dan Email wajib diisi!');
      return;
    }

    if (editingUser) {
      onUpdateUser({
        ...editingUser,
        name: formData.name,
        email: formData.email,
        role: formData.role,
        phone: formData.phone,
        isActive: formData.isActive
      });
    } else {
      onAddUser({
        id: 'usr-' + Math.floor(Math.random() * 100000),
        name: formData.name,
        email: formData.email,
        role: formData.role,
        phone: formData.phone,
        isActive: formData.isActive,
        createdAt: new Date().toLocaleDateString('id-ID', { day: '2-digit', month: 'short', year: 'numeric' })
      });
    }
    setIsFormOpen(false);
    setEditingUser(null);
  };

  const handleDeleteClick = (userId: string, userName: string) => {
    const isConfirm = window.confirm(`Apakah Anda yakin ingin menghapus permanen akun ${userName}?`);
    if (isConfirm) {
      onDeleteUser(userId);
    }
  };

  const handleToggleActivate = (user: SystemUser) => {
    onUpdateUser({
      ...user,
      isActive: !user.isActive
    });
  };

  // Database simulator triggers
  const triggerOptimize = () => {
    setIsProcessingDb(true);
    setDbProgress(0);
    setDbStatusText('Mengoptimalkan tabel-tabel relational sekolah...');
    
    let current = 0;
    const interval = setInterval(() => {
      current += 10;
      setDbProgress(current);
      if (current === 30) setDbStatusText('Merekontruksi index b-tree pada data murid & pendidik...');
      if (current === 60) setDbStatusText('Menghapus cache RPP & menormalisasi skoring kurikulum...');
      if (current === 90) setDbStatusText('Mengevaluasi SHA-256 integrasi kedaulatan audit trail...');
      
      if (current >= 100) {
        clearInterval(interval);
        setIsProcessingDb(false);
        setDbStatusText('Database Berhasil Dioptimalkan! Tingkat Efisiensi Kueri: +42%');
        alert('Optimasi Database Selesai! Indeks b-tree dibersihkan & kecepatan response server meningkat.');
      }
    }, 150);
  };

  const triggerExportBackup = () => {
    const backupObj = {
      exportedAt: new Date().toISOString(),
      schoolName: 'SD Islam Al Faraby',
      usersCount: users.length,
      users: users,
      menuConfig: enabledMenus,
      permissionMatrix: permissionMatrix,
      diagnosticStatus: 'PERFECT'
    };

    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(backupObj, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href",     dataStr);
    downloadAnchor.setAttribute("download", `AlFaraby_DBBackup_${new Date().toISOString().slice(0,10)}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  // Filter systems
  const filteredUsers = users.filter(u => {
    const matchesSearch = u.name.toLowerCase().includes(userSearch.toLowerCase()) || 
                          u.email.toLowerCase().includes(userSearch.toLowerCase());
    const matchesRole = userRoleFilter === 'ALL' || u.role === userRoleFilter;
    return matchesSearch && matchesRole;
  });

  const filteredLogs = activityLogs.filter(log => {
    const matchesSearch = log.userName.toLowerCase().includes(logSearch.toLowerCase()) ||
                          log.action.toLowerCase().includes(logSearch.toLowerCase()) ||
                          log.details.toLowerCase().includes(logSearch.toLowerCase());
    
    if (logLevelFilter === 'ALL') return matchesSearch;
    if (logLevelFilter === 'SECURITY') {
      return matchesSearch && (log.action.includes('Login') || log.action.includes('Logout') || log.action.includes('Peran'));
    }
    if (logLevelFilter === 'DATABASE') {
      return matchesSearch && (log.action.includes('Registrasi') || log.action.includes('Penghapusan') || log.action.includes('Modifikasi') || log.action.includes('Pemulihan') || log.action.includes('Pembersihan'));
    }
    if (logLevelFilter === 'RPP') {
      return matchesSearch && (log.action.includes('RPP') || log.action.includes('Jurnal') || log.action.includes('Mata Pelajaran'));
    }
    return matchesSearch;
  });

  // Sidebar Menu list matching sidebar
  const menuList = [
    { name: 'Dashboard', desc: 'Summary statistik makro & ringkasan adab siswa modern.' },
    { name: 'Master Data', desc: 'Manajemen record murid, dewan asatidzah & mata pelajaran.' },
    { name: 'Administrasi Pembelajaran', desc: 'Penyusunan RPP Kurikulum Merdeka Terintegrasi AI, CP, TP, ATP.' },
    { name: 'Administrasi Kelas', desc: 'Buku agenda mengajar digital, catatan perkembangan & tamu.' },
    { name: 'Penilaian', desc: 'Laporan prestasi formatif, sumatif & cetak ledger nilai.' },
    { name: 'Bank Soal', desc: 'Database butir ulangan harian, UTS, & UAS sekolah.' },
    { name: 'LKPD / LKS', desc: 'Lembar Kerja Peserta Didik interaktif bersumber AI.' },
    { name: 'Media Pembelajaran', desc: 'Modul ajar digital, salinan infografis, & visual presentasi.' },
    { name: 'Laporan', desc: 'Konsolidasikan data presensi, RPP, dan adab menjadi e-Rapor.' },
    { name: 'Arsip Digital', desc: 'Penyimpanan cloud dokumen penting terhubung Google Drive.' },
    { name: 'Pengaturan', desc: 'Identitas nomor NPSN lembaga, visi-misi & akreditasi sekolah.' }
  ];

  return (
    <div id="super-admin-root" className="space-y-6">
      
      {/* 1. HEADER SECTION */}
      <div className="flex flex-col md:flex-row md:items-center justify-between pb-4 border-b border-slate-200 gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="bg-rose-500 text-white text-[10px] uppercase font-extrabold px-2 py-0.5 rounded-sm">SUPER ADMIN</span>
            <span className="bg-brand-green-100 text-brand-green-800 text-[10px] font-bold px-2 py-0.5 rounded-sm flex items-center gap-1">
              <Sparkles className="h-3 w-3 text-brand-gold-500" /> Modul 13 Complete
            </span>
          </div>
          <h2 className="text-xl font-bold text-slate-800 school-display mt-1">Super Admin & Otorisasi Sistem</h2>
          <p className="text-xs text-slate-500">Dasbor tata kelola database santri, manajemen menu dinamis, auditing, dan pengamanan hak akses.</p>
        </div>

        {/* Real-time statistics widgets */}
        <div className="flex gap-2">
          <button
            onClick={() => {
              const confirmReset = window.confirm('Kembalikan konfigurasi menu visual navigasi ke konfigurasi bawaan?');
              if (confirmReset) onResetMenus();
            }}
            className="text-xxs font-bold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 px-3.5 py-2 border border-emerald-200 rounded-xl transition cursor-pointer flex items-center gap-1.5"
          >
            <RefreshCw className="h-3 w-3" /> Reset Menu Standard
          </button>
        </div>
      </div>

      {/* 2. ROLE TOGGLE WARNING AND SIMULATION BAR */}
      <div className="bg-yellow-50 border border-yellow-200/80 rounded-2xl p-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-start gap-3">
          <div className="p-2 bg-yellow-100 rounded-xl text-yellow-800 self-center">
            <Shield className="h-5 w-5" />
          </div>
          <div>
            <h4 className="text-xs font-bold text-yellow-900">Simulator Multi-Peran Aktif</h4>
            <p className="text-xxxxs text-yellow-700 leading-normal mt-0.5 max-w-xl">
              Saat ini Anda mengemban tanggung jawab simulasi sebagai <strong className="underline">{currentRole}</strong>. 
              Mengubah peran aktif di bawah ini akan secara langsung memperbarui visibilitas antarmuka, hak akses fungsionalitas menu, dan kedaulatan data Anda di sistem.
            </p>
          </div>
        </div>
        <div className="flex flex-wrap gap-1.5 shrink-0">
          {Object.values(UserRole).map((role) => (
            <button
              key={role}
              onClick={() => onRoleChange(role)}
              className={`px-3 py-1.5 rounded-lg text-xxs font-extrabold transition cursor-pointer flex items-center gap-1 ${
                currentRole === role
                  ? 'bg-brand-green-800 text-white shadow-md scale-102 border-b-2 border-brand-gold-500'
                  : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-200'
              }`}
            >
              {currentRole === role && <span className="w-1.5 h-1.5 bg-brand-gold-500 rounded-full animate-pulse inline-block" />}
              {role === UserRole.ADMIN ? 'Admin' : role === UserRole.KEPSEK ? 'Kepsek' : role === UserRole.GURU ? 'Guru' : 'Operator'}
            </button>
          ))}
        </div>
      </div>

      {/* 3. NAVIGATION TABS */}
      <div className="flex border-b border-slate-200 gap-1 overflow-x-auto pb-px">
        <button
          onClick={() => setActiveTab('users')}
          className={`px-4 py-2.5 text-xs font-bold transition flex items-center gap-2 shrink-0 border-b-2 cursor-pointer ${
            activeTab === 'users'
              ? 'border-brand-green-700 text-brand-green-850 bg-emerald-50/30'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Users className="h-4 w-4" /> Manajemen Pengguna
        </button>
        <button
          onClick={() => setActiveTab('permissions')}
          className={`px-4 py-2.5 text-xs font-bold transition flex items-center gap-2 shrink-0 border-b-2 cursor-pointer ${
            activeTab === 'permissions'
              ? 'border-brand-green-700 text-brand-green-850 bg-emerald-50/30'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Sliders className="h-4 w-4" /> Hak Akses & Menu Aktif
        </button>
        <button
          onClick={() => setActiveTab('logs')}
          className={`px-4 py-2.5 text-xs font-bold transition flex items-center gap-2 shrink-0 border-b-2 cursor-pointer ${
            activeTab === 'logs'
              ? 'border-brand-green-700 text-brand-green-850 bg-emerald-50/30'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Activity className="h-4 w-4" /> Monitor Audit & Log
        </button>
        <button
          onClick={() => setActiveTab('database')}
          className={`px-4 py-2.5 text-xs font-bold transition flex items-center gap-2 shrink-0 border-b-2 cursor-pointer ${
            activeTab === 'database'
              ? 'border-brand-green-700 text-brand-green-850 bg-emerald-50/30'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Database className="h-4 w-4" /> Pengelolaan Database
        </button>
      </div>

      {/* 4. TAB CONTENTS */}
      
      {/* TAB 1: MANAJEMEN PENGGUNA */}
      {activeTab === 'users' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="relative w-full sm:max-w-xs">
              <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
              <input
                type="text"
                value={userSearch}
                onChange={e => setUserSearch(e.target.value)}
                placeholder="Cari user berdasarkan nama/email..."
                className="w-full text-xs pl-9 pr-4 py-2 rounded-xl border border-slate-200 focus:outline-none focus:ring-1 focus:ring-brand-green-700 bg-white"
              />
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <select
                value={userRoleFilter}
                onChange={e => setUserRoleFilter(e.target.value)}
                className="text-xxs px-3 py-2 border border-slate-200 rounded-xl bg-white focus:outline-none focus:ring-1 focus:ring-brand-green-700"
              >
                <option value="ALL">Semua Peran</option>
                <option value="Administrator">Administrator</option>
                <option value="Kepala Sekolah">Kepala Sekolah</option>
                <option value="Guru">Guru</option>
                <option value="Operator">Operator</option>
              </select>

              <button
                onClick={handleOpenAddForm}
                className="text-xxs font-bold text-white bg-brand-green-800 hover:bg-brand-green-900 border border-transparent px-4 py-2 rounded-xl cursor-pointer shadow-sm transition-transform hover:scale-101 flex items-center gap-1.5"
              >
                <Plus className="h-3.5 w-3.5" /> Daftarkan Pengguna Baru
              </button>
            </div>
          </div>

          {/* USER FORM DIALOG BOX (INLINE ACCORDION FORM) */}
          {isFormOpen && (
            <div className="bg-slate-50 border border-slate-200 rounded-2xl p-6 transition-all animate-in slide-in-from-top-4 duration-200 max-w-xl">
              <div className="flex items-center justify-between pb-3 border-b border-slate-200 mb-4">
                <h3 className="text-xs font-bold text-slate-800 flex items-center gap-2">
                  <Key className="h-4 w-4 text-brand-green-700" />
                  {editingUser ? 'Ubah Informasi Pengguna' : 'Daftarkan Pengguna Baru'}
                </h3>
                <button
                  type="button"
                  onClick={() => setIsFormOpen(false)}
                  className="p-1 text-slate-400 hover:text-slate-600 rounded-lg"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>

              <form onSubmit={handleSubmitUser} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xxxxs font-bold text-slate-500 uppercase tracking-wider mb-1">Nama Lengkap & Gelar</label>
                    <input
                      type="text"
                      required
                      value={formData.name}
                      onChange={e => setFormData({ ...formData, name: e.target.value })}
                      placeholder="Contoh: Ustadzah Lailatul, S.Pd.I."
                      className="w-full text-xs px-3 py-2 border border-slate-200 rounded-lg bg-white"
                    />
                  </div>

                  <div>
                    <label className="block text-xxxxs font-bold text-slate-500 uppercase tracking-wider mb-1">Alamat Pos Email</label>
                    <input
                      type="email"
                      required
                      value={formData.email}
                      onChange={e => setFormData({ ...formData, email: e.target.value })}
                      placeholder="Contoh: lailatul@gmail.com"
                      className="w-full text-xs px-3 py-2 border border-slate-200 rounded-lg bg-white"
                    />
                  </div>

                  <div>
                    <label className="block text-xxxxs font-bold text-slate-500 uppercase tracking-wider mb-1">Hak Peran Utama</label>
                    <select
                      value={formData.role}
                      onChange={e => setFormData({ ...formData, role: e.target.value })}
                      className="w-full text-xs px-3 py-2 border border-slate-200 rounded-lg bg-white"
                    >
                      <option value="Administrator">Administrator</option>
                      <option value="Kepala Sekolah">Kepala Sekolah</option>
                      <option value="Guru">Guru</option>
                      <option value="Operator">Operator</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xxxxs font-bold text-slate-500 uppercase tracking-wider mb-1">Nomor Telepon Seluler</label>
                    <input
                      type="text"
                      value={formData.phone}
                      onChange={e => setFormData({ ...formData, phone: e.target.value })}
                      placeholder="Contoh: 081299881122"
                      className="w-full text-xs px-3 py-2 border border-slate-200 rounded-lg bg-white"
                    />
                  </div>
                </div>

                <div className="flex items-center gap-3 pt-2">
                  <span className="block text-xxxxs font-bold text-slate-500 uppercase tracking-wider">Status Aktivasi Akun:</span>
                  <button
                    type="button"
                    onClick={() => setFormData({ ...formData, isActive: !formData.isActive })}
                    className="flex items-center gap-1.5 focus:outline-none"
                  >
                    {formData.isActive ? (
                      <span className="text-xxs text-emerald-700 font-extrabold flex items-center gap-1">
                        <ToggleRight className="h-7 w-7 text-emerald-600" /> Aktif
                      </span>
                    ) : (
                      <span className="text-xxs text-rose-600 font-extrabold flex items-center gap-1">
                        <ToggleLeft className="h-7 w-7 text-slate-300" /> Nonaktif
                      </span>
                    )}
                  </button>
                </div>

                <div className="flex justify-end gap-2 pt-4 border-t border-slate-200 text-xxs">
                  <button
                    type="button"
                    onClick={() => setIsFormOpen(false)}
                    className="px-4 py-2 border border-slate-200 bg-white hover:bg-slate-50 font-bold rounded-lg cursor-pointer"
                  >
                    Batal
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 bg-brand-green-800 text-white hover:bg-brand-green-900 font-bold rounded-lg cursor-pointer shadow-xs"
                  >
                    {editingUser ? 'Simpan Perubahan' : 'Selesaikan Registrasi'}
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* LIST OF SYSTEM USERS */}
          <div className="bg-white rounded-2xl border border-slate-100 shadow-xs overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xxs">
                <thead>
                  <tr className="border-b border-slate-100 bg-slate-50/70 text-slate-500 font-bold uppercase tracking-wider">
                    <th className="p-4">Nama Pengguna</th>
                    <th className="p-4">Email</th>
                    <th className="p-4">Peran (Role)</th>
                    <th className="p-4">Telepon</th>
                    <th className="p-4">Aktivasi Sesi</th>
                    <th className="p-4 text-center">Tindakan</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-slate-700">
                  {filteredUsers.length > 0 ? (
                    filteredUsers.map((u) => (
                      <tr key={u.id} className="hover:bg-slate-50/40 transition-colors">
                        <td className="p-4">
                          <div className="flex items-center gap-2.5">
                            <div className="h-7 w-7 rounded-full bg-emerald-50 text-emerald-800 font-bold text-xxs flex items-center justify-center border border-emerald-100 uppercase">
                              {u.name.charAt(u.name.indexOf(' ') + 1) || 'AF'}
                            </div>
                            <div>
                              <div className="font-bold text-slate-800 text-xs">{u.name}</div>
                              <div className="text-[9px] text-slate-400">Terdaftar sejak {u.createdAt}</div>
                            </div>
                          </div>
                        </td>
                        <td className="p-4 font-semibold text-slate-600">{u.email}</td>
                        <td className="p-4">
                          <span className={`px-2 py-0.5 rounded-full font-bold text-xxxxs ${
                            u.role === 'Administrator' ? 'bg-indigo-50 text-indigo-700' :
                            u.role === 'Kepala Sekolah' ? 'bg-purple-50 text-purple-700' :
                            u.role === 'Operator' ? 'bg-amber-100 text-amber-800' :
                            'bg-teal-50 text-teal-700'
                          }`}>
                            {u.role}
                          </span>
                        </td>
                        <td className="p-4 font-mono text-slate-500">{u.phone || '-'}</td>
                        <td className="p-4">
                          <button
                            onClick={() => handleToggleActivate(u)}
                            id={`toggle-user-active-${u.id}`}
                            className="focus:outline-none transition-transform hover:scale-105"
                            title="Klik untuk mengubah status aktivasi akun"
                          >
                            {u.isActive ? (
                              <span className="inline-flex items-center gap-1 bg-emerald-50 text-emerald-800 px-2 py-0.5 rounded-lg font-bold border border-emerald-100">
                                <Check className="h-3 w-3" /> AKUN AKTIF
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1 bg-rose-50 text-rose-800 px-2 py-0.5 rounded-lg font-bold border border-rose-100">
                                <X className="h-3 w-3" /> DINONAKTIFKAN
                              </span>
                            )}
                          </button>
                        </td>
                        <td className="p-4">
                          <div className="flex items-center justify-center gap-2">
                            <button
                              onClick={() => handleOpenEditForm(u)}
                              className="p-1 px-2 text-xxs font-bold text-brand-green-800 hover:text-white hover:bg-brand-green-800 border border-brand-green-100 hover:border-brand-green-800 rounded-lg cursor-pointer transition-colors"
                              title="Sunting rincian data pengguna"
                            >
                              <Edit className="h-3 w-3" />
                            </button>
                            <button
                              onClick={() => handleDeleteClick(u.id, u.name)}
                              className="p-1 px-2 text-xxs font-bold text-rose-600 hover:text-white hover:bg-rose-600 border border-rose-100 hover:border-rose-600 rounded-lg cursor-pointer transition-colors"
                              title="Hapus permanen database pengguna"
                              disabled={u.email === 'ahmadfaruq@alfaraby.sch.id'} // Don't delete main admin
                            >
                              <Trash className="h-3 w-3" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan={6} className="p-8 text-center text-slate-400 font-semibold italic">
                        Tidak ditemukan data pengguna yang cocok dengan kriteria pencarian Anda.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
            
            <div className="p-3 bg-slate-50 text-xxxxs text-slate-500 font-medium italic border-t border-slate-100">
              * Keamanan Pengenal: Akun dengan status "DINONAKTIFKAN" segera dikunci dari portal dan simpul navigasi. Password login di-hash menggunakan otentikasi standard.
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: HAK AKSES & MENU AKTIF */}
      {activeTab === 'permissions' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          
          {/* PERMISSIONS MATRIX */}
          <div className="lg:col-span-7 bg-white rounded-2xl border border-slate-100 shadow-xs p-6 space-y-4">
            <div className="flex items-center gap-2 pb-3 border-b border-slate-100">
              <Sliders className="h-5 w-5 text-indigo-700" />
              <div>
                <h3 className="font-bold text-sm text-slate-800 school-display">Matriks Otorisasi Berbasis Peran</h3>
                <p className="text-xxx-small text-slate-400">Alihkan hak di bawah untuk menyesuaikan kemampuan fungsional setiap peran (simulasi).</p>
              </div>
            </div>

            <div className="overflow-x-auto pt-2">
              <table className="w-full text-left border-collapse text-xxs">
                <thead>
                  <tr className="border-b border-indigo-100 bg-indigo-50/50 text-indigo-800 font-bold uppercase tracking-wider">
                    <th className="p-3">Hak Peran (Role)</th>
                    <th className="p-3 text-center">Tulis CP/RPP</th>
                    <th className="p-3 text-center">Input Rapor</th>
                    <th className="p-3 text-center">Arsip Guru</th>
                    <th className="p-3 text-center">Cetak Berkas</th>
                    <th className="p-3 text-center">Gemini AI</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-slate-600 font-semibold">
                  {Object.keys(permissionMatrix).map((role) => (
                    <tr key={role} className="hover:bg-slate-50/20">
                      <td className="p-3">
                        <div className="font-bold text-slate-800">{role}</div>
                        <div className="text-xxxxs text-slate-400 font-normal">Sistem Otoritas</div>
                      </td>
                      
                      <td className="p-3 text-center">
                        <input
                          type="checkbox"
                          checked={permissionMatrix[role].cp_rpp}
                          onChange={() => toggleMatrixPermission(role, 'cp_rpp')}
                          className="h-3.5 w-3.5 text-brand-green-600 border-slate-300 rounded focus:ring-brand-green-500 cursor-pointer"
                        />
                      </td>

                      <td className="p-3 text-center">
                        <input
                          type="checkbox"
                          checked={permissionMatrix[role].grades}
                          onChange={() => toggleMatrixPermission(role, 'grades')}
                          className="h-3.5 w-3.5 text-brand-green-600 border-slate-300 rounded focus:ring-brand-green-500 cursor-pointer"
                        />
                      </td>

                      <td className="p-3 text-center">
                        <input
                          type="checkbox"
                          checked={permissionMatrix[role].master}
                          onChange={() => toggleMatrixPermission(role, 'master')}
                          className="h-3.5 w-3.5 text-brand-green-600 border-slate-300 rounded focus:ring-brand-green-500 cursor-pointer"
                        />
                      </td>

                      <td className="p-3 text-center">
                        <input
                          type="checkbox"
                          checked={permissionMatrix[role].print}
                          onChange={() => toggleMatrixPermission(role, 'print')}
                          className="h-3.5 w-3.5 text-brand-green-600 border-slate-300 rounded focus:ring-brand-green-500 cursor-pointer"
                        />
                      </td>

                      <td className="p-3 text-center">
                        <input
                          type="checkbox"
                          checked={permissionMatrix[role].ai_gemini}
                          onChange={() => toggleMatrixPermission(role, 'ai_gemini')}
                          className="h-3.5 w-3.5 text-brand-green-600 border-slate-300 rounded focus:ring-brand-green-500 cursor-pointer"
                        />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="p-3 bg-indigo-50/40 rounded-xl text-xxx-small text-indigo-900 border border-indigo-100 flex items-start gap-2">
              <span className="text-sm">💡</span>
              <div>
                <strong>Dampak Matriks:</strong> Konfigurasi ini mensimulasikan sistem multi-perizinan granular. 
                Hak akses asatidzah akan membatasi atau membuka tombol CRUD pada modul individual, seperti perumusan modul ajar Kurikulum Merdeka.
              </div>
            </div>
          </div>

          {/* APPLICATION MENU SETTINGS */}
          <div className="lg:col-span-5 bg-white rounded-2xl border border-slate-100 shadow-xs p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Menu className="h-5 w-5 text-emerald-700" />
                <div>
                  <h3 className="font-bold text-sm text-slate-800 school-display">Pengaturan Menu Aplikasi</h3>
                  <p className="text-xxx-small text-slate-400">Atur visibilitas dan ketersediaan modul sidebar navigasi.</p>
                </div>
              </div>
            </div>

            <p className="text-xxxxs text-slate-500 leading-normal">
              Nonaktifkan (uncheck) menu di bawah ini untuk **menyembunyikannya secara instan** dari menu navigasi sidebar utama bagi seluruh pengguna. Ini berguna untuk masa libur, ujian, atau pemeliharaan modul tertentu.
            </p>

            <div className="space-y-2.5 pt-2 max-h-96 overflow-y-auto pr-1">
              {menuList.map((m) => {
                const isEnabled = enabledMenus[m.name] !== false;
                return (
                  <div
                    key={m.name}
                    className={`p-3 rounded-xl border transition-colors flex items-center justify-between gap-4 ${
                      isEnabled ? 'border-brand-green-100 bg-emerald-50/20' : 'border-slate-100 bg-slate-50/40 opacity-70'
                    }`}
                  >
                    <div>
                      <div className="font-bold text-slate-800 text-xxs">{m.name}</div>
                      <p className="text-[9px] text-slate-400 font-medium leading-tight mt-0.5">{m.desc}</p>
                    </div>

                    <button
                      onClick={() => onToggleMenu(m.name)}
                      className="focus:outline-none shrink-0"
                      title={isEnabled ? 'Klik untuk menyembunyikan modul' : 'Klik untuk menampilkan modul'}
                    >
                      {isEnabled ? (
                        <span className="inline-flex items-center gap-1 text-[10px] font-bold text-brand-green-700">
                          <CheckSquare className="h-4.5 w-4.5 text-brand-green-600" /> Aktif
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 text-[10px] font-bold text-slate-400">
                          <span className="w-4 h-4 rounded border border-slate-300 block bg-white" /> Sembunyi
                        </span>
                      )}
                    </button>
                  </div>
                );
              })}
            </div>
          </div>

        </div>
      )}

      {/* TAB 3: SYSTEM LOGS AUDIT */}
      {activeTab === 'logs' && (
        <div className="bg-white rounded-2xl border border-slate-100 shadow-xs p-6 space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-3 border-b border-slate-100">
            <div>
              <h3 className="font-bold text-sm text-slate-800 school-display flex items-center gap-2">
                <Activity className="h-5 w-5 text-brand-gold-600" />
                Audit Trail Log Aktivitas Real-time
              </h3>
              <p className="text-xxx-small text-slate-400">Arsip otomatis seluruh modifikasi database, login terekam, audit fungsionalitas.</p>
            </div>

            <div className="flex flex-wrap gap-2 text-xxs">
              <button
                onClick={onClearLogs}
                className="text-xxxxs font-bold text-rose-600 hover:text-white hover:bg-rose-600 border border-rose-200 bg-white px-3 py-1.5 rounded-lg cursor-pointer transition-colors"
              >
                Kosongkan Logs
              </button>
              
              <button
                onClick={triggerExportBackup}
                className="text-xxxxs font-bold text-brand-green-800 hover:text-white hover:bg-brand-green-850 border border-brand-green-200 bg-white px-3 py-1.5 rounded-lg cursor-pointer transition-colors flex items-center gap-1"
              >
                <Download className="h-3 w-3" /> Unduh Raw JSON
              </button>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-2.5 items-center justify-between">
            <div className="relative w-full sm:max-w-xs">
              <Search className="absolute left-3 top-2 w-3.5 h-3.5 text-slate-400" />
              <input
                type="text"
                value={logSearch}
                onChange={e => setLogSearch(e.target.value)}
                placeholder="Cari log kueri tindakan..."
                className="w-full text-xxs pl-8 pr-4 py-1.5 rounded-lg border border-slate-200 focus:outline-none"
              />
            </div>

            <div className="flex items-center gap-1.5 shrink-0 text-xxxxs font-bold uppercase text-slate-400">
              <span>Saring Kategori:</span>
              <div className="flex gap-1.5">
                {['ALL', 'SECURITY', 'DATABASE', 'RPP'].map((lvl) => (
                  <button
                    key={lvl}
                    onClick={() => setLogLevelFilter(lvl)}
                    className={`px-2 py-1 rounded text-xxs font-bold border transition ${
                      logLevelFilter === lvl
                        ? 'bg-slate-800 text-white border-slate-800'
                        : 'bg-white text-slate-600 hover:bg-slate-100 border-slate-200'
                    }`}
                  >
                    {lvl}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* TABLE LOGS */}
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xxs">
              <thead>
                <tr className="border-b border-slate-100 bg-slate-50 text-slate-500 font-bold uppercase tracking-wider">
                  <th className="p-3 w-32">Waktu Log</th>
                  <th className="p-3 w-36">Nama Operator</th>
                  <th className="p-3 w-28">Hak Peran</th>
                  <th className="p-3 w-36">Kategori Tindakan</th>
                  <th className="p-3">Rincian Modifikasi / Operasi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700 font-medium">
                {filteredLogs.length > 0 ? (
                  filteredLogs.map((log) => {
                    const isSecurity = log.action.includes('Login') || log.action.includes('Logout') || log.action.includes('Peran');
                    const isDelete = log.action.includes('Penghapusan') || log.action.includes('Pembersihan');
                    return (
                      <tr key={log.id} className="hover:bg-slate-50/40">
                        <td className="p-3 font-mono text-slate-400 font-light text-xxx-small">{log.timestamp}</td>
                        <td className="p-3 font-bold text-slate-800 truncate max-w-xs">{log.userName}</td>
                        <td className="p-3">
                          <span className={`px-2 py-0.5 rounded font-extrabold text-xxxxs ${
                            log.userRole === 'Administrator' ? 'bg-indigo-50 text-indigo-700' :
                            log.userRole === 'Kepala Sekolah' ? 'bg-purple-50 text-purple-700' : 'bg-teal-50 text-teal-700'
                          }`}>
                            {log.userRole}
                          </span>
                        </td>
                        <td className="p-3 font-bold">
                          <span className={`inline-block px-2 py-0.5 rounded text-xxxxs ${
                            isSecurity ? 'bg-amber-50 text-amber-700' :
                            isDelete ? 'bg-rose-50 text-rose-700 font-extrabold' : 'bg-emerald-50 text-brand-green-850'
                          }`}>
                            {log.action}
                          </span>
                        </td>
                        <td className="p-3 text-slate-600 font-semibold">{log.details}</td>
                      </tr>
                    );
                  })
                ) : (
                  <tr>
                    <td colSpan={5} className="p-6 text-center text-slate-400 italic font-semibold">
                      Tidak ada log sistem yang cocok dengan filter kriteria Anda.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 4: PENGELOLAAN DATABASE */}
      {activeTab === 'database' && (
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
          
          <div className="md:col-span-8 bg-white rounded-2xl border border-slate-100 shadow-xs p-6 space-y-6">
            <div className="flex items-center gap-2 pb-3 border-b border-slate-100">
              <Database className="h-5 w-5 text-indigo-600" />
              <div>
                <h3 className="font-bold text-sm text-slate-800 school-display">Operasi Fisik & Pemeliharaan Database</h3>
                <p className="text-xxx-small text-slate-400">Kelola kondisi tabel sistem, backup reguler, dan pengindeksan data sekolah.</p>
              </div>
            </div>

            {/* Simulated Integrity check card */}
            <div className="border border-slate-100 rounded-2xl p-4 bg-slate-50 space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-[10px] font-bold text-indigo-800 uppercase bg-indigo-50 border border-indigo-100 px-2.5 py-0.5 rounded-md">Status Database</span>
                  <div className="text-xs font-bold text-slate-800 mt-2">{dbStatusText}</div>
                </div>
                
                <button
                  onClick={triggerOptimize}
                  disabled={isProcessingDb}
                  className="text-xxs font-bold text-indigo-700 hover:text-white hover:bg-indigo-700 border border-indigo-200 bg-white px-3 py-1.5 rounded-xl cursor-pointer disabled:opacity-50 transition"
                >
                  Optimalkan Indeks DB
                </button>
              </div>

              {isProcessingDb && (
                <div className="space-y-1.5 pt-2">
                  <div className="w-full bg-slate-200 rounded-full h-1.5">
                    <div
                      className="bg-indigo-600 h-1.5 rounded-full transition-all duration-150"
                      style={{ width: `${dbProgress}%` }}
                    />
                  </div>
                  <div className="text-right text-xxxxs font-bold text-slate-400">{dbProgress}% Selesai</div>
                </div>
              )}
            </div>

            {/* SEED & CLEAN OPTIONS */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              <div className="border border-brand-green-100 rounded-2xl p-4 space-y-2">
                <h4 className="text-xs font-bold text-brand-green-900">Seeding Data Contoh Default</h4>
                <p className="text-xxxxs text-slate-500 leading-normal">
                  Suntik ulang data santri awal, daftar asatidzah default (Siti Nurhaliza, Ahmad Dahlan), tabel mapel, kurikulum merdeka, dan log akademik bawaan sistem Al Faraby.
                </p>
                <button
                  onClick={onDatabaseSeeding}
                  className="w-full text-xxs font-bold text-white bg-brand-green-800 hover:bg-brand-green-900 py-2 rounded-xl transition cursor-pointer"
                >
                  Suntik & Segarkan Template Pabrik
                </button>
              </div>

              <div className="border border-rose-100 rounded-2xl p-4 space-y-2">
                <h4 className="text-xs font-bold text-rose-900">Wipe / Kosongkan Database</h4>
                <p className="text-xxxxs text-slate-500 leading-normal">
                  Keluarkan instruksi pengosongan tuntas atas seluruh relasi data murid, kehadiran, agenda mengajar, dan nilai rapor. Berguna untuk memulai tahun pelajaran baru.
                </p>
                <button
                  onClick={() => {
                    const confirmWipe1 = window.confirm('DANGER ZONE: Apakah Anda sungguh berniat membuang seluruh record data operasional sekolah?');
                    if (confirmWipe1) {
                      const confirmWipe2 = window.prompt('Ketikkan "KONFIRMASI" di bawah untuk mengosongkan seluruh relasi tabel:');
                      if (confirmWipe2 === 'KONFIRMASI') {
                        onDatabaseReset();
                      } else {
                        alert('Pengosongan dibatalkan! Kata kunci salah.');
                      }
                    }
                  }}
                  className="w-full text-xxs font-bold text-white bg-rose-600 hover:bg-rose-700 py-2 rounded-xl transition cursor-pointer"
                >
                  Kosongkan Seluruh Tabel (Reset)
                </button>
              </div>
            </div>
          </div>

          {/* SIDE DATA INFO DIAGNOSTICS */}
          <div className="md:col-span-4 bg-white rounded-2xl border border-slate-100 shadow-xs p-6 space-y-4">
            <div className="flex items-center gap-2 pb-3 border-b border-slate-100">
              <AlertTriangle className="h-5 w-5 text-brand-gold-600" />
              <div>
                <h3 className="font-bold text-sm text-slate-800 school-display">Arsitektur Berdaulat</h3>
                <p className="text-xxx-small text-slate-400">Diagnosis ringkasan penyimpanan virtual.</p>
              </div>
            </div>

            <div className="space-y-3 font-medium text-xxs text-slate-600">
              <div className="flex justify-between py-1.5 border-b border-slate-100">
                <span>Mesin Basis Data:</span>
                <span className="font-bold text-slate-800">IndexedDB Simulated Engine</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-slate-100">
                <span>Enkripsi Sesi:</span>
                <span className="font-bold text-slate-800">AES-256 (SHA-256 Audit)</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-slate-100">
                <span>Menu Aktif:</span>
                <span className="font-bold text-emerald-700">{Object.values(enabledMenus).filter(v => v !== false).length} Aktif / 11 Module</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-slate-100">
                <span>Security Check:</span>
                <span className="font-bold text-emerald-700 flex items-center gap-0.5">
                  <Check className="h-4.5 w-4.5" /> SECURE
                </span>
              </div>
            </div>

            <button
              onClick={triggerExportBackup}
              className="w-full text-xxs font-bold text-indigo-700 hover:text-white hover:bg-indigo-700 border border-indigo-100 bg-indigo-50/50 py-2.5 rounded-xl transition cursor-pointer flex items-center justify-center gap-2"
            >
              <Download className="h-4 w-4" /> Download Google-Suite Backup
            </button>
          </div>

        </div>
      )}

    </div>
  );
}
