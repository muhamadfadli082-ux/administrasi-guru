/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Search, 
  UserPlus, 
  Trash, 
  Edit, 
  Mail, 
  Check, 
  X, 
  Phone, 
  UserCheck, 
  BookOpen, 
  Calendar, 
  ClipboardList, 
  Plus, 
  MapPin, 
  User, 
  Users,
  Activity, 
  GraduationCap, 
  Briefcase, 
  Award, 
  ShieldAlert,
  ChevronRight,
  Info
} from 'lucide-react';
import { Student, Teacher, Subject, Classroom, AcademicYear, UserRole } from '../types';

interface MasterDataViewProps {
  students: Student[];
  teachers: Teacher[];
  subjects: Subject[];
  classrooms?: Classroom[];
  academicYears?: AcademicYear[];
  onAddStudent: (student: Student) => void;
  onEditStudent: (student: Student) => void;
  onDeleteStudent: (id: string) => void;
  onAddTeacher: (teacher: Teacher) => void;
  onEditTeacher: (teacher: Teacher) => void;
  onDeleteTeacher: (id: string) => void;
  onAddSubject?: (subject: Subject) => void;
  onEditSubject?: (subject: Subject) => void;
  onDeleteSubject?: (id: string) => void;
  onAddClassroom?: (classroom: Classroom) => void;
  onEditClassroom?: (classroom: Classroom) => void;
  onDeleteClassroom?: (id: string) => void;
  onAddAcademicYear?: (ay: AcademicYear) => void;
  onEditAcademicYear?: (ay: AcademicYear) => void;
  onDeleteAcademicYear?: (id: string) => void;
}

type SubTab = 'siswa' | 'guru' | 'kelas' | 'mapel' | 'tahun_ajaran';

export default function MasterDataView({
  students,
  teachers,
  subjects,
  classrooms = [],
  academicYears = [],
  onAddStudent,
  onEditStudent,
  onDeleteStudent,
  onAddTeacher,
  onEditTeacher,
  onDeleteTeacher,
  onAddSubject,
  onEditSubject,
  onDeleteSubject,
  onAddClassroom,
  onEditClassroom,
  onDeleteClassroom,
  onAddAcademicYear,
  onEditAcademicYear,
  onDeleteAcademicYear,
}: MasterDataViewProps) {
  const [activeSubTab, setActiveSubTab] = useState<SubTab>('siswa');
  const [searchTerm, setSearchTerm] = useState('');

  // Modal control states
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);

  // --- FORM STATES FOR EACH DB ---
  
  // 1. Student form inputs
  const [studNis, setStudNis] = useState('');
  const [studNisn, setStudNisn] = useState('');
  const [studName, setStudName] = useState('');
  const [studBirthplace, setStudBirthplace] = useState('');
  const [studBirthdate, setStudBirthdate] = useState('');
  const [studGender, setStudGender] = useState<'L' | 'P'>('L');
  const [studReligion, setStudReligion] = useState('Islam');
  const [studAddress, setStudAddress] = useState('');
  const [studFatherName, setStudFatherName] = useState('');
  const [studMotherName, setStudMotherName] = useState('');
  const [studPhone, setStudPhone] = useState('');
  const [studClass, setStudClass] = useState('Kelas 4A');
  const [studStatus, setStudStatus] = useState('Aktif');

  // 2. Teacher form inputs
  const [teachNip, setTeachNip] = useState('');
  const [teachNuptk, setTeachNuptk] = useState('');
  const [teachName, setTeachName] = useState('');
  const [teachGender, setTeachGender] = useState<'L' | 'P'>('L');
  const [teachBirthplaceDate, setTeachBirthplaceDate] = useState('');
  const [teachLastEducation, setTeachLastEducation] = useState('');
  const [teachJobTitle, setTeachJobTitle] = useState('');
  const [teachEmploymentStatus, setTeachEmploymentStatus] = useState('GTT / Honorer');
  const [teachSubjectsAssigned, setTeachSubjectsAssigned] = useState<string[]>([]);
  const [teachPhone, setTeachPhone] = useState('');
  const [teachEmail, setTeachEmail] = useState('');
  const [teachAddress, setTeachAddress] = useState('');
  const [teachPhotoUrl, setTeachPhotoUrl] = useState('🧕');
  const [teachRole, setTeachRole] = useState<UserRole>(UserRole.GURU);
  const [teachClass, setTeachClass] = useState('Kelas 4A');

  // 3. Classroom form inputs
  const [classGrade, setClassGrade] = useState('4');
  const [classNameInput, setClassNameInput] = useState('');
  const [classTeacher, setClassTeacher] = useState('');
  const [classStudentsCount, setClassStudentsCount] = useState(0);

  // 4. Subject form inputs
  const [subjName, setSubjName] = useState('');
  const [subjCode, setSubjCode] = useState('');
  const [subjCategory, setSubjCategory] = useState<'Agama' | 'Umum'>('Agama');
  const [subjFase, setSubjFase] = useState('Fase B');
  const [subjGradeLevel, setSubjGradeLevel] = useState('Kelas 4');
  const [subjHours, setSubjHours] = useState('4 JP / Pekan');

  // 5. Academic Year form inputs
  const [yearVal, setYearVal] = useState('2026/2027');
  const [semesterVal, setSemesterVal] = useState<'Ganjil' | 'Genap'>('Ganjil');
  const [isActiveVal, setIsActiveVal] = useState(true);

  // --- FORMS RESET ---
  const resetStudentForm = () => {
    setStudNis('');
    setStudNisn('');
    setStudName('');
    setStudBirthplace('Bogor');
    setStudBirthdate('2016-01-01');
    setStudGender('L');
    setStudReligion('Islam');
    setStudAddress('');
    setStudFatherName('');
    setStudMotherName('');
    setStudPhone('');
    setStudClass('Kelas 4A');
    setStudStatus('Aktif');
    setEditingId(null);
  };

  const resetTeacherForm = () => {
    setTeachNip('');
    setTeachNuptk('');
    setTeachName('');
    setTeachGender('L');
    setTeachBirthplaceDate('');
    setTeachLastEducation('');
    setTeachJobTitle('');
    setTeachEmploymentStatus('GTY / Pegawai Tetap');
    setTeachSubjectsAssigned([]);
    setTeachPhone('');
    setTeachEmail('');
    setTeachAddress('');
    setTeachPhotoUrl('👨‍💼');
    setTeachRole(UserRole.GURU);
    setTeachClass('Kelas 4A');
    setEditingId(null);
  };

  const resetClassroomForm = () => {
    setClassGrade('4');
    setClassNameInput('');
    setClassTeacher('');
    setClassStudentsCount(0);
    setEditingId(null);
  };

  const resetSubjectForm = () => {
    setSubjName('');
    setSubjCode('');
    setSubjCategory('Agama');
    setSubjFase('Fase B');
    setSubjGradeLevel('Kelas 4');
    setSubjHours('4 JP / Pekan');
    setEditingId(null);
  };

  const resetAcademicYearForm = () => {
    setYearVal('2026/2027');
    setSemesterVal('Ganjil');
    setIsActiveVal(true);
    setEditingId(null);
  };

  const handleOpenAddForm = () => {
    if (activeSubTab === 'siswa') resetStudentForm();
    else if (activeSubTab === 'guru') resetTeacherForm();
    else if (activeSubTab === 'kelas') resetClassroomForm();
    else if (activeSubTab === 'mapel') resetSubjectForm();
    else if (activeSubTab === 'tahun_ajaran') resetAcademicYearForm();
    setIsFormOpen(true);
  };

  // --- SAVE OPERATION ---
  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (activeSubTab === 'siswa') {
      if (!studNis || !studName) return;
      
      const defaultShalat = editingId ? (students.find(s => s.id === editingId)?.shalatPoin || 85) : 85;
      const defaultTahfidz = editingId ? (students.find(s => s.id === editingId)?.tahfidzStatus || 'Juz 30 (Baru)') : 'Juz 30 (Baru)';

      const data: Student = {
        id: editingId || 'S' + Math.floor(Math.random() * 1000).toString().padStart(3, '0'),
        nis: studNis,
        nisn: studNisn,
        name: studName,
        gender: studGender,
        classroom: studClass,
        parentsName: studFatherName || studMotherName || 'Orang Tua Santri',
        phone: studPhone,
        shalatPoin: defaultShalat,
        tahfidzStatus: defaultTahfidz,
        birthplace: studBirthplace,
        birthdate: studBirthdate,
        religion: studReligion,
        address: studAddress,
        fatherName: studFatherName,
        motherName: studMotherName,
        status: studStatus,
      };

      if (editingId) onEditStudent(data);
      else onAddStudent(data);

    } else if (activeSubTab === 'guru') {
      if (!teachNip || !teachName || !teachEmail) return;

      const data: Teacher = {
        id: editingId || 'T' + Math.floor(Math.random() * 1000).toString().padStart(3, '0'),
        nip: teachNip,
        name: teachName,
        role: teachRole,
        email: teachEmail,
        classroomAssigned: teachClass === 'Tidak Ada' ? undefined : teachClass,
        phone: teachPhone,
        subjectsAssigned: teachSubjectsAssigned.length > 0 ? teachSubjectsAssigned : ['Mata Pelajaran'],
        nuptk: teachNuptk,
        gender: teachGender,
        birthplaceDate: teachBirthplaceDate,
        lastEducation: teachLastEducation,
        jobTitle: teachJobTitle || (teachRole === UserRole.GURU ? 'Guru / Wali Kelas' : teachRole),
        employmentStatus: teachEmploymentStatus,
        address: teachAddress,
        photoUrl: teachPhotoUrl
      };

      if (editingId) onEditTeacher(data);
      else onAddTeacher(data);

    } else if (activeSubTab === 'kelas') {
      if (!classNameInput || !classNameInput.trim()) return;

      const data: Classroom = {
        id: editingId || 'C' + Math.floor(Math.random() * 1000).toString().padStart(3, '0'),
        grade: classGrade,
        name: classNameInput,
        homeroomTeacher: classTeacher || 'Tidak Ada',
        studentCount: classStudentsCount || 0
      };

      if (editingId && onEditClassroom) onEditClassroom(data);
      else if (onAddClassroom) onAddClassroom(data);

    } else if (activeSubTab === 'mapel') {
      if (!subjName || !subjCode) return;

      const data: Subject = {
        id: editingId || 'MAPEL' + Math.floor(Math.random() * 100).toString().padStart(2, '0'),
        code: subjCode,
        name: subjName,
        category: subjCategory,
        fase: subjFase,
        gradeLevel: subjGradeLevel,
        allocatedHours: subjHours
      };

      if (editingId && onEditSubject) onEditSubject(data);
      else if (onAddSubject) onAddSubject(data);

    } else if (activeSubTab === 'tahun_ajaran') {
      if (!yearVal) return;

      const data: AcademicYear = {
        id: editingId || 'TA' + Math.floor(Math.random() * 100).toString().padStart(2, '0'),
        year: yearVal,
        semester: semesterVal,
        isActive: isActiveVal
      };

      if (editingId && onEditAcademicYear) onEditAcademicYear(data);
      else if (onAddAcademicYear) onAddAcademicYear(data);
    }
    setIsFormOpen(false);
  };

  // --- EDIT TRIGGER ---
  const handleEdit = (item: any) => {
    setEditingId(item.id);
    if (activeSubTab === 'siswa') {
      const s = item as Student;
      setStudNis(s.nis || '');
      setStudNisn(s.nisn || '');
      setStudName(s.name || '');
      setStudGender(s.gender || 'L');
      setStudClass(s.classroom || 'Kelas 4A');
      setStudPhone(s.phone || '');
      setStudBirthplace(s.birthplace || 'Bogor');
      setStudBirthdate(s.birthdate || '2016-01-01');
      setStudReligion(s.religion || 'Islam');
      setStudAddress(s.address || '');
      setStudFatherName(s.fatherName || '');
      setStudMotherName(s.motherName || '');
      setStudStatus(s.status || 'Aktif');
    } else if (activeSubTab === 'guru') {
      const t = item as Teacher;
      setTeachNip(t.nip || '');
      setTeachNuptk(t.nuptk || '');
      setTeachName(t.name || '');
      setTeachGender(t.gender || 'L');
      setTeachBirthplaceDate(t.birthplaceDate || '');
      setTeachLastEducation(t.lastEducation || '');
      setTeachJobTitle(t.jobTitle || '');
      setTeachEmploymentStatus(t.employmentStatus || 'GTY / Pegawai Tetap');
      setTeachSubjectsAssigned(t.subjectsAssigned || []);
      setTeachPhone(t.phone || '');
      setTeachEmail(t.email || '');
      setTeachAddress(t.address || '');
      setTeachPhotoUrl(t.photoUrl || '👨‍💼');
      setTeachRole(t.role || UserRole.GURU);
      setTeachClass(t.classroomAssigned || 'Tidak Ada');
    } else if (activeSubTab === 'kelas') {
      const c = item as Classroom;
      setClassGrade(c.grade || '4');
      setClassNameInput(c.name || '');
      setClassTeacher(c.homeroomTeacher || '');
      setClassStudentsCount(c.studentCount || 0);
    } else if (activeSubTab === 'mapel') {
      const s = item as Subject;
      setSubjName(s.name || '');
      setSubjCode(s.code || '');
      setSubjCategory(s.category || 'Agama');
      setSubjFase(s.fase || 'Fase B');
      setSubjGradeLevel(s.gradeLevel || 'Kelas 4');
      setSubjHours(s.allocatedHours || '4 JP / Pekan');
    } else if (activeSubTab === 'tahun_ajaran') {
      const ay = item as AcademicYear;
      setYearVal(ay.year || '2026/2027');
      setSemesterVal(ay.semester || 'Ganjil');
      setIsActiveVal(ay.isActive || false);
    }
    setIsFormOpen(true);
  };

  // --- DELETE TRIGGER ---
  const handleDelete = (id: string) => {
    const isConfirmed = window.confirm('Apakah Anda yakin ingin menghapus data master ini? Tindakan ini tidak dapat dibatalkan.');
    if (!isConfirmed) return;
    
    if (activeSubTab === 'siswa') {
      onDeleteStudent(id);
    } else if (activeSubTab === 'guru') {
      onDeleteTeacher(id);
    } else if (activeSubTab === 'kelas') {
      if (onDeleteClassroom) onDeleteClassroom(id);
    } else if (activeSubTab === 'mapel') {
      if (onDeleteSubject) onDeleteSubject(id);
    } else if (activeSubTab === 'tahun_ajaran') {
      if (onDeleteAcademicYear) onDeleteAcademicYear(id);
    }
  };

  // --- FILTER & SEARCH ---
  const filteredStudents = students.filter(s =>
    s.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    s.nis.includes(searchTerm) ||
    s.nisn.includes(searchTerm) ||
    s.classroom.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (s.fatherName && s.fatherName.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const filteredTeachers = teachers.filter(t =>
    t.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    t.nip.includes(searchTerm) ||
    t.role.toString().toLowerCase().includes(searchTerm.toLowerCase()) ||
    t.jobTitle?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredClassrooms = classrooms.filter(c => 
    c.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    c.homeroomTeacher.toLowerCase().includes(searchTerm.toLowerCase()) ||
    c.grade.includes(searchTerm)
  );

  const filteredSubjects = subjects.filter(sub => 
    sub.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    sub.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
    sub.fase?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredAcademicYears = academicYears.filter(ay => 
    ay.year.includes(searchTerm) ||
    ay.semester.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div id="master-data-view" className="space-y-6 animate-in fade-in duration-150">
      
      {/* 1. Header Page Section */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-2xl border border-slate-100 shadow-xs">
        <div>
          <h2 className="text-lg font-bold text-slate-900 font-display flex items-center gap-2">
            <span className="p-1.5 bg-brand-green-100 text-brand-green-800 rounded-lg text-xs">MODUL 3</span>
            Pengelolaan Master Data Sekolah
          </h2>
          <p className="text-xs text-slate-500 mt-1 max-w-2xl leading-relaxed">
            Pusat administrasi seluruh pilar pembelajaran Al Faraby. Daftarkan lembaga guru, santri, pemetaan ruang kelas, beban kurikulum, dan kalender semester terpilih.
          </p>
        </div>
        
        <button
          onClick={handleOpenAddForm}
          className="flex items-center justify-center gap-2 bg-brand-green-700 hover:bg-brand-green-800 text-white font-bold text-xs px-4 py-2.5 rounded-xl shadow-md transition-all active:scale-95 cursor-pointer whitespace-nowrap self-start sm:self-center"
        >
          <Plus className="h-4 w-4" />
          Tambah {
            activeSubTab === 'siswa' ? 'Peserta Didik' :
            activeSubTab === 'guru' ? 'Guru & Staf' :
            activeSubTab === 'kelas' ? 'Kelas Baru' :
            activeSubTab === 'mapel' ? 'Mata Pelajaran' : 'Tahun Pelajaran'
          }
        </button>
      </div>

      {/* 2. Database Navigation Sub-Tabs */}
      <div className="flex overflow-x-auto whitespace-nowrap border-b border-slate-200 bg-white px-2 rounded-2xl border border-slate-100 shadow-xs">
        <button
          onClick={() => { setActiveSubTab('siswa'); setSearchTerm(''); }}
          className={`flex items-center gap-2 px-5 py-4 font-semibold text-xs transition-colors relative cursor-pointer ${
            activeSubTab === 'siswa' ? 'text-brand-green-700 font-bold bg-brand-green-50/10' : 'text-slate-500 hover:text-slate-800'
          }`}
        >
          <GraduationCap className={`h-4 w-4 ${activeSubTab === 'siswa' ? 'text-brand-green-700' : 'text-slate-400'}`} />
          Data Peserta Didik ({students.length})
          {activeSubTab === 'siswa' && <span className="absolute bottom-0 left-0 w-full h-0.5 bg-brand-green-700" />}
        </button>

        <button
          onClick={() => { setActiveSubTab('guru'); setSearchTerm(''); }}
          className={`flex items-center gap-2 px-5 py-4 font-semibold text-xs transition-colors relative cursor-pointer ${
            activeSubTab === 'guru' ? 'text-brand-green-700 font-bold bg-brand-green-50/10' : 'text-slate-500 hover:text-slate-800'
          }`}
        >
          <UserCheck className={`h-4 w-4 ${activeSubTab === 'guru' ? 'text-brand-green-700' : 'text-slate-400'}`} />
          Data Guru & Staf ({teachers.length})
          {activeSubTab === 'guru' && <span className="absolute bottom-0 left-0 w-full h-0.5 bg-brand-green-700" />}
        </button>

        <button
          onClick={() => { setActiveSubTab('kelas'); setSearchTerm(''); }}
          className={`flex items-center gap-2 px-5 py-4 font-semibold text-xs transition-colors relative cursor-pointer ${
            activeSubTab === 'kelas' ? 'text-brand-green-700 font-bold bg-brand-green-50/10' : 'text-slate-500 hover:text-slate-800'
          }`}
        >
          <ClipboardList className={`h-4 w-4 ${activeSubTab === 'kelas' ? 'text-brand-green-700' : 'text-slate-400'}`} />
          Data Kelas ({classrooms.length})
          {activeSubTab === 'kelas' && <span className="absolute bottom-0 left-0 w-full h-0.5 bg-brand-green-700" />}
        </button>

        <button
          onClick={() => { setActiveSubTab('mapel'); setSearchTerm(''); }}
          className={`flex items-center gap-2 px-5 py-4 font-semibold text-xs transition-colors relative cursor-pointer ${
            activeSubTab === 'mapel' ? 'text-brand-green-700 font-bold bg-brand-green-50/10' : 'text-slate-500 hover:text-slate-800'
          }`}
        >
          <BookOpen className={`h-4 w-4 ${activeSubTab === 'mapel' ? 'text-brand-green-700' : 'text-slate-400'}`} />
          Data Mata Pelajaran ({subjects.length})
          {activeSubTab === 'mapel' && <span className="absolute bottom-0 left-0 w-full h-0.5 bg-brand-green-700" />}
        </button>

        <button
          onClick={() => { setActiveSubTab('tahun_ajaran'); setSearchTerm(''); }}
          className={`flex items-center gap-2 px-5 py-4 font-semibold text-xs transition-colors relative cursor-pointer ${
            activeSubTab === 'tahun_ajaran' ? 'text-brand-green-700 font-bold bg-brand-green-50/10' : 'text-slate-500 hover:text-slate-800'
          }`}
        >
          <Calendar className={`h-4 w-4 ${activeSubTab === 'tahun_ajaran' ? 'text-brand-green-700' : 'text-slate-400'}`} />
          Data Tahun Pelajaran ({academicYears.length})
          {activeSubTab === 'tahun_ajaran' && <span className="absolute bottom-0 left-0 w-full h-0.5 bg-brand-green-700" />}
        </button>
      </div>

      {/* 3. Database Summary Stat Panel */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {activeSubTab === 'siswa' && (
          <>
            <div className="bg-white p-4 rounded-xl border border-slate-100 shadow-xs flex items-center gap-3">
              <div className="p-3 bg-brand-green-50 text-brand-green-700 rounded-xl">
                <GraduationCap className="h-5 w-5" />
              </div>
              <div>
                <div className="text-xxxxs font-bold text-slate-400 uppercase">Jumlah Santri</div>
                <div className="text-lg font-extrabold text-slate-800">{students.length} Orang</div>
              </div>
            </div>
            <div className="bg-white p-4 rounded-xl border border-slate-100 shadow-xs flex items-center gap-3">
              <div className="p-3 bg-blue-50 text-blue-700 rounded-xl">
                <User className="h-5 w-5" />
              </div>
              <div>
                <div className="text-xxxxs font-bold text-slate-400 uppercase">Santri Putra (L)</div>
                <div className="text-lg font-extrabold text-slate-800">{students.filter(s => s.gender === 'L').length} Orang</div>
              </div>
            </div>
            <div className="bg-white p-4 rounded-xl border border-slate-100 shadow-xs flex items-center gap-3">
              <div className="p-3 bg-pink-50 text-pink-700 rounded-xl">
                <User className="h-5 w-5" />
              </div>
              <div>
                <div className="text-xxxxs font-bold text-slate-400 uppercase">Santri Putri (P)</div>
                <div className="text-lg font-extrabold text-slate-800">{students.filter(s => s.gender === 'P').length} Orang</div>
              </div>
            </div>
            <div className="bg-white p-4 rounded-xl border border-slate-100 shadow-xs flex items-center gap-3">
              <div className="p-3 bg-emerald-50 text-emerald-700 rounded-xl">
                <Check className="h-5 w-5" />
              </div>
              <div>
                <div className="text-xxxxs font-bold text-slate-400 uppercase">Santri Aktif</div>
                <div className="text-lg font-extrabold text-slate-800">{students.filter(s => s.status !== 'Keluar').length} Orang</div>
              </div>
            </div>
          </>
        )}

        {activeSubTab === 'guru' && (
          <>
            <div className="bg-white p-4 rounded-xl border border-slate-100 shadow-xs flex items-center gap-3">
              <div className="p-3 bg-brand-green-50 text-brand-green-700 rounded-xl">
                <UserCheck className="h-5 w-5" />
              </div>
              <div>
                <div className="text-xxxxs font-bold text-slate-400 uppercase">Total Otoritas Dewan Guru</div>
                <div className="text-lg font-extrabold text-slate-800">{teachers.length} Orang</div>
              </div>
            </div>
            <div className="bg-white p-4 rounded-xl border border-slate-100 shadow-xs flex items-center gap-3">
              <div className="p-3 bg-amber-50 text-amber-700 rounded-xl">
                <Award className="h-5 w-5" />
              </div>
              <div>
                <div className="text-xxxxs font-bold text-slate-400 uppercase">Status Tetap (GTY/PNS)</div>
                <div className="text-lg font-extrabold text-slate-800">{teachers.filter(t => t.employmentStatus?.includes('Tetap') || t.employmentStatus?.includes('PNS')).length} Orang</div>
              </div>
            </div>
            <div className="bg-white p-4 rounded-xl border border-slate-100 shadow-xs flex items-center gap-3">
              <div className="p-3 bg-teal-50 text-teal-700 rounded-xl">
                <Briefcase className="h-5 w-5" />
              </div>
              <div>
                <div className="text-xxxxs font-bold text-slate-400 uppercase">Rata Pendidikan</div>
                <div className="text-lg font-extrabold text-slate-800">S1 / S2 Kependidikan</div>
              </div>
            </div>
            <div className="bg-white p-4 rounded-xl border border-slate-100 shadow-xs flex items-center gap-3">
              <div className="p-3 bg-indigo-50 text-indigo-700 rounded-xl">
                <Info className="h-5 w-5" />
              </div>
              <div>
                <div className="text-xxxxs font-bold text-slate-400 uppercase">Total Sertifikasi NUPTK</div>
                <div className="text-lg font-extrabold text-slate-800">{teachers.filter(t => t.nuptk && t.nuptk !== '').length} Guru</div>
              </div>
            </div>
          </>
        )}

        {activeSubTab === 'kelas' && (
          <>
            <div className="bg-white p-4 rounded-xl border border-slate-100 shadow-xs flex items-center gap-3">
              <div className="p-3 bg-brand-green-50 text-brand-green-700 rounded-xl">
                <ClipboardList className="h-5 w-5" />
              </div>
              <div>
                <div className="text-xxxxs font-bold text-slate-400 uppercase">Total Kelas</div>
                <div className="text-lg font-extrabold text-slate-800">{classrooms.length} Rombel</div>
              </div>
            </div>
            <div className="bg-white p-4 rounded-xl border border-slate-100 shadow-xs flex items-center gap-3">
              <div className="p-3 bg-indigo-50 text-indigo-700 rounded-xl">
                <UserCheck className="h-5 w-5" />
              </div>
              <div>
                <div className="text-xxxxs font-bold text-slate-400 uppercase">Wali Kelas Terisi</div>
                <div className="text-lg font-extrabold text-slate-800">{classrooms.filter(c => c.homeroomTeacher !== 'Tidak Ada').length} Otoritas</div>
              </div>
            </div>
            <div className="bg-white p-4 rounded-xl border border-slate-100 shadow-xs flex items-center gap-3">
              <div className="p-3 bg-orange-50 text-orange-700 rounded-xl">
                <Users className="h-5 w-5" />
              </div>
              <div>
                <div className="text-xxxxs font-bold text-slate-400 uppercase">Rata Siswa/Kelas</div>
                <div className="text-lg font-extrabold text-slate-800">
                  {classrooms.length > 0 ? (students.length / classrooms.length).toFixed(1) : 0} Siswa
                </div>
              </div>
            </div>
            <div className="bg-white p-4 rounded-xl border border-slate-100 shadow-xs flex items-center gap-3">
              <div className="p-3 bg-teal-50 text-teal-700 rounded-xl">
                <Info className="h-5 w-5" />
              </div>
              <div>
                <div className="text-xxxxs font-bold text-slate-400 uppercase">Kapasitas Maksimal</div>
                <div className="text-lg font-extrabold text-slate-800">28 Siswa/Kelas</div>
              </div>
            </div>
          </>
        )}

        {activeSubTab === 'mapel' && (
          <>
            <div className="bg-white p-4 rounded-xl border border-slate-100 shadow-xs flex items-center gap-3">
              <div className="p-3 bg-brand-green-50 text-brand-green-700 rounded-xl">
                <BookOpen className="h-5 w-5" />
              </div>
              <div>
                <div className="text-xxxxs font-bold text-slate-400 uppercase">Kategori Mapel Pilihan</div>
                <div className="text-lg font-extrabold text-slate-800">{subjects.length} Pembelajaran</div>
              </div>
            </div>
            <div className="bg-white p-4 rounded-xl border border-slate-100 shadow-xs flex items-center gap-3">
              <div className="p-3 bg-emerald-50 text-emerald-700 rounded-xl">
                <Check className="h-5 w-5" />
              </div>
              <div>
                <div className="text-xxxxs font-bold text-slate-400 uppercase">Pendidikan Agama (Kepesantrenan)</div>
                <div className="text-lg font-extrabold text-slate-800">{subjects.filter(s => s.category === 'Agama').length} Mapel</div>
              </div>
            </div>
            <div className="bg-white p-4 rounded-xl border border-slate-100 shadow-xs flex items-center gap-3">
              <div className="p-3 bg-blue-50 text-blue-700 rounded-xl">
                <Info className="h-5 w-5" />
              </div>
              <div>
                <div className="text-xxxxs font-bold text-slate-400 uppercase">Pendidikan Umum (Baku Kemendikbud)</div>
                <div className="text-lg font-extrabold text-slate-800">{subjects.filter(s => s.category === 'Umum').length} Mapel</div>
              </div>
            </div>
            <div className="bg-white p-4 rounded-xl border border-slate-100 shadow-xs flex items-center gap-3">
              <div className="p-3 bg-purple-50 text-purple-700 rounded-xl">
                <Activity className="h-5 w-5" />
              </div>
              <div>
                <div className="text-xxxxs font-bold text-slate-400 uppercase">Total Jam Pelajaran / Pekan</div>
                <div className="text-lg font-extrabold text-slate-800">34 JP</div>
              </div>
            </div>
          </>
        )}

        {activeSubTab === 'tahun_ajaran' && (
          <>
            <div className="bg-white p-4 rounded-xl border border-slate-100 shadow-xs flex items-center gap-3">
              <div className="p-3 bg-brand-green-50 text-brand-green-700 rounded-xl">
                <Calendar className="h-5 w-5" />
              </div>
              <div>
                <div className="text-xxxxs font-bold text-slate-400 uppercase">Tahun Pembelajaran Terdaftar</div>
                <div className="text-lg font-extrabold text-slate-800">{academicYears.length} Data</div>
              </div>
            </div>
            <div className="bg-white p-4 rounded-xl border border-slate-100 shadow-xs flex items-center gap-3">
              <div className="p-3 bg-emerald-50 text-emerald-700 rounded-xl">
                <UserCheck className="h-5 w-5" />
              </div>
              <div>
                <div className="text-xxxxs font-bold text-slate-400 uppercase">Status Aktif Sekarang</div>
                <div className="text-xs font-bold text-slate-800">
                  {academicYears.find(ay => ay.isActive) ? (
                    <span className="text-brand-green-800 bg-emerald-100 px-2 py-0.5 rounded-md font-bold">
                      TA {academicYears.find(ay => ay.isActive)?.year} ({academicYears.find(ay => ay.isActive)?.semester})
                    </span>
                  ) : 'Tidak Ada yang Aktif'}
                </div>
              </div>
            </div>
            <div className="bg-white p-4 rounded-xl border border-slate-100 shadow-xs flex items-center gap-3">
              <div className="p-3 bg-indigo-50 text-indigo-700 rounded-xl">
                <Info className="h-5 w-5" />
              </div>
              <div>
                <div className="text-xxxxs font-bold text-slate-400 uppercase">Metode Kurikulum</div>
                <div className="text-lg font-extrabold text-slate-800">Merdeka Belajar</div>
              </div>
            </div>
            <div className="bg-white p-4 rounded-xl border border-slate-100 shadow-xs flex items-center gap-3">
              <div className="p-3 bg-amber-50 text-amber-700 rounded-xl">
                <Award className="h-5 w-5" />
              </div>
              <div>
                <div className="text-xxxxs font-bold text-slate-400 uppercase">Siklus Laporan</div>
                <div className="text-lg font-extrabold text-slate-800">Per 6 Bulan</div>
              </div>
            </div>
          </>
        )}
      </div>

      {/* 4. Main Database Table / Grid Container */}
      <div className="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden">
        
        {/* Search Header Bar */}
        <div className="p-4 border-b border-slate-100 bg-slate-50/50 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="relative flex-1 w-full">
            <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
            <input
              type="text"
              className="w-full pl-9 pr-4 py-2 text-xs rounded-xl border border-slate-200 focus:outline-none focus:border-brand-green-600 bg-white"
              placeholder={`Cari dari database ${
                activeSubTab === 'siswa' ? 'santri (Nama, NIS, Wali, Kelas)...' : 
                activeSubTab === 'guru' ? 'guru (Nama, NIP, Jabatan)...' : 
                activeSubTab === 'kelas' ? 'kelas (Nama, Wali)...' : 
                activeSubTab === 'mapel' ? 'mata pelajaran (Nama, Kode)...' : 'tahun pelajaran...'
              }`}
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
            />
          </div>
          <div className="text-xxs text-slate-400 font-bold tracking-wider uppercase bg-white px-3 py-1.5 rounded-lg border border-slate-100">
            Menampilkan {
              activeSubTab === 'siswa' ? filteredStudents.length : 
              activeSubTab === 'guru' ? filteredTeachers.length : 
              activeSubTab === 'kelas' ? filteredClassrooms.length : 
              activeSubTab === 'mapel' ? filteredSubjects.length : filteredAcademicYears.length
            } Data Terdaftar
          </div>
        </div>

        {/* --- TABLES --- */}
        <div className="overflow-x-auto">
          
          {/* Active Sub Tab 1: Peserta Didik */}
          {activeSubTab === 'siswa' && (
            <table className="w-full text-left border-collapse min-w-max">
              <thead>
                <tr className="border-b border-slate-100 bg-slate-50/70 text-slate-400 text-xxs uppercase tracking-wider font-bold">
                  <th className="p-4 text-center w-12">Gender</th>
                  <th className="p-4">Nama Lengkap & Identitas</th>
                  <th className="p-4">Tanggal Lahir</th>
                  <th className="p-4">Kelas</th>
                  <th className="p-4">Orang Tua/Wali</th>
                  <th className="p-4">Alamat Santri</th>
                  <th className="p-4">Status</th>
                  <th className="p-4 text-right w-24">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-xs text-slate-700">
                {filteredStudents.length > 0 ? (
                  filteredStudents.map(s => (
                    <tr key={s.id} className="hover:bg-slate-50/50 transition-colors">
                      <td className="p-4 text-center">
                        <span className={`inline-flex h-7 w-7 rounded-full items-center justify-center font-extrabold text-xxs ${
                          s.gender === 'L' ? 'bg-blue-50 text-blue-700 border border-blue-100' : 'bg-pink-50 text-pink-700 border border-pink-100'
                        }`}>
                          {s.gender}
                        </span>
                      </td>
                      <td className="p-4">
                        <div className="font-bold text-slate-900 text-xs">{s.name}</div>
                        <div className="text-[10px] text-slate-400 font-semibold mt-0.5 uppercase tracking-wide">
                          NIS: {s.nis} &bull; NISN: {s.nisn || '-'}
                        </div>
                      </td>
                      <td className="p-4">
                        <div className="font-medium text-slate-600">{s.birthplace || 'Bogor'}</div>
                        <div className="text-[10px] text-slate-400">{s.birthdate || '-'}</div>
                      </td>
                      <td className="p-4">
                        <span className="bg-emerald-50 text-brand-green-800 text-[10px] px-2.5 py-1 rounded-full font-extrabold border border-emerald-100">
                          {s.classroom}
                        </span>
                      </td>
                      <td className="p-4">
                        <div className="font-semibold text-slate-800">{s.parentsName || s.fatherName || 'Ayah/Ibu'}</div>
                        <div className="text-[10px] text-slate-400 font-mono mt-0.5">{s.phone || '-'}</div>
                      </td>
                      <td className="p-4 max-w-xs truncate text-[11px] text-slate-500" title={s.address}>
                        {s.address || '-'}
                      </td>
                      <td className="p-4">
                        <span className={`px-2 py-0.5 rounded-full font-bold text-[10px] ${
                          s.status === 'Aktif' ? 'bg-emerald-100 text-emerald-800' : 
                          s.status === 'Pindahan' ? 'bg-blue-100 text-blue-800' : 'bg-rose-100 text-rose-800'
                        }`}>
                          {s.status || 'Aktif'}
                        </span>
                      </td>
                      <td className="p-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => handleEdit(s)}
                            className="p-1.5 text-slate-500 hover:text-brand-green-700 hover:bg-emerald-50 rounded-lg transition-colors cursor-pointer"
                          >
                            <Edit className="h-4 w-4" />
                          </button>
                          <button
                            onClick={() => handleDelete(s.id)}
                            className="p-1.5 text-slate-500 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                          >
                            <Trash className="h-4 w-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={8} className="p-8 text-center text-slate-400 text-xs">
                      Tidak ada data santri ditemukan.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          )}

          {/* Active Sub Tab 2: Dewan Guru */}
          {activeSubTab === 'guru' && (
            <table className="w-full text-left border-collapse min-w-max">
              <thead>
                <tr className="border-b border-slate-100 bg-slate-50/70 text-slate-400 text-xxs uppercase tracking-wider font-bold">
                  <th className="p-4 text-center w-12">Foto</th>
                  <th className="p-4">Nama Lengkap & Otoritas</th>
                  <th className="p-4">NIP / NUPTK</th>
                  <th className="p-4">Tempat & tgl lahir</th>
                  <th className="p-4">Jabatan Pokok</th>
                  <th className="p-4">Status Kepegawaian</th>
                  <th className="p-4">Mata Pelajaran Diampu</th>
                  <th className="p-4">Hubungi / HP</th>
                  <th className="p-4 text-right w-24">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-xs text-slate-700">
                {filteredTeachers.length > 0 ? (
                  filteredTeachers.map(t => (
                    <tr key={t.id} className="hover:bg-slate-50/50 transition-colors">
                      <td className="p-4 text-center">
                        <span className="inline-flex h-8 w-8 rounded-xl bg-slate-100 items-center justify-center text-sm shadow-xs border border-slate-200">
                          {t.photoUrl || (t.gender === 'P' ? '🧕' : '👨‍💼')}
                        </span>
                      </td>
                      <td className="p-4">
                        <div className="font-bold text-slate-900 text-xs">{t.name}</div>
                        <div className="text-[10px] text-slate-400 mt-0.5">{t.email}</div>
                      </td>
                      <td className="p-4">
                        <div className="font-mono text-slate-700">{t.nip}</div>
                        <div className="text-[10px] text-slate-400 font-semibold mt-0.5">NUPTK: {t.nuptk || '-'}</div>
                      </td>
                      <td className="p-4 text-slate-600">
                        {t.birthplaceDate || '-'}
                      </td>
                      <td className="p-4 font-semibold text-slate-800">
                        {t.jobTitle || 'Guru'}
                      </td>
                      <td className="p-4">
                        <span className="bg-brand-gold-50 text-brand-gold-800 text-[10px] px-2 py-0.5 rounded-md font-bold uppercase tracking-wider border border-brand-gold-100">
                          {t.employmentStatus || 'GTY / Tetap'}
                        </span>
                      </td>
                      <td className="p-4 max-w-xs truncate text-[11px] text-slate-500">
                        {t.subjectsAssigned ? t.subjectsAssigned.join(', ') : '-'}
                      </td>
                      <td className="p-4">
                        <div className="flex items-center gap-1 font-mono text-xxs text-slate-600">
                          <Phone className="h-3 w-3 text-slate-4
                          00" />
                          {t.phone}
                        </div>
                      </td>
                      <td className="p-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => handleEdit(t)}
                            className="p-1.5 text-slate-500 hover:text-brand-green-700 hover:bg-emerald-50 rounded-lg transition-colors cursor-pointer"
                          >
                            <Edit className="h-4 w-4" />
                          </button>
                          <button
                            disabled={t.role === UserRole.ADMIN}
                            onClick={() => handleDelete(t.id)}
                            className="p-1.5 text-slate-500 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors disabled:opacity-35 cursor-pointer"
                          >
                            <Trash className="h-4 w-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={9} className="p-8 text-center text-slate-400 text-xs">
                      Tidak ada data asatidzah ditemukan.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          )}

          {/* Active Sub Tab 3: Data Kelas */}
          {activeSubTab === 'kelas' && (
            <table className="w-full text-left border-collapse min-w-max">
              <thead>
                <tr className="border-b border-slate-100 bg-slate-50/70 text-slate-400 text-xxs uppercase tracking-wider font-bold">
                  <th className="p-4 w-20">Tingkat</th>
                  <th className="p-4">Nama Rombongan Belajar (Rombel)</th>
                  <th className="p-4">Otoritas Wali Kelas</th>
                  <th className="p-4">Kalkulasi Siswa Aktif</th>
                  <th className="p-4">Status Kapasitas</th>
                  <th className="p-4 text-right w-24">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-xs text-slate-700">
                {filteredClassrooms.length > 0 ? (
                  filteredClassrooms.map(c => {
                    const actualCount = students.filter(s => s.classroom === c.name).length;
                    return (
                      <tr key={c.id} className="hover:bg-slate-50/50 transition-colors">
                        <td className="p-4">
                          <span className="h-7 w-7 rounded-lg bg-indigo-50 border border-indigo-100 text-indigo-700 flex items-center justify-center font-bold text-xs">
                            Kls {c.grade}
                          </span>
                        </td>
                        <td className="p-4 font-bold text-slate-900 text-xs">
                          {c.name}
                        </td>
                        <td className="p-4 text-slate-800 font-semibold">
                          {c.homeroomTeacher}
                        </td>
                        <td className="p-4">
                          <div className="font-bold text-slate-700">{actualCount} Siswa</div>
                          <div className="text-[10px] text-slate-400 mt-0.5">Didaftarkan: {c.studentCount} kuota</div>
                        </td>
                        <td className="p-4">
                          <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                            actualCount >= 28 ? 'bg-orange-100 text-orange-850' : 'bg-emerald-100 text-emerald-800'
                          }`}>
                            {actualCount >= 28 ? 'Penuh (Max)' : 'Tersedia'}
                          </span>
                        </td>
                        <td className="p-4 text-right">
                          <div className="flex items-center justify-end gap-1.5">
                            <button
                              onClick={() => handleEdit(c)}
                              className="p-1.5 text-slate-500 hover:text-brand-green-700 hover:bg-emerald-50 rounded-lg transition-colors cursor-pointer"
                            >
                              <Edit className="h-4 w-4" />
                            </button>
                            <button
                              onClick={() => handleDelete(c.id)}
                              className="p-1.5 text-slate-500 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                            >
                              <Trash className="h-4 w-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })
                ) : (
                  <tr>
                    <td colSpan={6} className="p-8 text-center text-slate-400 text-xs">
                      Tidak ada data rombel kelas ditemukan.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          )}

          {/* Active Sub Tab 4: Mata Pelajaran */}
          {activeSubTab === 'mapel' && (
            <table className="w-full text-left border-collapse min-w-max">
              <thead>
                <tr className="border-b border-slate-100 bg-slate-50/70 text-slate-400 text-xxs uppercase tracking-wider font-bold">
                  <th className="p-4">Kode Mapel</th>
                  <th className="p-4">Nama Pelajaran Kurikulum</th>
                  <th className="p-4">Rumpun Mutu</th>
                  <th className="p-4">Fase CP</th>
                  <th className="p-4">Tingkat Kelas</th>
                  <th className="p-4">Alokasi Waktu Pembelajaran</th>
                  <th className="p-4 text-right w-24">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-xs text-slate-700">
                {filteredSubjects.length > 0 ? (
                  filteredSubjects.map(sub => (
                    <tr key={sub.id} className="hover:bg-slate-50/50 transition-colors">
                      <td className="p-4 font-mono font-bold text-brand-green-800">
                        {sub.code}
                      </td>
                      <td className="p-4 font-extrabold text-slate-900 text-xs">
                        {sub.name}
                      </td>
                      <td className="p-4">
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          sub.category === 'Agama' ? 'bg-emerald-500/10 text-brand-green-800 font-extrabold' : 'bg-slate-100 text-slate-700'
                        }`}>
                          {sub.category}
                        </span>
                      </td>
                      <td className="p-4 text-slate-600">
                        {sub.fase || 'Fase B'}
                      </td>
                      <td className="p-4 font-semibold text-slate-800">
                        {sub.gradeLevel || 'Kelas 4'}
                      </td>
                      <td className="p-4 font-bold text-brand-green-900">
                        {sub.allocatedHours || '4 JP / Pekan'}
                      </td>
                      <td className="p-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => handleEdit(sub)}
                            className="p-1.5 text-slate-500 hover:text-brand-green-700 hover:bg-emerald-50 rounded-lg transition-colors cursor-pointer"
                          >
                            <Edit className="h-4 w-4" />
                          </button>
                          <button
                            onClick={() => handleDelete(sub.id)}
                            className="p-1.5 text-slate-500 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                          >
                            <Trash className="h-4 w-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={7} className="p-8 text-center text-slate-400 text-xs">
                      Tidak ada data mata pelajaran ditemukan.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          )}

          {/* Active Sub Tab 5: Tahun Pelajaran */}
          {activeSubTab === 'tahun_ajaran' && (
            <table className="w-full text-left border-collapse min-w-max">
              <thead>
                <tr className="border-b border-slate-100 bg-slate-50/70 text-slate-400 text-xxs uppercase tracking-wider font-bold">
                  <th className="p-4">ID Master</th>
                  <th className="p-4">Rentang Tahun Pelajaran</th>
                  <th className="p-4">Semester Berjalan</th>
                  <th className="p-4">Status Kalender Akademik</th>
                  <th className="p-4 text-right w-24">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-xs text-slate-700">
                {filteredAcademicYears.length > 0 ? (
                  filteredAcademicYears.map(ay => (
                    <tr key={ay.id} className="hover:bg-slate-50/50 transition-colors">
                      <td className="p-4 font-mono font-bold text-slate-400">
                        {ay.id}
                      </td>
                      <td className="p-4 font-bold text-slate-900 text-xs">
                        Tahun Ajaran {ay.year}
                      </td>
                      <td className="p-4 font-semibold text-slate-700">
                        Semester {ay.semester}
                      </td>
                      <td className="p-4">
                        <span className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xxs font-extrabold ${
                          ay.isActive ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-400'
                        }`}>
                          <span className={`h-1.5 w-1.5 rounded-full ${ay.isActive ? 'bg-emerald-500 animate-ping' : 'bg-slate-400'}`} />
                          {ay.isActive ? 'AKTIF BERJALAN' : 'ARSIP HISTORIS'}
                        </span>
                      </td>
                      <td className="p-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => handleEdit(ay)}
                            className="p-1.5 text-slate-500 hover:text-brand-green-700 hover:bg-emerald-50 rounded-lg transition-colors cursor-pointer"
                          >
                            <Edit className="h-4 w-4" />
                          </button>
                          <button
                            onClick={() => handleDelete(ay.id)}
                            className="p-1.5 text-slate-500 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                          >
                            <Trash className="h-4 w-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={5} className="p-8 text-center text-slate-400 text-xs">
                      Tidak ada data kalender tahun ajaran ditemukan.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          )}

        </div>
      </div>

      {/* 5. DYNAMIC FORM MODAL - RESPONSIVE SCROLLABLE GRID */}
      {isFormOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center z-50 p-4 transition-opacity">
          <div className="bg-white rounded-2xl w-full max-w-2xl shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200 border border-slate-100 flex flex-col max-h-[90vh]">
            
            {/* Modal Header */}
            <div className="bg-brand-green-900 px-6 py-4 text-white flex justify-between items-center shrink-0">
              <div>
                <h3 className="font-bold text-sm font-display">
                  {editingId ? 'Koreksi Data Master' : 'Daftarkan Baru'} &bull; {
                    activeSubTab === 'siswa' ? 'Peserta Didik' :
                    activeSubTab === 'guru' ? 'Guru & Staf' :
                    activeSubTab === 'kelas' ? 'Rombongan Kelas' :
                    activeSubTab === 'mapel' ? 'Mata Pelajaran' : 'Tahun Ajaran'
                  }
                </h3>
                <p className="text-[10px] text-white/70 mt-0.5 font-sans">Kurikulum Merdeka Merdeka Al Faraby High-Fidelity Panel</p>
              </div>
              <button 
                onClick={() => setIsFormOpen(false)} 
                className="p-1 rounded-lg text-white/80 hover:text-white bg-white/10 hover:bg-white/20 transition cursor-pointer"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            
            {/* Modal Body Form */}
            <form onSubmit={handleSave} className="flex-1 overflow-y-auto p-6 space-y-4">
              
              {/* --- 1. STUDENT FORM --- */}
              {activeSubTab === 'siswa' && (
                <div className="space-y-4">
                  <div className="bg-amber-50 p-3 rounded-xl border border-amber-200/50 flex gap-2 text-xxs leading-relaxed text-amber-900">
                    <Info className="h-4 w-4 shrink-0 text-amber-700 mt-0.5" />
                    <div>
                      <strong>Petunjuk Administrasi:</strong> Pastikan isian NIS dan NISN sinkron dengan berkas Dapodik santri demi pemetaan rapor digital terintegrasi.
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xxs font-extrabold text-slate-500 uppercase tracking-wider">Nama Lengkap Santri</label>
                      <input
                        type="text"
                        required
                        value={studName}
                        onChange={e => setStudName(e.target.value)}
                        className="w-full text-xs mt-1.5 px-3.5 py-2.5 border border-slate-200 rounded-xl focus:outline-none focus:border-brand-green-600 focus:ring-1 focus:ring-brand-green-600 bg-slate-50/50"
                        placeholder="Ahmad Fauzan..."
                      />
                    </div>

                    <div>
                      <label className="block text-xxs font-extrabold text-slate-500 uppercase tracking-wider">Tingkatan Rombel (Kelas)</label>
                      <select
                        value={studClass}
                        onChange={e => setStudClass(e.target.value)}
                        className="w-full text-xs mt-1.5 px-3.5 py-2.5 border border-slate-200 rounded-xl bg-white focus:outline-none focus:border-brand-green-600"
                      >
                        {classrooms.length > 0 ? (
                          classrooms.map(c => <option key={c.id} value={c.name}>{c.name}</option>)
                        ) : (
                          <>
                            <option value="Kelas 4A">Kelas 4A</option>
                            <option value="Kelas 4B">Kelas 4B</option>
                            <option value="Kelas 5">Kelas 5</option>
                            <option value="Kelas 6">Kelas 6</option>
                          </>
                        )}
                      </select>
                    </div>

                    <div>
                      <label className="block text-xxs font-extrabold text-slate-500 uppercase tracking-wider">NIS (Nomor Induk Siswa)</label>
                      <input
                        type="text"
                        required
                        maxLength={6}
                        value={studNis}
                        onChange={e => setStudNis(e.target.value)}
                        className="w-full text-xs mt-1.5 px-3.5 py-2.5 border border-slate-200 rounded-xl focus:outline-none focus:border-brand-green-600 font-mono"
                        placeholder="240x"
                      />
                    </div>

                    <div>
                      <label className="block text-xxs font-extrabold text-slate-500 uppercase tracking-wider">NISN (Nasional)</label>
                      <input
                        type="text"
                        maxLength={10}
                        value={studNisn}
                        onChange={e => setStudNisn(e.target.value)}
                        className="w-full text-xs mt-1.5 px-3.5 py-2.5 border border-slate-200 rounded-xl focus:outline-none focus:border-brand-green-600 font-mono"
                        placeholder="012xxxxxxxx"
                      />
                    </div>

                    <div>
                      <label className="block text-xxs font-extrabold text-slate-500 uppercase tracking-wider">Tempat Lahir</label>
                      <input
                        type="text"
                        value={studBirthplace}
                        onChange={e => setStudBirthplace(e.target.value)}
                        className="w-full text-xs mt-1.5 px-3.5 py-2.5 border border-slate-200 rounded-xl"
                        placeholder="Contoh: Bogor"
                      />
                    </div>

                    <div>
                      <label className="block text-xxs font-extrabold text-slate-500 uppercase tracking-wider">Tanggal Lahir</label>
                      <input
                        type="date"
                        value={studBirthdate}
                        onChange={e => setStudBirthdate(e.target.value)}
                        className="w-full text-xs mt-1.5 px-3.5 py-2.5 border border-slate-200 rounded-xl"
                      />
                    </div>

                    <div>
                      <label className="block text-xxs font-extrabold text-slate-500 uppercase tracking-wider">Jenis Kelamin</label>
                      <div className="flex gap-4 mt-2">
                        <label className="flex items-center gap-1.5 text-xs font-semibold text-slate-700 cursor-pointer">
                          <input 
                            type="radio" 
                            name="studGender" 
                            checked={studGender === 'L'} 
                            onChange={() => setStudGender('L')} 
                            className="accent-brand-green-700 h-4 w-4"
                          />
                          Laki-laki (L)
                        </label>
                        <label className="flex items-center gap-1.5 text-xs font-semibold text-slate-700 cursor-pointer">
                          <input 
                            type="radio" 
                            name="studGender" 
                            checked={studGender === 'P'} 
                            onChange={() => setStudGender('P')} 
                            className="accent-brand-green-700 h-4 w-4"
                          />
                          Perempuan (P)
                        </label>
                      </div>
                    </div>

                    <div>
                      <label className="block text-xxs font-extrabold text-slate-500 uppercase tracking-wider">Agama</label>
                      <input
                        type="text"
                        value={studReligion}
                        onChange={e => setStudReligion(e.target.value)}
                        className="w-full text-xs mt-1.5 px-3.5 py-2.5 border border-slate-200 rounded-xl"
                        placeholder="Contoh: Islam"
                      />
                    </div>

                    <div>
                      <label className="block text-xxs font-extrabold text-slate-500 uppercase tracking-wider">Nama Ayah Kandung</label>
                      <input
                        type="text"
                        value={studFatherName}
                        onChange={e => setStudFatherName(e.target.value)}
                        className="w-full text-xs mt-1.5 px-3.5 py-2.5 border border-slate-200 rounded-xl"
                        placeholder="Ayah..."
                      />
                    </div>

                    <div>
                      <label className="block text-xxs font-extrabold text-slate-500 uppercase tracking-wider">Nama Ibu Kandung</label>
                      <input
                        type="text"
                        value={studMotherName}
                        onChange={e => setStudMotherName(e.target.value)}
                        className="w-full text-xs mt-1.5 px-3.5 py-2.5 border border-slate-200 rounded-xl"
                        placeholder="Ibu..."
                      />
                    </div>

                    <div>
                      <label className="block text-xxs font-extrabold text-slate-500 uppercase tracking-wider">Nomor Kontak Wali (WA)</label>
                      <input
                        type="text"
                        value={studPhone}
                        onChange={e => setStudPhone(e.target.value)}
                        className="w-full text-xs mt-1.5 px-3.5 py-2.5 border border-slate-200 rounded-xl"
                        placeholder="0813xxxxxxxx"
                      />
                    </div>

                    <div>
                      <label className="block text-xxs font-extrabold text-slate-500 uppercase tracking-wider">Status Keaktifan</label>
                      <select
                        value={studStatus}
                        onChange={e => setStudStatus(e.target.value)}
                        className="w-full text-xs mt-1.5 px-3.5 py-2.5 border border-slate-200 rounded-xl bg-white"
                      >
                        <option value="Aktif">Aktif</option>
                        <option value="Pindahan">Pindahan</option>
                        <option value="Lulus">Lulus</option>
                        <option value="Keluar">Keluar</option>
                      </select>
                    </div>

                    <div className="col-span-1 md:col-span-2">
                      <label className="block text-xxs font-extrabold text-slate-500 uppercase tracking-wider">Alamat Lengkap Domisili</label>
                      <textarea
                        rows={2}
                        value={studAddress}
                        onChange={e => setStudAddress(e.target.value)}
                        className="w-full text-xs mt-1.5 px-3.5 py-2.5 border border-slate-200 rounded-xl focus:outline-none focus:border-brand-green-600"
                        placeholder="Tuliskan alamat jalan, RT, RW, Kelurahan, Kecamatan, Kota..."
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* --- 2. TEACHER FORM --- */}
              {activeSubTab === 'guru' && (
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xxs font-extrabold text-slate-500 uppercase tracking-wider">Nama Lengkap & Gelar Akademik</label>
                      <input
                        type="text"
                        required
                        value={teachName}
                        onChange={e => setTeachName(e.target.value)}
                        className="w-full text-xs mt-1.5 px-3.5 py-2.5 border border-slate-200 rounded-xl"
                        placeholder="Ustadzah Siti Maryam, S.Pd.I."
                      />
                    </div>

                    <div>
                      <label className="block text-xxs font-extrabold text-slate-500 uppercase tracking-wider">Email Satuan Lembaga</label>
                      <input
                        type="email"
                        required
                        value={teachEmail}
                        onChange={e => setTeachEmail(e.target.value)}
                        className="w-full text-xs mt-1.5 px-3.5 py-2.5 border border-slate-200 rounded-xl"
                        placeholder="maryam.ops@gmail.com"
                      />
                    </div>

                    <div>
                      <label className="block text-xxs font-extrabold text-slate-500 uppercase tracking-wider">NIP / Identitas Pegawai Yayasan</label>
                      <input
                        type="text"
                        required
                        value={teachNip}
                        onChange={e => setTeachNip(e.target.value)}
                        className="w-full text-xs mt-1.5 px-3.5 py-2.5 border border-slate-200 rounded-xl font-mono"
                        placeholder="19xxxxxxxxxxxxxx"
                      />
                    </div>

                    <div>
                      <label className="block text-xxs font-extrabold text-slate-500 uppercase tracking-wider">NUPTK (Jika Ada)</label>
                      <input
                        type="text"
                        value={teachNuptk}
                        onChange={e => setTeachNuptk(e.target.value)}
                        className="w-full text-xs mt-1.5 px-3.5 py-2.5 border border-slate-200 rounded-xl font-mono"
                        placeholder="16-digit nomor sertifikasi"
                      />
                    </div>

                    <div>
                      <label className="block text-xxs font-extrabold text-slate-500 uppercase tracking-wider">Tempat, Tanggal Lahir</label>
                      <input
                        type="text"
                        value={teachBirthplaceDate}
                        onChange={e => setTeachBirthplaceDate(e.target.value)}
                        className="w-full text-xs mt-1.5 px-3.5 py-2.5 border border-slate-200 rounded-xl"
                        placeholder="Bogor, 12 Juli 1990"
                      />
                    </div>

                    <div>
                      <label className="block text-xxs font-extrabold text-slate-500 uppercase tracking-wider">Pendidikan Terakhir</label>
                      <input
                        type="text"
                        value={teachLastEducation}
                        onChange={e => setTeachLastEducation(e.target.value)}
                        className="w-full text-xs mt-1.5 px-3.5 py-2.5 border border-slate-200 rounded-xl"
                        placeholder="S1 Kependidikan Agama / PGSD"
                      />
                    </div>

                    <div>
                      <label className="block text-xxs font-extrabold text-slate-500 uppercase tracking-wider">Jabatan Pokok</label>
                      <input
                        type="text"
                        value={teachJobTitle}
                        onChange={e => setTeachJobTitle(e.target.value)}
                        className="w-full text-xs mt-1.5 px-3.5 py-2.5 border border-slate-200 rounded-xl"
                        placeholder="Contoh: Guru Kelas 4A / Wakasek"
                      />
                    </div>

                    <div>
                      <label className="block text-xxs font-extrabold text-slate-500 uppercase tracking-wider">Status Kepegawaian</label>
                      <select
                        value={teachEmploymentStatus}
                        onChange={e => setTeachEmploymentStatus(e.target.value)}
                        className="w-full text-xs mt-1.5 px-3.5 py-2.5 border border-slate-200 rounded-xl bg-white"
                      >
                        <option value="Pegawai Negeri Sipil (PNS)">Pegawai Negeri Sipil (PNS)</option>
                        <option value="Tetap Yayasan (GTY)">Tetap Yayasan (GTY)</option>
                        <option value="Kontrak Kerja">Kontrak Kerja</option>
                        <option value="GTT / Honorer">GTT / Honorer</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xxs font-extrabold text-slate-500 uppercase tracking-wider">Wali Kelas Untuk rombel</label>
                      <select
                        value={teachClass}
                        onChange={e => setTeachClass(e.target.value)}
                        className="w-full text-xs mt-1.5 px-3.5 py-2.5 border border-slate-200 rounded-xl bg-white"
                      >
                        <option value="Tidak Ada">Tidak Ada / Bukan Wali Kelas</option>
                        {classrooms.map(c => <option key={c.id} value={c.name}>{c.name}</option>)}
                      </select>
                    </div>

                    <div>
                      <label className="block text-xxs font-extrabold text-slate-500 uppercase tracking-wider">Otoritas Akses Sistem</label>
                      <select
                        value={teachRole}
                        onChange={e => setTeachRole(e.target.value as UserRole)}
                        className="w-full text-xs mt-1.5 px-3.5 py-2.5 border border-slate-200 rounded-xl bg-white"
                      >
                        <option value={UserRole.GURU}>{UserRole.GURU}</option>
                        <option value={UserRole.KEPSEK}>{UserRole.KEPSEK}</option>
                        <option value={UserRole.OPERATOR}>{UserRole.OPERATOR}</option>
                        <option value={UserRole.ADMIN}>{UserRole.ADMIN}</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xxs font-extrabold text-slate-500 uppercase tracking-wider">Nomor HP Aktif (WhatsApp)</label>
                      <input
                        type="text"
                        value={teachPhone}
                        onChange={e => setTeachPhone(e.target.value)}
                        className="w-full text-xs mt-1.5 px-3.5 py-2.5 border border-slate-200 rounded-xl"
                        placeholder="081xxxxxxxxx"
                      />
                    </div>

                    <div>
                      <label className="block text-xxs font-extrabold text-slate-500 uppercase tracking-wider">Simbol Foto / Avatar</label>
                      <select
                        value={teachPhotoUrl}
                        onChange={e => setTeachPhotoUrl(e.target.value)}
                        className="w-full text-xs mt-1.5 px-3.5 py-2.5 border border-slate-200 rounded-xl bg-white"
                      >
                        <option value="🧕">Ustadzah (Hijab Emoji - 🧕)</option>
                        <option value="👨‍💼">Ustadz / Guru (Pria - 👨‍💼)</option>
                        <option value="👩‍💼">Asisten Guru / Staf (Wanita - 👩‍💼)</option>
                        <option value="👨‍💻">Developer Admin (👨‍💻)</option>
                        <option value="🕌">Kiai / Pengasuh (🕌)</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xxs font-extrabold text-slate-500 uppercase tracking-wider">Jenis Kelamin</label>
                      <div className="flex gap-4 mt-2">
                        <label className="flex items-center gap-1.5 text-xs font-semibold text-slate-700 cursor-pointer">
                          <input 
                            type="radio" 
                            name="teachGenderInput" 
                            checked={teachGender === 'L'} 
                            onChange={() => setTeachGender('L')} 
                            className="accent-brand-green-700 h-4 w-4"
                          />
                          Laki-laki (L)
                        </label>
                        <label className="flex items-center gap-1.5 text-xs font-semibold text-slate-700 cursor-pointer">
                          <input 
                            type="radio" 
                            name="teachGenderInput" 
                            checked={teachGender === 'P'} 
                            onChange={() => setTeachGender('P')} 
                            className="accent-brand-green-700 h-4 w-4"
                          />
                          Perempuan (P)
                        </label>
                      </div>
                    </div>

                    <div className="col-span-1 md:col-span-2">
                      <label className="block text-xxs font-extrabold text-slate-500 uppercase tracking-wider">Mata Pelajaran yang Diampu (Pisahkan dengan koma)</label>
                      <input
                        type="text"
                        value={teachSubjectsAssigned.join(', ')}
                        onChange={e => setTeachSubjectsAssigned(e.target.value.split(',').map(s => s.trim()))}
                        className="w-full text-xs mt-1.5 px-3.5 py-2.5 border border-slate-200 rounded-xl"
                        placeholder="Aqidah Akhlak, Fikih, Matematika..."
                      />
                    </div>

                    <div className="col-span-1 md:col-span-2">
                      <label className="block text-xxs font-extrabold text-slate-500 uppercase tracking-wider">Alamat Tinggal Tetap</label>
                      <textarea
                        rows={2}
                        value={teachAddress}
                        onChange={e => setTeachAddress(e.target.value)}
                        className="w-full text-xs mt-1.5 px-3.5 py-2.5 border border-slate-200 rounded-xl focus:outline-none focus:border-brand-green-600"
                        placeholder="Tuliskan nama jalan dan wilayah asatidzah..."
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* --- 3. CLASSROOM FORM --- */}
              {activeSubTab === 'kelas' && (
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xxs font-extrabold text-slate-500 uppercase tracking-wider">Tingkatan Rombel (1 - 6)</label>
                      <select
                        value={classGrade}
                        onChange={e => setClassGrade(e.target.value)}
                        className="w-full text-xs mt-1.5 px-3.5 py-2.5 border border-slate-200 rounded-xl bg-white"
                      >
                        <option value="1">Tingkat 1</option>
                        <option value="2">Tingkat 2</option>
                        <option value="3">Tingkat 3</option>
                        <option value="4">Tingkat 4</option>
                        <option value="5">Tingkat 5</option>
                        <option value="6">Tingkat 6</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xxs font-extrabold text-slate-500 uppercase tracking-wider">Nama Kelas Belajar</label>
                      <input
                        type="text"
                        required
                        value={classNameInput}
                        onChange={e => setClassNameInput(e.target.value)}
                        className="w-full text-xs mt-1.5 px-3.5 py-2.5 border border-slate-200 rounded-xl"
                        placeholder="Contoh: Kelas 4C atau Kelas 6-Ikhwan"
                      />
                    </div>

                    <div>
                      <label className="block text-xxs font-extrabold text-slate-500 uppercase tracking-wider">Wali Kelas Terpilih</label>
                      <select
                        value={classTeacher}
                        onChange={e => setClassTeacher(e.target.value)}
                        className="w-full text-xs mt-1.5 px-3.5 py-2.5 border border-slate-200 rounded-xl bg-white"
                      >
                        <option value="">-- Hubungkan Guru / Wali --</option>
                        {teachers.map(t => <option key={t.id} value={t.name}>{t.name}</option>)}
                        <option value="Tidak Ada">Tidak Ada Wali Kelas</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xxs font-extrabold text-slate-500 uppercase tracking-wider">Kapasitas Maksimal Siswa (Kuota Dapodik)</label>
                      <input
                        type="number"
                        min={0}
                        max={40}
                        value={classStudentsCount}
                        onChange={e => setClassStudentsCount(Number(e.target.value))}
                        className="w-full text-xs mt-1.5 px-3.5 py-2.5 border border-slate-200 rounded-xl"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* --- 4. SUBJECT FORM --- */}
              {activeSubTab === 'mapel' && (
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xxs font-extrabold text-slate-500 uppercase tracking-wider">Nama Mata Pelajaran</label>
                      <input
                        type="text"
                        required
                        value={subjName}
                        onChange={e => setSubjName(e.target.value)}
                        className="w-full text-xs mt-1.5 px-3.5 py-2.5 border border-slate-200 rounded-xl"
                        placeholder="Contoh: Nahwu Shorof"
                      />
                    </div>

                    <div>
                      <label className="block text-xxs font-extrabold text-slate-500 uppercase tracking-wider">Kode Kurikulum Mapel</label>
                      <input
                        type="text"
                        required
                        value={subjCode}
                        onChange={e => setSubjCode(e.target.value)}
                        className="w-full text-xs mt-1.5 px-3.5 py-2.5 border border-slate-200 rounded-xl font-mono uppercase"
                        placeholder="Contoh: NS-04"
                      />
                    </div>

                    <div>
                      <label className="block text-xxs font-extrabold text-slate-500 uppercase tracking-wider">Kategori Rumpun Pembelajaran</label>
                      <select
                        value={subjCategory}
                        onChange={e => setSubjCategory(e.target.value as 'Agama' | 'Umum')}
                        className="w-full text-xs mt-1.5 px-3.5 py-2.5 border border-slate-200 rounded-xl bg-white"
                      >
                        <option value="Agama">Pendidikan Agama / Kepesantrenan</option>
                        <option value="Umum">Pendidikan Umum (Baku Kemendikbud)</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xxs font-extrabold text-slate-500 uppercase tracking-wider">Fase CP Kurikulum Merdeka</label>
                      <select
                        value={subjFase}
                        onChange={e => setSubjFase(e.target.value)}
                        className="w-full text-xs mt-1.5 px-3.5 py-2.5 border border-slate-200 rounded-xl bg-white"
                      >
                        <option value="Fase A">Fase A (Kelas 1-2)</option>
                        <option value="Fase B">Fase B (Kelas 3-4)</option>
                        <option value="Fase C">Fase C (Kelas 5-6)</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xxs font-extrabold text-slate-500 uppercase tracking-wider">Tingkatan Rujukan Kelas</label>
                      <input
                        type="text"
                        value={subjGradeLevel}
                        onChange={e => setSubjGradeLevel(e.target.value)}
                        className="w-full text-xs mt-1.5 px-3.5 py-2.5 border border-slate-200 rounded-xl"
                        placeholder="Contoh: Kelas 4"
                      />
                    </div>

                    <div>
                      <label className="block text-xxs font-extrabold text-slate-500 uppercase tracking-wider">Alokasi Waktu Tatap Muka</label>
                      <input
                        type="text"
                        value={subjHours}
                        onChange={e => setSubjHours(e.target.value)}
                        className="w-full text-xs mt-1.5 px-3.5 py-2.5 border border-slate-200 rounded-xl"
                        placeholder="Contoh: 4 JP / Pekan"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* --- 5. ACADEMIC YEAR FORM --- */}
              {activeSubTab === 'tahun_ajaran' && (
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xxs font-extrabold text-slate-500 uppercase tracking-wider">Rentang Tahun Pelajaran</label>
                      <input
                        type="text"
                        required
                        value={yearVal}
                        onChange={e => setYearVal(e.target.value)}
                        className="w-full text-xs mt-1.5 px-3.5 py-2.5 border border-slate-200 rounded-xl"
                        placeholder="Contoh: 2026/2027"
                      />
                    </div>

                    <div>
                      <label className="block text-xxs font-extrabold text-slate-500 uppercase tracking-wider">Semester Berlangsung</label>
                      <select
                        value={semesterVal}
                        onChange={e => setSemesterVal(e.target.value as 'Ganjil' | 'Genap')}
                        className="w-full text-xs mt-1.5 px-3.5 py-2.5 border border-slate-200 rounded-xl bg-white"
                      >
                        <option value="Ganjil">Semester Ganjil</option>
                        <option value="Genap">Semester Genap</option>
                      </select>
                    </div>

                    <div className="col-span-1 md:col-span-2 bg-slate-50 p-4 rounded-xl border border-slate-100 flex items-center justify-between">
                      <div>
                        <span className="block text-xs font-bold text-slate-800">Setel Sebagai Semester Aktif Berjalan</span>
                        <span className="block text-[10px] text-slate-400 mt-0.5">Sistem akan otomatis menyesuaikan kalender input absensi & administrasi ke TA ini.</span>
                      </div>
                      <label className="relative inline-flex items-center cursor-pointer">
                        <input
                          type="checkbox"
                          checked={isActiveVal}
                          onChange={e => setIsActiveVal(e.target.checked)}
                          className="sr-only peer"
                        />
                        <div className="w-11 h-6 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-brand-green-700"></div>
                      </label>
                    </div>
                  </div>
                </div>
              )}

              {/* Form Action Controls */}
              <div className="flex items-center justify-end gap-2 pt-6 border-t border-slate-100 shrink-0">
                <button
                  type="button"
                  onClick={() => setIsFormOpen(false)}
                  className="px-4.5 py-2.5 text-xs font-bold text-slate-500 hover:text-slate-800 bg-slate-100 hover:bg-slate-200 rounded-xl transition cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 text-xs font-extrabold text-white bg-brand-green-700 hover:bg-brand-green-800 rounded-xl shadow-md transition transform active:scale-95 cursor-pointer"
                >
                  {editingId ? 'Simpan Perubahan' : 'Daftarkan Record'}
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

    </div>
  );
}
