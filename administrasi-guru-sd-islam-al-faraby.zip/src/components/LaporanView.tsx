/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Award,
  Star,
  CheckCircle,
  BarChart3,
  LineChart,
  ListFilter,
  Download,
  FileText,
  Sparkles,
  ChevronRight,
  BookOpen,
  Calendar,
  FileCheck,
  ClipboardList,
  UserCheck,
  Briefcase,
  Layers,
  Printer,
  FileSpreadsheet,
  FileCode,
  Info,
  Clock,
  ExternalLink
} from 'lucide-react';
import { Student, AcademicScore, Subject, AttendanceLog, TeachingJournal, Teacher } from '../types';
import { PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, RadarChart, ResponsiveContainer, BarChart, Bar, CartesianGrid, XAxis, YAxis, Tooltip } from 'recharts';

interface LaporanViewProps {
  students: Student[];
  subjects: Subject[];
  academicScores: AcademicScore[];
  attendanceLogs?: AttendanceLog[];
  teachingJournals?: TeachingJournal[];
  teachers?: Teacher[];
}

export default function LaporanView({
  students,
  subjects,
  academicScores,
  attendanceLogs = [],
  teachingJournals = [],
  teachers = []
}: LaporanViewProps) {
  // Navigation Tabs: Rapor Individu vs Ekspor Hub (Modul 10)
  const [activeTab, setActiveTab] = useState<'rapor' | 'modul10'>('modul10');

  // Rapor Individu State
  const [selectedClass, setSelectedClass] = useState('Kelas 4A');
  const [selectedStudentId, setSelectedStudentId] = useState(students[0]?.id || 'S001');

  // Modul 10 State
  const [reportType, setReportType] = useState<'Kehadiran' | 'Jurnal' | 'Agenda' | 'Nilai' | 'Guru' | 'Semester' | 'Tahunan'>('Kehadiran');
  const [exportFormat, setExportFormat] = useState<'PDF' | 'Excel' | 'Word'>('PDF');
  const [reportSemester, setReportSemester] = useState<'Ganjil' | 'Genap'>('Ganjil');
  const [reportYear, setReportYear] = useState('2026/2027');
  const [reportMonth, setReportMonth] = useState('Juni');
  const [reportClass, setReportClass] = useState('Kelas 4A');

  const filteredStudents = students.filter(s => s.classroom === selectedClass);
  const selectedStudent = students.find(s => s.id === selectedStudentId) || students[0];

  // Prepare academic scores for radar chart of selected student
  const studentScores = academicScores.filter(sc => sc.studentId === selectedStudentId);

  const radarData = subjects.map(sub => {
    const matched = studentScores.find(sc => sc.subjectId === sub.id);
    return {
      subject: sub.name.substring(0, 10) + '..',
      Nilai: matched ? matched.finalScore : 75
    };
  });

  // Calculate overall average for bar chart
  const classScores = academicScores.filter(sc => sc.classroom === selectedClass);
  const subjectAverages = subjects.map(sub => {
    const matchedScores = classScores.filter(sc => sc.subjectId === sub.id);
    const avg = matchedScores.length > 0
      ? Math.round(matchedScores.reduce((acc, curr) => acc + curr.finalScore, 0) / matchedScores.length)
      : 75;
    return {
      name: sub.name,
      Rerata: avg
    };
  });

  // Print individual transcript card mockup
  const handleDownloadTranscript = () => {
    const printWindow = window.open('', '_blank');
    if (printWindow && selectedStudent) {
      printWindow.document.write(`
        <html>
          <head>
            <title>Rapor Santri - ${selectedStudent.name}</title>
            <style>
              body { font-family: 'Helvetica Neue', Arial, sans-serif; padding: 50px; line-height: 1.5; color: #334155; }
              .header { text-align: center; margin-bottom: 30px; }
              .school-title { font-size: 24px; font-weight: bold; color: #064e3b; margin: 0; }
              .sub-title { font-size: 14px; text-transform: uppercase; color: #b45309; font-weight: bold; margin-top: 5px; }
              .meta-info { width: 100%; border-collapse: collapse; margin-bottom: 35px; }
              .meta-info td { padding: 5px 0; font-size: 13px; }
              .grid-table { width: 100%; border-collapse: collapse; margin-top: 20px; }
              .grid-table th { background-color: #064e3b; color: white; padding: 12px; font-size: 13px; text-transform: uppercase; }
              .grid-table td { border: 1px solid #e2e8f0; padding: 10px; font-size: 13px; }
              .character-box { border: 2px solid #b45309; border-radius: 8px; padding: 15px; margin-top: 30px; background-color: #fffbeb; }
              .signature-section { width: 100%; margin-top: 50px; }
              .signature { text-align: center; font-size: 13px; width: 33%; }
            </style>
          </head>
          <body>
            <div class="header">
              <div class="school-title">SD ISLAM AL FARABY</div>
              <div class="sub-title">LAPORAN CAPAIAN BELAJAR SANTRI (RAPOR LEGE)</div>
              <small>NPSN: 20224419 | Akreditasi A (Unggul)</small>
            </div>
            
            <table class="meta-info">
              <tr>
                <td width="15%"><strong>Nama Lengkap:</strong></td>
                <td width="35%">${selectedStudent.name}</td>
                <td width="15%"><strong>Kelas / Rapor:</strong></td>
                <td width="35%">${selectedStudent.classroom} / Ganjil</td>
              </tr>
              <tr>
                <td><strong>NIS / NISN:</strong></td>
                <td>${selectedStudent.nis} / ${selectedStudent.nisn}</td>
                <td><strong>Tahun Ajaran:</strong></td>
                <td>2026/2027</td>
              </tr>
            </table>

            <h3>I. Pencapaian Bidang Akademik</h3>
            <table class="grid-table">
              <thead>
                <tr>
                  <th>No</th>
                  <th>Mata Pelajaran</th>
                  <th>Formatif</th>
                  <th>UTS</th>
                  <th>UAS</th>
                  <th>Nilai Akhir</th>
                </tr>
              </thead>
              <tbody>
                ${subjects.map((sub, i) => {
                  const s = studentScores.find(sc => sc.subjectId === sub.id);
                  return `
                    <tr>
                      <td style="text-align: center;">${i+1}</td>
                      <td><strong>${sub.name}</strong></td>
                      <td style="text-align: center;">${s ? s.harian : '80'}</td>
                      <td style="text-align: center;">${s ? s.uts : '80'}</td>
                      <td style="text-align: center;">${s ? s.uas : '80'}</td>
                      <td style="text-align: center; font-weight: bold; color: #064e3b;">${s ? s.finalScore : '80'}</td>
                    </tr>
                  `;
                }).join('')}
              </tbody>
            </table>

            <div class="character-box">
              <h4 style="margin: 0 0 10px 0; color: #b45309;">II. Log Karakter Adab & Tarbiyah Ibadah Penguat Mulia</h4>
              <p style="font-size: 13px;">
                <strong>Mutu Shalat:</strong> ${selectedStudent.shalatPoin}% Shalat Fardhu Berjamaah & Dhuha Mandiri.<br />
                <strong>Pencapaian Quranic:</strong> ${selectedStudent.tahfidzStatus}.<br />
                <strong>Pembinaan Karakter Sektoral:</strong> Ananda menyukai perilaku tolong-menolong (*Ta'awun*) dan bersikap sopan santun kepada segenap ustadz/ustadzah sekolah.
              </p>
            </div>

            <table class="signature-section">
              <tr>
                <td class="signature">
                  Mengetahui,<br />Orang Tua / Wali Santri<br /><br /><br /><br />............................
                </td>
                <td class="signature" style="width: 33%;"></td>
                <td class="signature">
                  Bogor, 17 Juni 2026<br />Wali Kelas,<br /><br /><br /><br /><strong>Siti Nurhaliza, S.Pd.I.</strong>
                </td>
              </tr>
            </table>
          </body>
        </html>
      `);
      printWindow.document.close();
      printWindow.print();
    } else {
      alert('Gagal membuka halaman cetak rapor: Browser memblokir pengeluaran pop-up. Silakan aktifkan preferensi "Izinkan Pop-up" untuk portal SD Islam Al Faraby atau klik tombol "Buka Aplikasi Baru (Tab)" di pojok kanan atas layar Anda agar fitur pratinjau PDF berjalan lancar!');
    }
  };

  // ================= MODUL 10 DATA GENERATORS =================
  // Generate mock / actual list records for live preview table and file downloads
  const getReportTitle = () => {
    switch (reportType) {
      case 'Kehadiran': return `Laporan Rekapitulasi Kehadiran Siswa ${reportClass}`;
      case 'Jurnal': return `Laporan Rekap Jurnal Mengajar Harian Guru`;
      case 'Agenda': return `Buku Agenda Mengajar & Agenda Kelas`;
      case 'Nilai': return `Laporan Transkrip Rekap Nilai Akademik Siswa`;
      case 'Guru': return `Dokumentasi Administrasi Kelengkapan Guru`;
      case 'Semester': return `Laporan Evaluasi Rekapitulasi Semester ${reportSemester}`;
      case 'Tahunan': return `Laporan Evaluasi Tahunan Akademik ${reportYear}`;
    }
  };

  const getReportSubTitle = () => {
    return `Madrasah Al Faraby - Semester ${reportSemester} - Tahun Ajaran ${reportYear} - Bulan: ${reportMonth}`;
  };

  // Preview Headers based on reportType
  const getTableHeaders = () => {
    switch (reportType) {
      case 'Kehadiran':
        return ['No', 'NIS', 'Nama Siswa', 'Hadir (H)', 'Sakit (S)', 'Izin (I)', 'Alpa (A)', 'Persentase'];
      case 'Jurnal':
        return ['No', 'Tanggal', 'Kelas', 'Mata Pelajaran', 'Topik / Pokokan', 'Hadir', 'Guru Piket'];
      case 'Agenda':
        return ['No', 'Tanggal', 'Kelas', 'Agenda Kegiatan', 'Media/Metode', 'Status Pelaksanaan'];
      case 'Nilai':
        return ['No', 'Nama Siswa', 'Kelas', 'Rata Formatif', 'Rata UTS', 'Rata UAS', 'Rerata Akhir', 'Catatan'];
      case 'Guru':
        return ['No', 'Nama Lengkap Guru', 'NIP / NUPTK', 'Bidang Pengampu', 'Status Kepegawaian', 'Pendidikan'];
      case 'Semester':
        return ['No', 'Aspek Evaluasi', 'Target Capaian', 'Realisasi Rata', 'Predikat', 'Status Ketuntasan'];
      case 'Tahunan':
        return ['No', 'Indikator Kinerja Madrasah', 'Tahun Lalu', 'Tahun Aktif', 'Peningkatan', 'Rekomendasi'];
    }
  };

  // Preview rows generation
  const getTableRows = () => {
    const defaultClassStudents = students.filter(s => s.classroom === reportClass);

    switch (reportType) {
      case 'Kehadiran':
        return defaultClassStudents.map((s, idx) => {
          const totalDays = 26;
          const randomH = Math.floor(Math.random() * 3) + 22; // 22-25 Hadir
          const randomS = Math.floor(Math.random() * 2);
          const randomI = Math.floor(Math.random() * 2);
          const randomA = totalDays - (randomH + randomS + randomI);
          const pct = Math.round((randomH / totalDays) * 100);
          return [
            (idx + 1).toString(),
            s.nis,
            s.name,
            `${randomH} hari`,
            `${randomS} hari`,
            `${randomI} hari`,
            `${randomA} hari`,
            `${pct}%`
          ];
        });

      case 'Jurnal':
        return [
          ['1', '2026-06-15', 'Kelas 4A', 'Aqidah Akhlak', 'Adab Bertamu & Silaturahmi', '24/24', 'Lengkap'],
          ['2', '2026-06-14', 'Kelas 4B', 'Al-Qur\'an Hadits', 'Kandungan Surah Al-Maun', '22/24', 'Sakit 2'],
          ['3', '2026-06-13', 'Kelas 5', 'Fiqih', 'Ketentuan Shalat Jama\' & Qashar', '25/25', 'Lengkap'],
          ['4', '2026-06-12', 'Kelas 6', 'SKI', 'Sejarah Dakwah Rasulullah di Madinah', '23/24', 'Izin 1'],
          ['5', '2026-06-11', 'Kelas 4A', 'Bahasa Arab', 'Afradul Madrasah (Warga Sekolah)', '24/24', 'Lengkap']
        ];

      case 'Agenda':
        return [
          ['1', '2026-06-15', 'Kelas 4A', 'Penyampaian presentasi PPT Adab Bertamu', 'Proyektor & Slide Interaktif', 'Selesai'],
          ['2', '2026-06-14', 'Kelas 4B', 'Praktik pelafalan tajwid hukum Iqlab', 'Kartu Tajwid Berwarna', 'Selesai'],
          ['3', '2026-06-13', 'Kelas 5', 'Diskusi kelompok rukun iman', 'Canva Board Kolaboratif', 'Selesai'],
          ['4', '2026-06-12', 'Kelas 6', 'Pemutaran video YouTube Shalat Sunnah', 'Semat YouTube Al Faraby', 'Selesai'],
          ['5', '2026-06-11', 'Kelas 4A', 'Mendengarkan Murottal Surah Al-Mulk', 'Audio MP3 Player', 'Selesai']
        ];

      case 'Nilai':
        return defaultClassStudents.map((s, idx) => {
          const personalScores = academicScores.filter(sc => sc.studentId === s.id);
          const size = personalScores.length;
          const avgForm = size > 0 ? Math.round(personalScores.reduce((acc, c) => acc + c.harian, 0) / size) : 82;
          const avgUts = size > 0 ? Math.round(personalScores.reduce((acc, c) => acc + c.uts, 0) / size) : 80;
          const avgUas = size > 0 ? Math.round(personalScores.reduce((acc, c) => acc + c.uas, 0) / size) : 85;
          const avgFinal = size > 0 ? Math.round(personalScores.reduce((acc, c) => acc + c.finalScore, 0) / size) : 83;
          return [
            (idx + 1).toString(),
            s.name,
            s.classroom,
            avgForm.toString(),
            avgUts.toString(),
            avgUas.toString(),
            avgFinal.toString(),
            avgFinal >= 80 ? 'Sangat Memuaskan' : 'Sesuai KKM'
          ];
        });

      case 'Guru':
        return teachers.map((t, idx) => [
          (idx + 1).toString(),
          t.name,
          t.nip || t.nuptk || '31244512993',
          t.subjectsAssigned?.join(', ') || 'Semua Studi',
          t.employmentStatus || 'GTY (Guru Tetap Yayasan)',
          t.lastEducation || 'S1 Pendidikan Agama Islam'
        ]);

      case 'Semester':
        return [
          ['1', 'Rerata Akademik Gabungan', '80.00', '84.65', 'A', 'Sangat Tuntas'],
          ['2', 'Indeks Karakter Islami (Adab)', 'Sangat Baik', 'Sangat Baik', 'A', 'Sangat Tuntas'],
          ['3', 'Rata-rata Shalat Fardhu', '85.00%', '88.50%', 'A', 'Tuntas'],
          ['4', 'Kepatuhan Kelengkapan Modul Ajar', '100%', '100%', 'A', 'Sangat Tuntas'],
          ['5', 'Kehadiran Mengajar Guru Harian', '96.00%', '98.40%', 'A', 'Sangat Tuntas']
        ];

      case 'Tahunan':
        return [
          ['1', 'Angka Kelulusan Santri Kelas 6', '100%', '100%', '0.00%', 'Pertahankan mutu pembinaan ujian'],
          ['2', 'Rerata Rapor Kelulusan', '82.40', '85.12', '+2.72', 'Tingkatkan ketersediaan bahan ajar digital'],
          ['3', 'Prestasi Juara Lomba Tahfidz Kabupaten', '2 Pemenang', '4 Pemenang', '+2 Kab', 'Kembangkan beasiswa santri berprestasi'],
          ['4', 'Indeks Kepuasan Wali Santri', '88.20%', '92.50%', '+4.30%', 'Optimalkan grup koordinasi Google Classroom'],
          ['5', 'Penyelesaian Sarana IT Ruang Mengajar', '60%', '90%', '+30%', 'Tambahkan chromebook/tablet belajar mandiri']
        ];
    }
  };

  // Execute actual export downloads
  const handleExportSubmit = () => {
    const title = getReportTitle();
    const info = getReportSubTitle();
    const headers = getTableHeaders();
    const rows = getTableRows();

    if (exportFormat === 'PDF') {
      // Trigger a beautiful styled print window for the selected report
      const printWin = window.open('', '_blank');
      if (!printWin) return;

      const pageHtml = `
        <html>
          <head>
            <title>${title}</title>
            <style>
              body { font-family: 'Helvetica Neue', Arial, Helvetica, sans-serif; padding: 40px; color: #1e293b; line-height: 1.4; }
              .logo-header { border-bottom: 3px double #047857; padding-bottom: 12px; margin-bottom: 25px; text-align: center; }
              .logo-header h1 { color: #064e43; font-size: 22px; margin: 0; font-weight: 800; letter-spacing: -0.5px; }
              .logo-header p { margin: 3px 0 0 0; font-size: 11px; color: #64748b; font-weight: 600; }
              .doc-title { text-align: center; font-size: 16px; font-weight: bold; margin-bottom: 15px; text-transform: uppercase; color: #0f172a; }
              .doc-meta { font-size: 11px; color: #475569; margin-bottom: 20px; text-align: center; font-weight: 500; }
              .report-table { width: 100%; border-collapse: collapse; margin-top: 15px; }
              .report-table th { background-color: #064e3b; color: white; border: 1px solid #14532d; padding: 8px 10px; font-size: 11px; text-transform: uppercase; font-weight: 700; text-align: left; }
              .report-table td { border: 1px solid #cbd5e1; padding: 7px 10px; font-size: 11px; color: #334155; }
              .report-table tr:nth-child(even) { background-color: #f8fafc; }
              .footer-signature { width: 100%; margin-top: 50px; font-size: 11px; }
              .sig-col { text-align: center; width: 40%; }
            </style>
          </head>
          <body>
            <div class="logo-header">
              <h1>SD ISLAM AL FARABY BOGOR</h1>
              <p>Alamat: Jl. KH. Syarifuddin No. 12, Pamijahan, Bogor, Jawa Barat | NPSN: 20224419</p>
            </div>
            
            <div class="doc-title">${title}</div>
            <div class="doc-meta">${info}</div>
            
            <table class="report-table">
              <thead>
                <tr>
                  ${headers.map(h => `<th>${h}</th>`).join('')}
                </tr>
              </thead>
              <tbody>
                ${rows.map(row => `
                  <tr>
                    ${row.map(cell => `<td>${cell}</td>`).join('')}
                  </tr>
                `).join('')}
              </tbody>
            </table>
            
            <table class="footer-signature">
              <tr>
                <td class="sig-col">
                  Mengetahui,<br />Kepala Sekolah SD Islam Al Faraby<br /><br /><br /><br /><strong>Dr. KH. Maimun Zubair, M.A.</strong><br />NIP. 197804152002121003
                </td>
                <td></td>
                <td class="sig-col">
                  Bogor, ${new Date().toLocaleDateString('id-ID', { day: '2-digit', month: 'long', year: 'numeric' })}<br />Ustadz/Ustadzah Pengadministrasi<br /><br /><br /><br /><strong>Wali Kelas Al Faraby</strong>
                </td>
              </tr>
            </table>
          </body>
        </html>
      `;
      printWin.document.write(pageHtml);
      printWin.document.close();
      printWin.print();

    } else if (exportFormat === 'Excel') {
      // Build Excel CSV format
      let csvContent = `SD ISLAM AL FARABY BOGOR\n${title}\n${info}\n\n`;
      csvContent += headers.join('\t') + '\n';
      rows.forEach(r => {
        csvContent += r.join('\t') + '\n';
      });

      const blob = new Blob([csvContent], { type: 'application/vnd.ms-excel;charset=utf-8' });
      const link = document.createElement('a');
      link.href = URL.createObjectURL(blob);
      link.setAttribute('download', `${title.replace(/\s+/g, '_')}_${reportYear.replace(/\//g, '-')}.xls`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      alert(`Alhamdulillah, Laporan Spreadsheet sukses diekspor! File "${title}.xls" siap diunduh.`);

    } else if (exportFormat === 'Word') {
      // Build clean DOC file
      let wordContent = `
        <html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'>
        <head>
          <style>
            body { font-family: 'Arial'; font-size: 12pt; }
            h1 { color: #064e3b; text-align: center; }
            table { width: 100%; border-collapse: collapse; }
            th { background-color: #064e43; color: white; padding: 8px; border: 1px solid black; }
            td { padding: 8px; border: 1px solid black; }
          </style>
        </head>
        <body>
          <h1>SD ISLAM AL FARABY BOGOR</h1>
          <p style='text-align:center;'>${title}</p>
          <p style='text-align:center; font-size:10pt; color:gray;'>${info}</p>
          <hr/>
          <table>
            <thead>
              <tr>${headers.map(h => `<th>${h}</th>`).join('')}</tr>
            </thead>
            <tbody>
              ${rows.map(row => `<tr>${row.map(c => `<td>${c}</td>`).join('')}</tr>`).join('')}
            </tbody>
          </table>
        </body>
        </html>
      `;

      const blob = new Blob([wordContent], { type: 'application/msword;charset=utf-8' });
      const link = document.createElement('a');
      link.href = URL.createObjectURL(blob);
      link.setAttribute('download', `${title.replace(/\s+/g, '_')}_${reportYear.replace(/\//g, '-')}.doc`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      alert(`Alhamdulillah, Dokumen Word sukses diekspor! File "${title}.doc" siap diunduh.`);
    }
  };

  return (
    <div id="laporan-monitoring-wrapper" className="space-y-6">
      
      {/* EXQUISITE TITLE AND SWITCH TRAY */}
      <div className="flex flex-col xl:flex-row xl:items-center justify-between pb-4 border-b border-slate-200 gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="bg-amber-100 text-amber-850 text-xxxxs uppercase font-extrabold px-2.5 py-1 rounded-full">
              Modul 10 Terintegrasi
            </span>
            <h2 className="text-xl font-bold text-slate-800 school-display">
              Pusat Pelaporan & Transkrip Akademik
            </h2>
          </div>
          <p className="text-xxs text-slate-500 mt-1">
            Ekspor berbagai rekapitulasi data sekolah. Mendukung format file representatif PDF, Lembar Excel Spreadsheet, atau Dokumen Word.
          </p>
        </div>

        {/* TABS TRAY CONTROL */}
        <div className="flex bg-slate-100 p-1 rounded-xl self-start">
          <button
            onClick={() => setActiveTab('modul10')}
            className={`px-4 py-1.5 text-xxs font-extrabold rounded-lg transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'modul10' ? 'bg-white shadow-xs text-brand-green-800' : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            <Layers className="h-3.5 w-3.5" />
            Ekspor Laporan (Modul 10)
          </button>
          <button
            onClick={() => setActiveTab('rapor')}
            className={`px-4 py-1.5 text-xxs font-extrabold rounded-lg transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'rapor' ? 'bg-white shadow-xs text-brand-green-800' : 'text-slate-500 hover:text-slate-850'
            }`}
          >
            <Star className="h-3.5 w-3.5 text-emerald-600" />
            Analisis Rapor Individu
          </button>
        </div>
      </div>

      {/* ===================== TAB 1: MODUL 10 EKSPOR UTAMA ===================== */}
      {activeTab === 'modul10' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* LEFT EXPORT PANEL (1 col) */}
          <div className="bg-white rounded-2xl border border-slate-100 shadow-xxs p-5 space-y-4">
            <div className="pb-3 border-b border-slate-100 flex items-center gap-2">
              <Sparkles className="h-4.5 w-4.5 text-brand-gold-500 fill-brand-gold-400" />
              <span className="text-xs font-bold text-slate-800">Panel Parameter Ekspor</span>
            </div>

            <div className="space-y-3.5 text-xxs">
              {/* Type Select */}
              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1.5">Jenis Laporan Madrasah</label>
                <div className="space-y-1">
                  {[
                    { key: 'Kehadiran', label: 'Rekap Kehadiran Siswa', icon: UserCheck, desc: 'Persentase presensi H/S/I/A harian' },
                    { key: 'Jurnal', label: 'Jurnal Mengajar Guru', icon: ClipboardList, desc: 'Materi ajar kelas & kelengkapan JP' },
                    { key: 'Agenda', label: 'Buku Agenda Kelas', icon: Calendar, desc: 'Agenda pelaksanaan tatap muka' },
                    { key: 'Nilai', label: 'Rangkuman Nilai Akademik', icon: Award, desc: 'Transkrip formatif, UTS, UAS' },
                    { key: 'Guru', label: 'Administrasi Ketenagaan', icon: Briefcase, desc: 'Pendidikan & status kepegawaian asatidzah' },
                    { key: 'Semester', label: 'Rekapitulasi Semester', icon: Layers, desc: 'Evaluasi tengah/akhir semester aktif' },
                    { key: 'Tahunan', label: 'Rekapitulasi Kinerja Tahunan', icon: FileCheck, desc: 'Indikator tahunan Al Faraby' }
                  ].map(op => {
                    const isSel = reportType === op.key;
                    const Icon = op.icon;
                    return (
                      <div
                        key={op.key}
                        onClick={() => setReportType(op.key as any)}
                        className={`p-2 rounded-xl border text-left cursor-pointer transition flex items-start gap-2.5 ${
                          isSel ? 'border-brand-green-600 bg-brand-green-50/20' : 'border-slate-150 bg-slate-50/20 hover:bg-slate-50'
                        }`}
                      >
                        <div className={`mt-0.5 p-1 rounded-md ${isSel ? 'bg-brand-green-100 text-brand-green-800' : 'bg-white text-slate-400 border border-slate-150'}`}>
                          <Icon className="h-3.5 w-3.5" />
                        </div>
                        <div>
                          <div className={`font-bold text-[11px] ${isSel ? 'text-brand-green-950' : 'text-slate-700'}`}>{op.label}</div>
                          <div className="text-[9px] text-slate-400 font-medium leading-none mt-0.5">{op.desc}</div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Parameter Filters */}
              <div className="pt-3 border-t border-slate-150 grid grid-cols-2 gap-3.5">
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Rapor Kelas</label>
                  <select
                    value={reportClass}
                    onChange={e => setReportClass(e.target.value)}
                    className="w-full text-xs px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:bg-white text-slate-750 font-bold"
                  >
                    <option value="Kelas 4A">Kelas 4A</option>
                    <option value="Kelas 4B">Kelas 4B</option>
                    <option value="Kelas 5">Kelas 5</option>
                    <option value="Kelas 6">Kelas 6</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Bulan Pelaporan</label>
                  <select
                    value={reportMonth}
                    onChange={e => setReportMonth(e.target.value)}
                    className="w-full text-xs px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:bg-white text-slate-755 font-bold"
                  >
                    <option value="Januari">Januari</option>
                    <option value="Februari">Februari</option>
                    <option value="Maret">Maret</option>
                    <option value="April">April</option>
                    <option value="Mei">Mei</option>
                    <option value="Juni">Juni</option>
                    <option value="Juli">Juli</option>
                    <option value="Agustus">Agustus</option>
                    <option value="September">September</option>
                    <option value="Oktober">Oktober</option>
                    <option value="November">November</option>
                    <option value="Desember">Desember</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Semester</label>
                  <select
                    value={reportSemester}
                    onChange={e => setReportSemester(e.target.value as any)}
                    className="w-full text-xs px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:bg-white text-slate-755 font-bold"
                  >
                    <option value="Ganjil">Semester Ganjil</option>
                    <option value="Genap">Semester Genap</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Tahun Ajaran</label>
                  <select
                    value={reportYear}
                    onChange={e => setReportYear(e.target.value)}
                    className="w-full text-xs px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:bg-white text-slate-755 font-bold"
                  >
                    <option value="2026/2027">2026/2027</option>
                    <option value="2027/2028">2027/2028</option>
                  </select>
                </div>
              </div>

              {/* Output Selection */}
              <div className="pt-3 border-t border-slate-150">
                <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1.5">Format Output berkas</label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { key: 'PDF', label: 'PDF Cetak', icon: Printer, color: 'text-rose-600 bg-rose-50 border-rose-150' },
                    { key: 'Excel', label: 'Spreadsheet', icon: FileSpreadsheet, color: 'text-emerald-600 bg-emerald-50 border-emerald-150' },
                    { key: 'Word', label: 'Word Doc', icon: FileText, color: 'text-blue-600 bg-blue-50 border-blue-150' }
                  ].map(f => {
                    const isSel = exportFormat === f.key;
                    return (
                      <button
                        key={f.key}
                        type="button"
                        onClick={() => setExportFormat(f.key as any)}
                        className={`p-2 rounded-xl border text-center transition cursor-pointer flex flex-col items-center justify-center gap-1 font-bold ${
                          isSel ? 'border-brand-green-600 ring-2 ring-brand-green-500/20 bg-white text-brand-green-800' : 'border-slate-200 text-slate-500 hover:bg-slate-50'
                        }`}
                      >
                        <f.icon className="h-4.5 w-4.5" />
                        <span className="text-[9px]">{f.label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Generate Trigger Button */}
              <button
                type="button"
                onClick={handleExportSubmit}
                className="w-full bg-brand-green-700 hover:bg-brand-green-800 text-white font-bold py-2.5 rounded-xl shadow-xs transition flex items-center justify-center gap-2 cursor-pointer pt-3 border-t text-[11px]"
              >
                <Download className="h-4 w-4" />
                Unduh / Cetak Laporan Sekarang
              </button>
            </div>
          </div>

          {/* RIGHT LIVE PREVIEW STAGE (2 cols) */}
          <div className="lg:col-span-2 space-y-4">
            
            <div className="bg-white rounded-2xl border border-slate-150 shadow-xxs p-6 flex flex-col justify-between">
              
              {/* Paper styled document preview frame */}
              <div className="border border-slate-200/80 bg-slate-50/50 p-6 rounded-xl relative space-y-4 shadow-inner min-h-[480px]">
                
                {/* School Header */}
                <div className="flex items-center justify-between border-b-2 border-slate-350 pb-3 text-center">
                  <div className="text-left">
                    <span className="text-[14px] font-extrabold text-slate-800 tracking-tight block school-display">
                      SD ISLAM AL FARABY BOGOR
                    </span>
                    <span className="text-[8px] text-slate-400 block font-semibold">
                      Akreditasi A &bull; NISN: 20224419 &bull; Kantor Pamijahan 16630
                    </span>
                  </div>
                  <span className="text-[8.5px] font-mono text-emerald-800 bg-emerald-50 px-2.5 py-0.5 rounded font-extrabold border border-emerald-100">
                    REAL-TIME SYSTEM GENERATED
                  </span>
                </div>

                {/* Report Header Title */}
                <div className="text-center space-y-1">
                  <h4 className="text-xs font-bold text-slate-800 uppercase tracking-tight">
                    {getReportTitle()}
                  </h4>
                  <p className="text-[9px] text-slate-400 font-semibold italic">
                    {getReportSubTitle()}
                  </p>
                </div>

                {/* Table Sheet Preview rendering dynamically */}
                <div className="overflow-x-auto">
                  <table className="w-full border-collapse text-[9.5px] font-medium text-slate-700">
                    <thead>
                      <tr className="bg-slate-100 border-b border-slate-250 text-slate-600 font-bold">
                        {getTableHeaders().map((h, i) => (
                          <th key={i} className="p-2 border border-slate-200/80 text-left uppercase">
                            {h}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {getTableRows().map((row, rowIdx) => (
                        <tr key={rowIdx} className="hover:bg-slate-50">
                          {row.map((cell, cellIdx) => (
                            <td key={cellIdx} className="p-2 border border-slate-200/80">
                              {cell}
                            </td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* Document preview footer info */}
                <div className="pt-6 border-t border-dashed border-slate-200 flex justify-between items-center text-[8.5px] text-slate-400 font-bold">
                  <span>Dicetak otomatis via: muhamadfadli082@gmail.com</span>
                  <span>Evaluasi Keabsahan Dokumen Siswa Terjamin</span>
                </div>

              </div>

              {/* Preview Info Box */}
              <div className="bg-slate-50 border border-slate-150 p-3.5 rounded-xl text-xxs text-slate-500 mt-4 leading-normal flex items-start gap-2.5">
                <Info className="h-4.5 w-4.5 text-brand-green-700 shrink-0 mt-0.5" />
                <p>
                  <strong>Catatan Pratinjau:</strong> Data lembaran di atas diambil langsung berdasarkan sinkronisasi state database yang terintegrasi di sidebar kelas Anda. Untuk mencetak fisik, silakan tentukan format file lalu tekan tombol unduh.
                </p>
              </div>

            </div>
          </div>

        </div>
      )}

      {/* ===================== TAB 2: ORIGINAL INDIVIDUAL RAPORT TRANSCRIPT ===================== */}
      {activeTab === 'rapor' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* Left selector card list */}
          <div className="bg-white rounded-2xl border border-slate-100 shadow-xxs p-4 space-y-4">
            <h3 className="text-xs font-bold text-slate-800 school-display flex items-center gap-1.5">
              <ListFilter className="h-4.5 w-4.5 text-brand-green-700" />
              Nama Siswa ({selectedClass})
            </h3>
            
            <div className="space-y-1.5 overflow-y-auto max-h-120 pr-1">
              {filteredStudents.map(student => (
                <div
                  key={student.id}
                  onClick={() => setSelectedStudentId(student.id)}
                  className={`p-2.5 rounded-xl border transition-all flex items-center justify-between cursor-pointer text-xxs ${
                    selectedStudentId === student.id ? 'border-brand-green-500 bg-brand-green-50/40 font-bold text-brand-green-950' : 'border-slate-50 bg-white hover:bg-slate-50 text-slate-700'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <span className="h-6 w-6 rounded-full bg-slate-150 flex items-center justify-center font-mono text-[9px] font-bold text-slate-500 shrink-0">
                      {student.gender}
                    </span>
                    <div>
                      <h4 className="text-slate-850 line-clamp-1">{student.name}</h4>
                      <p className="text-[9px] text-slate-405 mt-0.5 font-semibold">NIS: {student.nis}</p>
                    </div>
                  </div>
                  <ChevronRight className="h-3.5 w-3.5 text-slate-400" />
                </div>
              ))}
            </div>
          </div>

          {/* Right visualization with charts and download mockup */}
          <div className="bg-white rounded-2xl border border-slate-100 shadow-xxs p-6 lg:col-span-2 space-y-6">
            {selectedStudent ? (
              <div className="space-y-6">
                
                {/* Profile sub header */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
                  <div>
                    <h3 className="text-sm font-bold text-slate-850 school-display">{selectedStudent.name}</h3>
                    <p className="text-xxs text-slate-450 font-semibold mt-1">
                      NISN: {selectedStudent.nisn} &bull; {selectedStudent.classroom} &bull; Target Syahadah
                    </p>
                  </div>
                  
                  <button
                    onClick={handleDownloadTranscript}
                    className="flex items-center justify-center gap-1.5 bg-brand-green-700 hover:bg-brand-green-800 text-white font-bold text-xxs px-4 py-2 rounded-xl shadow-xs transition cursor-pointer"
                  >
                    <Printer className="h-3.5 w-3.5" />
                    Cetak Fisik Rapor Santri
                  </button>
                </div>

                {/* Grid with charts */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
                  
                  {/* Radar chart - Academic balance */}
                  <div className="space-y-2">
                    <h4 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest flex items-center gap-1">
                      <BarChart3 className="h-3.5 w-3.5 text-brand-green-700" />
                      Keseimbangan Kriteria Kelulusan
                    </h4>
                    <div className="h-56 mt-2 flex items-center justify-center">
                      <ResponsiveContainer width="100%" height="100%">
                        <RadarChart cx="50%" cy="50%" outerRadius="80%" data={radarData}>
                          <PolarGrid stroke="#e2e8f0" />
                          <PolarAngleAxis dataKey="subject" stroke="#64748b" fontSize={9} />
                          <PolarRadiusAxis angle={30} domain={[60, 100]} stroke="#64748b" fontSize={9} />
                          <Radar name={selectedStudent.name} dataKey="Nilai" stroke="#10b981" fill="#10b981" fillOpacity={0.3} />
                          <Tooltip />
                        </RadarChart>
                      </ResponsiveContainer>
                    </div>
                  </div>

                  {/* Score and Shalat brief metrics */}
                  <div className="space-y-4 bg-slate-50/70 p-5 rounded-2xl border border-slate-100 text-xxs">
                    <div className="flex items-center gap-3">
                      <div className="p-2.5 rounded-xl bg-emerald-100 text-emerald-850 font-bold text-center shrink-0">
                        {selectedStudent.shalatPoin}%
                      </div>
                      <div>
                        <h4 className="text-xs font-extrabold text-slate-800">Shalat Fardhu Berjamaah</h4>
                        <p className="text-[9px] text-slate-500 mt-0.5 leading-relaxed font-medium">
                          Indeks kedisiplinan beribadah dinilai wali kelas beserta amalan sunat dhuha harian.
                        </p>
                      </div>
                    </div>

                    <div className="space-y-1.5 border-t border-dashed border-slate-200 pt-4">
                      <div className="font-extrabold text-slate-650 uppercase text-[9px]">Pencapaian Capailah Hafalan:</div>
                      <div className="font-bold text-brand-green-900 bg-white p-2.5 border border-slate-150 rounded-lg">
                        {selectedStudent.tahfidzStatus}
                      </div>
                    </div>

                    <div className="space-y-1.5">
                      <div className="font-extrabold text-slate-650 uppercase text-[9px]">Kontak Silaturahmi Orang Tua Wali:</div>
                      <div className="font-semibold text-slate-700 bg-white p-2.5 border border-slate-150 rounded-lg leading-snug">
                        {selectedStudent.parentsName} &bull; {selectedStudent.phone}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Bar Chart representing overall class subject averages */}
                <div className="pt-4 border-t border-slate-100">
                  <h4 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest flex items-center gap-1.5 mb-4">
                    <LineChart className="h-3.5 w-3.5 text-indigo-700" />
                    Bagan Rerata Capaian Pembelajaran Siswa - {selectedClass}
                  </h4>
                  <div className="h-44">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={subjectAverages} margin={{ top: 10, right: 10, left: -25, bottom: 0 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                        <XAxis dataKey="name" stroke="#94a3b8" fontSize={9} tickLine={false} />
                        <YAxis stroke="#94a3b8" fontSize={9} domain={[70, 100]} tickLine={false} />
                        <Tooltip />
                        <Bar dataKey="Rerata" fill="#6366f1" radius={[4, 4, 0, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </div>
            ) : (
              <div className="p-8 text-center text-slate-400 text-xs flex flex-col items-center justify-center h-full">
                <BookOpen className="h-10 w-10 text-slate-300 mb-2" />
                Pilih santri dari daftar sebelah kiri untuk memproses rapot digitalnya.
              </div>
            )}
          </div>
        </div>
      )}

    </div>
  );
}
