/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { BookOpen, Calendar, Plus, Search, Trash2, Printer, ShieldCheck, Heart, User, Sparkles } from 'lucide-react';
import { BukuTamu } from '../../types';

interface BukuTamuSectionProps {
  classroom: string;
  selectedDate: string;
}

export default function BukuTamuSection({
  classroom,
  selectedDate
}: BukuTamuSectionProps) {
  // Mock seeded visitor logs
  const [visitors, setVisitors] = useState<BukuTamu[]>([
    {
      id: "VT001",
      date: "2026-06-17",
      visitorName: "Drs. H. Ahmad Sobari, M.Si.",
      institution: "Direktorat Pendidikan Agama Islam Kemenag Bogor",
      purpose: "Supervisi akademik pembelajaran rumpun PAI semester genap.",
      suggestions: "Penyampaian materi Aqidah Akhlak sangat santun dan runtut. Santri kondusif, dan rpp terstruktur matang. Sangat direkomendasikan menjadi rujukan gugus.",
      contactPhone: "081234567890"
    },
    {
      id: "VT002",
      date: "2026-06-15",
      visitorName: "Ustadzah Fatimah Azzahra",
      institution: "Komite Kelas 4A (Perwakilan Wali Murid)",
      purpose: "Eksplorasi koordinasi hiasan pojok baca ramah santri.",
      suggestions: "Pojok baca sudah sangat rapi, komite siap mensuplai 15 buku komik nabi tambahan pekan depan.",
      contactPhone: "082198765432"
    },
    {
      id: "VT003",
      date: "2026-05-12",
      visitorName: "dr. Hendra Wijaya, Sp.A.",
      institution: "Puskesmas Tegallega Bogor Sektor Imunisasi",
      purpose: "Pengecekan record gizi, berat badan, serta status imunisasi campak bulanan.",
      suggestions: "Santri kelas 4A bersemangat dan berbadan sehat. Hanya 1 santri disarankan rujuk kontrol gigi berlubang rutin.",
      contactPhone: "085711223344"
    }
  ]);

  // States
  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Form inputs
  const [formName, setFormName] = useState('');
  const [formInstitution, setFormInstitution] = useState('');
  const [formPurpose, setFormPurpose] = useState('');
  const [formSuggestions, setFormSuggestions] = useState('');
  const [formPhone, setFormPhone] = useState('');

  // Filtering
  const filteredVisitors = visitors.filter(vis => {
    return vis.visitorName.toLowerCase().includes(searchTerm.toLowerCase()) || 
           vis.institution.toLowerCase().includes(searchTerm.toLowerCase()) || 
           vis.purpose.toLowerCase().includes(searchTerm.toLowerCase());
  });

  // Action Save
  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName.trim() || !formPurpose.trim()) return;

    const newItem: BukuTamu = {
      id: "VT" + Math.floor(Math.random() * 1000).toString().padStart(3, '0'),
      date: selectedDate,
      visitorName: formName,
      institution: formInstitution,
      purpose: formPurpose,
      suggestions: formSuggestions,
      contactPhone: formPhone
    };

    setVisitors(prev => [newItem, ...prev]);
    setIsModalOpen(false);
    
    // reset
    setFormName('');
    setFormInstitution('');
    setFormPurpose('');
    setFormSuggestions('');
    setFormPhone('');
  };

  // Action Delete
  const handleDelete = (id: string) => {
    if (confirm('Yakin ingin membuang rekaman data tamu digital kelas ini?')) {
      setVisitors(prev => prev.filter(item => item.id !== id));
    }
  };

  // Print function
  const handlePrint = () => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) {
      alert('Mohon aktifkan pop-up browser untuk mencetak data tamu.');
      return;
    }

    const htmlContent = `
      <html>
        <head>
          <title>Buku Catatan Tamu Kelas — ${classroom}</title>
          <style>
            body { font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; padding: 25px; line-height: 1.5; color: #1e293b; }
            h1 { font-size: 15px; margin: 0; color: #111827; }
            p { font-size: 10px; margin: 3px 0 0 0; color: #555; }
            .header-table { width: 100%; border-bottom: 2px solid #047857; padding-bottom: 15px; margin-bottom: 20px; }
            table { width:100%; border-collapse:collapse; margin-top:15px; font-size:11px; }
            th, td { border:1px solid #cbd5e1; padding:8px; text-align:left; vertical-align:top; }
            th { background-color:#f8fafc; font-weight:bold; }
          </style>
        </head>
        <body>
          <table class="header-table" border="0">
            <tr>
              <td width="70" style="border:0;">
                <div style="width:55px; height:55px; background:#065f46; color:#fbbf24; font-weight:bold; font-size:24px; line-height:55px; text-align:center; border-radius:8px;">AF</div>
              </td>
              <td style="border:0;">
                <h1>SD ISLAM AL FARABY BOGOR</h1>
                <p>Digital Guestbook — Rekaman Tamu Kunjungan Kelas Akademik Terpadu</p>
                <div style="font-size:12px; font-weight:bold; margin-top:5px; color: #047857;">Daftar Tamu Kunjungan Kelas — Kelas ${classroom}</div>
              </td>
              <td align="right" valign="bottom" style="border:0;">
                <p>Tahun Pelajaran: 2026/2027</p>
                <p>Unduh: ${new Date().toLocaleDateString('id-ID', { dateStyle: 'long' })}</p>
              </td>
            </tr>
          </table>

          <table>
            <thead>
              <tr>
                <th width="30">No</th>
                <th width="80">Tanggal Kunjungan</th>
                <th width="150">Nama Tamu & Jabatan</th>
                <th width="150">Instansi / Lembaga</th>
                <th>Tujuan & Keperluan</th>
                <th>Saran, Masukan, Kesan Kunjungan</th>
                <th width="100">Hubungan Kontak</th>
              </tr>
            </thead>
            <tbody>
              ${filteredVisitors.map((item, idx) => `
                <tr>
                  <td align="center">${idx + 1}</td>
                  <td>${item.date}</td>
                  <td><b>${item.visitorName}</b></td>
                  <td>${item.institution}</td>
                  <td>${item.purpose}</td>
                  <td><i>"${item.suggestions}"</i></td>
                  <td>${item.contactPhone || '-'}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>

          <div style="margin-top:50px; float: right; width: 220px; text-align: center; font-size: 11px;">
            <p>Bogor, ${new Date().toLocaleDateString('id-ID', { dateStyle: 'long' })}</p>
            <p style="margin-top:10px;">Mengetahui, Wali Kelas</p>
            <br/><br/><br/>
            <p><b>Ustadzah Siti Nurhaliza, S.Pd.I.</b></p>
            <p style="font-size:9px; color:#666;">NIP. 19920815 201802 2 003</p>
          </div>
          <script>
            window.onload = function() { window.print(); }
          </script>
        </body>
      </html>
    `;

    printWindow.document.write(htmlContent);
    printWindow.document.close();
  };

  return (
    <div className="space-y-6" id="buku-tamu-kelas-submodule">
      
      {/* Control panel and filters */}
      <div className="bg-white rounded-2xl p-5 border border-slate-100 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        
        {/* Visitor Search Input */}
        <div className="relative flex-1 max-w-sm block">
          <Search className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
          <input
            type="text"
            placeholder="Cari nama, instansi, atau keperluan..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="w-full text-xs pl-9 pr-4 py-2.5 bg-slate-50 border border-slate-200 focus:border-brand-green-500 rounded-xl focus:outline-none"
          />
        </div>

        {/* Actions Button */}
        <div className="flex gap-2.5">
          <button
            onClick={handlePrint}
            className="p-1 px-4 text-xxs font-extrabold text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-xl cursor-pointer transition shadow-3xs flex items-center gap-1.5"
          >
            <Printer className="h-4 w-4" />
            <span>Cetak Tamu</span>
          </button>
          
          <button
            onClick={() => setIsModalOpen(true)}
            className="flex items-center gap-1.5 bg-brand-green-700 hover:bg-brand-green-800 text-white font-extrabold text-xxs px-4 py-2.5 rounded-xl shadow-xs transition cursor-pointer"
          >
            <Plus className="h-4 w-4" />
            <span>Isi Buku Tamu</span>
          </button>
        </div>
      </div>

      {/* Guest visit cards layout */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {filteredVisitors.map(vis => (
          <div key={vis.id} className="bg-white rounded-2xl p-5 border border-slate-100 shadow-3xs hover:border-emerald-100 transition-all flex flex-col justify-between">
            <div className="space-y-4">
              
              {/* Header card meta */}
              <div className="flex items-start justify-between">
                <div className="flex gap-2 text-xxs">
                  <span className="p-2 rounded-xl bg-slate-50 text-slate-600">
                    <User className="h-4 w-4" />
                  </span>
                  <div>
                    <h4 className="font-extrabold text-slate-800 text-xs leading-normal">{vis.visitorName}</h4>
                    <span className="inline-block text-[10px] text-slate-400 font-semibold uppercase tracking-wider">{vis.institution}</span>
                  </div>
                </div>
                <span className="text-[10px] text-slate-400 font-mono flex items-center gap-1">{vis.date}</span>
              </div>

              {/* Purpose block */}
              <div className="text-xxs leading-relaxed space-y-1">
                <h5 className="font-bold text-slate-400 uppercase tracking-widest text-[9px] flex items-center gap-1">
                  <ShieldCheck className="h-3.5 w-3.5 text-emerald-600" />
                  <span>Maksud & Tujuan Kunjungan</span>
                </h5>
                <p className="text-slate-700 font-bold leading-normal">
                  {vis.purpose}
                </p>
              </div>

              {/* Suggestions bubble */}
              <div className="text-xxs leading-relaxed bg-amber-50/40 p-3 rounded-xl border border-amber-100 leading-normal italic text-slate-500">
                <b>Kesan / Saran Tamu:</b> "{vis.suggestions}"
              </div>

              {vis.contactPhone && (
                <div className="text-[9px] font-mono text-slate-400 uppercase">
                  Kontak Telepon: {vis.contactPhone}
                </div>
              )}
            </div>

            {/* Deletion row */}
            <div className="flex justify-end pt-3 border-t border-slate-100 border-dashed mt-4">
              <button
                onClick={() => handleDelete(vis.id)}
                className="text-xxs text-rose-500 hover:text-rose-700 font-bold cursor-pointer transition flex items-center gap-1"
              >
                <Trash2 className="h-3.5 w-3.5" />
                Hapus Entri
              </button>
            </div>
          </div>
        ))}

        {filteredVisitors.length === 0 && (
          <div className="bg-white rounded-2xl border border-slate-100 p-12 text-center text-slate-400 italic md:col-span-2">
            Belum ada data kunjungan tamu terekam digital di kelas saat ini.
          </div>
        )}
      </div>

      {/* VISITORS FORM DIALOG */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-3xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl w-full max-w-md shadow-xl overflow-hidden border border-slate-200 animate-in zoom-in duration-150">
            
            {/* Header */}
            <div className="bg-brand-green-900 px-6 py-4 text-white flex justify-between items-center">
              <h3 className="font-extrabold text-sm school-display">Tandatangan Buku Tamu Kelas Digital</h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-white hover:text-brand-gold-100 cursor-pointer text-sm font-semibold"
              >
                &times;
              </button>
            </div>

            {/* Form */}
            <form onSubmit={handleSave} className="p-6 space-y-4 text-xs">
              
              <div>
                <label className="block text-xxs font-bold text-slate-500 uppercase">Nama Lengkap Tamu Beserta Gelar</label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: dr. H. Ahmad Fauzi, Sp.A"
                  value={formName}
                  onChange={e => setFormName(e.target.value)}
                  className="w-full text-xs mt-1 px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:border-brand-green-600"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xxs font-bold text-slate-500 uppercase">Lembaga / Jabatan Resmi</label>
                  <input
                    type="text"
                    required
                    placeholder="Instansi / Komite"
                    value={formInstitution}
                    onChange={e => setFormInstitution(e.target.value)}
                    className="w-full text-xs mt-1 px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:border-brand-green-600"
                  />
                </div>
                <div>
                  <label className="block text-xxs font-bold text-slate-500 uppercase">Hubungan Kontak (No HP)</label>
                  <input
                    type="tel"
                    placeholder="Contoh: 0812xxxxxxxx"
                    value={formPhone}
                    onChange={e => setFormPhone(e.target.value)}
                    className="w-full text-xs mt-1 px-3 py-2 border border-slate-200 rounded-lg focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xxs font-bold text-slate-500 uppercase">Tujuan & Keperluan Kunjungan</label>
                <input
                  type="text"
                  required
                  placeholder="Misal: Monitoring pelaksanaan ANBK atau perapian pojok baca"
                  value={formPurpose}
                  onChange={e => setFormPurpose(e.target.value)}
                  className="w-full text-xs mt-1.5 px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:border-brand-green-600"
                />
              </div>

              <div>
                <label className="block text-xxs font-bold text-slate-500 uppercase">Pesan, Saran & Kesan (Feedback)</label>
                <textarea
                  rows={3}
                  required
                  placeholder="Tuliskan saran konstruktif perkembangan akademik kelas madrasah..."
                  value={formSuggestions}
                  onChange={e => setFormSuggestions(e.target.value)}
                  className="w-full text-xs mt-1.5 px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:border-brand-green-600 bg-slate-50"
                />
              </div>

              <div className="flex justify-end gap-2 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 font-semibold text-slate-500 hover:bg-slate-50 rounded"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 font-bold text-white bg-brand-green-700 hover:bg-brand-green-800 rounded shadow-xs"
                >
                  Tandatangani Buku Tamu
                </button>
              </div>

            </form>

          </div>
        </div>
      )}

    </div>
  );
}
