/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { BookOpen, Calendar, Clock, Plus, Search, Trash2, Printer, Edit2, AlertCircle, CheckCircle } from 'lucide-react';
import { JurnalMengajarModul5 } from '../../types';

interface JurnalMengajarSectionProps {
  classroom: string;
  selectedDate: string;
}

export default function JurnalMengajarSection({
  classroom,
  selectedDate
}: JurnalMengajarSectionProps) {
  // Mock seeded data with requested parameters
  const [journals, setJournals] = useState<JurnalMengajarModul5[]>([
    {
      id: "JR001",
      date: "2026-06-17",
      classroom: "Kelas 4A",
      hours: "Jam Ke-1 s.d Ke-2 (07:30 - 08:40)",
      subject: "Aqidah Akhlak",
      materi: "Menghayati Sifat-sifat Wajib Allah SWT (Wujud, Qidam, Baqa).",
      metode: "Tanya Jawab & Kooperatif Jigsaw",
      attendanceDetails: "Hadir: 21, Sakit: 1 (Fathur), Izin: 1 (Humaira), Alpa: 0",
      hambatan: "Beberapa santri kurang berkonsentrasi karena cuaca pagi yang mendung dan dingin.",
      tindakLanjut: "Memberikan ice-breaking edukatif interaktif dan penugasan poster reflektif mandiri."
    },
    {
      id: "JR002",
      date: "2026-06-17",
      classroom: "Kelas 4A",
      hours: "Jam Ke-3 s.d Ke-4 (08:40 - 10:00)",
      subject: "Bahasa Arab",
      materi: "Muthala'ah tentang bab At-Tarfiq (Fasilitas Madrasah).",
      metode: "Demonstrasi dan Drill Kartu Kosakata",
      attendanceDetails: "Hadir: 22, Sakit: 1 (Fathur), Izin: 0, Alpa: 0",
      hambatan: "Pengucapan huruf 'ain dan kha masih sering tertukar pada beberapa santri.",
      tindakLanjut: "Mengulang pelafalan (makharijul huruf) secara klasikal 10 menit sebelum pulang."
    },
    {
      id: "JR003",
      date: "2026-06-16",
      classroom: "Kelas 4A",
      hours: "Jam Ke-5 s.d Ke-6 (10:30 - 11:45)",
      subject: "Al-Qur'an Hadist",
      materi: "Tajwid: Hukum bacaan Mad Thabi'i.",
      metode: "Metode Sorogan dan Tutor Sebaya",
      attendanceDetails: "Hadir: 23, Sakit: 0, Izin: 0, Alpa: 0",
      hambatan: "Santri kesulitan membedakan mad asli dengan mad thabi'i harfiah.",
      tindakLanjut: "Diberikan kuis lembar kerja mengidentifikasi mad thabi'i dari Surah Al-Mulk."
    }
  ]);

  // States
  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);

  // Form inputs
  const [formSubject, setFormSubject] = useState('Aqidah Akhlak');
  const [formHours, setFormHours] = useState('Jam Ke-1 s.d Ke-2 (07:30 - 08:40)');
  const [formMateri, setFormMateri] = useState('');
  const [formMetode, setFormMetode] = useState('Metode Ceramah & Diskusi');
  const [formAttendance, setFormAttendance] = useState('Hadir: 23, Sakit: 0, Izin: 0, Alpa: 0');
  const [formHambatan, setFormHambatan] = useState('');
  const [formTindakLanjut, setFormTindakLanjut] = useState('');

  // Filtering
  const filteredJournals = journals.filter(jr => {
    return jr.classroom === classroom && 
           (jr.materi.toLowerCase().includes(searchTerm.toLowerCase()) || 
            jr.hambatan.toLowerCase().includes(searchTerm.toLowerCase()) || 
            jr.subject.toLowerCase().includes(searchTerm.toLowerCase()) ||
            jr.metode.toLowerCase().includes(searchTerm.toLowerCase()));
  });

  // Action Add
  const handleOpenAdd = () => {
    setEditingId(null);
    setFormSubject('Aqidah Akhlak');
    setFormHours('Jam Ke-1 s.d Ke-2 (07:30 - 08:40)');
    setFormMateri('');
    setFormMetode('Metode Ceramah & Diskusi');
    setFormAttendance('Hadir: 23, Sakit: 0, Izin: 0, Alpa: 0');
    setFormHambatan('');
    setFormTindakLanjut('');
    setIsModalOpen(true);
  };

  // Action Edit
  const handleOpenEdit = (jr: JurnalMengajarModul5) => {
    setEditingId(jr.id);
    setFormSubject(jr.subject);
    setFormHours(jr.hours);
    setFormMateri(jr.materi);
    setFormMetode(jr.metode);
    setFormAttendance(jr.attendanceDetails);
    setFormHambatan(jr.hambatan);
    setFormTindakLanjut(jr.tindakLanjut);
    setIsModalOpen(true);
  };

  // Delete
  const handleDelete = (id: string) => {
    if (confirm('Apakah Anda yakin ingin membuang records jurnal mengajar ini?')) {
      setJournals(prev => prev.filter(item => item.id !== id));
    }
  };

  // Submit Save
  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formMateri.trim()) return;

    if (editingId) {
      setJournals(prev => prev.map(item => item.id === editingId ? {
        ...item,
        subject: formSubject,
        hours: formHours,
        materi: formMateri,
        metode: formMetode,
        attendanceDetails: formAttendance,
        hambatan: formHambatan,
        tindakLanjut: formTindakLanjut
      } : item));
    } else {
      const newItem: JurnalMengajarModul5 = {
        id: "JR" + Math.floor(Math.random() * 1000).toString().padStart(3, '0'),
        date: selectedDate,
        classroom: classroom,
        subject: formSubject,
        hours: formHours,
        materi: formMateri,
        metode: formMetode,
        attendanceDetails: formAttendance,
        hambatan: formHambatan,
        tindakLanjut: formTindakLanjut
      };
      setJournals(prev => [newItem, ...prev]);
    }
    setIsModalOpen(false);
  };

  // Print function
  const handlePrint = () => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) {
      alert('Tolong izinkan pop-up cetak tab baru.');
      return;
    }

    const htmlContent = `
      <html>
        <head>
          <title>Jurnal Mengajar Harian — Kelas ${classroom}</title>
          <style>
            body { font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; padding: 25px; line-height: 1.5; color: #1e293b; }
            h1 { font-size: 15px; margin: 0; color: #111827; }
            p { font-size: 10px; margin: 3px 0 0 0; color: #555; }
            .header-table { width: 100%; border-bottom: 2px solid #047857; padding-bottom: 15px; margin-bottom: 20px; }
            table { width:100%; border-collapse:collapse; margin-top:15px; font-size:11px; }
            th, td { border:1px solid #e2e8f0; padding:8px; text-align:left; vertical-align: top; }
            th { background-color:#f1f5f9; font-weight:bold; }
          </style>
        </head>
        <body>
          <table class="header-table" border="0">
            <tr>
              <td width="70" style="border:0;">
                <div style="width:55px; height:55px; background:#065f46; color:#fbbf24; font-weight:bold; font-size:24px; line-height:55px; text-align:center; border-radius:8px;">AF</div>
              </td>
              <td style="border:0;">
                <h1>SD ISLAM AL FARABY BOGOR</h1>
                <p>Komp. Yayasan Pendidikan Islam Al Faraby Bogor &bull; Email: info@alfaraby.sch.id</p>
                <div style="font-size:12px; font-weight:bold; margin-top:5px; color: #047857;">Jurnal Mengajar Guru — Kelas ${classroom}</div>
              </td>
              <td align="right" valign="bottom" style="border:0;">
                <p>Tahun Pelajaran: 2026/2027</p>
                <p>Download: ${new Date().toLocaleDateString('id-ID', { dateStyle: 'long' })}</p>
              </td>
            </tr>
          </table>

          <table>
            <thead>
              <tr>
                <th width="30">No</th>
                <th width="80">Tgl & Jam</th>
                <th width="100">Mapel</th>
                <th>Materi Pembelajaran</th>
                <th width="100">Metode</th>
                <th width="120">Kehadiran</th>
                <th>Hambatan Santri</th>
                <th>Tindak Lanjut</th>
              </tr>
            </thead>
            <tbody>
              ${filteredJournals.map((item, idx) => `
                <tr>
                  <td align="center">${idx + 1}</td>
                  <td>${item.date}<br/><small style="color:#666;">${item.hours}</small></td>
                  <td><b>${item.subject}</b></td>
                  <td>${item.materi}</td>
                  <td>${item.metode}</td>
                  <td><small>${item.attendanceDetails}</small></td>
                  <td><i>${item.hambatan || '-'}</i></td>
                  <td><b>${item.tindakLanjut || '-'}</b></td>
                </tr>
              `).join('')}
            </tbody>
          </table>

          <div style="margin-top:50px; float: right; width: 220px; text-align: center; font-size: 11px;">
            <p>Bogor, ${new Date().toLocaleDateString('id-ID', { dateStyle: 'long' })}</p>
            <p style="margin-top:10px;">Guru Pengampu Mapel</p>
            <br/><br/><br/>
            <p><b>Ustadzah Siti Nurhaliza, S.Pd.I.</b></p>
            <p style="font-size:9px; color:#666;">NIP. 19920815 201802 2 003</p>
          </div>
          <script>
            window.onload = function() { window.print(); }
          </script>
        </body>
      </html>
    `;

    printWindow.document.write(htmlContent);
    printWindow.document.close();
  };

  return (
    <div className="space-y-6" id="jurnal-mengajar-digital-submodule">
      
      {/* Control Panel Filter & Create */}
      <div className="bg-white rounded-2xl p-5 border border-slate-100 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        
        {/* Keyword Search field */}
        <div className="relative flex-1 max-w-sm block">
          <Search className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
          <input
            type="text"
            placeholder="Cari materi, metode, atau hambatan..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="w-full text-xs pl-9 pr-4 py-2.5 bg-slate-50 border border-slate-200 focus:border-brand-green-500 rounded-xl focus:outline-none"
          />
        </div>

        {/* Action Buttons */}
        <div className="flex gap-2.5">
          <button
            onClick={handlePrint}
            className="p-1 px-4 text-xxs font-extrabold text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 hover:border-slate-300 rounded-xl cursor-pointer transition shadow-3xs flex items-center gap-1.5"
          >
            <Printer className="h-4 w-4" />
            <span>Cetak Jurnal</span>
          </button>
          
          <button
            onClick={handleOpenAdd}
            className="flex items-center gap-1.5 bg-brand-green-700 hover:bg-brand-green-800 text-white font-extrabold text-xxs px-4 py-2.5 rounded-xl shadow-xs transition cursor-pointer"
          >
            <Plus className="h-4 w-4" />
            <span>Tulis Jurnal</span>
          </button>
        </div>
      </div>

      {/* Main Journal Row Listing */}
      <div className="space-y-4">
        {filteredJournals.map(jr => (
          <div key={jr.id} className="bg-white rounded-2xl p-5 border border-slate-100 shadow-3xs hover:border-emerald-100 transition duration-150">
            <div className="flex flex-col lg:flex-row lg:items-start justify-between gap-6">
              
              {/* Left Primary Data Column */}
              <div className="space-y-3 flex-1">
                
                <div className="flex flex-wrap items-center gap-2 text-xxs">
                  <span className="text-xxs font-extrabold bg-brand-green-50 text-brand-green-800 px-2.5 py-0.5 rounded">
                    {jr.subject}
                  </span>
                  <span className="h-3 w-px bg-slate-200" />
                  <span className="text-slate-400 font-mono flex items-center gap-1 font-semibold">
                    <Calendar className="h-3.5 w-3.5 text-slate-500" />
                    {jr.date}
                  </span>
                  <span className="h-3 w-px bg-slate-200" />
                  <span className="text-emerald-800 font-mono flex items-center gap-1 font-bold">
                    <Clock className="h-3.5 w-3.5" />
                    {jr.hours}
                  </span>
                </div>

                {/* Materi and Metode */}
                <div className="space-y-1">
                  <h4 className="text-xxs font-bold text-slate-400 uppercase tracking-wider">Materi Pelajaran</h4>
                  <p className="text-xs font-bold text-slate-800">{jr.materi}</p>
                </div>

                <div className="space-y-1">
                  <h4 className="text-xxs font-bold text-slate-400 uppercase tracking-wider">Metode Pembelajaran</h4>
                  <p className="text-xxs text-slate-600 font-semibold">{jr.metode}</p>
                </div>

                {/* Attendance Summary */}
                <div className="bg-slate-50 rounded-xl p-3 border border-slate-100 flex items-center gap-3">
                  <span className="text-xxs font-extrabold text-slate-400 uppercase tracking-wider block">Kehadiran:</span>
                  <p className="text-xxs font-bold text-slate-700">{jr.attendanceDetails}</p>
                </div>
              </div>

              {/* Right Columns: Hambatan & Tindak Lanjut */}
              <div className="w-full lg:w-96 border-t lg:border-t-0 lg:border-l border-slate-100 pt-4 lg:pt-0 lg:pl-6 space-y-3.5">
                
                <div className="space-y-1.5 text-xxs">
                  <div className="text-rose-700 font-extrabold flex items-center gap-1 uppercase tracking-wider">
                    <AlertCircle className="h-3.5 w-3.5" />
                    <span>Hambatan Belajar Santri</span>
                  </div>
                  <p className="text-slate-600 italic leading-relaxed">
                    "{jr.hambatan || 'Tidak ada hambatan berarti.'}"
                  </p>
                </div>

                <div className="space-y-1.5 text-xxs">
                  <div className="text-brand-green-800 font-extrabold flex items-center gap-1 uppercase tracking-wider">
                    <CheckCircle className="h-3.5 w-3.5 text-emerald-600" />
                    <span>Rencana Tindak Lanjut</span>
                  </div>
                  <p className="text-slate-800 font-bold leading-relaxed">
                    {jr.tindakLanjut || 'Melanjutkan materi berikutnya.'}
                  </p>
                </div>

                {/* Actions column */}
                <div className="flex justify-end gap-2 pt-3 border-t border-slate-100 border-dashed">
                  <button
                    onClick={() => handleOpenEdit(jr)}
                    className="p-1 px-3 text-xxs font-bold text-emerald-700 bg-emerald-50 hover:bg-emerald-100/60 rounded cursor-pointer transition"
                  >
                    Edit
                  </button>
                  <button
                    onClick={() => handleDelete(jr.id)}
                    className="p-1 px-3 text-xxs font-bold text-rose-600 hover:bg-rose-50 rounded cursor-pointer transition"
                  >
                    Hapus
                  </button>
                </div>

              </div>

            </div>
          </div>
        ))}

        {filteredJournals.length === 0 && (
          <div className="bg-white rounded-2xl border border-slate-100 p-12 text-center text-slate-400 italic">
            Belum ada record jurnal mengajar kelas terintegrasi pada filter pencarian tersebut.
          </div>
        )}
      </div>

      {/* JOURNAL FORM MODAL DIALOG */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-3xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl w-full max-w-xl shadow-xl overflow-hidden border border-slate-200 animate-in zoom-in duration-150">
            
            {/* Modal Header */}
            <div className="bg-brand-green-900 px-6 py-4 text-white flex justify-between items-center">
              <h3 className="font-extrabold text-sm school-display">
                {editingId ? 'Edit Jurnal Pembelajaran' : 'Registrasi Jurnal Pembelajaran Guru'}
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-white hover:text-brand-gold-100 cursor-pointer text-sm font-semibold"
              >
                &times;
              </button>
            </div>

            {/* Modal fields Form */}
            <form onSubmit={handleSave} className="p-6 space-y-4 text-xs">
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xxs font-bold text-slate-500 uppercase">Mata Pelajaran</label>
                  <input
                    type="text"
                    required
                    value={formSubject}
                    onChange={e => setFormSubject(e.target.value)}
                    className="w-full text-xs mt-1 px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:border-brand-green-600"
                  />
                </div>
                <div>
                  <label className="block text-xxs font-bold text-slate-500 uppercase">Durasi / Jam Pertemuan</label>
                  <input
                    type="text"
                    required
                    value={formHours}
                    onChange={e => setFormHours(e.target.value)}
                    className="w-full text-xs mt-1 px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:border-brand-green-600"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xxs font-bold text-slate-500 uppercase">Materi Pokok Pembelajaran</label>
                <input
                  type="text"
                  required
                  placeholder="Misal: Tajwid Mad Thabi'i beserta pencarian tamsilnya di Surah juz 30"
                  value={formMateri}
                  onChange={e => setFormMateri(e.target.value)}
                  className="w-full text-xs mt-1 px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:border-brand-green-600"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xxs font-bold text-slate-500 uppercase">Metode / Model Kelas</label>
                  <input
                    type="text"
                    required
                    value={formMetode}
                    onChange={e => setFormMetode(e.target.value)}
                    className="w-full text-xs mt-1 px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:border-brand-green-600"
                  />
                </div>
                <div>
                  <label className="block text-xxs font-bold text-slate-500 uppercase">Kehadiran (Rekap Sesi)</label>
                  <input
                    type="text"
                    required
                    value={formAttendance}
                    onChange={e => setFormAttendance(e.target.value)}
                    className="w-full text-xs mt-1 px-3 py-2 border border-slate-200 rounded-lg focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xxs font-bold text-slate-500 uppercase">Hambatan / Kendala Belajar Santri</label>
                <textarea
                  rows={2}
                  placeholder="Sebutkan kendala pemahaman, keterbatasan sarana, atau santri yang butuh asisten pembimbing..."
                  value={formHambatan}
                  onChange={e => setFormHambatan(e.target.value)}
                  className="w-full text-xs mt-1 px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:border-brand-green-600"
                />
              </div>

              <div>
                <label className="block text-xxs font-bold text-slate-500 uppercase">Rencana Tindak Lanjut Guru (RTL)</label>
                <textarea
                  rows={2}
                  required
                  placeholder="Tuliskan bimbingan perbaikan, tes susulan, penugasan kreatif, atau pengayaan pekan selanjutnya..."
                  value={formTindakLanjut}
                  onChange={e => setFormTindakLanjut(e.target.value)}
                  className="w-full text-xs mt-1.5 px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:border-brand-green-600"
                />
              </div>

              <div className="flex justify-end gap-2 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 font-semibold text-slate-500 hover:bg-slate-50 rounded-lg cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 font-bold text-white bg-brand-green-700 hover:bg-brand-green-800 rounded-lg cursor-pointer"
                >
                  Daftarkan Jurnal
                </button>
              </div>

            </form>

          </div>
        </div>
      )}

    </div>
  );
}
