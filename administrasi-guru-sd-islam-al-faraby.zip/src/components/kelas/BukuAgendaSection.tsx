/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { BookOpen, Calendar, Plus, Search, Trash2, Edit3, Printer, CheckCircle, Clock } from 'lucide-react';
import { BukuAgendaMengajar } from '../../types';

interface BukuAgendaSectionProps {
  classroom: string;
  selectedDate: string;
}

export default function BukuAgendaSection({
  classroom,
  selectedDate
}: BukuAgendaSectionProps) {
  // Inital seed records
  const [agendas, setAgendas] = useState<BukuAgendaMengajar[]>([
    {
      id: "AG001",
      date: "2026-06-17",
      classroom: "Kelas 4A",
      activity: "Membaca Al-Qur'an surah Al-Baqarah ayat 1-10 beserta tafsir ringkas mengenai ketakwaan.",
      teacherName: "Ustadzah Siti Nurhaliza, S.Pd.I.",
      status: "Selesai",
      notes: "Siswa sangat antusias terutama dalam menanyakan implementasi ketakwaan di kehidupan modern."
    },
    {
      id: "AG002",
      date: "2026-06-17",
      classroom: "Kelas 4A",
      activity: "Materi Fiqh Thaharah: Praktik berwudhu yang benar dan menghafal doa sesudah wudhu.",
      teacherName: "Ustadzah Siti Nurhaliza, S.Pd.I.",
      status: "Selesai",
      notes: "3 anak perlu bimbingan khusus pada runtutan membasuh telinga."
    },
    {
      id: "AG003",
      date: "2026-06-16",
      classroom: "Kelas 4A",
      activity: "Pelajaran Sejarah Kebudayaan Islam (SKI): Kisah keteladanan Khalifah Abu Bakar Ash-Shiddiq.",
      teacherName: "Ustadzah Siti Nurhaliza, S.Pd.I.",
      status: "Selesai",
      notes: "Sudah diadakan kuis singkat di akhir sesi, kelas meraih rata-rata nilai kognitif 88."
    },
    {
      id: "AG004",
      date: "2026-06-17",
      classroom: "Kelas 4B",
      activity: "Pelajaran Bahasa Arab: Kosakata benda-benda di kelas beserta latihan percakapan sederhana.",
      teacherName: "Ustadz Hanif Al-Hafiz",
      status: "Tertunda",
      notes: "Pelajaran terpotong agenda pengukuran baju seragam, dilanjutkan pekan depan."
    }
  ]);

  // Search filter
  const [searchTerm, setSearchTerm] = useState('');
  
  // Modal states
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  
  // Form states
  const [formActivity, setFormActivity] = useState('');
  const [formTeacher, setFormTeacher] = useState('Ustadzah Siti Nurhaliza, S.Pd.I.');
  const [formStatus, setFormStatus] = useState<'Selesai' | 'Tertunda' | 'Belum Mulai'>('Selesai');
  const [formNotes, setFormNotes] = useState('');

  // Handle open add modal
  const handleOpenAdd = () => {
    setEditingId(null);
    setFormActivity('');
    setFormStatus('Selesai');
    setFormNotes('');
    setIsModalOpen(true);
  };

  // Handle open edit
  const handleOpenEdit = (ag: BukuAgendaMengajar) => {
    setEditingId(ag.id);
    setFormActivity(ag.activity);
    setFormTeacher(ag.teacherName);
    setFormStatus(ag.status);
    setFormNotes(ag.notes || '');
    setIsModalOpen(true);
  };

  // Save agenda handler
  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formActivity.trim()) return;

    if (editingId) {
      // Edit mode
      setAgendas(prev => prev.map(item => item.id === editingId ? {
        ...item,
        activity: formActivity,
        teacherName: formTeacher,
        status: formStatus,
        notes: formNotes
      } : item));
    } else {
      // Add mode
      const newItem: BukuAgendaMengajar = {
        id: "AG" + Math.floor(Math.random() * 1000).toString().padStart(3, '0'),
        date: selectedDate,
        classroom: classroom,
        activity: formActivity,
        teacherName: formTeacher,
        status: formStatus,
        notes: formNotes
      };
      setAgendas(prev => [newItem, ...prev]);
    }
    setIsModalOpen(false);
  };

  // Delete handler
  const handleDelete = (id: string) => {
    if (confirm('Apakah Anda yakin ingin menghapus catatan agenda mengajar ini?')) {
      setAgendas(prev => prev.filter(item => item.id !== id));
    }
  };

  // Filtering agenda corresponding to selected class and search
  const filteredAgendas = agendas.filter(ag => {
    const isSameClass = ag.classroom === classroom;
    const matchesSearch = ag.activity.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          (ag.notes && ag.notes.toLowerCase().includes(searchTerm.toLowerCase())) ||
                          ag.teacherName.toLowerCase().includes(searchTerm.toLowerCase());
    return isSameClass && matchesSearch;
  });

  const handlePrint = () => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) {
      alert('Tolong izinkan pop-up jendela pencetakan.');
      return;
    }

    const htmlContent = `
      <html>
        <head>
          <title>Buku Agenda Mengajar — ${classroom}</title>
          <style>
            body { font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; padding: 25px; line-height: 1.5; color: #1e293b; }
            h1 { font-size: 16px; margin: 0; color: #111827; }
            p { font-size: 11px; margin: 3px 0 0 0; color: #555; }
            .header-table { width: 100%; border-bottom: 2px solid #047857; padding-bottom: 15px; margin-bottom: 20px; }
            table { width:100%; border-collapse:collapse; margin-top:15px; font-size:11px; }
            th, td { border:1px solid #cbd5e1; padding:8px; text-align:left; }
            th { background-color:#f8fafc; font-weight:bold; }
            .badge { padding:3px 6px; border-radius:4px; font-weight:bold; font-size:9px; text-transform:uppercase; }
            .badge-selesai { background-color:#d1fae5; color:#065f46; }
            .badge-tertunda { background-color:#fef3c7; color:#92400e; }
            .badge-belum { background-color:#f3f4f6; color:#374151; }
          </style>
        </head>
        <body>
          <table class="header-table" border="0">
            <tr>
              <td width="70" style="border:0;">
                <div style="width:55px; height:55px; background:#065f46; color:#fbbf24; font-weight:bold; font-size:24px; line-height:55px; text-align:center; border-radius:8px;">AF</div>
              </td>
              <td style="border:0;">
                <h1>SD ISLAM AL FARABY BOGOR</h1>
                <p>Komp. Yayasan Pendidikan Islam Al Faraby Bogor &bull; Email: info@alfaraby.sch.id</p>
                <div style="font-size:12px; font-weight:bold; margin-top:5px; color: #047857;">Buku Agenda Mengajar Harian — Kelas ${classroom}</div>
              </td>
              <td align="right" valign="bottom" style="border:0;">
                <p>Tahun Pelajaran: 2026/2027</p>
                <p>Tgl Unduh: ${new Date().toLocaleDateString('id-ID', { dateStyle: 'long' })}</p>
              </td>
            </tr>
          </table>

          <table>
            <thead>
              <tr>
                <th width="30">No</th>
                <th width="80">Tanggal</th>
                <th>Aktivitas Utama Pembelajaran</th>
                <th width="150">Pendidik Penanggung Jawab</th>
                <th width="80">Status</th>
                <th>Catatan Reflektif</th>
              </tr>
            </thead>
            <tbody>
              ${filteredAgendas.map((item, idx) => `
                <tr>
                  <td>${idx + 1}</td>
                  <td>${item.date}</td>
                  <td><b>${item.activity}</b></td>
                  <td>${item.teacherName}</td>
                  <td>
                    <span class="badge ${
                      item.status === 'Selesai' ? 'badge-selesai' : item.status === 'Tertunda' ? 'badge-tertunda' : 'badge-belum'
                    }">${item.status}</span>
                  </td>
                  <td>${item.notes || '-'}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>

          <div style="margin-top:50px; float: right; width: 220px; text-align: center; font-size: 11px;">
            <p>Bogor, ${new Date().toLocaleDateString('id-ID', { dateStyle: 'long' })}</p>
            <p style="margin-top:10px;">Wali Kelas / Guru Pendidik</p>
            <br/><br/><br/>
            <p><b>Ustadzah Siti Nurhaliza, S.Pd.I.</b></p>
            <p style="font-size:9px; color:#666;">NIP. 19920815 201802 2 003</p>
          </div>
          <script>
            window.onload = function() { window.print(); }
          </script>
        </body>
      </html>
    `;

    printWindow.document.write(htmlContent);
    printWindow.document.close();
  };

  return (
    <div className="space-y-6" id="agenda-pembelajaran-submodule">
      
      {/* Control panel & filters */}
      <div className="bg-white rounded-2xl p-5 border border-slate-100 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        
        {/* Search Input bar */}
        <div className="relative flex-1 max-w-sm block">
          <Search className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
          <input
            type="text"
            placeholder="Cari aktivitas atau evaluasi..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="w-full text-xs pl-9 pr-4 py-2.5 bg-slate-50 border border-slate-200 focus:border-brand-green-500 rounded-xl focus:outline-none focus:ring-0"
          />
        </div>

        {/* Action button triggers */}
        <div className="flex gap-2.5">
          <button
            onClick={handlePrint}
            className="p-1 px-4 text-xxs font-extrabold text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 hover:border-slate-300 rounded-xl cursor-pointer transition shadow-3xs flex items-center gap-1.5"
          >
            <Printer className="h-4 w-4" />
            <span>Cetak Agenda</span>
          </button>
          
          <button
            onClick={handleOpenAdd}
            className="flex items-center gap-1.5 bg-brand-green-700 hover:bg-brand-green-800 text-white font-extrabold text-xxs px-4 py-2.5 rounded-xl shadow-xs transition cursor-pointer"
          >
            <Plus className="h-4 w-4" />
            <span>Registrasi Agenda</span>
          </button>
        </div>
      </div>

      {/* Main Agenda Grid List */}
      <div className="space-y-4">
        {filteredAgendas.map(ag => (
          <div key={ag.id} className="bg-white rounded-2xl p-5 border border-slate-100 shadow-3xs flex flex-col md:flex-row md:items-start justify-between gap-4 transition-all hover:border-emerald-100">
            <div className="space-y-3 flex-1">
              <div className="flex items-center gap-2 text-xxs">
                <span className={`px-2.5 py-0.5 rounded-full font-bold text-[9px] uppercase flex items-center gap-1 ${
                  ag.status === 'Selesai'
                    ? 'bg-emerald-50 text-emerald-800'
                    : ag.status === 'Tertunda'
                    ? 'bg-amber-50 text-amber-800'
                    : 'bg-slate-100 text-slate-600'
                }`}>
                  {ag.status === 'Selesai' ? (
                    <span className="h-1.5 w-1.5 bg-emerald-600 rounded-full inline-block" />
                  ) : (
                    <span className="h-1.5 w-1.5 bg-amber-600 rounded-full inline-block" />
                  )}
                  {ag.status}
                </span>
                <span className="h-3 w-px bg-slate-200" />
                <span className="text-slate-400 font-mono flex items-center gap-1">
                  <Calendar className="h-3 w-3" />
                  {ag.date}
                </span>
                <span className="h-3 w-px bg-slate-200" />
                <span className="text-slate-500 font-semibold uppercase tracking-wider">
                  PJ: {ag.teacherName.split(',')[0]}
                </span>
              </div>

              {/* Main activity summary */}
              <p className="text-xs font-bold text-slate-800 leading-relaxed">
                {ag.activity}
              </p>

              {/* Evaluation note if exists */}
              {ag.notes && (
                <div className="bg-slate-50 border-l-2 border-slate-200 rounded-r-lg p-3 text-xxs text-slate-500 italic leading-relaxed">
                  <b>Refleksi Guru:</b> "{ag.notes}"
                </div>
              )}
            </div>

            {/* Quick Actions column */}
            <div className="flex md:flex-col items-center justify-end gap-2 shrink-0 pt-3 md:pt-0 border-t md:border-t-0 md:border-l border-slate-100 md:pl-5">
              <button
                onClick={() => handleOpenEdit(ag)}
                className="p-1 px-3 text-xxs font-bold text-emerald-700 bg-emerald-50 hover:bg-emerald-100/60 rounded-md cursor-pointer transition"
              >
                Ubah
              </button>
              <button
                onClick={() => handleDelete(ag.id)}
                className="p-1 px-3 text-xxs font-bold text-rose-600 hover:bg-rose-50 rounded-md cursor-pointer transition"
              >
                Hapus
              </button>
            </div>
          </div>
        ))}

        {filteredAgendas.length === 0 && (
          <div className="bg-white rounded-2xl border border-slate-100 p-12 text-center text-slate-400 italic">
            Belum ada data agenda mengajar tersusun untuk kelas ini pada filter saat ini.
          </div>
        )}
      </div>

      {/* CREATE / EDIT AGENDA DIALOG OVERLAY */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-3xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl w-full max-w-lg shadow-xl overflow-hidden border border-slate-200 animate-in zoom-in duration-150">
            
            {/* Modal Header */}
            <div className="bg-brand-green-900 px-6 py-4 text-white flex justify-between items-center">
              <h3 className="font-extrabold text-sm school-display">
                {editingId ? 'Suntik Agenda Mengajar' : 'Catat Agenda Mengajar Harian'}
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-white hover:text-brand-gold-100 cursor-pointer text-sm font-semibold"
              >
                &times;
              </button>
            </div>

            {/* Modal form */}
            <form onSubmit={handleSave} className="p-6 space-y-4 text-xs">
              
              {/* Field 1: Activity Description */}
              <div>
                <label className="block text-xxs font-bold text-slate-500 uppercase tracking-wider">Aktivitas Utama & Langkah Pembelajaran</label>
                <textarea
                  required
                  rows={4}
                  placeholder="Misal: Membaca surah pendek tahfidz dilanjutkan praktik ibadah rukun shalat jam ke-1 s.d ke-2..."
                  value={formActivity}
                  onChange={e => setFormActivity(e.target.value)}
                  className="w-full text-xs mt-1.5 px-3.5 py-2 border border-slate-200 rounded-xl focus:border-brand-green-600 focus:outline-none focus:ring-0 leading-relaxed bg-slate-50"
                />
              </div>

              {/* Field 2: PJ Teacher & Status */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xxs font-bold text-slate-500 uppercase tracking-wider">Guru Pengampu</label>
                  <input
                    type="text"
                    required
                    value={formTeacher}
                    onChange={e => setFormTeacher(e.target.value)}
                    className="w-full text-xs mt-1.5 px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:border-brand-green-600"
                  />
                </div>
                <div>
                  <label className="block text-xxs font-bold text-slate-500 uppercase tracking-wider">Status Penyelesaian</label>
                  <select
                    value={formStatus}
                    onChange={e => setFormStatus(e.target.value as any)}
                    className="w-full text-xs mt-1.5 px-3 py-2 border border-slate-200 rounded-lg focus:outline-none bg-white font-semibold text-slate-700"
                  >
                    <option value="Selesai">Selesai</option>
                    <option value="Tertunda">Tertunda</option>
                    <option value="Belum Mulai">Belum Mulai</option>
                  </select>
                </div>
              </div>

              {/* Field 3: Reflection / notes */}
              <div>
                <label className="block text-xxs font-bold text-slate-500 uppercase tracking-wider">Catatan Refleksi / Hambatan Khusus (Opsional)</label>
                <input
                  type="text"
                  placeholder="Misal: Siswa kondusif, 2 orang izin tidak mengikuti praktik karena demam."
                  value={formNotes}
                  onChange={e => setFormNotes(e.target.value)}
                  className="w-full text-xs mt-1.5 px-3 py-2 border border-slate-200 rounded-lg focus:outline-none bg-slate-50 focus:border-brand-green-600"
                />
              </div>

              {/* Submission actions */}
              <div className="flex items-center justify-end gap-2 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 font-semibold text-slate-500 hover:bg-slate-50 rounded-lg cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 font-bold text-white bg-brand-green-700 hover:bg-brand-green-800 rounded-lg cursor-pointer shadow-xs"
                >
                  {editingId ? 'Simpan Pembaruan' : 'Registrasikan Agenda'}
                </button>
              </div>

            </form>

          </div>
        </div>
      )}

    </div>
  );
}
