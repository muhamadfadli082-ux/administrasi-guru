/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Package, Plus, Search, Trash2, Edit3, Printer, ShieldCheck, AlertTriangle } from 'lucide-react';
import { InventarisBarang } from '../../types';

interface InventarisKelasSectionProps {
  classroom: string;
}

export default function InventarisKelasSection({
  classroom
}: InventarisKelasSectionProps) {
  // Initial seed classroom items with realistic codes & sources
  const [items, setItems] = useState<InventarisBarang[]>([
    {
      id: "INV001",
      itemName: "Meja Guru Kayu Jati",
      itemCode: "INV/AF-4A/MJ-01",
      quantity: 1,
      condition: "Baik",
      source: "Yayasan Pendidikan Islam Al Faraby",
      classroom: "Kelas 4A"
    },
    {
      id: "INV002",
      itemName: "Kursi Guru Busa Sandaran",
      itemCode: "INV/AF-4A/KS-01",
      quantity: 1,
      condition: "Baik",
      source: "Yayasan Pendidikan Islam Al Faraby",
      classroom: "Kelas 4A"
    },
    {
      id: "INV003",
      itemName: "Meja Belajar Santri Ganda",
      itemCode: "INV/AF-4A/MJS-12",
      quantity: 12,
      condition: "Baik",
      source: "Dana Alokasi BOS Reguler Kelompok IV",
      classroom: "Kelas 4A"
    },
    {
      id: "INV004",
      itemName: "Kursi Belajar Kayu Santri",
      itemCode: "INV/AF-4A/KSS-24",
      quantity: 24,
      condition: "Rusak Ringan",
      source: "Dana Alokasi BOS Reguler Kelompok IV",
      classroom: "Kelas 4A"
    },
    {
      id: "INV005",
      itemName: "Lemari Buku & Arsip Kelas Alumunium",
      itemCode: "INV/AF-4A/LM-01",
      quantity: 1,
      condition: "Baik",
      source: "Wakaf/Infaq Wali Murid Angkatan 2024",
      classroom: "Kelas 4A"
    },
    {
      id: "INV006",
      itemName: "Kipas Angin Dinding Cosmos 16 Inch",
      itemCode: "INV/AF-4A/KP-02",
      quantity: 2,
      condition: "Rusak Berat",
      source: "Infaq Komite Kelas 4A",
      classroom: "Kelas 4A"
    }
  ]);

  // States
  const [searchTerm, setSearchTerm] = useState('');
  const [conditionFilter, setConditionFilter] = useState<'all' | 'Baik' | 'Rusak Ringan' | 'Rusak Berat'>('all');
  
  // Modal states
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);

  // Form states
  const [formName, setFormName] = useState('');
  const [formCode, setFormCode] = useState('');
  const [formQty, setFormQty] = useState(1);
  const [formCondition, setFormCondition] = useState<'Baik' | 'Rusak Ringan' | 'Rusak Berat'>('Baik');
  const [formSource, setFormSource] = useState('Dana Alokasi BOS');

  // Filtering items by classroom & user filter
  const filteredItems = items.filter(it => {
    const isClassroom = it.classroom === classroom;
    const matchesSearch = it.itemName.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          it.itemCode.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCondition = conditionFilter === 'all' || it.condition === conditionFilter;
    
    return isClassroom && matchesSearch && matchesCondition;
  });

  // Calculate statistics
  const totalQty = filteredItems.reduce((acc, it) => acc + it.quantity, 0);
  const countBaik = filteredItems.filter(it => it.condition === 'Baik').reduce((acc, it) => acc + it.quantity, 0);
  const countRusakRingan = filteredItems.filter(it => it.condition === 'Rusak Ringan').reduce((acc, it) => acc + it.quantity, 0);
  const countRusakBerat = filteredItems.filter(it => it.condition === 'Rusak Berat').reduce((acc, it) => acc + it.quantity, 0);

  // Action Save
  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName.trim() || !formCode.trim()) return;

    if (editingId) {
      setItems(prev => prev.map(item => item.id === editingId ? {
        ...item,
        itemName: formName,
        itemCode: formCode,
        quantity: Number(formQty),
        condition: formCondition,
        source: formSource
      } : item));
    } else {
      const newItem: InventarisBarang = {
        id: "INV" + Math.floor(Math.random() * 1000).toString().padStart(3, '0'),
        itemName: formName,
        itemCode: formCode,
        quantity: Number(formQty),
        condition: formCondition,
        source: formSource,
        classroom: classroom
      };
      setItems(prev => [...prev, newItem]);
    }
    setIsModalOpen(false);
  };

  // Action Add
  const handleOpenAdd = () => {
    setEditingId(null);
    setFormName('');
    // Automatically suggest code format based on class
    const cleanClass = classroom.replace(' ', '-').toUpperCase();
    setFormCode(`INV/AF-${cleanClass}/`);
    setFormQty(1);
    setFormCondition('Baik');
    setFormSource('Dana Alokasi BOS');
    setIsModalOpen(true);
  };

  // Action Edit
  const handleOpenEdit = (it: InventarisBarang) => {
    setEditingId(it.id);
    setFormName(it.itemName);
    setFormCode(it.itemCode);
    setFormQty(it.quantity);
    setFormCondition(it.condition);
    setFormSource(it.source);
    setIsModalOpen(true);
  };

  // Action Delete
  const handleDelete = (id: string) => {
    if (confirm('Yakin ingin mencoret barang dari inventaris kelas ini?')) {
      setItems(prev => prev.filter(item => item.id !== id));
    }
  };

  // Print function
  const handlePrint = () => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) {
      alert('Tolong izinkan popup browser untuk mengunduh cetak berkas.');
      return;
    }

    const htmlContent = `
      <html>
        <head>
          <title>Daftar Inventaris Kelas — ${classroom}</title>
          <style>
            body { font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; padding: 25px; line-height: 1.5; color: #1e293b; }
            h1 { font-size: 15px; margin: 0; color: #111827; }
            p { font-size: 10px; margin: 3px 0 0 0; color: #555; }
            .header-table { width: 100%; border-bottom: 2px solid #047857; padding-bottom: 15px; margin-bottom: 20px; }
            table { width:100%; border-collapse:collapse; margin-top:15px; font-size:11px; }
            th, td { border:1px solid #cbd5e1; padding:8px; text-align:left; }
            th { background-color:#f8fafc; font-weight:bold; }
            .right { text-align:right; }
            .center { text-align:center; }
          </style>
        </head>
        <body>
          <table class="header-table" border="0">
            <tr>
              <td width="70" style="border:0;">
                <div style="width:55px; height:55px; background:#065f46; color:#fbbf24; font-weight:bold; font-size:24px; line-height:55px; text-align:center; border-radius:8px;">AF</div>
              </td>
              <td style="border:0;">
                <h1>SD ISLAM AL FARABY BOGOR</h1>
                <p>Komp. Yayasan Pendidikan Islam Al Faraby Bogor &bull; Email: info@alfaraby.sch.id</p>
                <div style="font-size:12px; font-weight:bold; margin-top:5px; color: #047857;">Laporan Mutasi & Inventaris Kelas Sipil — ${classroom}</div>
              </td>
              <td align="right" valign="bottom" style="border:0;">
                <p>Tahun Pelajaran: 2026/2027</p>
                <p>Tanggal Audit: ${new Date().toLocaleDateString('id-ID', { dateStyle: 'long' })}</p>
              </td>
            </tr>
          </table>

          <table>
            <thead>
              <tr>
                <th width="30">No</th>
                <th width="120">Kode Inventaris Barang</th>
                <th>Nama Klasifikasi Barang</th>
                <th width="40" class="center">Jml</th>
                <th width="100">Kondisi Asset</th>
                <th>Sumber Dana / Pengadaan</th>
              </tr>
            </thead>
            <tbody>
              ${filteredItems.map((item, idx) => `
                <tr>
                  <td class="center">${idx + 1}</td>
                  <td><b>${item.itemCode}</b></td>
                  <td>${item.itemName}</td>
                  <td class="center"><b>${item.quantity}</b> Unit</td>
                  <td>${item.condition}</td>
                  <td>${item.source}</td>
                </tr>
              `).join('')}
              <tr style="background-color:#f8fafc; font-weight:bold;">
                <td colspan="3" class="right">Total Volume Barang Terdaftar:</td>
                <td class="center">${totalQty} Unit</td>
                <td colspan="2">* Baik (${countBaik}), R.Ringan (${countRusakRingan}), R.Berat (${countRusakBerat})</td>
              </tr>
            </tbody>
          </table>

          <div style="margin-top:50px; float: right; width: 220px; text-align: center; font-size: 11px;">
            <p>Bogor, ${new Date().toLocaleDateString('id-ID', { dateStyle: 'long' })}</p>
            <p style="margin-top:10px;">Penanggungjawab Inventaris Kelas</p>
            <br/><br/><br/>
            <p><b>Ustadzah Siti Nurhaliza, S.Pd.I.</b></p>
            <p style="font-size:9px; color:#666;">Wali Kelas / NIP. 19920815 201802 2 003</p>
          </div>
          <script>
            window.onload = function() { window.print(); }
          </script>
        </body>
      </html>
    `;

    printWindow.document.write(htmlContent);
    printWindow.document.close();
  };

  return (
    <div className="space-y-6" id="inventaris-kelas-submodule">
      
      {/* Visual Statistics panel */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 text-center">
        <div className="bg-white rounded-2xl p-4 border border-slate-100 shadow-3xs">
          <span className="text-slate-400 block uppercase font-bold text-xxxxs tracking-wider">Total Volume Barang</span>
          <span className="text-base font-extrabold text-slate-800 focus:outline-none mt-1.5 block">{totalQty} Unit</span>
        </div>
        <div className="bg-white rounded-2xl p-4 border border-slate-100 shadow-3xs">
          <span className="text-emerald-700 block uppercase font-bold text-xxxxs tracking-wider">Kondisi Baik</span>
          <span className="text-base font-extrabold text-emerald-800 mt-1.5 block">{countBaik} Unit</span>
        </div>
        <div className="bg-white rounded-2xl p-4 border border-slate-100 shadow-3xs">
          <span className="text-amber-600 block uppercase font-bold text-xxxxs tracking-wider">Rusak Ringan</span>
          <span className="text-base font-extrabold text-amber-700 mt-1.5 block">{countRusakRingan} Unit</span>
        </div>
        <div className="bg-white rounded-2xl p-4 border border-slate-100 shadow-3xs">
          <span className="text-rose-600 block uppercase font-bold text-xxxxs tracking-wider">Rusak Berat</span>
          <span className="text-base font-extrabold text-rose-700 mt-1.5 block">{countRusakBerat} Unit</span>
        </div>
      </div>

      {/* Control panel, filters and search */}
      <div className="bg-white rounded-2xl p-5 border border-slate-100 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        
        {/* Left components */}
        <div className="flex-1 flex flex-col sm:flex-row gap-3">
          
          {/* Keyword search field */}
          <div className="relative flex-1 max-w-xs block">
            <Search className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
            <input
              type="text"
              placeholder="Cari barang atau kode barang..."
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              className="w-full text-xs pl-9 pr-4 py-2.5 bg-slate-50 border border-slate-200 focus:border-brand-green-500 rounded-xl focus:outline-none"
            />
          </div>

          {/* Saring Filter category */}
          <select
            value={conditionFilter}
            onChange={e => setConditionFilter(e.target.value as any)}
            className="text-xs px-3 py-2 border border-slate-200 rounded-xl bg-white font-semibold text-slate-600 focus:outline-none cursor-pointer"
          >
            <option value="all">Kondisi Barang (Semua)</option>
            <option value="Baik">Kondisi Baik</option>
            <option value="Rusak Ringan">Rusak Ringan</option>
            <option value="Rusak Berat">Rusak Berat</option>
          </select>

        </div>

        {/* Right buttons action tools */}
        <div className="flex gap-2.5">
          <button
            onClick={handlePrint}
            className="p-1 px-4 text-xxs font-extrabold text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-xl cursor-pointer transition shadow-3xs flex items-center gap-1.5"
          >
            <Printer className="h-4 w-4" />
            <span>Cetak Inventaris</span>
          </button>
          <button
            onClick={handleOpenAdd}
            className="flex items-center gap-1.5 bg-brand-green-700 hover:bg-brand-green-800 text-white font-extrabold text-xxs px-4 py-2.5 rounded-xl shadow-xs transition cursor-pointer"
          >
            <Plus className="h-4 w-4" />
            <span>Tambah Barang</span>
          </button>
        </div>

      </div>

      {/* Grid listing Inventaris */}
      <div className="bg-white rounded-2xl border border-slate-100 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-slate-100 bg-slate-50/50 text-slate-400 font-extrabold uppercase tracking-wider text-xxxxs">
                <th className="p-4 w-[25%] font-mono">Kode Inventory</th>
                <th className="p-4 w-[30%]">Nama Barang Klasifikasi</th>
                <th className="p-4 text-center">Jumlah Vol</th>
                <th className="p-4 text-center">Kondisi Barang</th>
                <th className="p-4">Sumber / Asal Pengadaan</th>
                <th className="p-4 text-center">Aksi Operasi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700 font-semibold text-xxs">
              {filteredItems.map(item => (
                <tr key={item.id} className="hover:bg-slate-50/20">
                  <td className="p-4 font-mono font-extrabold text-emerald-800">{item.itemCode}</td>
                  <td className="p-4 text-xs font-bold text-slate-800">{item.itemName}</td>
                  <td className="p-4 text-center text-xs font-bold text-slate-800">{item.quantity} Unit</td>
                  <td className="p-4 text-center">
                    <span className={`px-2.5 py-1 rounded-full text-[9px] font-extrabold inline-block text-center ${
                      item.condition === 'Baik' 
                        ? 'bg-emerald-100 text-emerald-800' 
                        : item.condition === 'Rusak Ringan'
                        ? 'bg-amber-100 text-amber-800'
                        : 'bg-rose-100 text-rose-800'
                    }`}>
                      {item.condition}
                    </span>
                  </td>
                  <td className="p-4 text-slate-500 italic font-medium">{item.source}</td>
                  <td className="p-4 text-center">
                    <div className="flex gap-2 justify-center">
                      <button
                        onClick={() => handleOpenEdit(item)}
                        className="p-1 px-[9px] text-[10px] font-bold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 rounded cursor-pointer transition"
                      >
                        Sunting
                      </button>
                      <button
                        onClick={() => handleDelete(item.id)}
                        className="p-1 px-[9px] text-[10px] font-bold text-rose-600 hover:bg-rose-50 rounded cursor-pointer transition"
                      >
                        Coret
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          {filteredItems.length === 0 && (
            <div className="p-12 text-center text-slate-400 italic">
              Tidak ada data barang terdaftar dalam inventaris kelas pada filter saat ini.
            </div>
          )}
        </div>
      </div>

      {/* DIALOG BOX FORM */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-3xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl w-full max-w-md shadow-xl overflow-hidden border border-slate-200 animate-in zoom-in duration-150">
            
            {/* Header */}
            <div className="bg-brand-green-900 px-6 py-4 text-white flex justify-between items-center">
              <h3 className="font-extrabold text-sm school-display">
                {editingId ? 'Edit Sifat Asset Inventaris' : 'Tambah Inventaris Barang Kelas'}
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-white hover:text-brand-gold-100 cursor-pointer text-sm font-semibold"
              >
                &times;
              </button>
            </div>

            {/* Form */}
            <form onSubmit={handleSave} className="p-6 space-y-4 text-xs">
              
              <div>
                <label className="block text-xxs font-bold text-slate-500 uppercase">Nama Barang</label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: Proyektor Epson EB-X400"
                  value={formName}
                  onChange={e => setFormName(e.target.value)}
                  className="w-full text-xs mt-1.5 px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:border-brand-green-600 bg-slate-50"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xxs font-bold text-slate-500 uppercase">Kode Inventaris Barang</label>
                  <input
                    type="text"
                    required
                    placeholder="INV/AF-4A/..."
                    value={formCode}
                    onChange={e => setFormCode(e.target.value)}
                    className="w-full text-xs mt-1.5 px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:border-brand-green-600 font-mono font-bold"
                  />
                </div>
                <div>
                  <label className="block text-xxs font-bold text-slate-500 uppercase">Volume Jumlah (Unit)</label>
                  <input
                    type="number"
                    min={1}
                    required
                    value={formQty}
                    onChange={e => setFormQty(Number(e.target.value))}
                    className="w-full text-xs mt-1.5 px-3 py-2 border border-slate-200 rounded-lg focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xxs font-bold text-slate-500 uppercase">Kondisi Asset</label>
                  <select
                    value={formCondition}
                    onChange={e => setFormCondition(e.target.value as any)}
                    className="w-full text-xs mt-1.5 px-3 py-2 border border-slate-200 bg-white rounded-lg focus:outline-none font-semibold text-slate-750"
                  >
                    <option value="Baik">Kondisi Baik</option>
                    <option value="Rusak Ringan">Rusak Ringan</option>
                    <option value="Rusak Berat">Rusak Berat</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xxs font-bold text-slate-500 uppercase">Sumber / Asal Pengadaan</label>
                  <input
                    type="text"
                    required
                    placeholder="Contoh: BOS, Komite Kelas, Yayasan"
                    value={formSource}
                    onChange={e => setFormSource(e.target.value)}
                    className="w-full text-xs mt-1.5 px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:border-brand-green-600"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 font-semibold text-slate-500 hover:bg-slate-50 rounded"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 font-bold text-white bg-brand-green-700 hover:bg-brand-green-800 rounded shadow-xs"
                >
                  {editingId ? 'Simpan Perubahan' : 'Catat Inventaris'}
                </button>
              </div>

            </form>

          </div>
        </div>
      )}

    </div>
  );
}
