/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { User, ShieldAlert, Award, MessageSquare, Plus, Search, Trash2, Printer, Edit2, TrendingUp, Compass } from 'lucide-react';
import { Student, CatatanPerkembangan } from '../../types';

interface CatatanPerkembanganSectionProps {
  students: Student[];
  classroom: string;
  selectedDate: string;
}

export default function CatatanPerkembanganSection({
  students,
  classroom,
  selectedDate
}: CatatanPerkembanganSectionProps) {
  const classStudents = students.filter(s => s.classroom === classroom);

  // Initial seed logs for development
  const [logs, setLogs] = useState<CatatanPerkembangan[]>([
    {
      id: "LOG01",
      studentId: classStudents[0]?.id || "stu1",
      studentName: classStudents[0]?.name || "Zaidan Al-Ghifari",
      classroom: classroom,
      date: "2026-06-17",
      aspect: "Akademik",
      category: "Prestasi",
      notes: "Menunjukkan pemahaman luar biasa dalam konsep pembagian bilangan besar serta mampu memandu kawan sejawat di kelompok belajarnya.",
      actionTaken: "Diberikan predikat bintang prestasi matematika harian serta diajukan sebagai tutor sebaya kelas."
    },
    {
      id: "LOG02",
      studentId: classStudents[2]?.id || "stu2",
      studentName: classStudents[2]?.name || "Fatima Az-Zahra",
      classroom: classroom,
      date: "2026-06-17",
      aspect: "Perilaku",
      category: "Sikap Spiritual",
      notes: "Sangat antusias mendirikan shalat sunnah Dhuha berjamah serta dengan tulus merapikan mukena di mushala tanpa diminta.",
      actionTaken: "Apresiasi verbal di forum kelas untuk meningkatkan keteladanan akhlak (uswah hasanah)."
    },
    {
      id: "LOG03",
      studentId: classStudents[1]?.id || "stu3",
      studentName: classStudents[1]?.name || "Ahmad Rifai",
      classroom: classroom,
      date: "2026-06-16",
      aspect: "Akademik",
      category: "Kesulitan Belajar",
      notes: "Mengalami kesulitan memfokuskan atensi saat pembelajaran menulis arab gundul, sering mencoret-coret lembaran kosong.",
      actionTaken: "Berkonsultasi dengan orang tua via WhatsApp untuk pembimbingan menulis bersama di rumah secara santai."
    }
  ]);

  // States
  const [searchTerm, setSearchTerm] = useState('');
  const [studentFilter, setStudentFilter] = useState('all');
  const [aspectFilter, setAspectFilter] = useState<'all' | 'Akademik' | 'Perilaku'>('all');
  
  // Modal states
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);

  // Form states
  const [formStudentId, setFormStudentId] = useState(classStudents[0]?.id || '');
  const [formAspect, setFormAspect] = useState<'Akademik' | 'Perilaku'>('Akademik');
  const [formCategory, setFormCategory] = useState('Prestasi');
  const [formNotes, setFormNotes] = useState('');
  const [formAction, setFormAction] = useState('');

  // Save handler
  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formNotes.trim()) return;

    const targetStudent = classStudents.find(s => s.id === formStudentId);
    if (!targetStudent) return;

    if (editingId) {
      setLogs(prev => prev.map(item => item.id === editingId ? {
        ...item,
        studentId: formStudentId,
        studentName: targetStudent.name,
        aspect: formAspect,
        category: formCategory,
        notes: formNotes,
        actionTaken: formAction
      } : item));
    } else {
      const newItem: CatatanPerkembangan = {
        id: "LOG" + Math.floor(Math.random() * 1000).toString().padStart(3, '0'),
        studentId: formStudentId,
        studentName: targetStudent.name,
        classroom: classroom,
        date: selectedDate,
        aspect: formAspect,
        category: formCategory,
        notes: formNotes,
        actionTaken: formAction
      };
      setLogs(prev => [newItem, ...prev]);
    }
    setIsModalOpen(false);
  };

  // Open add Modal
  const handleOpenAdd = () => {
    setEditingId(null);
    if (classStudents.length > 0) {
      setFormStudentId(classStudents[0].id);
    }
    setFormAspect('Akademik');
    setFormCategory('Prestasi');
    setFormNotes('');
    setFormAction('');
    setIsModalOpen(true);
  };

  // Open edit Modal
  const handleOpenEdit = (log: CatatanPerkembangan) => {
    setEditingId(log.id);
    setFormStudentId(log.studentId);
    setFormAspect(log.aspect);
    setFormCategory(log.category);
    setFormNotes(log.notes);
    setFormAction(log.actionTaken);
    setIsModalOpen(true);
  };

  // Delete log
  const handleDelete = (id: string) => {
    if (confirm('Yakin ingin membuang catatan perkembangan santri ini?')) {
      setLogs(prev => prev.filter(item => item.id !== id));
    }
  };

  // Filter logs logic
  const filteredLogs = logs.filter(log => {
    const isClassroom = log.classroom === classroom;
    const matchesSearch = log.studentName.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          log.notes.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStudent = studentFilter === 'all' || log.studentId === studentFilter;
    const matchesAspect = aspectFilter === 'all' || log.aspect === aspectFilter;
    
    return isClassroom && matchesSearch && matchesStudent && matchesAspect;
  });

  const handlePrint = () => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) {
      alert('Mohon izinkan popup tab cetak.');
      return;
    }

    const htmlContent = `
      <html>
        <head>
          <title>Laporan Perkembangan Santri — ${classroom}</title>
          <style>
            body { font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; padding: 25px; line-height: 1.5; color: #1e293b; }
            h1 { font-size: 15px; margin: 0; color: #111827; }
            p { font-size: 10px; margin: 3px 0 0 0; color: #555; }
            .header-table { width: 100%; border-bottom: 2px solid #047857; padding-bottom: 15px; margin-bottom: 20px; }
            .card { border: 1px solid #e2e8f0; border-radius: 8px; padding: 15px; margin-bottom: 15px; page-break-inside: avoid; }
            .meta { font-size: 10px; color:#64748b; font-weight:bold; text-transform:uppercase; margin-bottom:8px; }
            .student-name { font-size: 13px; font-weight: bold; color: #0f172a; margin-top:2px; }
            .desc { font-size: 11px; margin-top: 5px; color: #475569; }
            .act { font-size: 11px; margin-top: 5px; color: #047857; font-weight: bold; }
          </style>
        </head>
        <body>
          <table class="header-table" border="0">
            <tr>
              <td width="70" style="border:0;">
                <div style="width:55px; height:55px; background:#065f46; color:#fbbf24; font-weight:bold; font-size:24px; line-height:55px; text-align:center; border-radius:8px;">AF</div>
              </td>
              <td style="border:0;">
                <h1>SD ISLAM AL FARABY BOGOR</h1>
                <p>Arsip Laporan Konseling & Perkembangan Santri Terpadu G-Suite</p>
                <div style="font-size:12px; font-weight:bold; margin-top:5px; color: #047857;">Buku Catatan Catatan Perkembangan — Kelas ${classroom}</div>
              </td>
              <td align="right" valign="bottom" style="border:0;">
                <p>Tahun Pelajaran: 2026/2027</p>
                <p>Unduh: ${new Date().toLocaleDateString('id-ID', { dateStyle: 'long' })}</p>
              </td>
            </tr>
          </table>

          ${filteredLogs.map(item => `
            <div class="card">
              <div class="meta">Aspek: ${item.aspect} &bull; Kategori: ${item.category} &bull; Tanggal: ${item.date}</div>
              <div class="student-name">Santri: ${item.studentName}</div>
              <div class="desc"><b>Deskripsi Observasi Wali Kelas:</b> "${item.notes}"</div>
              <div class="act"><b>Bimbingan & Tindak Lanjut Guru:</b> ${item.actionTaken || '-'}</div>
            </div>
          `).join('')}

          <div style="margin-top:50px; float: right; width: 220px; text-align: center; font-size: 11px;">
            <p>Bogor, ${new Date().toLocaleDateString('id-ID', { dateStyle: 'long' })}</p>
            <p style="margin-top:10px;">Wali Kelas / Guru Pembimbing</p>
            <br/><br/><br/>
            <p><b>Ustadzah Siti Nurhaliza, S.Pd.I.</b></p>
            <p style="font-size:9px; color:#666;">NIP. 19920815 201802 2 003</p>
          </div>
          <script>
            window.onload = function() { window.print(); }
          </script>
        </body>
      </html>
    `;

    printWindow.document.write(htmlContent);
    printWindow.document.close();
  };

  return (
    <div className="space-y-6" id="catatan-perkembangan-submodule">
      
      {/* Control panel & Filter matrix */}
      <div className="bg-white rounded-2xl p-5 border border-slate-100 shadow-xs space-y-4">
        
        <div className="flex flex-col md:flex-row gap-3">
          
          {/* Keyword Search field */}
          <div className="relative flex-1 block">
            <Search className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
            <input
              type="text"
              placeholder="Cari nama santri observasi..."
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              className="w-full text-xs pl-9 pr-4 py-2.5 bg-slate-50 border border-slate-200 focus:border-brand-green-500 rounded-xl focus:outline-none"
            />
          </div>

          {/* Student Filter dropdown */}
          <select
            value={studentFilter}
            onChange={e => setStudentFilter(e.target.value)}
            className="text-xs px-3 py-2 border border-slate-200 rounded-xl bg-white font-semibold text-slate-600 focus:outline-none"
          >
            <option value="all">Saring Berdasarkan Santri (Semua)</option>
            {classStudents.map(s => (
              <option key={s.id} value={s.id}>{s.name}</option>
            ))}
          </select>

          {/* Aspect Filter dropdown */}
          <select
            value={aspectFilter}
            onChange={e => setAspectFilter(e.target.value as any)}
            className="text-xs px-3 py-2 border border-slate-200 rounded-xl bg-white font-semibold text-slate-600 focus:outline-none"
          >
            <option value="all">Sifat Aspek (Semua)</option>
            <option value="Akademik">Akademik</option>
            <option value="Perilaku">Perilaku</option>
          </select>

        </div>

        {/* Buttons Section */}
        <div className="flex items-center justify-between border-t border-slate-100 pt-3 flex-wrap gap-3">
          <span className="text-xxs text-slate-400 font-semibold uppercase tracking-wider">
            Ditemukan: <b className="text-slate-600">{filteredLogs.length} Records</b>
          </span>

          <div className="flex gap-2 text-xxs">
            <button
              onClick={handlePrint}
              className="p-1 px-4 text-xxs font-extrabold text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-xl cursor-pointer shadow-3xs flex items-center gap-1.5"
            >
              <Printer className="h-4 w-4" />
              <span>Cetak Hasil</span>
            </button>
            <button
              onClick={handleOpenAdd}
              className="flex items-center gap-1.5 bg-brand-green-700 hover:bg-brand-green-800 text-white font-extrabold text-xxs px-4 py-2 rounded-xl shadow-xs transition cursor-pointer"
            >
              <Plus className="h-4 w-4" />
              <span>Buat Log Observasi</span>
            </button>
          </div>
        </div>

      </div>

      {/* Grid of Development Logs */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredLogs.map(log => {
          const isAkademik = log.aspect === 'Akademik';
          return (
            <div key={log.id} className="bg-white rounded-2xl p-5 border border-slate-100 shadow-3xs flex flex-col justify-between hover:border-emerald-100 transition-all">
              
              <div className="space-y-4">
                
                {/* Header aspect card */}
                <div className="flex items-center justify-between pb-3 border-b border-dashed border-slate-100">
                  <div className="flex items-center gap-2">
                    <span className={`p-1.5 rounded-lg ${isAkademik ? 'bg-sky-50 text-sky-700' : 'bg-emerald-50 text-emerald-800'}`}>
                      {isAkademik ? <TrendingUp className="h-4 w-4" /> : <Compass className="h-4 w-4" />}
                    </span>
                    <div>
                      <h4 className="font-extrabold text-xs text-slate-800">{log.studentName}</h4>
                      <span className="text-[10px] text-slate-400 font-medium">Aspek: {log.aspect} &bull; {log.category}</span>
                    </div>
                  </div>
                  <span className="text-[10px] text-slate-400 font-mono font-medium">{log.date}</span>
                </div>

                {/* Notes observation content */}
                <div className="space-y-1 text-xxs leading-relaxed text-slate-600">
                  <h5 className="font-bold text-slate-400 uppercase tracking-widest text-[9px]">Hasil Pengamatan Wali Kelas</h5>
                  <p className="bg-slate-50/50 p-2.5 rounded-lg border border-slate-100 italic">
                    "{log.notes}"
                  </p>
                </div>

                {/* Follow up Action taken */}
                <div className="space-y-1 text-xxs leading-relaxed">
                  <h5 className="font-bold text-slate-400 uppercase tracking-widest text-[9px] flex items-center gap-1">
                    <MessageSquare className="h-3 w-3 text-emerald-600" />
                    <span>Tindak Lanjut & Rekomendasi</span>
                  </h5>
                  <p className="font-bold text-slate-800 pl-4 py-0.5 border-l-2 border-emerald-500">
                    {log.actionTaken}
                  </p>
                </div>

              </div>

              {/* Action Operations elements row */}
              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100 border-dashed mt-5 text-xxs">
                <button
                  onClick={() => handleOpenEdit(log)}
                  className="p-1 px-3 text-xxs font-bold text-emerald-700 bg-emerald-50 hover:bg-emerald-100/60 rounded cursor-pointer transition"
                >
                  Sunting
                </button>
                <button
                  onClick={() => handleDelete(log.id)}
                  className="p-1 px-3 text-xxs font-bold text-rose-600 hover:bg-rose-50 rounded cursor-pointer transition"
                >
                  Hapus
                </button>
              </div>

            </div>
          );
        })}

        {filteredLogs.length === 0 && (
          <div className="bg-white rounded-2xl border border-slate-100 p-12 text-center text-slate-400 italic md:col-span-2">
            Belum ada record catatan perilaku atau akademik terekam untuk santri hasil filter ini.
          </div>
        )}
      </div>

      {/* COMPOSER DIALOG OVERLAY */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-3xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl w-full max-w-md shadow-xl overflow-hidden border border-slate-200 animate-in zoom-in duration-150">
            
            {/* Modal Header */}
            <div className="bg-brand-green-900 px-6 py-4 text-white flex justify-between items-center">
              <h3 className="font-extrabold text-sm school-display">
                {editingId ? 'Edit Observasi Santri' : 'Catat Hasil Observasi Perkembangan'}
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-white hover:text-brand-gold-100 cursor-pointer text-sm font-semibold"
              >
                &times;
              </button>
            </div>

            {/* Form */}
            <form onSubmit={handleSave} className="p-6 space-y-4 text-xs">
              
              {/* Dropdown: Select Student */}
              <div>
                <label className="block text-xxs font-bold text-slate-500 uppercase">Pilih Santri Kelas ({classroom})</label>
                <select
                  value={formStudentId}
                  onChange={e => setFormStudentId(e.target.value)}
                  className="w-full text-xs mt-1 px-3 py-2 border border-slate-200 bg-white rounded-lg focus:outline-none"
                >
                  {classStudents.map(s => (
                    <option key={s.id} value={s.id}>{s.name} ({s.nis})</option>
                  ))}
                </select>
              </div>

              {/* Choice: Aspect and category */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xxs font-bold text-slate-500 uppercase">Aspek Pengamatan</label>
                  <select
                    value={formAspect}
                    onChange={e => setFormAspect(e.target.value as any)}
                    className="w-full text-xs mt-1 px-3 py-2 border border-slate-200 bg-white rounded-lg font-semibold text-slate-700"
                  >
                    <option value="Akademik">Akademik</option>
                    <option value="Perilaku">Perilaku</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xxs font-bold text-slate-500 uppercase">Klasifikasi Kategori</label>
                  <select
                    value={formCategory}
                    onChange={e => setFormCategory(e.target.value)}
                    className="w-full text-xs mt-1 px-3 py-2 border border-slate-200 bg-white rounded-lg font-semibold text-slate-700"
                  >
                    <option value="Prestasi">Prestasi Cemerlang</option>
                    <option value="Sikap Spiritual">Sikap Spiritual / Adab</option>
                    <option value="Sikap Sosial">Sikap Sosial / Sahabat</option>
                    <option value="Kesulitan Belajar">Kesulitan Belajar</option>
                    <option value="Remedial / Perbaikan">Remedial / Perbaikan</option>
                  </select>
                </div>
              </div>

              {/* Area Notes Description */}
              <div>
                <label className="block text-xxs font-bold text-slate-500 uppercase">Deskripsi Observasi Rinci (Case Study)</label>
                <textarea
                  required
                  rows={3}
                  placeholder="Ceritakan kejadian, prestasi riil, atau keluhan santri saat observasi..."
                  value={formNotes}
                  onChange={e => setFormNotes(e.target.value)}
                  className="w-full text-xs mt-1 px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:border-brand-green-600 bg-slate-50"
                />
              </div>

              {/* Recommendation Action Taken */}
              <div>
                <label className="block text-xxs font-bold text-slate-500 uppercase">Rencana Tindak Lanjut / Rekomendasi Pembimbingan</label>
                <textarea
                  required
                  rows={2}
                  placeholder="Misal: Diberikan buku penugasan tilawah harian tambahan, mediasi santri bersahabat, bimbingan sosiometris..."
                  value={formAction}
                  onChange={e => setFormAction(e.target.value)}
                  className="w-full text-xs mt-1 px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:border-brand-green-600 bg-slate-50"
                />
              </div>

              {/* Buttons Submission */}
              <div className="flex justify-end gap-2 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 font-semibold text-slate-500 hover:bg-slate-50 rounded"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 font-bold text-white bg-brand-green-700 hover:bg-brand-green-800 rounded shadow-xs"
                >
                  Simpan Catatan
                </button>
              </div>

            </form>

          </div>
        </div>
      )}

    </div>
  );
}
