/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { ClipboardCheck, QrCode, FileSpreadsheet, Calendar, Search, Printer, RefreshCw, Send, CheckCircle, AlertTriangle } from 'lucide-react';
import { Student, AttendanceLog } from '../../types';

interface AbsensiSectionProps {
  students: Student[];
  classroom: string;
  selectedDate: string;
}

export default function AbsensiSection({
  students,
  classroom,
  selectedDate
}: AbsensiSectionProps) {
  const [entryMode, setEntryMode] = useState<'manual' | 'qr' | 'form'>('manual');
  const [rekapTab, setRekapTab] = useState<'harian' | 'bulanan' | 'semester'>('harian');
  
  // Local master state
  const classStudents = students.filter(s => s.classroom === classroom);
  const [localAttendance, setLocalAttendance] = useState<Record<string, { status: 'H' | 'S' | 'I' | 'A', note: string }>>({});
  
  // QR Code states
  const [qrActive, setQrActive] = useState(false);
  const [qrScanCount, setQrScanCount] = useState(4);
  const [scannedStudents, setScannedStudents] = useState<string[]>([]);
  
  // Google Forms states
  const [formUrl, setFormUrl] = useState('https://forms.gle/AlFarabyAttendanceClass4A');
  const [isSyncingForm, setIsSyncingForm] = useState(false);

  // Initialize/reset local attendance when class or date changes
  useEffect(() => {
    // Seed with initial realistic data or default 'H'
    const newRecords: Record<string, { status: 'H' | 'S' | 'I' | 'A', note: string }> = {};
    classStudents.forEach((s, idx) => {
      // Simulate some absences to make data look real & interesting
      let status: 'H' | 'S' | 'I' | 'A' = 'H';
      let note = '';
      if (idx === 2) {
        status = 'S';
        note = 'Sakit Demam';
      } else if (idx === 5) {
        status = 'I';
        note = 'Acara Keluarga';
      } else if (idx === 8) {
        status = 'A';
        note = 'Tanpa Keterangan';
      }
      newRecords[s.id] = { status, note };
    });
    setLocalAttendance(newRecords);
    
    // Seed scanned student lists
    if (classStudents.length >= 4) {
      setScannedStudents(classStudents.slice(0, 4).map(s => s.id));
    }
  }, [classroom, selectedDate]);

  const handleSetStatus = (studentId: string, status: 'H' | 'S' | 'I' | 'A') => {
    setLocalAttendance(prev => ({
      ...prev,
      [studentId]: {
        ...prev[studentId],
        status
      }
    }));
  };

  const handleSetNote = (studentId: string, note: string) => {
    setLocalAttendance(prev => ({
      ...prev,
      [studentId]: {
        ...prev[studentId],
        note
      }
    }));
  };

  // Absensi Manual Save
  const handleSaveManual = () => {
    alert(`Sukses memvalidasi & mengarsip data Absensi ${classroom} tanggal ${selectedDate} ke server cloud.`);
  };

  // Simulating QR checking in
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (qrActive) {
      interval = setInterval(() => {
        // Find next unscanned student
        const unscanned = classStudents.find(s => !scannedStudents.includes(s.id));
        if (unscanned) {
          setScannedStudents(prev => [...prev, unscanned.id]);
          setQrScanCount(prev => prev + 1);
          // Set status to Present (H) in local attendance
          setLocalAttendance(prev => ({
            ...prev,
            [unscanned.id]: { status: 'H', note: 'Scan QR Mandiri' }
          }));
        } else {
          setQrActive(false);
          alert('Semua siswa aktif kelas telah menyelesaikan presensi via QR mandiri!');
        }
      }, 3500); // Check in every 3.5 seconds
    }
    return () => clearInterval(interval);
  }, [qrActive, classStudents, scannedStudents]);

  // Sync Google Forms
  const handleSyncGoogleForm = () => {
    if (isSyncingForm) return;
    setIsSyncingForm(true);
    setTimeout(() => {
      setIsSyncingForm(false);
      // Simulate changes
      if (classStudents.length > 0) {
        const firstStudent = classStudents[0];
        setLocalAttendance(prev => ({
          ...prev,
          [firstStudent.id]: { status: 'H', note: 'Sinkronisasi Google Forms (Respon 038)' }
        }));
      }
      alert('Sinkronisasi Google Form Sukses! Berhasil menarik data presensi digital terbaru.');
    }, 2000);
  };

  // Calculating counters
  const totalStudents = classStudents.length;
  const countH = Object.values(localAttendance).filter((x: any) => x.status === 'H').length;
  const countS = Object.values(localAttendance).filter((x: any) => x.status === 'S').length;
  const countI = Object.values(localAttendance).filter((x: any) => x.status === 'I').length;
  const countA = Object.values(localAttendance).filter((x: any) => x.status === 'A').length;
  const attendanceRate = totalStudents > 0 ? Math.round((countH / totalStudents) * 100) : 0;

  // Print function
  const handlePrint = () => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) {
      alert('Tolong izinkan pop-up untuk mencetak berkas rekapitulasi.');
      return;
    }
    
    let reportTitle = '';
    let tableHtml = '';

    if (rekapTab === 'harian') {
      reportTitle = `REKAPITULASI HARIAN ABSENSI KELAS — ${classroom}`;
      tableHtml = `
        <table border="1" cellpadding="8" style="width:100%; border-collapse:collapse; margin-top:15px; font-size:12px;">
          <tr style="background:#f1f5f9;">
            <th>No</th>
            <th>NIS</th>
            <th>Nama Lengkap Santri</th>
            <th>Gender</th>
            <th>Status</th>
            <th>Keterangan</th>
          </tr>
          ${classStudents.map((s, idx) => {
            const att = localAttendance[s.id] || { status: 'H', note: '' };
            const statusLabel = att.status === 'H' ? 'Hadir' : att.status === 'S' ? 'Sakit' : att.status === 'I' ? 'Izin' : 'Alpa';
            return `
              <tr>
                <td align="center">${idx + 1}</td>
                <td align="center">${s.nis}</td>
                <td><b>${s.name}</b></td>
                <td align="center">${s.gender}</td>
                <td align="center" style="font-weight:bold; color:${att.status === 'H' ? 'green' : 'red'};">${statusLabel}</td>
                <td>${att.note || '-'}</td>
              </tr>
            `;
          }).join('')}
        </table>
        <div style="margin-top:20px; font-size:12px; font-weight:bold;">
          Ringkasan Kehadiran: Hadir (${countH}), Sakit (${countS}), Izin (${countI}), Alpa (${countA})<br/>
          Persentase Efektivitas Hari Ini: ${attendanceRate}%
        </div>
      `;
    } else if (rekapTab === 'bulanan') {
      reportTitle = `REKAPITULASI BULANAN ABSENSI KELAS — ${classroom}`;
      // Generate daily days
      const days = Array.from({ length: 15 }, (_, i) => i + 1); // print first 15 days for space optimization
      tableHtml = `
        <table border="1" cellpadding="5" style="width:100%; border-collapse:collapse; margin-top:15px; font-size:10px;">
          <tr style="background:#f1f5f9;">
            <th rowspan="2">No</th>
            <th rowspan="2">Nama Santri</th>
            <th colspan="15" align="center">Tanggal Pertemuan (Hari)</th>
            <th colspan="4" align="center">Total</th>
          </tr>
          <tr style="background:#f8fafc;">
            ${days.map(d => `<th width="20">${d}</th>`).join('')}
            <th>H</th>
            <th>S</th>
            <th>I</th>
            <th>A</th>
          </tr>
          ${classStudents.map((s, idx) => {
            // Seed a realistic monthly distribution for printing
            const rowH = 12 + (idx % 3);
            const rowS = idx === 2 ? 2 : 0;
            const rowI = idx === 5 ? 1 : 0;
            const rowA = idx === 8 ? 1 : 0;
            return `
              <tr>
                <td align="center">${idx + 1}</td>
                <td><b>${s.name}</b></td>
                ${days.map(d => {
                  let cellVal = 'H';
                  if (idx === 2 && d === 12) cellVal = 'S';
                  if (idx === 5 && d === 4) cellVal = 'I';
                  if (idx === 8 && d === 8) cellVal = 'A';
                  return `<td align="center" style="font-size:8px;">${cellVal}</td>`;
                }).join('')}
                <td align="center" style="font-weight:bold; color:green;">${rowH}</td>
                <td align="center">${rowS}</td>
                <td align="center">${rowI}</td>
                <td align="center" style="color:red;">${rowA}</td>
              </tr>
            `;
          }).join('')}
        </table>
      `;
    } else {
      reportTitle = `REKAPITULASI SEMESTER ABSENSI KELAS — ${classroom}`;
      tableHtml = `
        <table border="1" cellpadding="8" style="width:100%; border-collapse:collapse; margin-top:15px; font-size:12px;">
          <tr style="background:#f1f5f9;">
            <th>No</th>
            <th>Nama Lengkap Santri</th>
            <th>Total Pertemuan</th>
            <th>Hadir (H)</th>
            <th>Sakit (S)</th>
            <th>Izin (I)</th>
            <th>Alpa (A)</th>
            <th>Persentase</th>
            <th>Status</th>
          </tr>
          ${classStudents.map((s, idx) => {
            const totalSinyal = 96;
            const h = idx === 8 ? 84 : idx === 2 ? 90 : idx === 5 ? 92 : 96;
            const sVal = idx === 2 ? 6 : 0;
            const iVal = idx === 5 ? 4 : 0;
            const aVal = idx === 8 ? 12 : 0;
            const percent = Math.round((h / totalSinyal) * 100);
            const statusLabel = percent >= 90 ? 'AMAN' : 'PERINGATAN';
            return `
              <tr>
                <td align="center">${idx + 1}</td>
                <td><b>${s.name}</b></td>
                <td align="center">${totalSinyal}</td>
                <td align="center">${h}</td>
                <td align="center">${sVal}</td>
                <td align="center">${iVal}</td>
                <td align="center" style="color:red;">${aVal}</td>
                <td align="center" style="font-weight:bold;">${percent}%</td>
                <td align="center" style="font-weight:bold; color:${percent >= 90 ? 'green' : 'red'};">${statusLabel}</td>
              </tr>
            `;
          }).join('')}
        </table>
      `;
    }

    const htmlContent = `
      <html>
        <head>
          <title>${reportTitle}</title>
          <style>
            body { font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; padding: 25px; line-height: 1.5; color: #1e293b; }
            h1 { font-size: 16px; margin: 0; color: #111827; letter-spacing: 0.5px; }
            p { font-size: 11px; margin: 3px 0 0 0; color: #555; }
            .header-table { width: 100%; border-bottom: 2px solid #047857; padding-bottom: 15px; margin-bottom: 20px; }
            .footer-sig { margin-top: 50px; float: right; width: 250px; text-align: center; font-size: 12px; }
          </style>
        </head>
        <body>
          <table class="header-table">
            <tr>
              <td width="80">
                <div style="width:60px; height:60px; background:#065f46; color:#fbbf24; font-weight:bold; font-size:28px; line-height:60px; text-align:center; border-radius:10px;">AF</div>
              </td>
              <td>
                <h1>SD ISLAM AL FARABY</h1>
                <p>Komp. Yayasan Pendidikan Islam Al Faraby Bogor &bull; Email: info@alfaraby.sch.id</p>
                <div style="font-size:12px; font-weight:bold; margin-top:8px; color: #047857;">${reportTitle}</div>
              </td>
              <td align="right" valign="bottom">
                <p>Tahun Pelajaran: 2026/2027</p>
                <p>Tanggal Cetak: ${new Date().toLocaleDateString('id-ID', { dateStyle: 'long' })}</p>
              </td>
            </tr>
          </table>

          ${tableHtml}

          <div style="margin-top:40px; font-size:11px; float:left;">
            * Dokumen ini dibuat melalui modul administrasi guru terpadu G-Suite Al-Faraby.<br/>
            * Klasifikasi absensi telah divalidasi oleh wali kelas.
          </div>

          <div class="footer-sig">
            <p>Bogor, ${new Date().toLocaleDateString('id-ID', { dateStyle: 'long' })}</p>
            <p style="margin-top:10px;">Wali Kelas ${classroom}</p>
            <br/><br/><br/>
            <p><b>Ustadzah Siti Nurhaliza, S.Pd.I.</b></p>
            <p style="font-size:10px; color:#666;">NIP. 19920815 201802 2 003</p>
          </div>

          <script>
            window.onload = function() {
              window.print();
            }
          </script>
        </body>
      </html>
    `;

    printWindow.document.write(htmlContent);
    printWindow.document.close();
  };

  return (
    <div className="space-y-6" id="absensi-submodule">
      
      {/* Selector: Entry Mode */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        
        {/* Card Manual */}
        <button
          onClick={() => setEntryMode('manual')}
          className={`flex items-start gap-4 p-4 rounded-2xl border text-left cursor-pointer transition ${
            entryMode === 'manual'
              ? 'bg-emerald-50/50 border-emerald-500 shadow-xs ring-1 ring-emerald-500'
              : 'bg-white border-slate-100 hover:border-slate-300'
          }`}
        >
          <div className={`p-3 rounded-xl ${entryMode === 'manual' ? 'bg-emerald-500 text-white' : 'bg-slate-50 text-slate-500'}`}>
            <ClipboardCheck className="h-5 w-5" />
          </div>
          <div>
            <h4 className="font-bold text-xs text-slate-800">Presensi Manual</h4>
            <p className="text-xxs text-slate-500 mt-1 leading-relaxed">Centang langsung kehadiran santri secara cepat dan tepat.</p>
          </div>
        </button>

        {/* Card QR Code */}
        <button
          onClick={() => setEntryMode('qr')}
          className={`flex items-start gap-4 p-4 rounded-2xl border text-left cursor-pointer transition ${
            entryMode === 'qr'
              ? 'bg-emerald-50/50 border-emerald-500 shadow-xs ring-1 ring-emerald-500'
              : 'bg-white border-slate-100 hover:border-slate-300'
          }`}
        >
          <div className={`p-3 rounded-xl ${entryMode === 'qr' ? 'bg-emerald-500 text-white' : 'bg-slate-50 text-slate-500'}`}>
            <QrCode className="h-5 w-5" />
          </div>
          <div>
            <h4 className="font-bold text-xs text-slate-800">QR Code Mandiri</h4>
            <p className="text-xxs text-slate-500 mt-1 leading-relaxed">Tampilkan QR, santri memindai otomatis via perangkat kelas.</p>
          </div>
        </button>

        {/* Card Google Forms */}
        <button
          onClick={() => setEntryMode('form')}
          className={`flex items-start gap-4 p-4 rounded-2xl border text-left cursor-pointer transition ${
            entryMode === 'form'
              ? 'bg-emerald-50/50 border-emerald-500 shadow-xs ring-1 ring-emerald-500'
              : 'bg-white border-slate-100 hover:border-slate-300'
          }`}
        >
          <div className={`p-3 rounded-xl ${entryMode === 'form' ? 'bg-emerald-500 text-white' : 'bg-slate-50 text-slate-500'}`}>
            <FileSpreadsheet className="h-5 w-5" />
          </div>
          <div>
            <h4 className="font-bold text-xs text-slate-800">Integrasi Google Forms</h4>
            <p className="text-xxs text-slate-500 mt-1 leading-relaxed">Sinkronisasikan isian wali murid melalui tautan formulir.</p>
          </div>
        </button>
      </div>

      {/* Main Workspace Frame based on active entryMode */}
      <div className="bg-white rounded-2xl border border-slate-100 shadow-xs overflow-hidden">
        
        {/* MANUAL WORKSPACE */}
        {entryMode === 'manual' && (
          <div>
            <div className="p-5 border-b border-slate-100 bg-slate-50/50 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="space-y-1">
                <span className="text-xxs font-extrabold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded uppercase tracking-wide">
                  Entry Manual Aktif
                </span>
                <p className="text-xxs text-slate-500">Silakan tentukan status kehadiran tiap santri pada tanggal terpilih.</p>
              </div>
              <div className="flex gap-2.5">
                <div className="flex items-center gap-1.5 bg-white border border-slate-200 px-3 py-1 text-xxs font-semibold rounded-lg text-slate-600 shadow-3xs">
                  <span>Total: <b className="text-slate-800">{totalStudents}</b></span>
                  <span className="text-slate-300">|</span>
                  <span className="text-emerald-600 font-bold">H: {countH}</span>
                  <span className="text-blue-500">S: {countS}</span>
                  <span className="text-amber-500">I: {countI}</span>
                  <span className="text-rose-500">A: {countA}</span>
                </div>
                <button
                  onClick={handleSaveManual}
                  className="bg-brand-green-700 hover:bg-brand-green-800 text-white font-extrabold text-xxs px-4 py-1.5 rounded-lg shadow-xs cursor-pointer"
                >
                  Simpan Absensi
                </button>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-slate-100 bg-slate-50/20 text-slate-400 font-extrabold uppercase tracking-wider text-xxxxs">
                    <th className="p-4 w-[38%]">Nama Lengkap Murid</th>
                    <th className="p-4 w-[12%]">NIS/NISN</th>
                    <th className="p-4 text-center w-[25%] font-mono">Tandakan Status</th>
                    <th className="p-4">Keterangan / Alasan Khusus</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-slate-700">
                  {classStudents.map(student => {
                    const record = localAttendance[student.id] || { status: 'H', note: '' };
                    return (
                      <tr key={student.id} className="hover:bg-slate-50/20 transition-colors">
                        <td className="p-4">
                          <div className="flex items-center gap-3">
                            <span className="h-6.5 w-6.5 rounded-full bg-slate-100 text-slate-500 flex items-center justify-center font-bold text-xxs">
                              {student.gender}
                            </span>
                            <div>
                              <div className="font-bold text-slate-800 text-xs">{student.name}</div>
                              <div className="text-[10px] text-slate-400 font-medium italic mt-0.5">Wali: {student.parentsName}</div>
                            </div>
                          </div>
                        </td>
                        <td className="p-4 font-mono text-slate-500 text-xxs leading-relaxed">
                          NIS: {student.nis}<br/>NISN: {student.nisn || '-'}
                        </td>
                        <td className="p-4">
                          <div className="flex justify-center gap-1">
                            {[
                              { code: 'H', label: 'Hadir', col: 'bg-emerald-600 text-white ring-2 ring-emerald-100', off: 'bg-slate-50 hover:bg-emerald-50 text-slate-500 border border-slate-200' },
                              { code: 'S', label: 'Sakit', col: 'bg-blue-600 text-white ring-2 ring-blue-100', off: 'bg-slate-50 hover:bg-blue-50 text-slate-500 border border-slate-200' },
                              { code: 'I', label: 'Izin', col: 'bg-amber-600 text-white ring-2 ring-amber-100', off: 'bg-slate-50 hover:bg-amber-50 text-slate-500 border border-slate-200' },
                              { code: 'A', label: 'Alpa', col: 'bg-rose-600 text-white ring-2 ring-rose-100', off: 'bg-slate-50 hover:bg-rose-50 text-slate-500 border border-slate-200' }
                            ].map(opt => (
                              <button
                                key={opt.code}
                                type="button"
                                onClick={() => handleSetStatus(student.id, opt.code as any)}
                                className={`px-3 py-1.5 rounded-lg text-xxs font-extrabold transition cursor-pointer ${
                                  record.status === opt.code ? opt.col : opt.off
                                }`}
                              >
                                {opt.code}
                              </button>
                            ))}
                          </div>
                        </td>
                        <td className="p-4">
                          <input
                            type="text"
                            value={record.note}
                            onChange={e => handleSetNote(student.id, e.target.value)}
                            placeholder={record.status === 'H' ? 'Catatan harian...' : 'Masukan info sakit/izin...'}
                            className="w-full bg-slate-50 border border-slate-200 focus:border-brand-green-500 text-xxs rounded px-2.5 py-1.5 focus:outline-none focus:ring-0"
                          />
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* QR CODE WORKSPACE */}
        {entryMode === 'qr' && (
          <div className="p-6 flex flex-col md:flex-row items-center justify-between gap-8">
            <div className="space-y-4 max-w-md">
              <span className="text-xxs font-extrabold text-brand-green-800 bg-brand-green-50 px-2 py-0.5 rounded uppercase tracking-wide">
                QR CODE MANDIRI AKTIF
              </span>
              <h3 className="font-bold text-sm text-slate-800 school-display">Presensi Otomatis Menggunakan QR Mandiri</h3>
              <p className="text-xxs text-slate-600 leading-relaxed">
                Tampilkan visual QR Code di bawah pada proyektor kelas atau tablet asisten. Santri dapat membawa kartu ID santri berlogo QR untuk dipindai otomatis.
              </p>

              <div className="bg-slate-50 border border-slate-100 rounded-xl p-4 space-y-2">
                <div className="flex items-center justify-between text-xxs">
                  <span className="text-slate-500 font-bold">Status Pemindai (Scanner):</span>
                  <span className={`px-2 py-0.5 rounded-full font-extrabold ${qrActive ? 'bg-emerald-100 text-emerald-800 animate-pulse' : 'bg-slate-200 text-slate-600'}`}>
                    {qrActive ? '● Menerima Hubungan' : '■ Berhenti'}
                  </span>
                </div>
                <div className="flex items-center justify-between text-xxs">
                  <span className="text-slate-500">Santri Sukses Terpindai Hari Ini:</span>
                  <span className="font-bold text-brand-green-900 font-mono">{qrScanCount} dari {totalStudents} Santri</span>
                </div>
              </div>

              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setQrActive(!qrActive)}
                  className={`px-4 py-2 text-xxs font-bold rounded-lg cursor-pointer transition ${
                    qrActive
                      ? 'bg-amber-600 hover:bg-amber-700 text-white'
                      : 'bg-brand-green-700 hover:bg-brand-green-800 text-white'
                  }`}
                >
                  {qrActive ? 'Hentikan Sesi QR' : 'Mulai / Tampilkan QR'}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setScannedStudents([]);
                    setQrScanCount(0);
                  }}
                  className="px-4 py-2 text-xxs font-bold text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-lg cursor-pointer transition"
                >
                  Reset Log Pemindaian
                </button>
              </div>
            </div>

            {/* QR Mockup visualizer */}
            <div className="bg-slate-50 p-6 rounded-2xl border border-slate-200 flex flex-col items-center justify-center shrink-0 w-64 shadow-xs">
              <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-3xs flex items-center justify-center w-full">
                {/* SVG Simulated QR code so we don't depend on raw plugins */}
                <div className="w-40 h-40 bg-[url('https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=al-faraby-attendance')] bg-contain bg-center bg-no-repeat" style={{ minWidth: '160px', minHeight: '160px' }} />
              </div>
              <div className="text-[10px] text-slate-400 font-mono text-center mt-3">
                ID KELAS: {classroom.replace(' ', '_').toUpperCase()}
                <b className="block text-emerald-700 mt-1">Pindai menggunakan aplikasi wali murid</b>
              </div>
            </div>
          </div>
        )}

        {/* GOOGLE FORMS WORKSPACE */}
        {entryMode === 'form' && (
          <div className="p-6 space-y-6">
            <div className="space-y-4 max-w-2xl bg-amber-50/40 border border-amber-200/50 rounded-2xl p-5">
              <div className="flex gap-3">
                <FileSpreadsheet className="h-5 w-5 text-amber-700 shrink-0" />
                <div>
                  <h4 className="font-bold text-xs text-slate-800 school-display">Sinkronisasi Tanggapan Google Forms</h4>
                  <p className="text-xxs text-slate-600 leading-relaxed mt-1">
                    Isian perizinan/ketidakhadiran santri yang diekspos oleh wali murid dapat dipetakan langsung ke sheet absensi harian kelas ini secara digital.
                  </p>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs">
              <div className="space-y-3">
                <div>
                  <label className="block text-xxs font-bold text-slate-500 uppercase">Tautan Google Forms Aktif (G-Suite)</label>
                  <input
                    type="url"
                    value={formUrl}
                    onChange={e => setFormUrl(e.target.value)}
                    className="w-full text-xs mt-1.5 px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:border-brand-green-600 bg-white"
                  />
                </div>
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={handleSyncGoogleForm}
                    disabled={isSyncingForm}
                    className="flex items-center gap-1.5 bg-brand-green-700 hover:bg-brand-green-800 text-white font-bold text-xxs px-4 py-2.5 rounded-lg shadow-xs cursor-pointer disabled:opacity-50 transition"
                  >
                    <RefreshCw className={`h-3.5 w-3.5 ${isSyncingForm ? 'animate-spin' : ''}`} />
                    {isSyncingForm ? 'Menyinkronkan...' : 'Sinkronkan Google Sheet Response'}
                  </button>
                  <a
                    href={formUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="px-4 py-2.5 text-slate-600 bg-slate-100 font-bold text-xxs rounded-lg border border-slate-200 hover:bg-slate-200 text-center flex items-center justify-center transition"
                  >
                    Buka Formulir
                  </a>
                </div>
              </div>

              <div className="bg-slate-50 rounded-xl p-4 border border-slate-100 flex flex-col justify-between space-y-4">
                <div className="flex justify-between items-center text-xxs">
                  <span className="text-slate-500 font-bold uppercase tracking-wider">Log Sinkronisasi Terakhir</span>
                  <span className="text-slate-400 font-mono">17-Jun-2026 04:30 WIB</span>
                </div>
                <div className="space-y-1.5 text-xxs">
                  <div className="flex items-center gap-1.5 text-emerald-800 font-semibold">
                    <CheckCircle className="h-3.5 w-3.5" />
                    <span>Sukses memproses 12 baris pendaftaran baru hari ini.</span>
                  </div>
                  <div className="flex items-center gap-1.5 text-slate-600">
                    <CheckCircle className="h-3.5 w-3.5" />
                    <span>0 data bentrok terdeteksi. Master data mengesampingkan duplikasi.</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* SECTION: OUTPUT REKAPITULASI (Output) */}
      <div className="bg-white rounded-2xl border border-slate-100 shadow-xs overflow-hidden">
        
        {/* Navigation Bar Output */}
        <div className="p-4 bg-slate-50 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <FileSpreadsheet className="h-4 w-4 text-emerald-700" />
            <h3 className="font-extrabold text-xs text-slate-700 uppercase tracking-wider school-display">
              Output Dokumen Rekapitulasi Absensi
            </h3>
          </div>

          <div className="flex items-center gap-2 self-end sm:self-auto">
            <div className="flex bg-slate-200 p-0.5 rounded-lg text-xxs">
              <button
                onClick={() => setRekapTab('harian')}
                className={`px-3 py-1 font-bold rounded-md transition cursor-pointer ${rekapTab === 'harian' ? 'bg-white text-slate-800 shadow-3xs' : 'text-slate-500 hover:text-slate-800'}`}
              >
                Rekap Harian
              </button>
              <button
                onClick={() => setRekapTab('bulanan')}
                className={`px-3 py-1 font-bold rounded-md transition cursor-pointer ${rekapTab === 'bulanan' ? 'bg-white text-slate-800 shadow-3xs' : 'text-slate-500 hover:text-slate-800'}`}
              >
                Rekap Bulanan
              </button>
              <button
                onClick={() => setRekapTab('semester')}
                className={`px-3 py-1 font-bold rounded-md transition cursor-pointer ${rekapTab === 'semester' ? 'bg-white text-slate-800 shadow-3xs' : 'text-slate-500 hover:text-slate-800'}`}
              >
                Rekap Semester
              </button>
            </div>

            <button
              onClick={handlePrint}
              className="p-1 px-3 text-xxs font-extrabold text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg flex items-center gap-1 cursor-pointer shadow-3xs transition"
            >
              <Printer className="h-3.5 w-3.5" />
              <span>Cetak Rekap</span>
            </button>
          </div>
        </div>

        {/* REKAP PANEL CONTAINER */}
        <div className="p-5">
          
          {/* HARIAN REKAP */}
          {rekapTab === 'harian' && (
            <div className="space-y-4">
              <div className="flex justify-between items-center text-xxs text-slate-500">
                <span>Rekap Absensi Harian Kelas {classroom} tanggal {selectedDate}</span>
                <span className="font-mono">Total Santri: {totalStudents}</span>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                <div className="bg-slate-50 rounded-xl p-3 border border-slate-100 text-center">
                  <span className="text-emerald-700 font-extrabold text-sm block">{countH}</span>
                  <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block mt-1">Hadir (H)</span>
                </div>
                <div className="bg-slate-50 rounded-xl p-3 border border-slate-100 text-center">
                  <span className="text-blue-600 font-extrabold text-sm block">{countS}</span>
                  <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block mt-1">Sakit (S)</span>
                </div>
                <div className="bg-slate-50 rounded-xl p-3 border border-slate-100 text-center">
                  <span className="text-amber-500 font-extrabold text-sm block">{countI}</span>
                  <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block mt-1">Izin (I)</span>
                </div>
                <div className="bg-slate-50 rounded-xl p-3 border border-slate-100 text-center">
                  <span className="text-rose-600 font-extrabold text-sm block">{countA}</span>
                  <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block mt-1">Alpa (A)</span>
                </div>
              </div>

              {/* List of Absences */}
              <div className="bg-slate-50 rounded-xl border border-slate-100 p-4">
                <h4 className="text-xxs font-extrabold text-slate-700 uppercase tracking-widest mb-3">Catatan Santri Berhalangan Hari Ini</h4>
                <div className="space-y-2 text-xxs">
                  {classStudents
                    .filter(s => (localAttendance[s.id]?.status || 'H') !== 'H')
                    .map(student => {
                      const rec = localAttendance[student.id];
                      return (
                        <div key={student.id} className="flex justify-between items-center border-b border-white pb-2 last:border-b-0">
                          <span className="font-bold text-slate-800">{student.name}</span>
                          <div className="flex gap-2 items-center">
                            <span className={`px-2 py-0.5 rounded font-bold text-[9px] uppercase ${
                              rec.status === 'S' ? 'bg-blue-100 text-blue-800' : rec.status === 'I' ? 'bg-amber-100 text-amber-800' : 'bg-rose-100 text-rose-800'
                            }`}>
                              {rec.status === 'S' ? 'Sakit' : rec.status === 'I' ? 'Izin' : 'Alpa'}
                            </span>
                            <span className="text-slate-500 italic">"{rec.note || 'Tanpa keterangan'}"</span>
                          </div>
                        </div>
                      );
                    })}
                  {classStudents.filter(s => (localAttendance[s.id]?.status || 'H') !== 'H').length === 0 && (
                    <div className="text-center text-slate-400 py-2 italic font-medium">Semua santri hadir dalam kelas hari ini. Alhamdulillah!</div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* BULANAN REKAP */}
          {rekapTab === 'bulanan' && (
            <div className="space-y-4">
              <div className="flex justify-between items-center text-xxs text-slate-500">
                <span>Rangkaian Presensi Bulanan (Juni 2026)</span>
                <span className="italic text-emerald-700">* Data disimulasikan dari log pertemuan reguler</span>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-xxs">
                  <thead>
                    <tr className="border-b border-slate-100 bg-slate-50/50 text-slate-400 font-extrabold uppercase tracking-wider text-[9px]">
                      <th className="p-3">Nama Lengkap Santri</th>
                      {Array.from({ length: 15 }, (_, i) => i + 1).map(day => (
                        <th key={day} className="p-2 text-center w-[25px] font-mono">{day}</th>
                      ))}
                      <th className="p-3 text-center text-emerald-700">H</th>
                      <th className="p-3 text-center text-blue-500">S</th>
                      <th className="p-3 text-center text-amber-500">I</th>
                      <th className="p-3 text-center text-rose-500 font-mono">A</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-slate-600 font-medium">
                    {classStudents.map((student, sIdx) => {
                      // Generate realistic numbers
                      const totH = 12 + (sIdx % 3);
                      const totS = sIdx === 2 ? 2 : 0;
                      const totI = sIdx === 5 ? 1 : 0;
                      const totA = sIdx === 8 ? 1 : 0;
                      return (
                        <tr key={student.id} className="hover:bg-slate-50/40">
                          <td className="p-3 font-bold text-slate-800 text-xs">{student.name}</td>
                          {Array.from({ length: 15 }, (_, i) => i + 1).map(day => {
                            let mark = 'H';
                            let markClass = 'text-slate-400';
                            if (sIdx === 2 && day === 12) { mark = 'S'; markClass = 'text-blue-500 font-bold bg-blue-50 rounded-xs'; }
                            if (sIdx === 5 && day === 4) { mark = 'I'; markClass = 'text-amber-500 font-bold bg-amber-50 rounded-xs'; }
                            if (sIdx === 8 && day === 8) { mark = 'A'; markClass = 'text-rose-500 font-bold bg-rose-50 rounded-xs'; }
                            return (
                              <td key={day} className={`p-2 text-center border-l border-slate-50 ${markClass}`}>
                                {mark}
                              </td>
                            );
                          })}
                          <td className="p-3 text-center text-emerald-700 font-extrabold">{totH}</td>
                          <td className="p-3 text-center font-bold">{totS}</td>
                          <td className="p-3 text-center font-bold">{totI}</td>
                          <td className="p-3 text-center text-rose-500 font-bold">{totA}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* SEMESTER REKAP */}
          {rekapTab === 'semester' && (
            <div className="space-y-4">
              <div className="flex justify-between items-center text-xxs text-slate-500">
                <span>Ringkasan Kehadiran Satu Semester Penuh (Semester Genap TA 2026/2027)</span>
                <span className="text-rose-600 font-semibold italic">* Warning batas aman minimal kehadiran adalah 90%</span>
              </div>
              <div className="overflow-x-auto animate-in fade-in">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="border-b border-slate-100 bg-slate-50/30 text-slate-400 font-extrabold uppercase tracking-wider text-xxxxs">
                      <th className="p-4 w-1/3">Nama Lengkap Santri</th>
                      <th className="p-4 text-center">Kelas</th>
                      <th className="p-4 text-center">Total Sesi</th>
                      <th className="p-4 text-center text-emerald-800">Hadir (H)</th>
                      <th className="p-4 text-center text-blue-500">Sakit (S)</th>
                      <th className="p-4 text-center text-amber-500">Izin (I)</th>
                      <th className="p-4 text-center text-rose-600">Alpa (A)</th>
                      <th className="p-4 text-center">Persentase</th>
                      <th className="p-4 text-center">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-slate-700 font-medium text-xxs">
                    {classStudents.map((student, sIdx) => {
                      const totalSesi = 96;
                      const h = sIdx === 8 ? 84 : sIdx === 2 ? 90 : sIdx === 5 ? 92 : 96;
                      const sVal = sIdx === 2 ? 6 : 0;
                      const iVal = sIdx === 5 ? 4 : 0;
                      const aVal = sIdx === 8 ? 12 : 0;
                      const percent = Math.round((h / totalSesi) * 100);
                      const isDanger = percent < 90;
                      return (
                        <tr key={student.id} className="hover:bg-slate-50/20">
                          <td className="p-4 font-bold text-slate-800 text-xs">{student.name}</td>
                          <td className="p-4 text-center">{student.classroom}</td>
                          <td className="p-4 text-center font-mono">{totalSesi}</td>
                          <td className="p-4 text-center font-mono text-emerald-700 font-bold">{h}</td>
                          <td className="p-4 text-center font-mono">{sVal}</td>
                          <td className="p-4 text-center font-mono">{iVal}</td>
                          <td className="p-4 text-center font-mono text-rose-500 font-bold">{aVal}</td>
                          <td className="p-4 text-center font-bold text-slate-800">{percent}%</td>
                          <td className="p-4 text-center">
                            <span className={`px-2.5 py-1 rounded-full text-[9px] font-extrabold ${
                              isDanger ? 'bg-rose-100 text-rose-800' : 'bg-emerald-100 text-emerald-800'
                            }`}>
                              {isDanger ? 'PERINGATAN' : 'AKADEMIK AMAN'}
                            </span>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
