/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  Award,
  Sparkles,
  Send,
  RefreshCw,
  Layers,
  CheckCircle2,
  FileText,
  ClipboardList,
  BookOpen,
  ChevronRight,
  BarChart3,
  TrendingUp,
  Printer,
  Download,
  Smile,
  AlertCircle,
  Plus,
  X,
  Heart,
  Settings,
  ArrowUpRight,
  Check,
  RotateCw,
  Sliders,
  UserCheck
} from 'lucide-react';
import { Student, AcademicScore, Subject } from '../types';
import {
  ComposedChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  ReferenceLine,
  Line
} from 'recharts';

interface PenilaianViewProps {
  students: Student[];
  subjects: Subject[];
  academicScores: AcademicScore[];
  onAddScore: (score: AcademicScore) => void;
  onEditScore: (score: AcademicScore) => void;
  onDeleteScore: (id: string) => void;
}

export default function PenilaianView({
  students,
  subjects,
  academicScores,
  onAddScore,
  onEditScore,
  onDeleteScore
}: PenilaianViewProps) {
  // Top-level filter states
  const [selectedClass, setSelectedClass] = useState('Kelas 4A');
  const [selectedSubjectId, setSelectedSubjectId] = useState(subjects[0]?.id || 'MAPEL01');

  // Secondary sub-tab navigation
  // Options: 'Kognitif', 'Keterampilan', 'Sikap', 'Analisis', 'Remedial', 'Pengayaan', 'Cetak'
  const [activeSubTab, setActiveSubTab] = useState<'Kognitif' | 'Keterampilan' | 'Sikap' | 'Analisis' | 'Remedial' | 'Pengayaan' | 'Cetak'>('Kognitif');

  // Modular scores state (Local cache with pre-populated seeds to avoid empty screens)
  const [cognitiveScores, setCognitiveScores] = useState<Record<string, { tugas: number; kuis: number; harian: number; uts: number; uas: number }>>({
    'S001-MAPEL01': { tugas: 85, kuis: 80, harian: 85, uts: 88, uas: 90 },
    'S002-MAPEL01': { tugas: 95, kuis: 94, harian: 95, uts: 92, uas: 96 },
    'S003-MAPEL01': { tugas: 78, kuis: 77, harian: 78, uts: 75, uas: 82 },
    'S004-MAPEL01': { tugas: 62, kuis: 65, harian: 60, uts: 68, uas: 66 }, // remedial target (<75)
    'S005-MAPEL01': { tugas: 72, kuis: 70, harian: 73, uts: 74, uas: 75 }, // borderline
    'S001-MAPEL02': { tugas: 90, kuis: 85, harian: 92, uts: 88, uas: 90 },
    'S002-MAPEL02': { tugas: 98, kuis: 98, harian: 99, uts: 97, uas: 99 },
  });

  const [skillScores, setSkillScores] = useState<Record<string, { praktik: number; produk: number; proyek: number; portofolio: number }>>({
    'S001-MAPEL01': { praktik: 84, produk: 80, proyek: 85, portofolio: 88 },
    'S002-MAPEL01': { praktik: 92, produk: 95, proyek: 90, portofolio: 94 },
    'S003-MAPEL01': { praktik: 75, produk: 78, proyek: 80, portofolio: 76 },
    'S004-MAPEL01': { praktik: 68, produk: 70, proyek: 72, portofolio: 70 },
    'S005-MAPEL01': { praktik: 74, produk: 72, proyek: 75, portofolio: 76 },
  });

  const [attitudeScores, setAttitudeScores] = useState<Record<string, { observasi: 'SB' | 'B' | 'C' | 'PB'; jurnal: 'SB' | 'B' | 'C' | 'PB'; diri: 'SB' | 'B' | 'C' | 'PB'; sebaya: 'SB' | 'B' | 'C' | 'PB' }>>({
    'S001-MAPEL01': { observasi: 'SB', jurnal: 'B', diri: 'B', sebaya: 'SB' },
    'S002-MAPEL01': { observasi: 'SB', jurnal: 'SB', diri: 'SB', sebaya: 'SB' },
    'S003-MAPEL01': { observasi: 'B', jurnal: 'B', diri: 'B', sebaya: 'B' },
    'S004-MAPEL01': { observasi: 'B', jurnal: 'B', diri: 'C', sebaya: 'C' },
    'S005-MAPEL01': { observasi: 'B', jurnal: 'B', diri: 'B', sebaya: 'B' },
  });

  // Automated Remedial logs state
  const [remedialLogs, setRemedialLogs] = useState<Array<{
    id: string;
    studentId: string;
    studentName: string;
    subjectId: string;
    subjectName: string;
    oldScore: number;
    newScore: number;
    activity: string;
    date: string;
  }>>([
    { id: 'REM01', studentId: 'S003', studentName: 'Ali Zainal Abidin', subjectId: 'MAPEL06', subjectName: 'Matematika', oldScore: 62, newScore: 78, activity: 'Pengulangan Tes Mandiri dengan Pendampingan', date: '2026-06-15' }
  ]);

  // Automated Pengayaan logs state
  const [pengayaanLogs, setPengayaanLogs] = useState<Array<{
    id: string;
    studentId: string;
    studentName: string;
    subjectId: string;
    subjectName: string;
    score: number;
    activity: string;
    target: string;
    date: string;
    status: 'Dalam Proses' | 'Selesai';
  }>>([
    { id: 'PENG01', studentId: 'S002', studentName: 'Fatima Az-Zahra Ramadhani', subjectId: 'MAPEL01', subjectName: 'Aqidah Akhlak', score: 94.6, activity: 'Tutor Sebaya membantu Ali Zainal Abidin', target: 'Mampu menjelaskan adab birrul walidain secara verbal', date: '2026-06-16', status: 'Selesai' }
  ]);

  // Combined Dialog state for adding/editing scores
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [modalStudentId, setModalStudentId] = useState('');
  const [modalTab, setModalTab] = useState<'Kognitif' | 'Keterampilan' | 'Sikap'>('Kognitif');

  // Temporary dialog input states
  const [inputTugas, setInputTugas] = useState(80);
  const [inputKuis, setInputKuis] = useState(80);
  const [inputHarian, setInputHarian] = useState(80);
  const [inputUts, setInputUts] = useState(80);
  const [inputUas, setInputUas] = useState(80);

  const [inputPraktik, setInputPraktik] = useState(80);
  const [inputProduk, setInputProduk] = useState(80);
  const [inputProyek, setInputProyek] = useState(80);
  const [inputPortofolio, setInputPortofolio] = useState(80);

  const [inputObservasi, setInputObservasi] = useState<'SB' | 'B' | 'C' | 'PB'>('B');
  const [inputJurnal, setInputJurnal] = useState<'SB' | 'B' | 'C' | 'PB'>('B');
  const [inputDiri, setInputDiri] = useState<'SB' | 'B' | 'C' | 'PB'>('B');
  const [inputSebaya, setInputSebaya] = useState<'SB' | 'B' | 'C' | 'PB'>('B');
  const [inputNotes, setInputNotes] = useState('');

  // AI Narrative state (kept from original)
  const [isAiGenerating, setIsAiGenerating] = useState(false);
  const [aiDraftOutput, setAiDraftOutput] = useState('');
  const [aiSelectedStudentId, setAiSelectedStudentId] = useState('');

  // Remedial & Pengayaan action inputs
  const [selectedRemedialStudentId, setSelectedRemedialStudentId] = useState('');
  const [remedialActivity, setRemedialActivity] = useState('Bimbingan Belajar & Tes Ulang');
  const [remedialNewScore, setRemedialNewScore] = useState(78);

  const [selectedPengayaanStudentId, setSelectedPengayaanStudentId] = useState('');
  const [pengayaanActivity, setPengayaanActivity] = useState('Tugas Pendalaman Materi & Tutor Sebaya');
  const [pengayaanTarget, setPengayaanTarget] = useState('Daya nalar kritis analitis materi syariah');

  // Filter context
  const classStudents = students.filter(s => s.classroom === selectedClass);
  const currentSubject = subjects.find(sub => sub.id === selectedSubjectId);

  // Helper dynamic score getters:
  const getCognitive = (studentId: string) => {
    const key = `${studentId}-${selectedSubjectId}`;
    const local = cognitiveScores[key];
    if (local) return local;

    // Fallback to parent academic scores database
    const parent = academicScores.find(sc => sc.studentId === studentId && sc.subjectId === selectedSubjectId);
    if (parent) {
      return {
        tugas: parent.harian,
        kuis: parent.harian,
        harian: parent.harian,
        uts: parent.uts,
        uas: parent.uas
      };
    }
    return { tugas: 80, kuis: 80, harian: 80, uts: 80, uas: 80 };
  };

  const getSkill = (studentId: string) => {
    const key = `${studentId}-${selectedSubjectId}`;
    return skillScores[key] || { praktik: 80, produk: 80, proyek: 80, portofolio: 80 };
  };

  const getAttitude = (studentId: string) => {
    const key = `${studentId}-${selectedSubjectId}`;
    return attitudeScores[key] || { observasi: 'B', jurnal: 'B', diri: 'B', sebaya: 'B' };
  };

  // Arithmetic computations
  const getCognitiveAverage = (studentId: string) => {
    const c = getCognitive(studentId);
    // Formula: (Tugas 15% + Kuis 15% + Harian 30% + UTS 20% + UAS 20%)
    const score = (c.tugas * 0.15) + (c.kuis * 0.15) + (c.harian * 0.30) + (c.uts * 0.20) + (c.uas * 0.20);
    return Math.round(score * 10) / 10;
  };

  const getSkillsAverage = (studentId: string) => {
    const s = getSkill(studentId);
    // Simple average of all four categories
    const score = (s.praktik + s.produk + s.proyek + s.portofolio) / 4;
    return Math.round(score * 10) / 10;
  };

  const getFinalCombinedScore = (studentId: string) => {
    const cog = getCognitiveAverage(studentId);
    const skill = getSkillsAverage(studentId);
    // Standard kurikulum merdeka weighted ratio: 60% Pengetahuan (Kognitif) & 40% Keterampilan (Psikomotorik)
    const score = (cog * 0.6) + (skill * 0.4);
    return Math.round(score * 10) / 10;
  };

  const getAttitudePhrase = (studentId: string) => {
    const a = getAttitude(studentId);
    const count = { SB: 0, B: 0, C: 0, PB: 0 };
    count[a.observasi]++;
    count[a.jurnal]++;
    count[a.diri]++;
    count[a.sebaya]++;

    // Majority check or standard fallback
    if (count.SB >= 2) return 'Sangat Baik (SB)';
    if (count.PB >= 1) return 'Perlu Bimbingan (PB)';
    if (count.C >= 2) return 'Cukup (C)';
    return 'Baik (B)';
  };

  // Sync back to parent database
  const syncWithParentDatabase = (studentId: string) => {
    const stu = students.find(s => s.id === studentId);
    if (!stu || !currentSubject) return;

    const cog = getCognitive(studentId);
    const finalScoreVal = getFinalCombinedScore(studentId);
    
    // Find comments of existing parent node
    const existingParent = academicScores.find(sc => sc.studentId === studentId && sc.subjectId === selectedSubjectId);
    const finalNotesStr = existingParent?.notes || `Menunjukkan pemahaman yang sangat akseptabel dalam mapel ${currentSubject.name}.`;

    const scoreData: AcademicScore = {
      id: existingParent?.id || 'N' + Math.floor(Math.random() * 1000).toString().padStart(3, '0'),
      studentId: studentId,
      studentName: stu.name,
      classroom: selectedClass,
      subjectId: selectedSubjectId,
      subjectName: currentSubject.name,
      harian: cog.harian, // Maps to main harian field
      uts: cog.uts,
      uas: cog.uas,
      finalScore: finalScoreVal,
      notes: finalNotesStr
    };

    if (existingParent) {
      onEditScore(scoreData);
    } else {
      onAddScore(scoreData);
    }
  };

  // Open multi-attribute slider modal for editing pupil's stats
  const handleOpenEditModal = (studentId: string) => {
    setModalStudentId(studentId);
    setModalTab('Kognitif');

    const cog = getCognitive(studentId);
    setInputTugas(cog.tugas);
    setInputKuis(cog.kuis);
    setInputHarian(cog.harian);
    setInputUts(cog.uts);
    setInputUas(cog.uas);

    const s = getSkill(studentId);
    setInputPraktik(s.praktik);
    setInputProduk(s.produk);
    setInputProyek(s.proyek);
    setInputPortofolio(s.portofolio);

    const a = getAttitude(studentId);
    setInputObservasi(a.observasi);
    setInputJurnal(a.jurnal);
    setInputDiri(a.diri);
    setInputSebaya(a.sebaya);

    // Notes
    const parentScore = academicScores.find(sc => sc.studentId === studentId && sc.subjectId === selectedSubjectId);
    setInputNotes(parentScore?.notes || '');

    setIsEditModalOpen(true);
  };

  // Save Modal States
  const handleSaveModalScore = (e: React.FormEvent) => {
    e.preventDefault();
    if (!modalStudentId) return;

    // Save Cognitive
    const cogKey = `${modalStudentId}-${selectedSubjectId}`;
    setCognitiveScores(prev => ({
      ...prev,
      [cogKey]: { tugas: inputTugas, kuis: inputKuis, harian: inputHarian, uts: inputUts, uas: inputUas }
    }));

    // Save Skill
    setSkillScores(prev => ({
      ...prev,
      [cogKey]: { praktik: inputPraktik, produk: inputProduk, proyek: inputProyek, portofolio: inputPortofolio }
    }));

    // Save Attitude
    setAttitudeScores(prev => ({
      ...prev,
      [cogKey]: { observasi: inputObservasi, jurnal: inputJurnal, diri: inputDiri, sebaya: inputSebaya }
    }));

    // Close Modal
    setIsEditModalOpen(false);

    // Sync state
    setTimeout(() => {
      syncWithParentDatabase(modalStudentId);
      // If parent comments need updating as well:
      const existingParent = academicScores.find(sc => sc.studentId === modalStudentId && sc.subjectId === selectedSubjectId);
      const stuObj = students.find(s => s.id === modalStudentId);
      if (existingParent && stuObj && currentSubject) {
        onEditScore({
          ...existingParent,
          notes: inputNotes || existingParent.notes
        });
      }
    }, 50);
  };

  // Execute Gemini AI Narrative Generation
  const handleGenerateAiReport = async (studentId: string) => {
    const studentObj = students.find(s => s.id === studentId);
    if (!studentObj) return;

    setAiSelectedStudentId(studentId);
    setIsAiGenerating(true);
    setAiDraftOutput('');

    const finalVal = getFinalCombinedScore(studentId);
    const notesInput = inputNotes || `Santri berprestasi baik, ketaatan ibadah ${studentObj.shalatPoin}%.`;

    try {
      const response = await fetch('/api/gemini/evaluate-character', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          studentName: studentObj.name,
          classroom: studentObj.classroom,
          academicScore: finalVal,
          shalatScore: studentObj.shalatPoin,
          notes: notesInput
        })
      });
      const data = await response.json();
      if (data.content) {
        setAiDraftOutput(data.content);
        setInputNotes(data.content);
      }
    } catch (err) {
      console.error("AI Generation failed", err);
      setAiDraftOutput("Ustadz/Ustadzah, sistem mengalami ketidakstabilan jaringan sementara. Namun siswa ini terbukti tekun, hormat kepada pengajar, rajin menyelesaikan tugas tepat waktu, dan memiliki kedewasaan adab Islami yang tulus.");
      setInputNotes("Terbukti tekun, hormat kepada pengajar, rajin menyelesaikan tugas tepat waktu, dan memiliki kedewasaan adab Islami yang tulus.");
    } finally {
      setIsAiGenerating(false);
    }
  };

  // Execute automated interactive Remedial
  const handleExecuteRemedial = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedRemedialStudentId || !currentSubject) return;

    const studentObj = students.find(s => s.id === selectedRemedialStudentId);
    if (!studentObj) return;

    const oldScoreVal = getFinalCombinedScore(selectedRemedialStudentId);

    // Update Local Cognitive score values (boosting average to achieve the new score)
    const key = `${selectedRemedialStudentId}-${selectedSubjectId}`;
    setCognitiveScores(prev => ({
      ...prev,
      [key]: {
        tugas: Math.max(75, remedialNewScore),
        kuis: Math.max(75, remedialNewScore),
        harian: Math.max(75, remedialNewScore),
        uts: Math.max(75, remedialNewScore),
        uas: Math.max(75, remedialNewScore)
      }
    }));

    // Record Remedial execution log
    const newRemLog = {
      id: 'REM' + Math.floor(Math.random() * 1000).toString(),
      studentId: selectedRemedialStudentId,
      studentName: studentObj.name,
      subjectId: selectedSubjectId,
      subjectName: currentSubject.name,
      oldScore: oldScoreVal,
      newScore: remedialNewScore,
      activity: remedialActivity,
      date: new Date().toISOString().split('T')[0]
    };

    setRemedialLogs(prev => [newRemLog, ...prev]);

    // Update parent database
    setTimeout(() => {
      syncWithParentDatabase(selectedRemedialStudentId);
      // Give custom appraisal review logs
      const parentScore = academicScores.find(sc => sc.studentId === selectedRemedialStudentId && sc.subjectId === selectedSubjectId);
      if (parentScore) {
        onEditScore({
          ...parentScore,
          notes: `Telah menempuh program remedial (${remedialActivity}) pada tanggal ${newRemLog.date} dengan hasil tuntas kriteria ketuntasan minimal.`
        });
      }
      setSelectedRemedialStudentId('');
      alert(`Alhamdulillah, santri ${studentObj.name} berhasil dituntaskan melalui Program Remedial! Sesi diperbarui.`);
    }, 100);
  };

  // Execute Enrichment Registration
  const handleRegisterPengayaan = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPengayaanStudentId || !currentSubject) return;

    const studentObj = students.find(s => s.id === selectedPengayaanStudentId);
    if (!studentObj) return;

    const currentFinal = getFinalCombinedScore(selectedPengayaanStudentId);

    const newPenLog = {
      id: 'PENG' + Math.floor(Math.random() * 1000).toString(),
      studentId: selectedPengayaanStudentId,
      studentName: studentObj.name,
      subjectId: selectedSubjectId,
      subjectName: currentSubject.name,
      score: currentFinal,
      activity: pengayaanActivity,
      target: pengayaanTarget,
      date: new Date().toISOString().split('T')[0],
      status: 'Dalam Proses' as const
    };

    setPengayaanLogs(prev => [newPenLog, ...prev]);
    setSelectedPengayaanStudentId('');
    alert(`Sukses menambahkan santri ${studentObj.name} ke Program Pengayaan Akademis.`);
  };

  const handleFinishPengayaan = (logId: string) => {
    setPengayaanLogs(prev => prev.map(log => log.id === logId ? { ...log, status: 'Selesai' } : log));
    alert('Alhamdulillah! Program pengayaan santri terkait sukses diselesaikan secara paripurna.');
  };

  // Cetak Laporan Nilai - Direct Downloads simulating high fidelity exports
  const handleExportCSV = () => {
    if (!currentSubject) return;
    let csvContent = "data:text/csv;charset=utf-8,";
    csvContent += "No,Nama Lengkap,NIS,Nilai Pengetahuan,Nilai Keterampilan,Nilai Sikap,Nilai Rapor Akhir,Ketuntasan\n";
    
    classStudents.forEach((st, idx) => {
      const cogAvg = getCognitiveAverage(st.id);
      const skillAvg = getSkillsAverage(st.id);
      const att = getAttitudePhrase(st.id);
      const final = getFinalCombinedScore(st.id);
      const status = final >= 75 ? "Tuntas" : "Remedial";
      csvContent += `"${idx + 1}","${st.name}","${st.nis}","${cogAvg}","${skillAvg}","${att}","${final}","${status}"\n`;
    });
    
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `Laporan_Nilai_Modul6_${selectedClass.replace(" ", "_")}_${currentSubject.name.replace(" ", "_")}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleExportWord = () => {
    if (!currentSubject) return;
    let docContent = `
      <html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'>
      <head><title>REKAP LAPORAN NILAI - SD ISLAM AL FARABY</title><style>body {font-family: Arial; padding: 20px;} table {width: 100%; border-collapse: collapse;} th, td {border: 1.5px solid #000; padding: 8px;} th {background-color: #f2f2f2;}</style></head>
      <body>
      <h2 style='text-align: center; margin-bottom: 0px;'>SD ISLAM AL FARABY BOGOR</h2>
      <p style='text-align: center; font-style: italic; font-size: 11px; margin-top: 5px; margin-bottom: 20px;'>"Unggul dalam Adab, Cerdas dalam Pengetahuan"</p>
      <h3 style='text-align: center;'>REKAPITULASI PROGRAM EVALUASI & PENILAIAN MASSA</h3>
      
      <table style='border: none; margin-bottom: 15px;'>
        <tr><td style='border: none; width: 120px;'><b>Mata Pelajaran:</b></td><td style='border: none;'>${currentSubject.name} (${currentSubject.code})</td></tr>
        <tr><td style='border: none;'><b>Kelas / Fase:</b></td><td style='border: none;'>${selectedClass} / ${currentSubject.fase || 'B'}</td></tr>
        <tr><td style='border: none;'><b>Tahun Pelajaran:</b></td><td style='border: none;'>2026/2027 Ganjil</td></tr>
      </table>

      <table>
        <thead>
          <tr style='background-color: #e6f4ea;'>
            <th>No</th>
            <th>Nama Lengkap Santri</th>
            <th>NIS</th>
            <th>Rerata Pengetahuan</th>
            <th>Rerata Keterampilan</th>
            <th>Predikat Sikap</th>
            <th>Nilai Rapor Akhir</th>
            <th>Status Ketuntasan</th>
          </tr>
        </thead>
        <tbody>
    `;
    
    classStudents.forEach((st, idx) => {
      const cogAvg = getCognitiveAverage(st.id);
      const skillAvg = getSkillsAverage(st.id);
      const att = getAttitudePhrase(st.id);
      const final = getFinalCombinedScore(st.id);
      const status = final >= 75 ? "Tuntas (MEMENUHI)" : "Remedial (BIMBINGAN)";
      docContent += `
        <tr>
          <td style='text-align: center;'>${idx + 1}</td>
          <td><b>${st.name}</b></td>
          <td style='text-align: center;'>${st.nis}</td>
          <td style='text-align: center;'>${cogAvg}</td>
          <td style='text-align: center;'>${skillAvg}</td>
          <td style='text-align: center;'>${att}</td>
          <td style='text-align: center; font-weight: bold;'>${final}</td>
          <td style='text-align: center; color: ${final >= 75 ? 'green' : 'red'};'>${status}</td>
        </tr>
      `;
    });
    
    docContent += `
        </tbody>
      </table>
      <div style='margin-top: 40px; float: right; width: 250px; text-align: center;'>
         <p>Bogor, ${new Date().toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' })}</p>
         <p>Guru Bidang Studi</p>
         <br/><br/><br/>
         <p><b>Siti Nurhaliza, S.Pd.I.</b><br/>NIP. 198506122010011002</p>
      </div>
      </body>
      </html>
    `;
    
    const blob = new Blob(['\ufeff' + docContent], {
      type: 'application/msword;charset=utf-8'
    });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `Recap_Nilai_Modul6_${selectedClass.replace(" ", "_")}_${currentSubject.name.replace(" ", "_")}.doc`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handlePrintDocument = () => {
    // Elegant simulation of browser print layout context
    window.print();
  };

  // Compute stats for Analysis tab
  const totalStudents = classStudents.length;
  const classAveragesList = classStudents.map(st => getFinalCombinedScore(st.id));
  const classAverage = totalStudents > 0 ? Math.round((classAveragesList.reduce((a, b) => a + b, 0) / totalStudents) * 10) / 10 : 0;
  const masteredCount = classStudents.filter(st => getFinalCombinedScore(st.id) >= 75).length;
  const masteryPercentage = totalStudents > 0 ? Math.round((masteredCount / totalStudents) * 100) : 0;
  const remedialCount = totalStudents - masteredCount;

  // Recharts data formatters
  const chartData = classStudents.map(st => ({
    name: st.name.split(' ').slice(0, 2).join(' '),
    'Nilai Pengetahuan': getCognitiveAverage(st.id),
    'Nilai Keterampilan': getSkillsAverage(st.id),
    'Rapor Akhir': getFinalCombinedScore(st.id)
  }));

  // Analyze indicators class averages
  const getSubIndicatorClassAvg = (field: 'tugas' | 'kuis' | 'harian' | 'uts' | 'uas') => {
    if (totalStudents === 0) return 0;
    const sum = classStudents.reduce((acc, st) => acc + getCognitive(st.id)[field], 0);
    return Math.round((sum / totalStudents) * 10) / 10;
  };

  const indicatorAverages = {
    tugas: getSubIndicatorClassAvg('tugas'),
    kuis: getSubIndicatorClassAvg('kuis'),
    harian: getSubIndicatorClassAvg('harian'),
    uts: getSubIndicatorClassAvg('uts'),
    uas: getSubIndicatorClassAvg('uas')
  };

  // Find lowest and highest indicator to highlight remedial / teaching adjustments
  const indicatorKeys = Object.keys(indicatorAverages) as Array<keyof typeof indicatorAverages>;
  let weakestIndicator = indicatorKeys[0];
  let strongestIndicator = indicatorKeys[0];
  indicatorKeys.forEach(k => {
    if (indicatorAverages[k] < indicatorAverages[weakestIndicator]) weakestIndicator = k;
    if (indicatorAverages[k] > indicatorAverages[strongestIndicator]) strongestIndicator = k;
  });

  const getIndicatorLabel = (name: string) => {
    switch(name) {
      case 'tugas': return 'Tugas Mandiri';
      case 'kuis': return 'Kuis Harian';
      case 'harian': return 'Sumatif Harian';
      case 'uts': return 'Tengah Semester (UTS)';
      case 'uas': return 'Akhir Semester (UAS)';
      default: return name;
    }
  };

  return (
    <div id="penilaian-view-wrapper" className="space-y-6">
      
      {/* SECTION HEADER */}
      <div className="flex flex-col xl:flex-row xl:items-center justify-between pb-4 border-b border-slate-200 gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="bg-emerald-100 text-emerald-800 text-xxxxs uppercase font-extrabold px-2.5 py-1 rounded-full">
              Modul 6
            </span>
            <h2 className="text-lg font-bold text-slate-800 school-display">
              Administrasi Penilaian & Analisis Rapor Siswa
            </h2>
          </div>
          <p className="text-xxs text-slate-500 mt-1">
            Kelola Penilaian Pengetahuan, Keterampilan, Evaluasi Sikap Akhlak Terpadu, Program Remedial/Pengayaan serta Ekspor Data.
          </p>
        </div>

        {/* Global Filter Toolbar */}
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center gap-1 bg-white border border-slate-200 rounded-xl px-2 py-1 shadow-xxs">
            <span className="text-[10px] text-slate-400 font-bold px-1 uppercase">Kelas</span>
            <select
              value={selectedClass}
              onChange={e => setSelectedClass(e.target.value)}
              className="text-xs font-semibold text-slate-700 bg-transparent pr-4 py-1 cursor-pointer focus:outline-none border-none"
            >
              <option value="Kelas 4A">Kelas 4A</option>
              <option value="Kelas 4B">Kelas 4B</option>
              <option value="Kelas 5">Kelas 5</option>
              <option value="Kelas 6">Kelas 6</option>
            </select>
          </div>
          
          <div className="flex items-center gap-1 bg-white border border-slate-200 rounded-xl px-2 py-1 shadow-xxs">
            <span className="text-[10px] text-slate-400 font-bold px-1 uppercase">Mapel</span>
            <select
              value={selectedSubjectId}
              onChange={e => setSelectedSubjectId(e.target.value)}
              className="text-xs font-semibold text-slate-700 bg-transparent pr-4 py-1 max-w-[150px] sm:max-w-xs truncate cursor-pointer focus:outline-none border-none"
            >
              {subjects.map(s => (
                <option key={s.id} value={s.id}>{s.name}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* SUBTAB HORIZONTAL NAVIGATION BAR */}
      <div className="overflow-x-auto pb-1">
        <div className="flex items-center gap-1.5 border-b border-gray-200 min-w-max">
          <button
            onClick={() => setActiveSubTab('Kognitif')}
            className={`px-4 py-2.5 text-xs font-bold transition flex items-center gap-1.5 border-b-2 ${
              activeSubTab === 'Kognitif'
                ? 'border-brand-green-700 text-brand-green-800'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <BookOpen className="h-4 w-4" />
            1. Penilaian Pengetahuan
          </button>
          
          <button
            onClick={() => setActiveSubTab('Keterampilan')}
            className={`px-4 py-2.5 text-xs font-bold transition flex items-center gap-1.5 border-b-2 ${
              activeSubTab === 'Keterampilan'
                ? 'border-brand-green-700 text-brand-green-800'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Layers className="h-4 w-4" />
            2. Penilaian Keterampilan
          </button>
          
          <button
            onClick={() => setActiveSubTab('Sikap')}
            className={`px-4 py-2.5 text-xs font-bold transition flex items-center gap-1.5 border-b-2 ${
              activeSubTab === 'Sikap'
                ? 'border-brand-green-700 text-brand-green-800'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Smile className="h-4 w-4" />
            3. Penilaian Sikap
          </button>

          <button
            onClick={() => setActiveSubTab('Analisis')}
            className={`px-4 py-2.5 text-xs font-bold transition flex items-center gap-1.5 border-b-2 ${
              activeSubTab === 'Analisis'
                ? 'border-brand-green-700 text-brand-green-800'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <BarChart3 className="h-4 w-4" />
            4. Analisis Nilai
          </button>

          <button
            onClick={() => setActiveSubTab('Remedial')}
            className={`px-4 py-2.5 text-xs font-bold transition flex items-center gap-1.5 border-b-2 ${
              activeSubTab === 'Remedial'
                ? 'border-brand-green-700 text-brand-green-800'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <AlertCircle className="h-4 w-4 text-rose-500" />
            5. Program Remedial
            {remedialCount > 0 && (
              <span className="bg-rose-500 text-white text-[9px] font-extrabold px-1.5 py-0.5 rounded-full">
                {remedialCount}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveSubTab('Pengayaan')}
            className={`px-4 py-2.5 text-xs font-bold transition flex items-center gap-1.5 border-b-2 ${
              activeSubTab === 'Pengayaan'
                ? 'border-brand-green-700 text-brand-green-800'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Award className="h-4 w-4 text-amber-500" />
            6. Program Pengayaan
          </button>

          <button
            onClick={() => setActiveSubTab('Cetak')}
            className={`px-4 py-2.5 text-xs font-bold transition flex items-center gap-1.5 border-b-2 ${
              activeSubTab === 'Cetak'
                ? 'border-brand-green-700 text-brand-green-800'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Printer className="h-4 w-4" />
            7. Laporan & Cetak Rapor
          </button>
        </div>
      </div>

      {/* CORE DISPLAY WORKSPACE CHANGING BY ACTIVE SUBTAB */}

      {/* TAB 1: PENILAIAN PENGETAHUAN */}
      {activeSubTab === 'Kognitif' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 animate-in fade-in duration-100">
          
          {/* Main Grade inputs */}
          <div className="bg-white rounded-2xl border border-slate-100 shadow-xxs overflow-hidden lg:col-span-2">
            <div className="p-4 bg-slate-50/70 border-b border-slate-100 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <BookOpen className="h-4.5 w-4.5 text-brand-green-700" />
                <span className="text-xs font-bold text-slate-700">
                  Daftar Nilai Kognitif ({selectedClass} &bull; {currentSubject?.name})
                </span>
              </div>
              <span className="text-[10px] text-slate-400 font-bold uppercase italic">Bobot: T-15% | K-15% | H-30% | UTS-20% | UAS-20%</span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-gray-100 bg-slate-50 text-slate-400 font-bold uppercase text-[10px]">
                    <th className="p-4">Santri</th>
                    <th className="p-4 text-center">Tugas (15%)</th>
                    <th className="p-4 text-center">Kuis (15%)</th>
                    <th className="p-4 text-center">Sumatif Har (30%)</th>
                    <th className="p-4 text-center">UTS/Mid (20%)</th>
                    <th className="p-4 text-center">UAS/End (20%)</th>
                    <th className="p-4 text-center bg-emerald-50 text-emerald-800">Rata-rata</th>
                    <th className="p-4 text-right">Aksi</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-slate-700">
                  {classStudents.map(student => {
                    const cog = getCognitive(student.id);
                    const avg = getCognitiveAverage(student.id);
                    return (
                      <tr key={student.id} className="hover:bg-slate-50/30 transition-colors">
                        <td className="p-4">
                          <div className="font-bold text-slate-800">{student.name}</div>
                          <div className="text-[10px] text-slate-400">NIS: {student.nis}</div>
                        </td>
                        <td className="p-4 text-center font-medium">{cog.tugas}</td>
                        <td className="p-4 text-center font-medium">{cog.kuis}</td>
                        <td className="p-4 text-center font-medium">{cog.harian}</td>
                        <td className="p-4 text-center font-medium">{cog.uts}</td>
                        <td className="p-4 text-center font-medium">{cog.uas}</td>
                        <td className="p-4 text-center font-display font-extrabold text-brand-green-800 bg-brand-green-50/20">
                          {avg}
                        </td>
                        <td className="p-4 text-right">
                          <div className="flex gap-1.5 justify-end">
                            <button
                              onClick={() => handleOpenEditModal(student.id)}
                              className="bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold px-2.5 py-1.5 rounded-lg text-xxxxs uppercase tracking-wider transition cursor-pointer"
                            >
                              Suntik Nilai
                            </button>
                            <button
                              onClick={() => handleGenerateAiReport(student.id)}
                              className="bg-brand-gold-50 hover:bg-brand-gold-100 text-brand-gold-800 font-bold px-2 py-1 rounded-lg text-xxxxs uppercase tracking-wider flex items-center gap-1 transition cursor-pointer"
                              title="Analisis narasi raport otomatis via Gemini"
                            >
                              <Sparkles className="h-3 w-3 text-brand-gold-600 fill-brand-gold-500" />
                              AI Narasi
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* AI Narasi Sidebar panel */}
          <div className="bg-white rounded-2xl border border-slate-100 shadow-xxs p-5 flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2 pb-3 border-b border-slate-100 mb-4">
                <Sparkles className="h-4.5 w-4.5 text-brand-gold-500 fill-brand-gold-500" />
                <h3 className="font-bold text-xs text-slate-800 font-display uppercase tracking-wide">
                  Gemini AI Rapor Commentary
                </h3>
              </div>

              {aiSelectedStudentId ? (
                <div className="space-y-4">
                  <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 text-xxs">
                    <span className="text-[10px] text-slate-400 font-bold uppercase block">Menyusun Catatan G-Suite Rapor:</span>
                    <span className="font-extrabold text-slate-800 text-xs block mt-0.5">
                      {students.find(s => s.id === aiSelectedStudentId)?.name}
                    </span>
                    <span className="text-[10px] text-brand-green-700 block mt-1">
                      Nilai Pengetahuan: {getCognitiveAverage(aiSelectedStudentId)} &bull; Ibadah Shalat: {students.find(s => s.id === aiSelectedStudentId)?.shalatPoin}%
                    </span>
                  </div>

                  <div className="bg-brand-green-50/30 p-4 rounded-xl border border-brand-green-100">
                    <span className="text-[9px] font-bold text-brand-green-800 uppercase block tracking-wider mb-2">Draf Evaluasi Tarbiyah:</span>
                    {isAiGenerating ? (
                      <div className="space-y-2 py-8 text-center">
                        <RotateCw className="h-6 w-6 animate-spin text-brand-gold-700 mx-auto" />
                        <span className="text-[10px] text-slate-500 block">Menghubungkan kecerdasan santri...</span>
                      </div>
                    ) : (
                      <div className="space-y-3">
                        <textarea
                          rows={10}
                          className="w-full text-xxs p-3 bg-white border border-slate-200 rounded-lg text-slate-700 leading-relaxed focus:ring-1 focus:ring-emerald-500 focus:outline-none"
                          value={aiDraftOutput}
                          onChange={e => setAiDraftOutput(e.target.value)}
                        />
                        <p className="text-[9px] text-slate-400 leading-normal italic">
                          * Draf di atas dirakit otomatis dengan adab islami kurikulum Birrul Walidain. Ustadz dapat mengoreksi sebelum menyimpan.
                        </p>
                      </div>
                    )}
                  </div>
                </div>
              ) : (
                <div className="py-16 text-center text-slate-400 text-xs flex flex-col items-center justify-center space-y-3">
                  <div className="w-12 h-12 bg-slate-50 rounded-full flex items-center justify-center">
                    <Award className="h-6 w-6 text-slate-300" />
                  </div>
                  <div className="font-semibold text-slate-500">Asisten Narasi Rapor Aktif</div>
                  <p className="text-xxxxs text-slate-400 max-w-xs mx-auto leading-normal">
                    Silakan klik tombol <span className="text-brand-gold-700 font-bold">"AI Narasi"</span> di baris santri terkait. Sistem akan memindai nilai akademis & poin karakter dhuha untuk merancang deskripsi raport bernilai mulia secara instan.
                  </p>
                </div>
              )}
            </div>

            {aiDraftOutput && aiSelectedStudentId && (
              <div className="mt-4 pt-4 border-t border-slate-100 flex items-center justify-end gap-2 text-xxs">
                <button
                  type="button"
                  onClick={() => { setAiDraftOutput(''); setAiSelectedStudentId(''); }}
                  className="px-3 py-2 font-bold text-slate-500 hover:text-slate-800 cursor-pointer"
                >
                  Reset
                </button>
                <button
                  type="button"
                  onClick={() => {
                    const existingParent = academicScores.find(sc => sc.studentId === aiSelectedStudentId && sc.subjectId === selectedSubjectId);
                    const stuObj = students.find(s => s.id === aiSelectedStudentId);
                    if (stuObj && currentSubject) {
                      const cog = getCognitive(aiSelectedStudentId);
                      const scoreData: AcademicScore = {
                        id: existingParent?.id || 'N' + Math.floor(Math.random() * 1000).toString().padStart(3, '0'),
                        studentId: aiSelectedStudentId,
                        studentName: stuObj.name,
                        classroom: selectedClass,
                        subjectId: selectedSubjectId,
                        subjectName: currentSubject.name,
                        harian: cog.harian,
                        uts: cog.uts,
                        uas: cog.uas,
                        finalScore: getFinalCombinedScore(aiSelectedStudentId),
                        notes: aiDraftOutput
                      };
                      if (existingParent) onEditScore(scoreData);
                      else onAddScore(scoreData);
                      alert(`Alhamdulillah, narasi khusus sukses diterapkan ke raport ${stuObj.name}!`);
                      setAiDraftOutput('');
                      setAiSelectedStudentId('');
                    }
                  }}
                  className="bg-brand-green-700 hover:bg-brand-green-800 text-white font-bold px-4 py-2 rounded-xl shadow-xxs transition cursor-pointer"
                >
                  Terapkan Ke Rapor
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 2: PENILAIAN KETERAMPILAN */}
      {activeSubTab === 'Keterampilan' && (
        <div className="bg-white rounded-2xl border border-slate-100 shadow-xxs overflow-hidden animate-in fade-in duration-100">
          <div className="p-4 bg-slate-50/70 border-b border-slate-100 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Layers className="h-4.5 w-4.5 text-brand-green-700" />
              <span className="text-xs font-bold text-slate-700">
                Pencatatan Portofolio & Penilaian Keterampilan Siswa ({selectedClass})
              </span>
            </div>
            <span className="text-[10px] text-slate-400 font-bold uppercase italic">Aspek Psikomotorik (Bobot Rata-rata Sama / Seimbang)</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-gray-100 bg-slate-50 text-slate-400 font-bold uppercase text-[10px]">
                  <th className="p-4">Santri</th>
                  <th className="p-4 text-center">Praktik (Perfomance)</th>
                  <th className="p-4 text-center">Produk (Hasil Karya)</th>
                  <th className="p-4 text-center">Proyek (Kolaborasi)</th>
                  <th className="p-4 text-center">Portofolio (Berkas)</th>
                  <th className="p-4 text-center bg-teal-50 text-teal-800">Rerata Keterampilan</th>
                  <th className="p-4 text-right header-action">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700">
                {classStudents.map(student => {
                  const s = getSkill(student.id);
                  const avg = getSkillsAverage(student.id);
                  return (
                    <tr key={student.id} className="hover:bg-slate-50/30 transition-colors">
                      <td className="p-4">
                        <div className="font-bold text-slate-800">{student.name}</div>
                        <div className="text-[10px] text-slate-400">NIS: {student.nis}</div>
                      </td>
                      <td className="p-4 text-center font-medium">{s.praktik}</td>
                      <td className="p-4 text-center font-medium">{s.produk}</td>
                      <td className="p-4 text-center font-medium">{s.proyek}</td>
                      <td className="p-4 text-center font-medium">{s.portofolio}</td>
                      <td className="p-4 text-center font-display font-extrabold text-teal-800 bg-teal-50/20">
                        {avg}
                      </td>
                      <td className="p-4 text-right">
                        <button
                          onClick={() => {
                            handleOpenEditModal(student.id);
                            setTimeout(() => setModalTab('Keterampilan'), 50);
                          }}
                          className="bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold px-3 py-1.5 rounded-lg text-xxxxs uppercase tracking-wider cursor-pointer"
                        >
                          Suntik Nilai
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 3: PENILAIAN SIKAP */}
      {activeSubTab === 'Sikap' && (
        <div className="bg-white rounded-2xl border border-slate-100 shadow-xxs overflow-hidden animate-in fade-in duration-100">
          <div className="p-4 bg-slate-50/70 border-b border-slate-100 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Smile className="h-4.5 w-4.5 text-brand-green-700" />
              <span className="text-xs font-bold text-slate-700">
                Pemantauan Karakter Akhlak & Adab Harian Santri ({selectedClass})
              </span>
            </div>
            <span className="text-[10px] text-slate-400 font-bold uppercase italic">Kategori Kualitatif: SB (Sangat Baik) | B (Baik) | C (Cukup) | PB (Perlu Bimbingan)</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-gray-100 bg-slate-50 text-slate-400 font-bold uppercase text-[10px]">
                  <th className="p-4">Santri</th>
                  <th className="p-4 text-center">Observasi Guru</th>
                  <th className="p-4 text-center">Jurnal Perilaku</th>
                  <th className="p-4 text-center">Penilaian Diri (Swat)</th>
                  <th className="p-4 text-center">Penilaian Teman Sebaya</th>
                  <th className="p-4 text-center bg-amber-50 text-amber-800">Konklusi Deskriptif</th>
                  <th className="p-4 text-right">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700">
                {classStudents.map(student => {
                  const a = getAttitude(student.id);
                  const predikatText = getAttitudePhrase(student.id);
                  
                  const renderBadge = (valObj: 'SB' | 'B' | 'C' | 'PB') => {
                    switch(valObj) {
                      case 'SB': return <span className="bg-emerald-100 text-emerald-800 font-extrabold px-2 py-0.5 rounded-full text-xxxxs">SB</span>;
                      case 'B': return <span className="bg-blue-100 text-blue-800 font-extrabold px-2 py-0.5 rounded-full text-xxxxs">B</span>;
                      case 'C': return <span className="bg-orange-100 text-orange-800 font-extrabold px-2 py-0.5 rounded-full text-xxxxs">C</span>;
                      case 'PB': return <span className="bg-rose-100 text-rose-800 font-extrabold px-2 py-0.5 rounded-full text-xxxxs">PB</span>;
                      default: return <span>-</span>;
                    }
                  };

                  return (
                    <tr key={student.id} className="hover:bg-slate-50/30 transition-colors">
                      <td className="p-4">
                        <div className="font-bold text-slate-800">{student.name}</div>
                        <div className="text-[10px] text-slate-400">NIS: {student.nis}</div>
                      </td>
                      <td className="p-4 text-center">{renderBadge(a.observasi)}</td>
                      <td className="p-4 text-center">{renderBadge(a.jurnal)}</td>
                      <td className="p-4 text-center">{renderBadge(a.diri)}</td>
                      <td className="p-4 text-center">{renderBadge(a.sebaya)}</td>
                      <td className="p-4 text-center font-bold text-slate-800 bg-amber-50/10">
                        {predikatText}
                      </td>
                      <td className="p-4 text-right">
                        <button
                          onClick={() => {
                            handleOpenEditModal(student.id);
                            setTimeout(() => setModalTab('Sikap'), 50);
                          }}
                          className="bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold px-3 py-1.5 rounded-lg text-xxxxs uppercase tracking-wider cursor-pointer"
                        >
                          Suntik Nilai
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 4: ANALISIS NILAI (DIAGNOSTIC VIEW WITH CHARTS) */}
      {activeSubTab === 'Analisis' && (
        <div id="analisis-dashboard-section" className="space-y-6 animate-in fade-in duration-100">
          
          {/* STATS DECK */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            
            <div className="bg-white rounded-2xl border border-slate-100 shadow-xxs p-4 flex items-center gap-4">
              <div className="w-10 h-10 bg-emerald-100 rounded-xl flex items-center justify-center text-emerald-700 shadow-xxs">
                <TrendingUp className="h-5 w-5" />
              </div>
              <div>
                <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Rata-Rata Kelas</span>
                <h4 className="text-lg font-black text-slate-800 mt-0.5">{classAverage} <span className="text-xxs font-normal text-slate-400">/ 100</span></h4>
              </div>
            </div>

            <div className="bg-white rounded-2xl border border-slate-100 shadow-xxs p-4 flex items-center gap-4">
              <div className="w-10 h-10 bg-teal-100 rounded-xl flex items-center justify-center text-teal-700 shadow-xxs">
                <CheckCircle2 className="h-5 w-5" />
              </div>
              <div>
                <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Ketuntasan (KKTP &ge; 75)</span>
                <h4 className="text-lg font-black text-slate-800 mt-0.5">{masteryPercentage}% <span className="text-xxs font-normal text-slate-400">Tuntas</span></h4>
              </div>
            </div>

            <div className="bg-white rounded-2xl border border-slate-100 shadow-xxs p-4 flex items-center gap-4">
              <div className="w-10 h-10 bg-blue-100 rounded-xl flex items-center justify-center text-blue-700 shadow-xxs">
                <UserCheck className="h-5 w-5" />
              </div>
              <div>
                <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Santri Memenuhi</span>
                <h4 className="text-lg font-black text-slate-800 mt-0.5">{masteredCount} <span className="text-xxs font-normal text-slate-400">/ {totalStudents} Santri</span></h4>
              </div>
            </div>

            <div className="bg-white rounded-2xl border border-slate-100 shadow-xxs p-4 flex items-center gap-4">
              <div className="w-10 h-10 bg-rose-100 rounded-xl flex items-center justify-center text-rose-700 shadow-xxs">
                <AlertCircle className="h-5 w-5" />
              </div>
              <div>
                <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Butuh Remedial</span>
                <h4 className="text-lg font-black text-rose-700 mt-0.5">{remedialCount} <span className="text-xxs font-normal text-slate-400">Santri</span></h4>
              </div>
            </div>
          </div>

          {/* MAIN GRAPH DECK */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            {/* Recharts Graphical comparison */}
            <div className="bg-white rounded-2xl border border-slate-100 shadow-xxs p-5 lg:col-span-2">
              <h3 className="text-xs font-bold text-slate-800 font-display uppercase tracking-wider mb-4 flex items-center gap-1.5">
                <BarChart3 className="h-4.5 w-4.5 text-brand-green-700" />
                Grafik Kompetensi Capaian Santri
              </h3>
              
              <div className="h-80 w-full text-xs">
                {totalStudents > 0 ? (
                  <ResponsiveContainer width="100%" height="100%">
                    <ComposedChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                      <XAxis dataKey="name" stroke="#94a3b8" fontSize={9} tickLine={false} />
                      <YAxis stroke="#94a3b8" domain={[40, 100]} fontSize={9} tickLine={false} />
                      <Tooltip contentStyle={{ fontSize: '10px', borderRadius: '8px' }} />
                      <Legend wrapperStyle={{ fontSize: '10px', paddingTop: '10px' }} />
                      
                      {/* Bar representations */}
                      <Bar dataKey="Nilai Pengetahuan" fill="#022c22" radius={[4, 4, 0, 0]} maxBarSize={30} />
                      <Bar dataKey="Nilai Keterampilan" fill="#14b8a6" radius={[4, 4, 0, 0]} maxBarSize={30} />
                      
                      <Line type="monotone" dataKey="Rapor Akhir" stroke="#f59e0b" strokeWidth={2.5} dot={{ r: 4 }} activeDot={{ r: 6 }} />
                      
                      {/* Reference line for KKM / KKTP of 75 */}
                      <ReferenceLine y={75} stroke="#f43f5e" strokeDasharray="4 4" label={{ value: 'KKM: 75', fill: '#f43f5e', position: 'insideRight', fontSize: 9, fontWeight: 'bold' }} />
                    </ComposedChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="h-full flex items-center justify-center text-slate-400">Tidak ada data untuk kelas ini.</div>
                )}
              </div>
            </div>

            {/* Indicator average distribution breakdown */}
            <div className="bg-white rounded-2xl border border-slate-100 shadow-xxs p-5 flex flex-col justify-between">
              <div>
                <h3 className="text-xs font-bold text-slate-800 font-display uppercase tracking-wider mb-4 flex items-center gap-1.5">
                  <Sliders className="h-4.5 w-4.5 text-brand-green-700" />
                  Analisis per Indikator Pembelajaran
                </h3>

                <div className="space-y-3.5">
                  {Object.entries(indicatorAverages).map(([key, val]) => (
                    <div key={key} className="space-y-1">
                      <div className="flex justify-between text-xxs font-semibold text-slate-600">
                        <span>{getIndicatorLabel(key)}</span>
                        <span className="font-extrabold text-slate-900">{val}</span>
                      </div>
                      <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                        <div
                          className={`h-full rounded-full ${val >= 75 ? 'bg-brand-green-700' : 'bg-rose-500'}`}
                          style={{ width: `${Math.min(100, val)}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-emerald-50/50 p-3.5 rounded-xl border border-emerald-100 mt-4 text-xxs leading-relaxed">
                <span className="font-bold text-brand-green-950 block">Rekomendasi Tarbiyah:</span>
                <p className="text-xxs text-slate-600 mt-1">
                  Materi pada komponen <span className="font-bold text-emerald-800">"{getIndicatorLabel(strongestIndicator)}"</span> berhasil dikuasai secara maksimal. Namun, komponen <span className="font-bold text-rose-600">"{getIndicatorLabel(weakestIndicator)}"</span> dengan rerata terendah ({indicatorAverages[weakestIndicator]}) memerlukan penanganan atau penguatan tambahan pada pekan berikutnya.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 5: PROGRAM REMEDIAL */}
      {activeSubTab === 'Remedial' && (
        <div className="space-y-6 animate-in fade-in duration-100">
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            {/* Student list categorized as needing remedial */}
            <div className="bg-white rounded-2xl border border-slate-100 shadow-xxs overflow-hidden lg:col-span-2">
              <div className="p-4 bg-slate-50/70 border-b border-slate-100 flex items-center justify-between">
                <span className="text-xs font-bold text-slate-700 flex items-center gap-1.5 font-display uppercase tracking-wide">
                  <AlertCircle className="h-4.5 w-4.5 text-rose-500 animate-pulse" />
                  Antrean Remedial ({currentSubject?.name})
                </span>
                <span className="text-[10px] text-rose-600 font-extrabold bg-rose-50 px-2 py-0.5 rounded-full">Nilai di bawah KKM 75</span>
              </div>

              <div className="overflow-x-auto text-xs">
                {classStudents.filter(st => getFinalCombinedScore(st.id) < 75).length > 0 ? (
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="border-b border-gray-100 bg-slate-50 text-slate-400 font-bold uppercase text-[10px]">
                        <th className="p-4">Nama Santri</th>
                        <th className="p-4">Kelas</th>
                        <th className="p-4 text-center">Skor Sekarang</th>
                        <th className="p-4 text-center">Ketuntasan KKM</th>
                        <th className="p-4 text-right">Tindakan</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 text-slate-700">
                      {classStudents.filter(st => getFinalCombinedScore(st.id) < 75).map(st => {
                        const actualScore = getFinalCombinedScore(st.id);
                        return (
                          <tr key={st.id} className="hover:bg-slate-50/30 transition-colors">
                            <td className="p-4">
                              <div className="font-extrabold text-slate-800">{st.name}</div>
                              <div className="text-[9px] text-slate-400 font-mono">ID: {st.id}</div>
                            </td>
                            <td className="p-4 font-semibold text-slate-500">{st.classroom}</td>
                            <td className="p-4 text-center text-rose-600 font-extrabold">{actualScore}</td>
                            <td className="p-4 text-center">
                              <span className="bg-rose-50 text-rose-700 text-[9px] font-extrabold px-2.5 py-0.5 rounded-full uppercase">
                                Belum Tuntas ({actualScore - 75})
                              </span>
                            </td>
                            <td className="p-4 text-right">
                              <button
                                type="button"
                                onClick={() => {
                                  setSelectedRemedialStudentId(st.id);
                                  setRemedialNewScore(78);
                                }}
                                className="bg-rose-600 hover:bg-rose-700 text-white font-extrabold px-3 py-1.5 rounded-xl text-xxxxs uppercase tracking-wider transition cursor-pointer"
                              >
                                Jalankan Remedial
                              </button>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                ) : (
                  <div className="p-12 text-center text-slate-400 space-y-3">
                    <div className="w-16 h-16 bg-emerald-50 rounded-full flex items-center justify-center mx-auto text-emerald-600">
                      <CheckCircle2 className="h-8 w-8" />
                    </div>
                    <div className="font-extrabold text-slate-800">Semua Siswa Tuntas!</div>
                    <p className="text-xxs text-slate-400 max-w-sm mx-auto leading-normal">
                      Luar biasa, seluruh santri di {selectedClass} pada mata pelajaran {currentSubject?.name} telah melampaui ambang kriteria minimal 75. Tidak ada antrean remedial saat ini.
                    </p>
                  </div>
                )}
              </div>
            </div>

            {/* Run Remedial Form Side panel */}
            <div className="bg-white rounded-2xl border border-slate-100 shadow-xxs p-5">
              <h3 className="text-xs font-bold text-slate-800 font-display uppercase tracking-wider mb-4 pb-2 border-b border-slate-100 flex items-center gap-1.5">
                <Settings className="h-4.5 w-4.5 text-brand-green-700" />
                Eksekusi Program Remedial
              </h3>

              {selectedRemedialStudentId ? (
                <form onSubmit={handleExecuteRemedial} className="space-y-4 text-xxs">
                  <div>
                    <label className="block text-[10px] font-extrabold text-slate-400 uppercase tracking-wider">Metode Remedial</label>
                    <select
                      value={remedialActivity}
                      onChange={e => setRemedialActivity(e.target.value)}
                      className="w-full text-xs mt-1 p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none"
                    >
                      <option value="Bimbingan Individu & Tes Tulis Ulang">Bimbingan Individu & Tes Tulis Ulang</option>
                      <option value="Penugasan Khusus Portofolio Ringkasan">Penugasan Khusus Portofolio Ringkasan</option>
                      <option value="Tutor Sebaya & Tes Lisan Terintegrasi">Tutor Sebaya & Tes Lisan Terintegrasi</option>
                      <option value="Pengerjaan Soal Penilaian Harian Alternatif">Pengerjaan Soal Penilaian Harian Alternatif</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[10px] font-extrabold text-slate-400 uppercase tracking-wider">Nilai Rapor Hasil Remedial</label>
                    <div className="flex gap-2 items-center mt-1">
                      <input
                        type="range"
                        min={75}
                        max={85}
                        value={remedialNewScore}
                        onChange={e => setRemedialNewScore(Number(e.target.value))}
                        className="flex-1 focus:outline-none h-1.5 bg-slate-200 rounded-full appearance-none cursor-pointer"
                      />
                      <span className="font-bold text-slate-800 text-sm border border-slate-200 px-2.5 py-1 rounded-xl bg-slate-50">{remedialNewScore}</span>
                    </div>
                    <span className="text-[10px] text-slate-400 mt-1.5 block leading-normal italic">
                      * Sesuai ketentuan, batas maksimal konversi nilai pasca remedial adalah rentang 75 - 85.
                    </span>
                  </div>

                  <button
                    type="submit"
                    className="w-full bg-rose-600 hover:bg-rose-700 text-white font-extrabold py-3.5 rounded-xl shadow-xs transition uppercase tracking-wider text-xxs cursor-pointer"
                  >
                    Simpan & Perbarui Nilai Santri
                  </button>
                </form>
              ) : (
                <div className="py-12 text-center text-slate-400 text-xxs leading-normal">
                  Klik tombol <span className="font-extrabold text-rose-600">"Jalankan Remedial"</span> untuk memilih santri yang hendak dibina dan dimasukkan nilai kelulusan barunya.
                </div>
              )}
            </div>
          </div>

          {/* HISTORIC LOGS FOR REMEDIAL COMPLETED */}
          <div className="bg-white rounded-2xl border border-slate-100 shadow-xxs p-5">
            <h3 className="text-xs font-bold text-slate-800 font-display uppercase tracking-wider mb-4 flex items-center gap-1.5">
              <CheckCircle2 className="h-4.5 w-4.5 text-emerald-600" />
              Arsip Penyelesaian Remedial (Tahun Ajaran Berjalan)
            </h3>
            
            <div className="space-y-2.5 max-h-60 overflow-y-auto">
              {remedialLogs.map(log => (
                <div key={log.id} className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xxs flex items-start justify-between">
                  <div>
                    <span className="font-bold text-slate-800 block">{log.studentName}</span>
                    <span className="text-[10px] text-slate-400 block mt-0.5">{log.subjectName} &bull; Metode: {log.activity}</span>
                    <span className="text-[10px] text-slate-400 block mt-0.5 font-mono">{log.date}</span>
                  </div>
                  <div className="text-right">
                    <span className="text-[10px] text-slate-400 font-bold block">Hasil</span>
                    <span className="font-bold text-emerald-700 mt-0.5 block">{log.oldScore} &rarr; {log.newScore}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 6: PROGRAM PENGAYAAN */}
      {activeSubTab === 'Pengayaan' && (
        <div className="space-y-6 animate-in fade-in duration-100">
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            {/* Over-performing students table */}
            <div className="bg-white rounded-2xl border border-slate-100 shadow-xxs overflow-hidden lg:col-span-2">
              <div className="p-4 bg-slate-50/70 border-b border-slate-100 flex items-center justify-between">
                <span className="text-xs font-bold text-slate-700 flex items-center gap-1.5 font-display uppercase tracking-wide">
                  <Award className="h-4.5 w-4.5 text-amber-500" />
                  Santri Berprestasi Pengayaan ({currentSubject?.name})
                </span>
                <span className="text-[10px] text-brand-green-700 font-bold bg-emerald-50 px-2 py-0.5 rounded-full">Nilai &ge; 75 KKM</span>
              </div>

              <div className="overflow-x-auto text-xs">
                {classStudents.filter(st => getFinalCombinedScore(st.id) >= 75).length > 0 ? (
                  <table className="w-full text-left border-collapse mt-0.5">
                    <thead>
                      <tr className="border-b border-gray-100 bg-slate-50 text-slate-400 font-bold uppercase text-[10px]">
                        <th className="p-4">Nama Santri</th>
                        <th className="p-4">Kelas</th>
                        <th className="p-4 text-center">Nilai Rapor Akhir</th>
                        <th className="p-4 text-center">Status</th>
                        <th className="p-4 text-right">Tindakan</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 text-slate-700">
                      {classStudents.filter(st => getFinalCombinedScore(st.id) >= 75).map(st => {
                        const score = getFinalCombinedScore(st.id);
                        return (
                          <tr key={st.id} className="hover:bg-slate-50/30 transition-colors">
                            <td className="p-4">
                              <div className="font-extrabold text-slate-800">{st.name}</div>
                              <div className="text-[9px] text-slate-400">NIS: {st.nis}</div>
                            </td>
                            <td className="p-4 font-semibold text-slate-500">{st.classroom}</td>
                            <td className="p-4 text-center text-brand-green-800 font-black">{score}</td>
                            <td className="p-4 text-center">
                              <span className="bg-emerald-50 text-emerald-800 text-[9px] font-extrabold px-2 py-0.5 rounded-full">
                                TERCAPAI
                              </span>
                            </td>
                            <td className="p-4 text-right">
                              <button
                                type="button"
                                onClick={() => setSelectedPengayaanStudentId(st.id)}
                                className="bg-amber-500 hover:bg-amber-600 text-white font-extrabold px-3 py-1.5 rounded-xl text-xxxxs uppercase tracking-wider cursor-pointer"
                              >
                                Daftar Pengayaan
                              </button>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                ) : (
                  <div className="p-12 text-center text-slate-400 font-semibold leading-normal">
                    Tidak ada santri dengan nilai di atas 75 saat ini untuk didaftarkan program pengayaan.
                  </div>
                )}
              </div>
            </div>

            {/* Register enrichment action */}
            <div className="bg-white rounded-2xl border border-slate-100 shadow-xxs p-5">
              <h3 className="text-xs font-bold text-slate-800 font-display uppercase tracking-wider mb-4 pb-2 border-b border-slate-100 flex items-center gap-1.5">
                <Plus className="h-4.5 w-4.5 text-brand-green-700" />
                Registrasi Pengayaan
              </h3>

              {selectedPengayaanStudentId ? (
                <form onSubmit={handleRegisterPengayaan} className="space-y-4 text-xxs">
                  <div>
                    <label className="block text-[10px] font-extrabold text-slate-400 uppercase tracking-wider">Aktivitas Pengayaan</label>
                    <select
                      value={pengayaanActivity}
                      onChange={e => setPengayaanActivity(e.target.value)}
                      className="w-full text-xs mt-1 p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none"
                    >
                      <option value="Tutor Sebaya membantu Rekan Remedial">Tutor Sebaya membantu Rekan Remedial</option>
                      <option value="Pemecahan Kasus Menantang Modul Tambahan">Pemecahan Kasus Menantang Modul Tambahan</option>
                      <option value="Penyusunan Riset Ringkas di Perpustakaan">Penyusunan Riset Ringkas di Perpustakaan</option>
                      <option value="Proyek Implementasi Hadis Tematik Berkelompok">Proyek Implementasi Hadis Tematik Berkelompok</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[10px] font-extrabold text-slate-400 uppercase tracking-wider">Target Pencapaian</label>
                    <input
                      type="text"
                      className="w-full text-xs mt-1 p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none"
                      placeholder="Contoh: Menguasai lafadz syariat tingkat mahir"
                      value={pengayaanTarget}
                      onChange={e => setPengayaanTarget(e.target.value)}
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full bg-amber-500 hover:bg-amber-600 text-white font-extrabold py-3.5 rounded-xl uppercase tracking-wider text-xxs cursor-pointer"
                  >
                    Daftarkan Ke Program
                  </button>
                </form>
              ) : (
                <div className="py-12 text-center text-slate-400 text-xxs">
                  Klik tombol <span className="font-extrabold text-amber-600">"Daftar Pengayaan"</span> untuk merancang agenda pendalaman materi khusus santri cerdas secepatnya.
                </div>
              )}
            </div>
          </div>

          {/* ACTIVE ENRICHMENT PROGRAMS LIST */}
          <div className="bg-white rounded-2xl border border-slate-100 shadow-xxs p-5">
            <h3 className="text-xs font-bold text-slate-800 font-display uppercase tracking-wider mb-4 flex items-center gap-1.5">
              <CheckCircle2 className="h-4.5 w-4.5 text-amber-500" />
              Daftar Program Pengayaan Berjalan
            </h3>

            <div className="space-y-3">
              {pengayaanLogs.map(log => (
                <div key={log.id} className="p-4 bg-slate-50 rounded-xl border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between text-xxs gap-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-black text-slate-800 text-xs">{log.studentName}</span>
                      <span className="bg-teal-50 text-teal-800 font-bold px-2 py-0.5 rounded-full text-xxxxs">Nilai: {log.score}</span>
                    </div>
                    <p className="text-slate-500 mt-1"><b>Program:</b> {log.activity}</p>
                    <p className="text-slate-400 mt-0.5"><b>Target:</b> {log.target} &bull; <span className="font-mono">{log.date}</span></p>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    {log.status === 'Dalam Proses' ? (
                      <button
                        type="button"
                        onClick={() => handleFinishPengayaan(log.id)}
                        className="bg-brand-green-700 hover:bg-brand-green-800 text-white font-bold px-3 py-1.5 rounded-xl text-xxxxs uppercase tracking-wider cursor-pointer"
                      >
                        Selesaikan Program
                      </button>
                    ) : (
                      <span className="bg-emerald-100 text-emerald-800 font-bold px-3 py-1.5 rounded-full text-[10px] flex items-center gap-1">
                        <Check className="h-3.5 w-3.5" />
                        Selesai Paripurna
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 7: CETAK LAPORAN NILAI - PREVIEW */}
      {activeSubTab === 'Cetak' && (
        <div className="space-y-6 animate-in fade-in duration-100 select-none">
          
          {/* CONTROL EXPORTS BAR */}
          <div className="bg-white p-4 rounded-2xl border border-slate-100 shadow-xxs flex flex-wrap items-center justify-between gap-4">
            <span className="text-xs font-bold text-slate-700 school-display flex items-center gap-1.5">
              <FileText className="h-4.5 w-4.5 text-brand-green-700" />
              Kontrol Dokumen Cetak Rapor Berbasis Kurikulum Terpadu
            </span>

            <div className="flex flex-wrap items-center gap-2 text-xxs font-bold">
              <button
                type="button"
                onClick={handlePrintDocument}
                className="bg-brand-green-800 hover:bg-brand-green-950 text-white px-3.5 py-2 rounded-xl flex items-center gap-1 cursor-pointer transition shadow-xxs"
              >
                <Printer className="h-3.5 w-3.5" />
                Cetak PDF
              </button>

              <button
                type="button"
                onClick={handleExportCSV}
                className="bg-slate-100 hover:bg-slate-200 text-slate-800 px-3.5 py-2 rounded-xl flex items-center gap-1 cursor-pointer transition border border-slate-200"
              >
                <Download className="h-3.5 w-3.5" />
                Ekspor Excel (CSV)
              </button>

              <button
                type="button"
                onClick={handleExportWord}
                className="bg-slate-100 hover:bg-slate-200 text-slate-800 px-3.5 py-2 rounded-xl flex items-center gap-1 cursor-pointer transition border border-slate-200"
              >
                <Download className="h-3.5 w-3.5" />
                Ekspor Word (DOC)
              </button>
            </div>
          </div>

          {/* DOCUMENT PREVIEW BLOCK */}
          <div className="bg-white p-8 sm:p-12 rounded-3xl border border-slate-200 shadow-md max-w-4xl mx-auto space-y-8 print-document-body" id="print-raport-container">
            
            {/* Header Sekolah standard Kemenag / Depdiknas */}
            <div className="text-center space-y-1.5 border-b-4 border-double border-slate-800 pb-5">
              <h1 className="text-lg font-black tracking-wider text-slate-900 uppercase font-display leading-tight">YAYASAN PONDOK PESANTREN AL FARABY BOGOR</h1>
              <h2 className="text-base font-extrabold text-slate-800 uppercase font-sans">SD ISLAM INTEGRAL AL FARABY BOGOR</h2>
              <p className="text-[10px] text-slate-500 italic">Izin Operasional No: Dep.Ag/411/V.42.1/Bogor | NPSN: 20224419</p>
              <p className="text-[9px] text-slate-400">Jl. Pemuda No. 45, Kecamatan Sukamanah, Kota Bogor, Jawa Barat</p>
            </div>

            {/* Document Title */}
            <div className="text-center">
              <h3 className="text-sm font-extrabold text-slate-800 uppercase tracking-widest line-clamp-1">DAFTAR NILAI AKHIR CAPAIAN HASIL BELAJAR (RAPOR)</h3>
              <p className="text-[11px] text-slate-500 italic mt-0.5">Semester Ganjil, Tahun Ajaran 2026/2027</p>
            </div>

            {/* Metadata specifics */}
            <div className="grid grid-cols-2 text-xxs font-semibold text-slate-700 gap-x-8 gap-y-2">
              <div className="flex justify-between border-b border-dashed border-slate-200 pb-1">
                <span>Mata Pelajaran:</span>
                <span className="text-slate-900 font-extrabold">{currentSubject?.name} ({currentSubject?.code})</span>
              </div>
              <div className="flex justify-between border-b border-dashed border-slate-200 pb-1">
                <span>Fase Kurikulum:</span>
                <span className="text-slate-900 font-extrabold">{currentSubject?.fase || 'Fase B'}</span>
              </div>
              <div className="flex justify-between border-b border-dashed border-slate-200 pb-1">
                <span>Wali Kelas Pengampu:</span>
                <span className="text-slate-900 font-extrabold">Siti Nurhaliza, S.Pd.I.</span>
              </div>
              <div className="flex justify-between border-b border-dashed border-slate-200 pb-1">
                <span>Kelas Terkait:</span>
                <span className="text-slate-100 bg-emerald-800 px-2.5 py-0.5 rounded font-extrabold">{selectedClass}</span>
              </div>
            </div>

            {/* Structured Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xxs" style={{ border: '1.5px solid #1e293b' }}>
                <thead>
                  <tr className="bg-slate-100 text-slate-800 font-extrabold uppercase" style={{ borderBottom: '1.5px solid #1e293b' }}>
                    <th className="p-3 border-r border-slate-800 text-center">No</th>
                    <th className="p-3 border-r border-slate-800">Nama Lengkap Santri</th>
                    <th className="p-3 border-r border-slate-800 text-center">NIS</th>
                    <th className="p-3 border-r border-slate-800 text-center">Pengetahuan (60%)</th>
                    <th className="p-3 border-r border-slate-800 text-center">Keterampilan (40%)</th>
                    <th className="p-3 border-r border-slate-800 text-center">Predikat Adab</th>
                    <th className="p-3 border-r border-slate-800 text-center">Rapor Akhir</th>
                    <th className="p-3 text-center">Ketuntasan</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800 text-slate-800">
                  {classStudents.map((st, idx) => {
                    const cogAvg = getCognitiveAverage(st.id);
                    const skillAvg = getSkillsAverage(st.id);
                    const att = getAttitudePhrase(st.id);
                    const final = getFinalCombinedScore(st.id);
                    const isTuntas = final >= 75;

                    return (
                      <tr key={st.id} className="hover:bg-slate-50/20">
                        <td className="p-3 border-r border-slate-800 text-center font-bold">{idx + 1}</td>
                        <td className="p-3 border-r border-slate-800"><b>{st.name}</b></td>
                        <td className="p-3 border-r border-slate-800 text-center font-mono">{st.nis}</td>
                        <td className="p-3 border-r border-slate-800 text-center">{cogAvg}</td>
                        <td className="p-3 border-r border-slate-800 text-center">{skillAvg}</td>
                        <td className="p-3 border-r border-slate-800 text-center font-medium">{att}</td>
                        <td className="p-3 border-r border-slate-800 text-center font-black text-brand-green-950 font-display">{final}</td>
                        <td className="p-3 text-center font-bold">
                          {isTuntas ? (
                            <span className="text-emerald-700">Tuntas</span>
                          ) : (
                            <span className="text-rose-600">Belum Tuntas</span>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* Footnotes & Signature area */}
            <div className="flex justify-between items-start pt-12 text-xxs font-semibold">
              <div className="w-56 text-center">
                <p className="invisible">Keterangan tanggal</p>
                <p className="mt-1">Mengetahui,<br/>Kepala Sekolah SD Islam Al Faraby</p>
                <br/><br/><br/>
                <p className="font-extrabold text-slate-900 border-b border-slate-900 pb-1 inline-block">Hj. Siti Aminah, S.Pd.I.</p>
                <p className="text-[10px] text-slate-400 font-semibold uppercase block mt-0.5">NIP. 197609202005012003</p>
              </div>

              <div className="w-64 text-center">
                <p>Bogor, {new Date().toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' })}</p>
                <p className="mt-1">Wali Kelas Pengampu,</p>
                <br/><br/><br/>
                <p className="font-extrabold text-slate-900 border-b border-slate-900 pb-1 inline-block">Siti Nurhaliza, S.Pd.I.</p>
                <p className="text-[10px] text-slate-400 font-semibold uppercase block mt-0.5">NIP. 198506122010011002</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* COMPREHENSIVE MULTI-TAB DIALOG FOR MANUAL SCORES SUNTIK DATA */}
      {isEditModalOpen && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl w-full max-w-lg shadow-2xl overflow-hidden border border-slate-100 flex flex-col justify-between">
            
            {/* Modal Title Banner */}
            <div className="bg-brand-green-950 px-6 py-4 text-white flex justify-between items-center shrink-0">
              <div>
                <h3 className="font-extrabold text-sm school-display text-brand-gold-500">
                  Formulir Penilaian Hasil Mengajar Santri
                </h3>
                <span className="text-xxs text-emerald-200 mt-1 block font-semibold">
                  Siswa: {students.find(s => s.id === modalStudentId)?.name} ({selectedClass})
                </span>
              </div>
              <button
                type="button"
                onClick={() => setIsEditModalOpen(false)}
                className="text-white hover:text-rose-400 transition cursor-pointer text-base bg-white/10 hover:bg-white/20 w-8 h-8 rounded-full flex items-center justify-center"
              >
                &times;
              </button>
            </div>

            {/* Form */}
            <form onSubmit={handleSaveModalScore} className="p-6 overflow-y-auto space-y-4 text-xxs flex-1 max-h-[70vh]">
              
              {/* Modal local tab indicator */}
              <div className="flex border-b border-gray-100">
                <button
                  type="button"
                  onClick={() => setModalTab('Kognitif')}
                  className={`flex-1 py-2 font-bold transition border-b-2 text-[11px] ${modalTab === 'Kognitif' ? 'border-brand-green-700 text-brand-green-800' : 'border-transparent text-slate-400'}`}
                >
                  1. Kognitif
                </button>
                <button
                  type="button"
                  onClick={() => setModalTab('Keterampilan')}
                  className={`flex-1 py-2 font-bold transition border-b-2 text-[11px] ${modalTab === 'Keterampilan' ? 'border-brand-green-700 text-brand-green-800' : 'border-transparent text-slate-400'}`}
                >
                  2. Keterampilan
                </button>
                <button
                  type="button"
                  onClick={() => setModalTab('Sikap')}
                  className={`flex-1 py-2 font-bold transition border-b-2 text-[11px] ${modalTab === 'Sikap' ? 'border-brand-green-700 text-brand-green-800' : 'border-transparent text-slate-400'}`}
                >
                  3. Sikap Adab
                </button>
              </div>

              {/* CARD FOR KOGNITIF INPUTS */}
              {modalTab === 'Kognitif' && (
                <div className="space-y-4 animate-in fade-in duration-75">
                  <span className="text-[10px] text-slate-400 font-bold block mb-2">Nilai Kognitif Pengetahuan (Rentang 0 - 100)</span>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                    <div>
                      <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider">Tugas Mandiri</label>
                      <input
                        type="number"
                        min={0}
                        max={100}
                        required
                        value={inputTugas}
                        onChange={e => setInputTugas(Number(e.target.value))}
                        className="w-full text-xs mt-1 p-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider">Kuis Harian</label>
                      <input
                        type="number"
                        min={0}
                        max={100}
                        required
                        value={inputKuis}
                        onChange={e => setInputKuis(Number(e.target.value))}
                        className="w-full text-xs mt-1 p-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider">Sumatif Harian</label>
                      <input
                        type="number"
                        min={0}
                        max={100}
                        required
                        value={inputHarian}
                        onChange={e => setInputHarian(Number(e.target.value))}
                        className="w-full text-xs mt-1 p-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider">UTS / Mid</label>
                      <input
                        type="number"
                        min={0}
                        max={100}
                        required
                        value={inputUts}
                        onChange={e => setInputUts(Number(e.target.value))}
                        className="w-full text-xs mt-1 p-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider">UAS / End</label>
                      <input
                        type="number"
                        min={0}
                        max={100}
                        required
                        value={inputUas}
                        onChange={e => setInputUas(Number(e.target.value))}
                        className="w-full text-xs mt-1 p-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* CARD FOR KETERAMPILAN INPUTS */}
              {modalTab === 'Keterampilan' && (
                <div className="space-y-4 animate-in fade-in duration-75">
                  <span className="text-[10px] text-slate-400 font-bold block mb-2">Nilai Keterampilan Praktik (Rentang 0 - 100)</span>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider">Praktik (Performance)</label>
                      <input
                        type="number"
                        min={0}
                        max={100}
                        required
                        value={inputPraktik}
                        onChange={e => setInputPraktik(Number(e.target.value))}
                        className="w-full text-xs mt-1 p-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider">Produk (Hasil Karya)</label>
                      <input
                        type="number"
                        min={0}
                        max={100}
                        required
                        value={inputProduk}
                        onChange={e => setInputProduk(Number(e.target.value))}
                        className="w-full text-xs mt-1 p-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider">Proyek (Kolaborasi)</label>
                      <input
                        type="number"
                        min={0}
                        max={100}
                        required
                        value={inputProyek}
                        onChange={e => setInputProyek(Number(e.target.value))}
                        className="w-full text-xs mt-1 p-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider">Portofolio (Arsip)</label>
                      <input
                        type="number"
                        min={0}
                        max={100}
                        required
                        value={inputPortofolio}
                        onChange={e => setInputPortofolio(Number(e.target.value))}
                        className="w-full text-xs mt-1 p-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* CARD FOR SIKAP ADAB INPUTS */}
              {modalTab === 'Sikap' && (
                <div className="space-y-4 animate-in fade-in duration-75">
                  <span className="text-[10px] text-slate-400 font-bold block mb-2">Penilaian Sikap Karakter Perkembangan</span>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider">Observasi Guru</label>
                      <select
                        value={inputObservasi}
                        onChange={e => setInputObservasi(e.target.value as any)}
                        className="w-full text-xs mt-1 p-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-emerald-500"
                      >
                        <option value="SB">Sangat Baik (SB)</option>
                        <option value="B">Baik (B)</option>
                        <option value="C">Cukup (C)</option>
                        <option value="PB">Perlu Bimbingan (PB)</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider">Jurnal Perilaku</label>
                      <select
                        value={inputJurnal}
                        onChange={e => setInputJurnal(e.target.value as any)}
                        className="w-full text-xs mt-1 p-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-emerald-500"
                      >
                        <option value="SB">Sangat Baik (SB)</option>
                        <option value="B">Baik (B)</option>
                        <option value="C">Cukup (C)</option>
                        <option value="PB">Perlu Bimbingan (PB)</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider">Penilaian Diri</label>
                      <select
                        value={inputDiri}
                        onChange={e => setInputDiri(e.target.value as any)}
                        className="w-full text-xs mt-1 p-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-emerald-500"
                      >
                        <option value="SB">Sangat Baik (SB)</option>
                        <option value="B">Baik (B)</option>
                        <option value="C">Cukup (C)</option>
                        <option value="PB">Perlu Bimbingan (PB)</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider">Rekan Sebaya</label>
                      <select
                        value={inputSebaya}
                        onChange={e => setInputSebaya(e.target.value as any)}
                        className="w-full text-xs mt-1 p-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-emerald-500"
                      >
                        <option value="SB">Sangat Baik (SB)</option>
                        <option value="B">Baik (B)</option>
                        <option value="C">Cukup (C)</option>
                        <option value="PB">Perlu Bimbingan (PB)</option>
                      </select>
                    </div>
                  </div>
                </div>
              )}

              {/* COMMENTS TEXTAREA */}
              <div className="pt-2 border-t border-slate-100">
                <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider">Deskripsi Pembelajaran & Catatan Akhlak Rapor</label>
                <textarea
                  rows={3}
                  required
                  placeholder="Contoh: Menguasai cara pemecahan adab harian dengan sangat memuaskan..."
                  value={inputNotes}
                  onChange={e => setInputNotes(e.target.value)}
                  className="w-full text-xs mt-1 px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-1 focus:ring-emerald-500 focus:outline-none"
                />
              </div>
              
              {/* Footer controls inside modal */}
              <div className="flex items-center justify-end gap-2 pt-4 border-t border-slate-100 shrink-0">
                <button
                  type="button"
                  onClick={() => setIsEditModalOpen(false)}
                  className="px-4 py-2.5 font-bold text-slate-400 hover:text-slate-700 hover:bg-slate-50 rounded-xl"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 font-black text-white bg-brand-green-800 hover:bg-brand-green-950 rounded-xl shadow-xs transition cursor-pointer uppercase tracking-wider"
                >
                  Simpan & Sinkronkan
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
