/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  BookOpen, Sparkles, Plus, Trash, FileText, CheckCircle2, Award, Download, Printer, RefreshCw, Layers,
  LayoutGrid, Calendar, HelpCircle, Check, BookOpenCheck
} from 'lucide-react';
import { LessonPlan, Subject, CapaianPembelajaran, TujuanPembelajaran } from '../types';

// Importing the modular Modul 4 components
import CapaianPembelajaranSection from './pembelajaran/CapaianPembelajaranSection';
import TujuanPembelajaranSection from './pembelajaran/TujuanPembelajaranSection';
import AlurTujuanPembelajaranSection from './pembelajaran/AlurTujuanPembelajaranSection';
import ModulAjarSection from './pembelajaran/ModulAjarSection';
import ProtaPromesSection from './pembelajaran/ProtaPromesSection';
import AnalisisMingguEfektifSection from './pembelajaran/AnalisisMingguEfektifSection';
import KalenderPendidikanSection from './pembelajaran/KalenderPendidikanSection';
import JadwalMengajarSection from './pembelajaran/JadwalMengajarSection';

interface AdministrasiPembelajaranViewProps {
  subjects: Subject[];
  lessonPlans: LessonPlan[];
  onAddLessonPlan: (plan: LessonPlan) => void;
  onDeleteLessonPlan: (id: string) => void;
  onUpdateLessonPlanSync: (id: string, synced: boolean) => void;
}

export default function AdministrasiPembelajaranView({
  subjects,
  lessonPlans,
  onAddLessonPlan,
  onDeleteLessonPlan,
  onUpdateLessonPlanSync
}: AdministrasiPembelajaranViewProps) {
  
  // Categorized structural tabs (Classic RPP features vs. New Merdeka Modul 4)
  const [activeTab, setActiveTab] = useState<
    'rpp-list' | 'rpp-builder' | 'kurikulum' | 
    'cp' | 'tp' | 'atp' | 'modul-ajar' | 'prota-promes' | 'minggu-efektif' | 'kalender-pendidikan' | 'jadwal-mengajar'
  >('rpp-list');
  
  const [rppSearch, setRppSearch] = useState('');

  // Selected Lesson Plan for detail list
  const [viewingPlan, setViewingPlan] = useState<LessonPlan | null>(lessonPlans[0] || null);

  // === LOCAL SEEDED STATE FOR MODUL 4: CAPAIAN PEMBELAJARAN (CP) ===
  const [cpList, setCpList] = useState<CapaianPembelajaran[]>([
    {
      id: "CP01",
      code: "CP-AA-01",
      subjectName: "Aqidah Akhlak",
      fase: "Fase B",
      gradeLevel: "Kelas 4",
      element: "Aqidah",
      description: "Peserta didik mampu memahami sifat-sifat wajib Allah SWT, sifat-sifat mustahil, serta sifat Jaiz Allah SWT sebagai fondasi keyakinan tauhid yang kokoh."
    },
    {
      id: "CP02",
      code: "CP-AA-02",
      subjectName: "Aqidah Akhlak",
      fase: "Fase B",
      gradeLevel: "Kelas 4",
      element: "Akhlak",
      description: "Peserta didik mampu mempraktikkan akhlak mulia kepada kedua orang tua, guru, dan teman sebaya, serta menjauhi akhlak tercela sesuai rukun Islam."
    },
    {
      id: "CP03",
      code: "CP-QH-01",
      subjectName: "Al-Qur'an Hadist",
      fase: "Fase B",
      gradeLevel: "Kelas 4",
      element: "Al-Qur'an",
      description: "Peserta didik mampu melafalkan, menghafal, dan memahami kandungan arti surat-surat pendek pilihan seperti Al-Ma'un dan At-Takatsur."
    }
  ]);

  // === LOCAL SEEDED STATE FOR MODUL 4: TUJUAN PEMBELAJARAN (TP) ===
  const [tpList, setTpList] = useState<TujuanPembelajaran[]>([
    {
      id: "TP01",
      code: "TP-AA-01.1",
      cpId: "CP01",
      cpCode: "CP-AA-01",
      subjectName: "Aqidah Akhlak",
      gradeLevel: "Kelas 4",
      description: "Menyebutkan dan mengklasifikasikan 20 Sifat Wajib Allah SWT beserta dalil aqli dan naqli dengan benar sesuai aqidah Ahlussunnah."
    },
    {
      id: "TP02",
      code: "TP-AA-01.2",
      cpId: "CP01",
      cpCode: "CP-AA-01",
      subjectName: "Aqidah Akhlak",
      gradeLevel: "Kelas 4",
      description: "Menjelaskan fenomena penciptaan alam semesta sebagai bukti nyata kekuasaan Allah SWT."
    },
    {
      id: "TP03",
      code: "TP-AA-02.1",
      cpId: "CP02",
      cpCode: "CP-AA-02",
      subjectName: "Aqidah Akhlak",
      gradeLevel: "Kelas 4",
      description: "Mendemonstrasikan tata krama khidmah takzim (sopan santun) berinteraksi dengan asatidzah di sekolah."
    }
  ]);

  // --- CP List Handlers ---
  const handleAddCp = (cp: CapaianPembelajaran) => setCpList([cp, ...cpList]);
  const handleEditCp = (updated: CapaianPembelajaran) => setCpList(cpList.map(c => c.id === updated.id ? updated : c));
  const handleDeleteCp = (id: string) => setCpList(cpList.filter(c => c.id !== id));

  // --- TP List Handlers ---
  const handleAddTp = (tp: TujuanPembelajaran) => setTpList([tp, ...tpList]);
  const handleEditTp = (updated: TujuanPembelajaran) => setTpList(tpList.map(t => t.id === updated.id ? updated : t));
  const handleDeleteTp = (id: string) => setTpList(tpList.filter(t => t.id !== id));

  // === CLASSIC AI RPP BUILDER VARIABLES ===
  const [selectedSubject, setSelectedSubject] = useState(subjects[0]?.name || 'Aqidah Akhlak');
  const [selectedGrade, setSelectedGrade] = useState('Kelas 4A');
  const [inputTopic, setInputTopic] = useState('');
  const [inputDuration, setInputDuration] = useState('2 JP x 35 Menit');
  const [inputIslamValue, setInputIslamValue] = useState('');
  const [isAiGenerating, setIsAiGenerating] = useState(false);
  const [generatedContent, setGeneratedContent] = useState('');
  const [generatedIslam, setGeneratedIslam] = useState('');

  // === CLASSIC CURRICULUM VARIABLES ===
  const [currSubject, setCurrSubject] = useState(subjects[0]?.name || 'Aqidah Akhlak');
  const [isMappingLoading, setIsMappingLoading] = useState(false);
  const [curriculumRows, setCurriculumRows] = useState<Array<{ kd: string; kompetensi: string; indikator: string; alokasiWaktu: string }>>([
    {
      kd: "KD 3.1",
      kompetensi: "Memahami kebesaran Allah SWT melalui pengenalan Asmaul Husna yang diajarkan dalam kurikulum dasar.",
      indikator: "Menyebutkan arti lafadz As-Salam, Al-Mukmin, Al-Karim dan hikmahnya dalam ketenangan beribadah harian.",
      alokasiWaktu: "4 JP"
    },
    {
      kd: "KD 3.2",
      kompetensi: "Mendemonstrasikan sikap berbakti kepada bapak ibu guru di lingkungan madrasah serta orang tua di rumah.",
      indikator: "Mempraktikkan tegur sapa takzim, antri masuk mushallah, dan memelihara keheningan lingkungan belajar.",
      alokasiWaktu: "6 JP"
    }
  ]);

  // Handle Classic RPP PDF export simulation
  const handlePrintRPP = (plan: LessonPlan) => {
    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(`
        <html>
          <head>
            <title>RPP - ${plan.title}</title>
            <style>
              body { font-family: 'Segoe UI', sans-serif; padding: 40px; color: #1e293b; line-height: 1.6; }
              h1, h2, h3, h4 { color: #047857; margin-top: 20px; }
              hr { border: 0; border-top: 1px solid #e2e8f0; margin: 20px 0; }
              pre { background: #f8fafc; padding: 15px; border-radius: 8px; border: 1px solid #e2e8f0; white-space: pre-wrap; font-family: inherit; }
            </style>
          </head>
          <body>
            <h1>${plan.title}</h1>
            <p><strong>Mata Pelajaran:</strong> ${plan.subject} | <strong>Kelas:</strong> ${plan.grade}</p>
            <p><strong>Integrasi Nilai Islam:</strong> ${plan.islamicIntegration}</p>
            <hr />
            <pre>${plan.content}</pre>
          </body>
        </html>
      `);
      printWindow.document.close();
      printWindow.print();
    }
  };

  // Generate Syllabus / Curriculum Map via AI (Classic Tab)
  const handleGenerateSyllabus = async () => {
    setIsMappingLoading(true);
    try {
      const response = await fetch('/api/gemini/generate-syllabus', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ subject: currSubject, grade: 'Kelas IV' })
      });
      const data = await response.json();
      if (data.rows && Array.isArray(data.rows)) {
        setCurriculumRows(data.rows);
      }
    } catch (err) {
      console.error("Syllabus generation failed:", err);
    } finally {
      setIsMappingLoading(false);
    }
  };

  // Handle AI RPP Generation (Classic Tab)
  const handleGenerateRppWithAi = async () => {
    if (!inputTopic) {
      alert('Mohon masukkan deskripsi topik pembelajaran terlebih dahulu.');
      return;
    }
    setIsAiGenerating(true);
    setGeneratedContent('');
    try {
      const response = await fetch('/api/gemini/generate-rpp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          subject: selectedSubject,
          grade: selectedGrade,
          topic: inputTopic,
          duration: inputDuration,
          islamicIntegration: inputIslamValue
        })
      });
      const data = await response.json();
      if (data.content) {
        setGeneratedContent(data.content);
        setGeneratedIslam(inputIslamValue || 'Adab Islami, ayat Al-Qur\'an/Hadis yang relevan');
      }
    } catch (err) {
      console.error("RPP generation failed:", err);
    } finally {
      setIsAiGenerating(false);
    }
  };

  // Save generated RPP (Classic Tab)
  const handleSaveGeneratedRpp = () => {
    if (!generatedContent) return;
    const newPlan: LessonPlan = {
      id: 'RPP' + Math.floor(Math.random() * 1000).toString().padStart(3, '0'),
      title: inputTopic || 'Rancangan Pokok Pembelajaran ' + selectedSubject,
      subject: selectedSubject,
      grade: selectedGrade,
      topic: inputTopic,
      duration: inputDuration,
      content: generatedContent,
      islamicIntegration: generatedIslam || 'Integrasi Nilai Islami',
      createdAt: new Date().toISOString().split('T')[0],
      syncedToDocs: false
    };
    onAddLessonPlan(newPlan);
    setViewingPlan(newPlan);
    setActiveTab('rpp-list');
    setInputTopic('');
    setInputIslamValue('');
    setGeneratedContent('');
  };

  const handleSyncToDocs = (plan: LessonPlan) => {
    const isConfirmed = window.confirm(`Apakah Anda hendak mengekspor RPP "${plan.title}" ini ke Google Docs baru untuk disimpan di folder Google Drive sekolah?`);
    if (!isConfirmed) return;
    onUpdateLessonPlanSync(plan.id, true);
    alert(`Sukses mengekspor RPP ke Google Docs! Memperbarui status arsip digital.`);
  };

  const handleRppDelete = (id: string) => {
    const isConfirmed = window.confirm('Apakah Anda yakin ingin menghapus RPP ini dari data ajar?');
    if (!isConfirmed) return;
    onDeleteLessonPlan(id);
    if (viewingPlan?.id === id) {
      setViewingPlan(null);
    }
  };

  const filteredPlans = lessonPlans.filter(p =>
    p.title.toLowerCase().includes(rppSearch.toLowerCase()) ||
    p.subject.toLowerCase().includes(rppSearch.toLowerCase()) ||
    p.grade.toLowerCase().includes(rppSearch.toLowerCase())
  );

  return (
    <div id="pembelajaran-tab-wrapper" className="space-y-6">
      
      {/* Title Header Section */}
      <div className="bg-gradient-to-br from-brand-green-800 to-emerald-900 rounded-3xl p-5 border border-brand-green-700 shadow-sm text-white">
        <div className="flex items-center gap-3">
          <BookOpenCheck className="h-7 w-7 text-brand-gold-400" />
          <div>
            <h2 className="text-sm font-bold text-white uppercase tracking-wider school-display">
              Administrasi &amp; Perangkat Pembelajaran (Modul 4)
            </h2>
            <p className="text-xxxxs text-emerald-200/95 font-medium mt-0.5 max-w-2xl leading-normal">
              Kelola Kurikulum Merdeka terintegrasi Al-Faraby, struktur Capaian Umum (CP), Tujuan Pembelajaran (TP), modul generator ATP, 18-in-1 Modul Ajar lengkap, analisis kalender akademik, dan jadwal mengajar staff.
            </p>
          </div>
        </div>
      </div>

      {/* Structured Category Selector Blocks */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Category 1: Classic RPP */}
        <div className="bg-slate-50 border border-slate-200 p-3 rounded-2xl space-y-2">
          <span className="text-[9px] font-extrabold text-slate-500 uppercase tracking-widest pl-1 block">
            Kelompok A: Perangkat RPP Classic (1 s.d 3)
          </span>
          <div className="flex flex-wrap gap-1.5">
            <button
              onClick={() => setActiveTab('rpp-list')}
              className={`px-3 py-1.5 text-xxs font-bold rounded-lg cursor-pointer transition ${
                activeTab === 'rpp-list' ? 'bg-brand-green-700 text-white shadow-xs' : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'
              }`}
            >
              Arsip RPP G-Drive ({lessonPlans.length})
            </button>
            <button
              onClick={() => setActiveTab('rpp-builder')}
              className={`px-3 py-1.5 text-xxs font-bold rounded-lg cursor-pointer transition flex items-center gap-1 ${
                activeTab === 'rpp-builder' ? 'bg-brand-green-700 text-white shadow-xs' : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'
              }`}
            >
              <Sparkles className="h-3 w-3 text-brand-gold-500 fill-brand-gold-500" />
              Gemini AI Builder
            </button>
            <button
              onClick={() => setActiveTab('kurikulum')}
              className={`px-3 py-1.5 text-xxs font-bold rounded-lg cursor-pointer transition ${
                activeTab === 'kurikulum' ? 'bg-brand-green-700 text-white shadow-xs' : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'
              }`}
            >
              Kurikulum (KD)
            </button>
          </div>
        </div>

        {/* Category 2: Modul 4 Kurikulum Merdeka */}
        <div className="bg-slate-50 border border-slate-200 p-3 rounded-2xl space-y-2">
          <span className="text-[9px] font-extrabold text-slate-500 uppercase tracking-widest pl-1 block">
            Kelompok B: Kurikulum Merdeka Terpadu / Modul 4 (4 s.d 9)
          </span>
          <div className="flex flex-wrap gap-1.5">
            <button
              onClick={() => setActiveTab('cp')}
              className={`px-2.5 py-1.5 text-xxs font-bold rounded-lg cursor-pointer transition ${
                activeTab === 'cp' ? 'bg-brand-green-700 text-white shadow-xs' : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'
              }`}
            >
              1. Capaian (CP)
            </button>
            <button
              onClick={() => setActiveTab('tp')}
              className={`px-2.5 py-1.5 text-xxs font-bold rounded-lg cursor-pointer transition ${
                activeTab === 'tp' ? 'bg-brand-green-700 text-white shadow-xs' : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'
              }`}
            >
              2. Tujuan (TP)
            </button>
            <button
              onClick={() => setActiveTab('atp')}
              className={`px-2.5 py-1.5 text-xxs font-bold rounded-lg cursor-pointer transition flex items-center gap-1 ${
                activeTab === 'atp' ? 'bg-brand-green-700 text-white shadow-xs' : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'
              }`}
            >
              3. Alur (ATP)
            </button>
            <button
              onClick={() => setActiveTab('modul-ajar')}
              className={`px-2.5 py-1.5 text-xxs font-bold rounded-lg cursor-pointer transition ${
                activeTab === 'modul-ajar' ? 'bg-brand-green-700 text-white shadow-xs' : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'
              }`}
            >
              4. Modul Ajar (18-In-1)
            </button>
            <button
              onClick={() => setActiveTab('prota-promes')}
              className={`px-2.5 py-1.5 text-xxs font-bold rounded-lg cursor-pointer transition ${
                activeTab === 'prota-promes' ? 'bg-brand-green-700 text-white shadow-xs' : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'
              }`}
            >
              5 & 6. Prota / Promes
            </button>
            <button
              onClick={() => setActiveTab('minggu-efektif')}
              className={`px-2.5 py-1.5 text-xxs font-bold rounded-lg cursor-pointer transition ${
                activeTab === 'minggu-efektif' ? 'bg-brand-green-700 text-white shadow-xs' : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'
              }`}
            >
              7. Minggu Efektif
            </button>
            <button
              onClick={() => setActiveTab('kalender-pendidikan')}
              className={`px-2.5 py-1.5 text-xxs font-bold rounded-lg cursor-pointer transition ${
                activeTab === 'kalender-pendidikan' ? 'bg-brand-green-700 text-white shadow-xs' : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'
              }`}
            >
              8. GCal Akademik
            </button>
            <button
              onClick={() => setActiveTab('jadwal-mengajar')}
              className={`px-2.5 py-1.5 text-xxs font-bold rounded-lg cursor-pointer transition ${
                activeTab === 'jadwal-mengajar' ? 'bg-brand-green-700 text-white shadow-xs' : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'
              }`}
            >
              9. Jadwal Mengajar (Swap)
            </button>
          </div>
        </div>
      </div>

      {/* ========================================================= */}
      {/* ============ TAB RENDERING ACCORDING TO STATE ========== */}
      {/* ========================================================= */}

      {/* --- TAB 1: MODUL RPP AKTIF --- */}
      {activeTab === 'rpp-list' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* List panel */}
          <div className="bg-white rounded-2xl border border-slate-100 shadow-xs p-4 space-y-4">
            <h3 className="text-sm font-bold text-slate-800 school-display">Arsip RPP Terdaftar</h3>
            <input
              type="text"
              value={rppSearch}
              onChange={e => setRppSearch(e.target.value)}
              placeholder="Cari RPP, mata pelajaran..."
              className="w-full text-xs px-3 py-2 border border-slate-200 focus:outline-none focus:border-brand-green-600 rounded-lg"
            />
            
            <div className="space-y-2 overflow-y-auto max-h-120 pr-1">
              {filteredPlans.map(plan => (
                <div
                  key={plan.id}
                  onClick={() => setViewingPlan(plan)}
                  className={`p-3 rounded-xl border transition-all text-xs cursor-pointer ${
                    viewingPlan?.id === plan.id ? 'border-brand-green-500 bg-brand-green-50/40' : 'border-slate-100 bg-white hover:bg-slate-50'
                  }`}
                >
                  <div className="flex justify-between items-start gap-2">
                    <span className="bg-brand-green-100 text-brand-green-905 text-xxs font-bold px-2 py-0.5 rounded">
                      {plan.subject}
                    </span>
                    <span className="text-slate-400 text-xxs font-mono">{plan.createdAt}</span>
                  </div>
                  <h4 className="font-bold text-slate-800 mt-2 line-clamp-1">{plan.title}</h4>
                  <div className="flex justify-between items-center mt-2.5 pt-2 border-t border-dashed border-slate-100 text-xxs text-slate-500">
                    <span>{plan.grade}</span>
                    {plan.syncedToDocs ? (
                      <span className="text-emerald-700 font-semibold flex items-center gap-0.5">
                        <CheckCircle2 className="h-3 w-3" /> Synced GDoc
                      </span>
                    ) : (
                      <span className="text-slate-400">Offline</span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Viewer panel */}
          <div className="bg-white rounded-2xl border border-slate-100 shadow-xs lg:col-span-2 p-6 flex flex-col justify-between">
            {viewingPlan ? (
              <div className="space-y-6">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-100 gap-4">
                  <div>
                    <h3 className="text-lg font-bold text-slate-800 school-display">{viewingPlan.title}</h3>
                    <p className="text-xs text-slate-500 mt-1">
                      {viewingPlan.subject} &bull; {viewingPlan.grade} &bull; {viewingPlan.duration}
                    </p>
                  </div>
                  <div className="flex items-center gap-1.5 shrink-0">
                    <button
                      onClick={() => handlePrintRPP(viewingPlan)}
                      className="p-2 bg-slate-50 hover:bg-slate-100 border border-slate-200 text-slate-600 rounded-lg text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
                      title="Cetak RPP ke PDF"
                    >
                      <Printer className="h-3.5 w-3.5" />
                      Cetak
                    </button>
                    {!viewingPlan.syncedToDocs && (
                      <button
                        onClick={() => handleSyncToDocs(viewingPlan)}
                        className="p-2 bg-sky-50 text-sky-750 hover:bg-sky-100 border border-sky-100 rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                        title="Ekspor ke Google Docs"
                      >
                        <FileText className="h-3.5 w-3.5" />
                        Ekspor Docs
                      </button>
                    )}
                    <button
                      onClick={() => handleRppDelete(viewingPlan.id)}
                      className="p-2 bg-rose-50 hover:bg-rose-100 text-rose-700 rounded-lg text-xs font-semibold cursor-pointer border-0"
                    >
                      <Trash className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </div>

                <div className="bg-brand-gold-50/50 p-4 rounded-xl border border-brand-gold-100">
                  <h4 className="text-xxs font-bold text-brand-gold-800 uppercase flex items-center gap-2">
                    <Award className="h-4 w-4 text-brand-gold-600" />
                    Aspek Keislaman (Tarbiyah Integration)
                  </h4>
                  <p className="text-xs text-brand-gold-900 mt-1.5 leading-relaxed font-semibold italic">
                    "{viewingPlan.islamicIntegration}"
                  </p>
                </div>

                <div className="prose prose-sm max-w-none text-xs text-slate-700 bg-slate-50 rounded-2xl p-6 overflow-y-auto max-h-120 border border-slate-100">
                  <div className="whitespace-pre-wrap">{viewingPlan.content}</div>
                </div>
              </div>
            ) : (
              <div className="p-8 text-center text-slate-400 text-sm flex flex-col items-center justify-center h-full">
                <BookOpen className="h-12 w-12 text-slate-300 mb-2" />
                Silakan pilih RPP dari kolom daftar atau ciptakan RPP baru dengan asisten Gemini.
              </div>
            )}
          </div>
        </div>
      )}

      {/* --- TAB 2: AI GEMINI RPP BUILDER --- */}
      {activeTab === 'rpp-builder' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="bg-white rounded-2xl border border-slate-100 shadow-xs p-6 space-y-4">
            <div className="flex items-center gap-2 pb-3 border-b border-slate-100">
              <Sparkles className="h-5 w-5 text-brand-gold-500 fill-brand-gold-500" />
              <h3 className="font-bold text-sm text-slate-800 school-display">Gemini RPP Rabbani</h3>
            </div>
            
            <div className="space-y-3">
              <div>
                <label className="block text-xxs font-bold text-slate-500 uppercase">Pilih Mata Pelajaran</label>
                <select
                  value={selectedSubject}
                  onChange={e => setSelectedSubject(e.target.value)}
                  className="w-full text-xs mt-1 px-3 py-2 border border-slate-200 rounded-lg bg-white focus:outline-none"
                >
                  {subjects.map(sub => (
                    <option key={sub.id} value={sub.name}>{sub.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xxs font-bold text-slate-500 uppercase">Kelas Sasaran</label>
                <select
                  value={selectedGrade}
                  onChange={e => setSelectedGrade(e.target.value)}
                  className="w-full text-xs mt-1 px-3 py-2 border border-slate-200 rounded-lg bg-white focus:outline-none"
                >
                  <option value="Kelas 4A">Kelas 4A</option>
                  <option value="Kelas 4B">Kelas 4B</option>
                  <option value="Kelas 5">Kelas 5</option>
                  <option value="Kelas 6">Kelas 6</option>
                </select>
              </div>

              <div>
                <label className="block text-xxs font-bold text-slate-500 uppercase">Topik / Sub Materi Utama</label>
                <input
                  type="text"
                  placeholder="Contoh: Tata cara Shalat Khusyu / Energi Bunyi"
                  value={inputTopic}
                  onChange={e => setInputTopic(e.target.value)}
                  className="w-full text-xs mt-1 px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:border-brand-green-600"
                />
              </div>

              <div>
                <label className="block text-xxs font-bold text-slate-500 uppercase">Alokasi Waktu</label>
                <input
                  type="text"
                  value={inputDuration}
                  onChange={e => setInputDuration(e.target.value)}
                  className="w-full text-xs mt-1 px-3 py-2 border border-slate-200 rounded-lg"
                />
              </div>

              <div>
                <label className="block text-xxs font-bold text-slate-500 uppercase">Fokus Hikmah Islam (Opsional)</label>
                <textarea
                  rows={3}
                  placeholder="Contoh: Mengaitkan ilmu sirkulasi air dengan QS. Fatir ayat 9. Menumbuhkan rasa syukur."
                  value={inputIslamValue}
                  onChange={e => setInputIslamValue(e.target.value)}
                  className="w-full text-xs mt-1 px-3 py-2 border border-slate-200 rounded-lg focus:outline-none"
                />
              </div>

              <button
                disabled={isAiGenerating}
                onClick={handleGenerateRppWithAi}
                className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-emerald-700 to-emerald-800 text-white font-bold text-xs py-3 rounded-xl hover:from-emerald-800 hover:to-emerald-900 shadow-xs cursor-pointer disabled:opacity-50 border-0"
              >
                {isAiGenerating ? (
                  <>
                    <RefreshCw className="h-4 w-4 animate-spin" />
                    Menyusun RPP Rabbani...
                  </>
                ) : (
                  <>
                    <Sparkles className="h-4 w-4" />
                    Rancang RPP AI
                  </>
                )}
              </button>
            </div>
          </div>

          {/* RPP Output view */}
          <div className="bg-white rounded-2xl border border-slate-100 shadow-xs lg:col-span-2 p-6 flex flex-col justify-between">
            {generatedContent ? (
              <div className="space-y-4 h-full flex flex-col justify-between">
                <div>
                  <div className="flex justify-between items-center pb-3 border-b border-slate-100">
                    <h3 className="font-bold text-sm text-slate-805 school-display flex items-center gap-2">
                      <CheckCircle2 className="h-5 w-5 text-emerald-600" />
                      Hasil Draft RPP Terintegrasi Nilai Islam
                    </h3>
                    <div className="text-xxs text-emerald-850 font-semibold bg-emerald-50 px-2 py-1 rounded">
                      Generasi Selesai
                    </div>
                  </div>
                  <div className="text-slate-700 text-xs bg-slate-50 rounded-2xl p-5 overflow-y-auto max-h-120 border border-slate-100 mt-4 whitespace-pre-wrap">
                    {generatedContent}
                  </div>
                </div>

                <div className="flex justify-end gap-2 pt-4 border-t border-slate-100">
                  <button
                    onClick={() => setGeneratedContent('')}
                    className="px-4 py-2 text-slate-500 hover:text-slate-800 text-xs font-semibold bg-slate-100 hover:bg-slate-200 rounded-lg cursor-pointer border-0"
                  >
                    Rancang Ulang
                  </button>
                  <button
                    onClick={handleSaveGeneratedRpp}
                    className="px-4 py-2 text-white text-xs font-bold bg-brand-green-700 hover:bg-brand-green-800 rounded-lg cursor-pointer border-0"
                  >
                    Simpan &amp; Daftarkan RPP
                  </button>
                </div>
              </div>
            ) : (
              <div className="p-8 text-center text-slate-400 text-sm flex flex-col items-center justify-center h-full">
                {isAiGenerating ? (
                  <div className="space-y-4">
                    <div className="h-10 w-10 border-4 border-brand-green-600 border-t-transparent rounded-full animate-spin mx-auto" />
                    <p className="text-brand-green-905 font-bold school-display">Gemini sedang menyinkronkan syariat keilmuan...</p>
                    <p className="text-xxs text-slate-400 max-w-xs mx-auto">Kami menyusun dalil penunjang, indikator akhlak, serta evaluasi kognitif secara terstruktur.</p>
                  </div>
                ) : (
                  <>
                    <Sparkles className="h-12 w-12 text-brand-gold-500 mb-2 animate-bounce" />
                    <h4 className="font-bold text-slate-705 school-display">Belum ada Draft yang Dibuat</h4>
                    <p className="text-xxs text-slate-500 mt-1 max-w-sm mx-auto">
                      Gunakan modul asisten cerdas Gemini di samping kiri untuk menghasilkan draf RPP islami instan yang disesuaikan khusus kurikulum madrasah Anda.
                    </p>
                  </>
                )}
              </div>
            )}
          </div>
        </div>
      )}

      {/* --- TAB 3: PEMETAAN KURIKULUM KD --- */}
      {activeTab === 'kurikulum' && (
        <div className="bg-white rounded-2xl border border-slate-100 shadow-xs p-6 space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-100 gap-4">
            <div>
              <h3 className="font-bold text-sm text-slate-800 school-display">Mapping Kompetensi Kurikulum Terintegrasi</h3>
              <p className="text-xs text-slate-500 mt-0.5">Pemetaan Standar Kompetensi Dasar (KD) per tingkatan kelas dasar.</p>
            </div>
            
            <div className="flex items-center gap-2 shrink-0">
              <span className="text-xs text-slate-600 font-medium">Mapel:</span>
              <select
                value={currSubject}
                onChange={e => setCurrSubject(e.target.value)}
                className="text-xs bg-slate-50 border border-slate-200 px-3 py-2 rounded-lg cursor-pointer"
              >
                {subjects.map(s => (
                  <option key={s.id} value={s.name}>{s.name}</option>
                ))}
              </select>
              
              <button
                onClick={handleGenerateSyllabus}
                disabled={isMappingLoading}
                className="flex items-center gap-1 bg-brand-green-700 hover:bg-brand-green-800 text-white font-bold text-xs px-3.5 py-2 rounded-lg cursor-pointer disabled:opacity-40 whitespace-nowrap border-0"
              >
                {isMappingLoading ? (
                  <>
                    <RefreshCw className="h-3 w-3 animate-spin" />
                    Menyusun...
                  </>
                ) : (
                  <>
                    <RefreshCw className="h-3 w-3" />
                    Sinkron Kompetensi
                  </>
                )}
              </button>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-100 bg-slate-50 text-slate-500 font-bold uppercase">
                  <th className="p-4 w-28">Kode KD</th>
                  <th className="p-4">Kompetensi Inti &amp; Dasar</th>
                  <th className="p-4">Indikator Kunci Pencapaian</th>
                  <th className="p-4 w-24">Durasi Ajar</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700">
                {curriculumRows.map((row, idx) => (
                  <tr key={idx} className="hover:bg-slate-50/40 transition-colors">
                    <td className="p-4 font-mono font-bold text-brand-green-850">{row.kd}</td>
                    <td className="p-4 font-semibold text-slate-800 leading-relaxed">{row.kompetensi}</td>
                    <td className="p-4 text-slate-600 leading-relaxed italic">{row.indikator}</td>
                    <td className="p-4 font-bold text-slate-800">{row.alokasiWaktu}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* ============ NEW MODUL 4 CORES SUB-TABS (4 s.d 9) ===== */}
      {/* ========================================================= */}

      {/* --- TAB 4: CAPAIAN PEMBELAJARAN (CP) --- */}
      {activeTab === 'cp' && (
        <CapaianPembelajaranSection 
          subjects={subjects}
          cpList={cpList}
          onAddCp={handleAddCp}
          onEditCp={handleEditCp}
          onDeleteCp={handleDeleteCp}
        />
      )}

      {/* --- TAB 5: TUJUAN PEMBELAJARAN (TP) --- */}
      {activeTab === 'tp' && (
        <TujuanPembelajaranSection 
          subjects={subjects}
          cpList={cpList}
          tpList={tpList}
          onAddTp={handleAddTp}
          onEditTp={handleEditTp}
          onDeleteTp={handleDeleteTp}
        />
      )}

      {/* --- TAB 6: ALUR TUJUAN PEMBELAJARAN (ATP) --- */}
      {activeTab === 'atp' && (
        <AlurTujuanPembelajaranSection 
          subjects={subjects}
          cpList={cpList}
          tpList={tpList}
        />
      )}

      {/* --- TAB 7: MASTER MODUL AJAR (18-IN-1) --- */}
      {activeTab === 'modul-ajar' && (
        <ModulAjarSection 
          subjects={subjects}
          lessonPlans={lessonPlans}
          onAddLessonPlan={onAddLessonPlan}
          onDeleteLessonPlan={onDeleteLessonPlan}
          onUpdateLessonPlanSync={onUpdateLessonPlanSync}
        />
      )}

      {/* --- TAB 8 & 9: PROTA / PROMES GRID MATRIX --- */}
      {activeTab === 'prota-promes' && (
        <ProtaPromesSection 
          subjects={subjects}
          tpList={tpList}
        />
      )}

      {/* --- TAB 10: ANALISIS MINGGU EFEKTIF CALCULATOR --- */}
      {activeTab === 'minggu-efektif' && (
        <AnalisisMingguEfektifSection />
      )}

      {/* --- TAB 11: KALENDER AKADEMIK INTEGRASI GCAL --- */}
      {activeTab === 'kalender-pendidikan' && (
        <KalenderPendidikanSection />
      )}

      {/* --- TAB 12: JADWAL MENGAJAR SWAP PLANNER --- */}
      {activeTab === 'jadwal-mengajar' && (
        <JadwalMengajarSection />
      )}

    </div>
  );
}
