/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  FileText,
  FileVideo,
  FileCode,
  Music,
  Image as ImageIcon,
  Youtube,
  Layout,
  ExternalLink,
  Plus,
  Search,
  Filter,
  Trash2,
  Download,
  Eye,
  Share2,
  FolderPlus,
  Sparkles,
  Play,
  Pause,
  ChevronLeft,
  ChevronRight,
  Maximize2,
  Clock,
  BookOpen,
  Send,
  UploadCloud,
  CheckCircle,
  HelpCircle,
  Presentation
} from 'lucide-react';
import { Subject } from '../types';

interface MediaPembelajaranViewProps {
  subjects: Subject[];
}

export interface LearnMedia {
  id: string;
  title: string;
  type: 'PPT' | 'PDF' | 'Video' | 'Audio' | 'Gambar' | 'Canva' | 'YouTube';
  subjectId: string;
  subjectName: string;
  className: string;
  topic: string;
  description: string;
  sourceUrl: string; // File simulation or real URL
  thumbnailUrl?: string;
  fileSize?: string;
  duration?: string; // For audio/video
  dateAdded: string;
  downloadsCount: number;
}

// Initial rich seeds for Media Pembelajaran
const INITIAL_MEDIA_LIST: LearnMedia[] = [
  {
    id: 'MEDIA-001',
    title: 'Adab Bertamu & Birrul Walidain PPT Master',
    type: 'PPT',
    subjectId: 'MAPEL01',
    subjectName: 'Aqidah Akhlak',
    className: 'Kelas 4A',
    topic: 'Adab Sosial Muslim',
    description: 'Bahan presentasi interaktif lengkap dengan kuis adab, gambar keteladanan salafus shalih, dan tuntunan praktis silaturahmi.',
    sourceUrl: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?q=80&w=600',
    fileSize: '14.5 MB',
    dateAdded: '2026-06-15',
    downloadsCount: 84
  },
  {
    id: 'MEDIA-002',
    title: 'Panduan Praktis Hukum Tajwid Idzhar & Iqlab',
    type: 'PDF',
    subjectId: 'MAPEL02',
    subjectName: 'Al-Qur\'an Hadits',
    className: 'Kelas 4A',
    topic: 'Ilmu Tajwid Dasar',
    description: 'E-book saku visual berwarna untuk membantu santri menghafal hukum nun mati dan tanwin dengan peta konsep menarik.',
    sourceUrl: 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?q=80&w=600',
    fileSize: '4.2 MB',
    dateAdded: '2026-06-12',
    downloadsCount: 142
  },
  {
    id: 'MEDIA-003',
    title: 'Visualisasi Tata Cara Wudhu Sesuai Sunnah',
    type: 'YouTube',
    subjectId: 'MAPEL01',
    subjectName: 'Aqidah Akhlak',
    className: 'Kelas 4B',
    topic: 'Thaharah (Bersisih)',
    description: 'Video animasi instruksional langkah demi langkah membasuh anggota wudhu dengan fardhu serta sunnahnya.',
    sourceUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ', // Placeholder embedded video
    dateAdded: '2026-06-16',
    downloadsCount: 210
  },
  {
    id: 'MEDIA-004',
    title: 'Template Canva Interaktif: Hubungan Rukun Iman',
    type: 'Canva',
    subjectId: 'MAPEL01',
    subjectName: 'Aqidah Akhlak',
    className: 'Kelas 5',
    topic: 'Rukun Iman',
    description: 'Papan kolaboratif Canva untuk melengkapi bagan rukun iman bersama kelompok santri secara real-time.',
    sourceUrl: 'https://www.canva.com/design/play-embedded',
    dateAdded: '2026-06-14',
    downloadsCount: 65
  },
  {
    id: 'MEDIA-005',
    title: 'Murottal Surah Al-Mulk Penenang Hati',
    type: 'Audio',
    subjectId: 'MAPEL02',
    subjectName: 'Al-Qur\'an Hadits',
    className: 'Kelas 5',
    topic: 'Hafalan Surah Pendek',
    description: 'Audio murottal merdu surah Al-Mulk beserta terjemahan per ayat untuk didengarkan santri sebelum mulai belajar.',
    sourceUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3', // Functional public test MP3 file
    duration: '04:12',
    fileSize: '8.1 MB',
    dateAdded: '2026-06-11',
    downloadsCount: 95
  },
  {
    id: 'MEDIA-006',
    title: 'Infografis Sifat Wajib & Mustahil bagi Allah',
    type: 'Gambar',
    subjectId: 'MAPEL01',
    subjectName: 'Aqidah Akhlak',
    className: 'Kelas 4A',
    topic: 'Tauhid & Aqidah',
    description: 'Peta klasifikasi 20 sifat wajib Allah SWT yang saling berlawanan dengan warna penanda intuitif.',
    sourceUrl: 'https://images.unsplash.com/photo-1542856391-010fb87dcfed?auto=format&fit=crop&q=80&w=800',
    dateAdded: '2026-06-13',
    downloadsCount: 112
  }
];

export default function MediaPembelajaranView({ subjects }: MediaPembelajaranViewProps) {
  const [mediaList, setMediaList] = useState<LearnMedia[]>(INITIAL_MEDIA_LIST);
  const [activeMedia, setActiveMedia] = useState<LearnMedia | null>(INITIAL_MEDIA_LIST[0]);

  // Filters State
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedType, setSelectedType] = useState<string>('Semua');
  const [selectedClass, setSelectedClass] = useState<string>('Semua');
  const [selectedSubject, setSelectedSubject] = useState<string>('Semua');

  // Input states for Add media
  const [showAddForm, setShowAddForm] = useState(false);
  const [inputTitle, setInputTitle] = useState('');
  const [inputType, setInputType] = useState<'PPT' | 'PDF' | 'Video' | 'Audio' | 'Gambar' | 'Canva' | 'YouTube'>('PPT');
  const [inputSubjectId, setInputSubjectId] = useState(subjects[0]?.id || 'MAPEL01');
  const [inputClass, setInputClass] = useState('Kelas 4A');
  const [inputTopic, setInputTopic] = useState('');
  const [inputDescription, setInputDescription] = useState('');
  const [inputSourceUrl, setInputSourceUrl] = useState('');
  const [inputFileSize, setInputFileSize] = useState('5.0 MB');
  const [inputDuration, setInputDuration] = useState('05:00');

  // Audio Player states
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const audioRef = React.useRef<HTMLAudioElement | null>(null);

  // PPT slides state simulation
  const [currentPptSlide, setCurrentPptSlide] = useState(1);
  const TOTAL_PPT_SLIDES = 6;

  // Handle Play/Pause for Audio
  const toggleAudioPlay = () => {
    if (!audioRef.current) return;
    if (isPlayingAudio) {
      audioRef.current.pause();
    } else {
      audioRef.current.play().catch(err => console.log('Audio playback failed', err));
    }
    setIsPlayingAudio(!isPlayingAudio);
  };

  // Submit media
  const handleAddMedia = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputTitle.trim()) return;

    const actualSubject = subjects.find(s => s.id === inputSubjectId);
    const subjName = actualSubject ? actualSubject.name : 'Mata Pelajaran';

    // Build smart defaults based on type if URL is blank
    let finalUrl = inputSourceUrl.trim();
    if (!finalUrl) {
      if (inputType === 'YouTube') {
        finalUrl = 'https://www.youtube.com/embed/dQw4w9WgXcQ';
      } else if (inputType === 'Canva') {
        finalUrl = 'https://www.canva.com/design/play-embedded';
      } else if (inputType === 'Audio') {
        finalUrl = 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3';
      } else {
        finalUrl = 'https://images.unsplash.com/photo-1456513080510-7bf3a84b82f8?q=80&w=600';
      }
    }

    const newMedia: LearnMedia = {
      id: 'MEDIA-' + Date.now().toString().slice(-3),
      title: inputTitle,
      type: inputType,
      subjectId: inputSubjectId,
      subjectName: subjName,
      className: inputClass,
      topic: inputTopic || 'Umum',
      description: inputDescription || 'Deskripsi media pembelajaran.',
      sourceUrl: finalUrl,
      fileSize: ['PPT', 'PDF', 'Video', 'Audio'].includes(inputType) ? inputFileSize : undefined,
      duration: ['Video', 'Audio'].includes(inputType) ? inputDuration : undefined,
      dateAdded: new Date().toISOString().split('T')[0],
      downloadsCount: 0
    };

    setMediaList(prev => [newMedia, ...prev]);
    setActiveMedia(newMedia);
    setShowAddForm(false);
    alert(`Alhamdulillah, Media Pembelajaran "${inputTitle}" berhasil diunggah!`);

    // Reset Form
    setInputTitle('');
    setInputTopic('');
    setInputDescription('');
    setInputSourceUrl('');
  };

  const handleDeleteMedia = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (confirm('Apakah Ustadz/Ustadzah yakin ingin menghapus media ini dari repositori?')) {
      const remaining = mediaList.filter(m => m.id !== id);
      setMediaList(remaining);
      if (activeMedia?.id === id) {
        setActiveMedia(remaining[0] || null);
      }
    }
  };

  // Filter Logic
  const filteredList = mediaList.filter(m => {
    const matchesSearch = m.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          m.topic.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          m.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesType = selectedType === 'Semua' || m.type === selectedType;
    const matchesClass = selectedClass === 'Semua' || m.className === selectedClass;
    const matchesSubject = selectedSubject === 'Semua' || m.subjectId === selectedSubject;
    return matchesSearch && matchesType && matchesClass && matchesSubject;
  });

  const getIconForType = (type: LearnMedia['type']) => {
    switch (type) {
      case 'PPT': return <Presentation className="h-4 w-4 text-orange-600" />;
      case 'PDF': return <FileText className="h-4 w-4 text-rose-600" />;
      case 'Video': return <FileVideo className="h-4 w-4 text-blue-600" />;
      case 'Audio': return <Music className="h-4 w-4 text-indigo-600" />;
      case 'Gambar': return <ImageIcon className="h-4 w-4 text-teal-600" />;
      case 'Canva': return <Layout className="h-4 w-4 text-purple-600" />;
      case 'YouTube': return <Youtube className="h-4 w-4 text-red-600" />;
      default: return <FileCode className="h-4 w-4 text-slate-600" />;
    }
  };

  return (
    <div id="media-pembelajaran-container" className="space-y-6">
      <audio ref={audioRef} src={activeMedia?.type === 'Audio' ? activeMedia.sourceUrl : undefined} onEnded={() => setIsPlayingAudio(false)} />

      {/* TOP TITLE HEADER */}
      <div className="flex flex-col xl:flex-row xl:items-center justify-between pb-4 border-b border-slate-200 gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="bg-emerald-100 text-emerald-800 text-xxxxs uppercase font-extrabold px-2.5 py-1 rounded-full">
              Modul 9
            </span>
            <h2 className="text-lg font-bold text-slate-800 school-display">
              Repositori Media Pembelajaran Kreatif
            </h2>
          </div>
          <p className="text-xxs text-slate-500 mt-1">
            Kumpulan aset multimedia bahan mengajar guru. Simpan & sematkan presentasi PPT, e-book PDF, video tutorial, audio tadarus, infografis, desain Canva, serta video YouTube.
          </p>
        </div>

        <button
          onClick={() => setShowAddForm(!showAddForm)}
          className="bg-brand-green-700 hover:bg-brand-green-800 text-white font-bold text-xxs px-4 py-2 rounded-xl shadow-xs transition flex items-center gap-1.5 cursor-pointer self-start"
        >
          <FolderPlus className="h-4 w-4" />
          Unggah Media Baru
        </button>
      </div>

      {/* INLINE ADD FORM */}
      {showAddForm && (
        <form onSubmit={handleAddMedia} className="bg-white p-5 rounded-2xl border border-slate-150 shadow-xxs space-y-4 animate-in fade-in duration-200">
          <div className="pb-2 border-b border-slate-100 flex items-center gap-1.5">
            <Sparkles className="h-4.5 w-4.5 text-brand-gold-500 fill-brand-gold-400" />
            <span className="text-xs font-bold text-slate-800">Formulir Penyimpanan Media Pembelajaran Kreatif</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xxs/relaxed">
            <div>
              <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Judul Media Pembelajaran</label>
              <input
                type="text"
                placeholder="Contoh: Slide Interaktif Kisah Nabi"
                required
                className="w-full text-xs px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:bg-white focus:border-brand-green-600 text-slate-800 font-medium"
                value={inputTitle}
                onChange={e => setInputTitle(e.target.value)}
              />
            </div>

            <div>
              <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Jenis Media (Jenis File)</label>
              <select
                value={inputType}
                onChange={e => setInputType(e.target.value as any)}
                className="w-full text-xs px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:bg-white focus:border-brand-green-600 font-bold text-slate-800"
              >
                <option value="PPT">PowerPoint Presentation (PPT)</option>
                <option value="PDF">Dokumen Buku (PDF)</option>
                <option value="YouTube">Video Semat (YouTube Embed)</option>
                <option value="Canva">Desain Semat (Canva Template)</option>
                <option value="Audio">Audio Rekaman (MP3/Tadarus)</option>
                <option value="Gambar">Gambar Ilustrasi / Infografis</option>
                <option value="Video">Video Mandiri (MP4/WebM)</option>
              </select>
            </div>

            <div>
              <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Mata Pelajaran Terkait</label>
              <select
                value={inputSubjectId}
                onChange={e => setInputSubjectId(e.target.value)}
                className="w-full text-xs px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:bg-white focus:border-brand-green-600 text-slate-700"
              >
                {subjects.map(s => (
                  <option key={s.id} value={s.id}>{s.name}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Target Kelas</label>
              <select
                value={inputClass}
                onChange={e => setInputClass(e.target.value)}
                className="w-full text-xs px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:bg-white focus:border-brand-green-600 text-slate-700"
              >
                <option value="Kelas 4A">Kelas 4A</option>
                <option value="Kelas 4B">Kelas 4B</option>
                <option value="Kelas 5">Kelas 5</option>
                <option value="Kelas 6">Kelas 6</option>
                <option value="Semua Kelas">Semua Tingkat</option>
              </select>
            </div>

            <div>
              <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Bab / Topik Bahasan</label>
              <input
                type="text"
                placeholder="Contoh: Thaharah"
                className="w-full text-xs px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:bg-white focus:border-brand-green-600 text-slate-800"
                value={inputTopic}
                onChange={e => setInputTopic(e.target.value)}
              />
            </div>

            <div>
              <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">URL / Link Semat (Kosongkan untuk Default)</label>
              <input
                type="text"
                placeholder="e.g. https://www.canva.com/..."
                className="w-full text-xs px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:bg-white focus:border-brand-green-600 text-slate-700"
                value={inputSourceUrl}
                onChange={e => setInputSourceUrl(e.target.value)}
              />
            </div>

            {['PPT', 'PDF', 'Audio', 'Video'].includes(inputType) && (
              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Ukuran File / Estimasi Durasi</label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder="Ukuran, misal: 4.5 MB"
                    className="w-1/2 text-xs px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:bg-white focus:border-brand-green-600"
                    value={inputFileSize}
                    onChange={e => setInputFileSize(e.target.value)}
                  />
                  <input
                    type="text"
                    placeholder="Durasi, misal: 04:30"
                    className="w-1/2 text-xs px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:bg-white focus:border-brand-green-600"
                    value={inputDuration}
                    onChange={e => setInputDuration(e.target.value)}
                  />
                </div>
              </div>
            )}
          </div>

          <div>
            <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Catatan Singkat / Petunjuk Pembelajaran</label>
            <textarea
              rows={2}
              placeholder="Berikan panduan penggunaan media ini bagi guru atau santri mandiri..."
              className="w-full text-xs p-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:bg-white focus:border-brand-green-600 text-slate-800 leading-normal"
              value={inputDescription}
              onChange={e => setInputDescription(e.target.value)}
            />
          </div>

          <div className="flex justify-end gap-2 text-xxs">
            <button
              type="button"
              onClick={() => setShowAddForm(false)}
              className="px-4 py-2 font-bold text-slate-500 hover:text-slate-800 cursor-pointer"
            >
              Batalkan
            </button>
            <button
              type="submit"
              className="bg-brand-green-700 hover:bg-brand-green-800 text-white font-bold px-5 py-2 rounded-xl transition cursor-pointer"
            >
              Simpan ke Database
            </button>
          </div>
        </form>
      )}

      {/* FILTER CONTROLS TRAY */}
      <div className="bg-white p-4 rounded-2xl border border-slate-100 shadow-xxs grid grid-cols-1 md:grid-cols-4 gap-3 text-xxs">
        <div className="relative">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
          <input
            type="text"
            placeholder="Cari pokok judul / bab..."
            className="w-full text-xs pl-9 pr-4 py-2 rounded-xl bg-slate-50 border border-slate-200 focus:outline-none focus:border-brand-green-600 focus:bg-white text-slate-800"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
          />
        </div>

        <div>
           <select
             value={selectedType}
             onChange={e => setSelectedType(e.target.value)}
             className="w-full text-xs px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none text-slate-700 focus:bg-white focus:border-brand-green-600 cursor-pointer"
           >
             <option value="Semua">Semua Format Media</option>
             <option value="PPT">PPT (Presentasi)</option>
             <option value="PDF">PDF (E-Book)</option>
             <option value="YouTube">YouTube Video</option>
             <option value="Canva">Canva Designs</option>
             <option value="Audio">Audio MP3</option>
             <option value="Gambar">Gambar / Ilustrasi</option>
             <option value="Video">Video Lokal</option>
           </select>
        </div>

        <div>
           <select
             value={selectedClass}
             onChange={e => setSelectedClass(e.target.value)}
             className="w-full text-xs px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none text-slate-700 focus:bg-white focus:border-brand-green-600 cursor-pointer"
           >
             <option value="Semua">Semua Tingkat Kelas</option>
             <option value="Kelas 4A">Kelas 4A</option>
             <option value="Kelas 4B">Kelas 4B</option>
             <option value="Kelas 5">Kelas 5</option>
             <option value="Kelas 6">Kelas 6</option>
           </select>
        </div>

        <div>
           <select
             value={selectedSubject}
             onChange={e => setSelectedSubject(e.target.value)}
             className="w-full text-xs px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none text-slate-700 focus:bg-white focus:border-brand-green-600 cursor-pointer"
           >
             <option value="Semua">Semua Mata Pelajaran</option>
             {subjects.map(s => (
               <option key={s.id} value={s.id}>{s.name}</option>
             ))}
           </select>
        </div>
      </div>

      {/* TWO COLUMNS LAYOUT: MEDIA LIST SIDEBAR & LARGE ACTIVE EMBEDDED PLAYER */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* MEDIA LIST SIDEBAR (1 col) */}
        <div className="bg-white rounded-2xl border border-slate-100 shadow-xxs p-4 space-y-4 max-h-[640px] overflow-y-auto">
          <div className="pb-2 border-b border-slate-100 flex items-center justify-between">
            <span className="font-extrabold text-[10px] text-slate-500 uppercase tracking-widest flex items-center gap-1">
              <BookOpen className="h-4 w-4 text-brand-green-700" />
              Katalog Media ({filteredList.length})
            </span>
          </div>

          <div className="space-y-2">
            {filteredList.length === 0 ? (
              <div className="py-12 text-center text-slate-400 text-xxs flex flex-col items-center justify-center space-y-2">
                <HelpCircle className="h-8 w-8 text-slate-200" />
                <p>Media tidak ditemukan.</p>
              </div>
            ) : (
              filteredList.map(item => {
                const isActive = activeMedia?.id === item.id;
                return (
                  <div
                    key={item.id}
                    onClick={() => {
                      setActiveMedia(item);
                      setIsPlayingAudio(false); // Reset audio playing state if channel changes
                    }}
                    className={`p-3 rounded-xl border text-left cursor-pointer transition relative group flex gap-3 ${
                      isActive
                        ? 'border-brand-green-600 bg-brand-green-50/35 shadow-xxs'
                        : 'border-slate-150 bg-slate-50/25 hover:bg-slate-50'
                    }`}
                  >
                    {/* Visual Media Indicator Icon Wrapper */}
                    <div className="w-9 h-9 rounded-xl flex items-center justify-center bg-white border border-slate-200 shrink-0 shadow-xxs">
                      {getIconForType(item.type)}
                    </div>

                    <div className="min-w-0 flex-grow text-xxs">
                      <div className="font-extrabold text-slate-800 line-clamp-1 group-hover:text-brand-green-800 transition">
                        {item.title}
                      </div>
                      <div className="text-[9px] text-slate-400 mt-0.5 font-semibold line-clamp-1">
                        {item.subjectName} &bull; {item.className}
                      </div>
                      <div className="flex items-center gap-2 mt-1 text-[8px] text-slate-400">
                        <span className="bg-slate-100 px-1 py-0.2 rounded font-mono">{item.type}</span>
                        {item.fileSize && <span>{item.fileSize}</span>}
                        {item.duration && <span>{item.duration}</span>}
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={(e) => handleDeleteMedia(item.id, e)}
                      className="text-slate-300 hover:text-red-600 hover:bg-red-50 p-1.5 rounded-lg transition shrink-0 self-center opacity-0 group-hover:opacity-100"
                      title="Hapus media"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* ACTIVE PREVIEW STAGE (2 cols) */}
        <div className="lg:col-span-2 space-y-6">
          {activeMedia ? (
            <div className="bg-white rounded-2xl border border-slate-150 shadow-xxs p-6 space-y-5">
              
              {/* STAGE HEADER AND META */}
              <div className="flex flex-wrap items-center justify-between pb-3.5 border-b border-slate-100 gap-3">
                <div className="space-y-1">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span className="bg-emerald-50 text-emerald-800 text-[9px] font-extrabold px-2.5 py-0.5 rounded-md">
                      {activeMedia.subjectName}
                    </span>
                    <span className="bg-emerald-50 text-emerald-800 text-[9px] font-bold px-2 py-0.5 rounded-md">
                      {activeMedia.className}
                    </span>
                    <span className="bg-blue-50 text-blue-800 text-[9px] font-bold px-2 py-0.5 rounded-md">
                      Topik: {activeMedia.topic}
                    </span>
                  </div>
                  <h3 className="font-bold text-xs text-slate-800 flex items-center gap-1.5">
                    {getIconForType(activeMedia.type)}
                    {activeMedia.title}
                  </h3>
                </div>

                <div className="flex items-center gap-2 text-xxs">
                  <button
                    onClick={() => {
                      alert('Aset media disiapkan untuk dibagikan ke Google Classroom!');
                    }}
                    className="bg-slate-50 hover:bg-slate-100 text-slate-600 font-bold px-3 py-1.5 rounded-lg border border-slate-200 flex items-center gap-1 cursor-pointer transition"
                  >
                    <Share2 className="h-3.5 w-3.5" /> Bagikan
                  </button>

                  <a
                    href={activeMedia.sourceUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="bg-brand-green-700 hover:bg-brand-green-800 text-white font-bold px-3 py-1.5 rounded-lg flex items-center gap-1 cursor-pointer transition shadow-xxs"
                  >
                    <Download className="h-3.5 w-3.5" /> Ambil / Akses Asli
                  </a>
                </div>
              </div>

              {/* CORE INTERACTIVE STAGE VIEWER ACCORDING TO TYPE */}
              <div className="bg-slate-900 rounded-xl overflow-hidden min-h-[340px] flex flex-col justify-between text-white relative">
                
                {/* 1. YOUTUBE VIEW */}
                {activeMedia.type === 'YouTube' && (
                  <div className="w-full h-[340px] bg-black">
                    <iframe
                      width="100%"
                      height="100%"
                      src={activeMedia.sourceUrl}
                      title={activeMedia.title}
                      frameBorder="0"
                      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                      allowFullScreen
                      referrerPolicy="no-referrer"
                    />
                  </div>
                )}

                {/* 2. CANVA SEMAT INTERACTIVE */}
                {activeMedia.type === 'Canva' && (
                  <div className="w-full h-[340px] bg-slate-950 flex flex-col items-center justify-center p-8 text-center space-y-4">
                    <div className="w-16 h-16 bg-purple-900/30 rounded-full flex items-center justify-center text-purple-400 border border-purple-500/30 animate-pulse">
                      <Layout className="h-8 w-8" />
                    </div>
                    <div className="space-y-1 max-w-sm">
                      <h4 className="font-bold text-xs">Penyematan Canva Pro Terdeteksi</h4>
                      <p className="text-[10px] text-slate-405 leading-relaxed">
                        Papan tulis kolaboratif terintegrasi dengan tautan akun guru. Klik tombol akses di bawah untuk mengisi kuiz saku adab secara langsung.
                      </p>
                    </div>
                    <a
                      href="https://canva.com"
                      target="_blank"
                      rel="noreferrer"
                      className="bg-purple-600 hover:bg-purple-700 text-white font-bold px-5 py-2 rounded-xl text-xxs flex items-center gap-1.5 transition"
                    >
                      Buka Kolaborasi Canva <ExternalLink className="h-3.5 w-3.5" />
                    </a>
                  </div>
                )}

                {/* 3. PPT PRESENTATION SLIDE CAROUSEL SIMULATOR */}
                {activeMedia.type === 'PPT' && (
                  <div className="w-full h-[340px] bg-amber-950 flex flex-col justify-between p-6 select-none relative" style={{ backgroundImage: 'radial-gradient(circle, #3d1c02 0%, #170a00 100%)' }}>
                    
                    {/* Top slide counts */}
                    <div className="flex justify-between items-center text-[10px] font-mono text-amber-300 pointer-events-none">
                      <span className="uppercase font-semibold tracking-wider">Presentasi Akademik Al Faraby</span>
                      <span>Halaman Slide {currentPptSlide} dari {TOTAL_PPT_SLIDES}</span>
                    </div>

                    {/* Continuous Simulated Slide Body Content rendering on state */}
                    <div className="flex-grow flex flex-col items-center justify-center text-center space-y-4 mt-4 px-4">
                      
                      {currentPptSlide === 1 && (
                        <div className="space-y-2 max-w-lg">
                          <h4 className="text-sm font-extrabold text-amber-100 tracking-tight leading-tight uppercase school-display">
                            Membina Adab Terpuji Terhadap Orang Tua & Masyarakat
                          </h4>
                          <p className="text-[10px] text-amber-200/80 leading-relaxed font-medium">
                            Disusun oleh: Bidang Studi Tarbiyah SD Islam Al Faraby Bogor. Silaturahmi sebagai kunci dibukanya pintu rezeki yang luas.
                          </p>
                        </div>
                      )}

                      {currentPptSlide === 2 && (
                        <div className="space-y-2 max-w-lg animate-in fade-in">
                          <h4 className="text-xs font-bold text-amber-200 uppercase tracking-widest">Kandungan Dalil Naqli</h4>
                          <blockquote className="text-[10px] text-amber-100/90 italic leading-relaxed font-semibold">
                            "Sembahlah Allah dan janganlah kamu mempersekutukan-Nya dengan sesuatupun. Dan berbuat baiklah kepada dua orang ibu-bapa..."
                          </blockquote>
                          <span className="text-[8px] text-amber-300 font-mono italic block">- QS. An-Nisa: 36</span>
                        </div>
                      )}

                      {currentPptSlide === 3 && (
                        <div className="space-y-2 max-w-lg animate-in fade-in">
                          <h4 className="text-xs font-bold text-amber-200 uppercase tracking-widest">3 Aspek Birrul Walidain</h4>
                          <div className="grid grid-cols-3 gap-2 text-left">
                            <div className="bg-amber-900/40 p-2 rounded border border-amber-850">
                              <div className="text-[9px] font-bold text-amber-300">1. Ketaatan</div>
                              <p className="text-[7.5px] text-amber-200/80 mt-1">Mentaati perintah selama tidak dalam maksiat.</p>
                            </div>
                            <div className="bg-amber-900/40 p-2 rounded border border-amber-850">
                              <div className="text-[9px] font-bold text-amber-300">2. Kelembutan</div>
                              <p className="text-[7.5px] text-amber-200/80 mt-1">Berbicara dengan intonasi rendah dan santun.</p>
                            </div>
                            <div className="bg-amber-900/40 p-2 rounded border border-amber-850">
                              <div className="text-[9px] font-bold text-amber-300">3. Doa</div>
                              <p className="text-[7.5px] text-amber-200/80 mt-1">Mendoakan ampunan siang maupun malam.</p>
                            </div>
                          </div>
                        </div>
                      )}

                      {currentPptSlide === 4 && (
                        <div className="space-y-2 max-w-lg text-left animate-in">
                          <h4 className="text-xs font-bold text-amber-200 uppercase tracking-widest text-center">Etika Bertamu dalam Islam</h4>
                          <ul className="text-[9px] text-amber-100/90 list-disc pl-4 space-y-1">
                            <li>Mengucapkan salam maksimal 3x sebelum dipersilahkan.</li>
                            <li>Tidak menghadap ke arah dalam pintu sebelum memperoleh izin.</li>
                            <li>Menghindari bertamu di waktu tidur siang atau larat malam.</li>
                          </ul>
                        </div>
                      )}

                      {currentPptSlide === 5 && (
                        <div className="space-y-3 max-w-lg text-center animate-in">
                          <h4 className="text-xs font-bold text-amber-200 uppercase tracking-widest">Kuis Interaktif Pendek</h4>
                          <p className="text-[9px] text-amber-105 leading-relaxed font-medium">
                            Apabila tuan rumah tampak sibuk dan belum bisa menemui kita setelah salam ketiga, adab terbaik kita adalah...
                          </p>
                          <div className="inline-block bg-emerald-800 text-white text-[8px] font-bold px-3 py-1 rounded">
                            Jawaban Benar: Memohon izin untuk pamit kembali lain waktu.
                          </div>
                        </div>
                      )}

                      {currentPptSlide === 6 && (
                        <div className="space-y-2 max-w-md animate-in">
                          <h4 className="text-xs font-bold text-amber-300 uppercase tracking-widest">Alhamdulillah, Selesai!</h4>
                          <p className="text-[9px] text-amber-100">Jadilah santri pembela kehormatan akhlak orang tua.</p>
                          <button
                            onClick={() => setCurrentPptSlide(1)}
                            className="bg-amber-700 hover:bg-amber-600 text-white font-bold text-[8px] px-2.5 py-1 rounded transition uppercase"
                          >
                            Putar Kembali
                          </button>
                        </div>
                      )}

                    </div>

                    {/* Bottom Navigation controls */}
                    <div className="flex justify-between items-center pt-4 border-t border-amber-900/50">
                      <button
                        onClick={() => setCurrentPptSlide(prev => Math.max(1, prev - 1))}
                        disabled={currentPptSlide === 1}
                        className="bg-amber-800/60 hover:bg-amber-700 text-amber-100 p-1.5 rounded-lg text-xxs transition disabled:opacity-30 disabled:cursor-not-allowed flex items-center"
                      >
                        <ChevronLeft className="h-4 w-4" /> Slide Sebelumnya
                      </button>

                      <div className="flex gap-1">
                        {Array.from({ length: TOTAL_PPT_SLIDES }).map((_, i) => (
                          <div
                            key={i}
                            onClick={() => setCurrentPptSlide(i + 1)}
                            className={`h-1.5 w-1.5 rounded-full cursor-pointer transition-colors ${
                              currentPptSlide === i + 1 ? 'bg-amber-400' : 'bg-amber-800'
                            }`}
                          />
                        ))}
                      </div>

                      <button
                        onClick={() => setCurrentPptSlide(prev => Math.min(TOTAL_PPT_SLIDES, prev + 1))}
                        disabled={currentPptSlide === TOTAL_PPT_SLIDES}
                        className="bg-amber-800/60 hover:bg-amber-700 text-amber-100 p-1.5 rounded-lg text-xxs transition disabled:opacity-30 disabled:cursor-not-allowed flex items-center"
                      >
                        Slide Selanjutnya <ChevronRight className="h-4 w-4" />
                      </button>
                    </div>

                  </div>
                )}

                {/* 4. AUDIO MUSIC STREAM VIEWER PLAYER */}
                {activeMedia.type === 'Audio' && (
                  <div className="w-full h-[340px] bg-slate-950 flex flex-col justify-between p-6 text-center">
                     
                     <div className="text-[10px] text-indigo-400 font-mono tracking-widest uppercase">
                       Media Audio Player Terpadu
                     </div>

                     <div className="my-auto space-y-4 max-w-sm mx-auto">
                       <div className="w-16 h-16 bg-indigo-900/30 rounded-full flex items-center justify-center text-indigo-400 border border-indigo-500/30 mx-auto">
                         <Music className={`h-8 w-8 ${isPlayingAudio ? 'animate-spin' : ''}`} />
                       </div>

                       <div>
                         <h4 className="font-bold text-xs">{activeMedia.title}</h4>
                         <p className="text-[9px] text-slate-400 mt-1">Format: Standar .MP3 &bull; Durasi: {activeMedia.duration || '04:12'}</p>
                       </div>

                       {/* Interactive Waveform visual mockup */}
                       <div className="flex items-end justify-center gap-1 h-8 px-4">
                         {Array.from({ length: 24 }).map((_, waveIdx) => {
                           const randomHeight = isPlayingAudio 
                             ? Math.floor(Math.random() * 20) + 4 
                             : [4, 6, 8, 12, 14, 18, 12, 10, 8, 6, 4, 3, 5, 8, 14, 22, 18, 12, 10, 8, 6, 4, 5, 4][waveIdx];
                           return (
                             <div
                               key={waveIdx}
                               className={`w-1 rounded-full transition-all duration-300 ${
                                 isPlayingAudio ? 'bg-indigo-400' : 'bg-slate-700'
                               }`}
                               style={{ height: `${randomHeight}px` }}
                             />
                           );
                         })}
                       </div>

                       {/* Control action triggers */}
                       <button
                         onClick={toggleAudioPlay}
                         className="mx-auto w-12 h-12 bg-indigo-600 hover:bg-indigo-700 text-white rounded-full flex items-center justify-center transition shadow-md cursor-pointer"
                       >
                         {isPlayingAudio ? (
                           <Pause className="h-5 w-5 fill-white" />
                         ) : (
                           <Play className="h-5 w-5 fill-white ml-0.5" />
                         )}
                       </button>
                     </div>

                     <div className="text-[9px] text-slate-500 italic">
                       * Kontrol audio interaktif fungsional didengar untuk menghafal ayat Al Quran.
                     </div>
                  </div>
                )}

                {/* 5. IMAGE / LIGHTBOX PREVIEW */}
                {activeMedia.type === 'Gambar' && (
                  <div className="w-full h-[340px] bg-slate-900 flex items-center justify-center relative overflow-hidden group">
                    <img
                      src={activeMedia.sourceUrl}
                      alt={activeMedia.title}
                      className="max-w-full max-h-full object-contain"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end p-4">
                      <span className="text-[10px] text-white/95 font-semibold">Infografis resolusi tinggi santri madrasah.</span>
                    </div>
                  </div>
                )}

                {/* 6. PDF PREVIEW VIEWER SIMULATOR */}
                {activeMedia.type === 'PDF' && (
                  <div className="w-full h-[340px] bg-slate-800 flex flex-col justify-between p-4">
                    
                    {/* Toolbar mockup */}
                    <div className="flex justify-between items-center bg-slate-900 text-slate-300 p-2 rounded text-[10px] font-semibold">
                      <span>Tajwid_Concept_Map.pdf</span>
                      <div className="flex items-center gap-2">
                        <span>Halaman 1 dari 8</span>
                        <Maximize2 className="h-3 w-3 text-slate-400 hover:text-white cursor-pointer" />
                      </div>
                    </div>

                    {/* PDF visual mockup placeholder */}
                    <div className="flex-grow bg-white text-slate-800 my-3 rounded p-4 flex flex-col justify-between shadow-inner animate-in">
                       <div className="space-y-3">
                         <h4 className="font-extrabold text-xs text-rose-800 border-b pb-1.5 uppercase tracking-wide">ILMU TAJWID DASAR - NUN MATI & TANWIN</h4>
                         
                         <table className="w-full border-collapse text-[9px] leading-relaxed">
                           <thead>
                             <tr className="bg-slate-100 text-slate-700 font-bold">
                               <th className="border p-1">Hukum Bacaan</th>
                               <th className="border p-1">Sebab Pertemuan</th>
                               <th className="border p-1">Cara Bacaan</th>
                             </tr>
                           </thead>
                           <tbody className="font-semibold">
                             <tr>
                               <td className="border p-1 text-rose-700 font-bold">1. Idzhar Halqi</td>
                               <td className="border p-1">Nun mati bertemu (أ, هـ, ع, ح, غ, خ)</td>
                               <td className="border p-1">Dibaca jelas, tanpa mendengung</td>
                             </tr>
                             <tr>
                               <td className="border p-1 text-teal-700 font-bold">2. Idgham Bighunnah</td>
                               <td className="border p-1">Nun mati bertemu (ي, ن, م, و)</td>
                               <td className="border p-1">Dibuka, dimasukkan & mendengung</td>
                             </tr>
                             <tr>
                               <td className="border p-1 text-amber-700 font-bold">3. Iqlab</td>
                               <td className="border p-1">Nun mati bertemu Ba (ب)</td>
                               <td className="border p-1">Merubah suara nun menjadi mim</td>
                             </tr>
                           </tbody>
                         </table>
                         
                         <p className="text-[8px] text-slate-500 italic text-justify leading-tight">
                           Catatan: Ingatlah ustadz bahwa melafalkan idzhar tidak boleh ditekan terlalu keras, tetap dibaca lunak sesuai sifat huruf makhraj halqi demi mempertahankan estetika adab bertilawah.
                         </p>
                       </div>
                    </div>

                    <div className="text-[9px] text-center text-slate-400">
                      Silakan klik tombol <span className="text-white font-bold">"Ambil / Akses Asli"</span> di atas untuk mengunduh naskah PDF lengkap.
                    </div>
                  </div>
                )}

                {/* 7. OTHER LOCAL VIDEOS MP4 */}
                {activeMedia.type === 'Video' && (
                  <div className="w-full h-[340px] bg-black flex flex-col justify-between p-6 text-center">
                    <div className="text-[10px] text-blue-400 font-mono tracking-widest uppercase">
                       Media Player Video Terpadu
                     </div>

                     <div className="my-auto space-y-3 max-w-sm mx-auto">
                       <div className="w-16 h-16 bg-blue-900/30 rounded-full flex items-center justify-center text-blue-400 border border-blue-500/30 mx-auto animate-pulse">
                         <Play className="h-8 w-8 text-blue-400 fill-blue-300" />
                       </div>
                       <div>
                         <h4 className="font-bold text-xs">{activeMedia.title}</h4>
                         <p className="text-[9px] text-slate-400">Format Video MP4 &bull; Durasi: {activeMedia.duration || '05:00'}</p>
                       </div>
                     </div>

                     <button
                       onClick={() => alert('Simulasi: Video MP4 diputar di layar penuh.')}
                       className="mx-auto bg-blue-600 hover:bg-blue-700 text-white font-bold text-xxs px-4 py-2 rounded-xl"
                     >
                       Putar Video Sekarang
                     </button>
                  </div>
                )}

              </div>

              {/* ACTIVE PREVIEW BOTTOM DESCRIPTION METAS */}
              <div className="space-y-3 p-4 bg-slate-50/50 rounded-xl border border-slate-100 text-xxs/relaxed text-slate-650">
                <div>
                  <span className="font-extrabold text-slate-700 block uppercase text-[9px] tracking-wider mb-0.5">Petunjuk & Deskripsi Media:</span>
                  <p className="font-medium text-slate-600">
                    {activeMedia.description}
                  </p>
                </div>

                <div className="pt-2 border-t border-slate-200 flex flex-wrap items-center justify-between text-slate-400 text-[10px] font-semibold gap-2">
                  <div className="flex items-center gap-1">
                    <Clock className="h-3.5 w-3.5 text-slate-400" />
                    <span>Diupload: {activeMedia.dateAdded}</span>
                  </div>
                  <span>Total Diakses: {activeMedia.downloadsCount + 12} guru wali</span>
                </div>
              </div>

            </div>
          ) : (
            <div className="bg-white rounded-2xl border border-slate-150 p-16 text-center text-slate-450 shadow-xxs">
              <BookOpen className="h-12 w-12 text-slate-250 mx-auto mb-3" />
              <p className="text-xs font-semibold">Silakan buat baru atau pilih media pembelajaran di sisi kiri untuk memulai penayangan.</p>
            </div>
          )}
        </div>

      </div>

    </div>
  );
}
