/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import {
  Users,
  BookOpen,
  ClipboardList,
  FolderGit,
  Settings,
  Shield,
  LayoutDashboard,
  Heart,
  Award,
  LogOut,
  Sparkles,
  Cloud,
  Clock,
  ChevronDown,
  User,
  Lock,
  Mail,
  CheckCircle2,
  AlertTriangle,
  Database,
  FileText,
  Presentation,
  ChevronLeft,
  ChevronRight
} from 'lucide-react';
import { Student, Teacher, Subject, LessonPlan, AttendanceLog, TeachingJournal, CharacterLog, AcademicScore, DigitalFile, ActivityLog, SchoolProfile, UserRole, Classroom, AcademicYear, SystemUser } from './types';
import {
  INITIAL_STUDENTS,
  INITIAL_TEACHERS,
  INITIAL_SUBJECTS,
  INITIAL_CLASSROOMS,
  INITIAL_ACADEMIC_YEARS,
  INITIAL_LESSON_PLANS,
  INITIAL_ATTENDANCE,
  INITIAL_JOURNALS,
  INITIAL_CHARACTER_LOGS,
  INITIAL_ACADEMIC_SCORES,
  INITIAL_DIGITAL_FILES,
  INITIAL_ACTIVITY_LOGS,
  SCHOOL_PROFILE
} from './mockData';

// Import Modular Subcomponents
import DashboardView from './components/DashboardView';
import MasterDataView from './components/MasterDataView';
import AdministrasiPembelajaranView from './components/AdministrasiPembelajaranView';
import AdministrasiKelasView from './components/AdministrasiKelasView';
import PenilaianView from './components/PenilaianView';
import LaporanView from './components/LaporanView';
import ArsipDigitalView from './components/ArsipDigitalView';
import PengaturanView from './components/PengaturanView';
import SuperAdminView from './components/SuperAdminView';
import GoogleSyncPanel from './components/GoogleSyncPanel';
import BankSoalView from './components/BankSoalView';
import LkpdView from './components/LkpdView';
import MediaPembelajaranView from './components/MediaPembelajaranView';

export default function App() {
  // Authentication states
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [currentUser, setCurrentUser] = useState({
    name: 'Ustadzah Siti Nurhaliza, S.Pd.I.',
    role: UserRole.GURU as string,
    email: 'sitinurhaliza@alfaraby.sch.id'
  });
  
  // Login Page states
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPass, setLoginPass] = useState('');
  const [isResetMode, setIsResetMode] = useState(false);
  const [resetEmailText, setResetEmailText] = useState('');

  // Primary Workspace States
  const [menuSelection, setMenuSelection] = useState<string>('Dashboard');
  const [sidebarCollapsed, setSidebarCollapsed] = useState<boolean>(false);
  const [students, setStudents] = useState<Student[]>(INITIAL_STUDENTS);
  const [teachers, setTeachers] = useState<Teacher[]>(INITIAL_TEACHERS);
  const [subjects, setSubjects] = useState<Subject[]>(INITIAL_SUBJECTS);
  const [classrooms, setClassrooms] = useState<Classroom[]>(INITIAL_CLASSROOMS);
  const [academicYears, setAcademicYears] = useState<AcademicYear[]>(INITIAL_ACADEMIC_YEARS);
  const [lessonPlans, setLessonPlans] = useState<LessonPlan[]>(INITIAL_LESSON_PLANS);
  const [attendanceLogs, setAttendanceLogs] = useState<AttendanceLog[]>(INITIAL_ATTENDANCE);
  const [teachingJournals, setTeachingJournals] = useState<TeachingJournal[]>(INITIAL_JOURNALS);
  const [characterLogs, setCharacterLogs] = useState<CharacterLog[]>(INITIAL_CHARACTER_LOGS);
  const [files, setFiles] = useState<DigitalFile[]>(INITIAL_DIGITAL_FILES);
  const [activityLogs, setActivityLogs] = useState<ActivityLog[]>(INITIAL_ACTIVITY_LOGS);
  const [schoolProfile, setSchoolProfile] = useState<SchoolProfile>(SCHOOL_PROFILE);
  const [usersList, setUsersList] = useState<SystemUser[]>([
    { id: 'usr-1', name: 'Ustadz Ahmad Al-Faruq, M.Pd.', email: 'ahmadfaruq@alfaraby.sch.id', role: 'Administrator', isActive: true, phone: '081255556666', createdAt: '17-Jun-2026' },
    { id: 'usr-2', name: 'Dr. KH. Maimun Zubair, M.A.', email: 'maimunzubair@alfaraby.sch.id', role: 'Kepala Sekolah', isActive: true, phone: '081122233344', createdAt: '17-Jun-2026' },
    { id: 'usr-3', name: 'Ustadzah Siti Nurhaliza, S.Pd.I.', email: 'sitinurhaliza@alfaraby.sch.id', role: 'Guru', isActive: true, phone: '085211223344', createdAt: '17-Jun-2026' },
    { id: 'usr-4', name: 'Ustadz Hanif Al-Hafiz', email: 'hanifalhafiz@alfaraby.sch.id', role: 'Operator', isActive: true, phone: '081344445555', createdAt: '17-Jun-2026' },
    { id: 'usr-5', name: 'Ustadz Ahmad Dahlan, M.Pd.', email: 'dahlan.alfaraby@gmail.com', role: 'Guru', isActive: false, phone: '085299887766', createdAt: '16-Jun-2026' }
  ]);

  const [enabledMenus, setEnabledMenus] = useState<Record<string, boolean>>({
    'Dashboard': true,
    'Master Data': true,
    'Administrasi Pembelajaran': true,
    'Administrasi Kelas': true,
    'Penilaian': true,
    'Bank Soal': true,
    'LKPD / LKS': true,
    'Media Pembelajaran': true,
    'Laporan': true,
    'Arsip Digital': true,
    'Pengaturan': true,
    'Super Admin': true,
  });

  // Google Sync Trackers
  const [lastSynced, setLastSynced] = useState({
    sheets: '17-Jun-2026 03:00 WIB',
    drive: '17-Jun-2026 03:15 WIB',
    calendar: '17-Jun-2026 02:45 WIB',
    gmail: '17-Jun-2026 03:30 WIB'
  });

  // Track session duration clock
  const [sessionTime, setSessionTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setSessionTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // System Audit Helper
  const logSystemActivity = (action: string, details: string) => {
    const newLog: ActivityLog = {
      id: 'AL' + Math.floor(Math.random() * 100000).toString(),
      timestamp: new Date().toLocaleString('id-ID', { hour12: false }) + ' WIB',
      userName: currentUser.name,
      userRole: currentUser.role,
      userEmail: currentUser.email,
      action: action,
      details: details
    };
    setActivityLogs(prev => [newLog, ...prev]);
  };

  // Google Authentication Trigger
  const handleGoogleSignIn = () => {
    setCurrentUser({
      name: 'Ustadz Ahmad Al-Faruq, M.Pd.',
      role: UserRole.ADMIN,
      email: 'ahmadfaruq@alfaraby.sch.id'
    });
    setIsAuthenticated(true);
    // Log trace
    const timeNow = new Date().toLocaleString('id-ID', { hour12: false }) + ' WIB';
    const newLog: ActivityLog = {
      id: 'AL-G' + Math.floor(Math.random() * 10000).toString(),
      timestamp: timeNow,
      userName: 'Ustadz Ahmad Al-Faruq, M.Pd.',
      userRole: UserRole.ADMIN,
      userEmail: 'ahmadfaruq@alfaraby.sch.id',
      action: 'Login Sukses',
      details: 'Masuk sistem via Secure OpenID Google OAuth'
    };
    setActivityLogs(prev => [newLog, ...prev]);
    alert('Selamat datang! Sukses terautentikasi otomatis menggunakan Google OAuth G-Suite Santri Al Faraby.');
  };

  const handleCredentialsSignIn = (e: React.FormEvent) => {
    e.preventDefault();
    if (!loginEmail || !loginPass) return;
    
    // Check credentials inside active usersList database first
    const matchedUser = usersList.find(u => u.email.toLowerCase() === loginEmail.toLowerCase());
    
    let assignedRole = UserRole.GURU as string;
    let assignedName = 'Ustadzah Siti Nurhaliza, S.Pd.I.';
    
    if (matchedUser) {
      if (!matchedUser.isActive) {
        alert('Gagal Masuk: Akun Anda sedang dinonaktifkan oleh Administrator!');
        return;
      }
      assignedRole = matchedUser.role;
      assignedName = matchedUser.name;
    } else {
      // Fallback for demo convenience
      if (loginEmail.toLowerCase().includes('admin')) {
        assignedRole = UserRole.ADMIN;
        assignedName = 'Ustadz Ahmad Al-Faruq, M.Pd.';
      } else if (loginEmail.toLowerCase().includes('kepsek')) {
        assignedRole = UserRole.KEPSEK;
        assignedName = 'Dr. KH. Maimun Zubair, M.A.';
      } else if (loginEmail.toLowerCase().includes('operator')) {
        assignedRole = UserRole.OPERATOR;
        assignedName = 'Ustadz Hanif Al-Hafiz';
      }
    }

    setCurrentUser({
      name: assignedName,
      role: assignedRole,
      email: loginEmail
    });
    setIsAuthenticated(true);

    const timeNow = new Date().toLocaleString('id-ID', { hour12: false }) + ' WIB';
    const newLog: ActivityLog = {
      id: 'AL-C' + Math.floor(Math.random() * 10000).toString(),
      timestamp: timeNow,
      userName: assignedName,
      userRole: assignedRole,
      userEmail: loginEmail,
      action: 'Login Sukses',
      details: `Pengguna masuk portal via email ${loginEmail}`
    };
    setActivityLogs(prev => [newLog, ...prev]);
    alert(`Berhasil login sebagai ${assignedName} (${assignedRole})`);
  };

  const handleResetPassword = (e: React.FormEvent) => {
    e.preventDefault();
    if (!resetEmailText) return;
    alert(`Tautan pemulihan kata sandi darurat sukses dikirimkan ke ${resetEmailText}. Silakan periksa kotak masuk Gmail Anda.`);
    setIsResetMode(false);
  };

  const handleLogout = () => {
    const isConfirmed = window.confirm('Apakah Anda hendak keluar dari sesi administrasi saat ini?');
    if (!isConfirmed) return;
    logSystemActivity('Logout Sukses', 'Meninggalkan sistem administrasi kelas');
    setIsAuthenticated(false);
    setLoginEmail('');
    setLoginPass('');
  };

  // Google Sync operations simulation
  const handleGoogleSyncTrigger = (type: 'sheets' | 'drive' | 'calendar' | 'gmail') => {
    const stamp = new Date().toLocaleString('id-ID', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' }) + ' WIB';
    setLastSynced(prev => ({ ...prev, [type]: stamp }));
    logSystemActivity('Sinkronisasi Cloud', `Pembaruan sinkronisasi terarah sektor: ${type.toUpperCase()}`);
  };

  // State update modifications
  const handleAddSubject = (sub: Subject) => {
    setSubjects(prev => [sub, ...prev]);
    logSystemActivity('Registrasi Mapel', `Menambahkan mata pelajaran baru ${sub.name}`);
  };

  const handleEditSubject = (sub: Subject) => {
    setSubjects(prev => prev.map(item => item.id === sub.id ? sub : item));
    logSystemActivity('Modifikasi Mapel', `Mengubah mata pelajaran ${sub.name}`);
  };

  const handleDeleteSubject = (id: string) => {
    setSubjects(prev => prev.filter(item => item.id !== id));
    logSystemActivity('Penghapusan Mapel', `Menghapus mata pelajaran ID ${id}`);
  };

  const handleAddClassroom = (c: Classroom) => {
    setClassrooms(prev => [c, ...prev]);
    logSystemActivity('Registrasi Kelas', `Menambahkan kelas baru ${c.name}`);
  };

  const handleEditClassroom = (c: Classroom) => {
    setClassrooms(prev => prev.map(item => item.id === c.id ? c : item));
    logSystemActivity('Modifikasi Kelas', `Mengubah data kelas ${c.name}`);
  };

  const handleDeleteClassroom = (id: string) => {
    setClassrooms(prev => prev.filter(item => item.id !== id));
    logSystemActivity('Penghapusan Kelas', `Menghapus kelas ID ${id}`);
  };

  const handleAddAcademicYear = (ay: AcademicYear) => {
    setAcademicYears(prev => [ay, ...prev]);
    logSystemActivity('Registrasi Tahun Pelajaran', `Menambahkan tahun pelajaran ${ay.year} - ${ay.semester}`);
  };

  const handleEditAcademicYear = (ay: AcademicYear) => {
    setAcademicYears(prev => prev.map(item => item.id === ay.id ? ay : item));
    logSystemActivity('Modifikasi Tahun Pelajaran', `Mengubah tahun pelajaran ${ay.year} - ${ay.semester}`);
  };

  const handleDeleteAcademicYear = (id: string) => {
    setAcademicYears(prev => prev.filter(item => item.id !== id));
    logSystemActivity('Penghapusan Tahun Pelajaran', `Menghapus tahun pelajaran ID ${id}`);
  };

  const handleAddStudent = (s: Student) => {
    setStudents(prev => [s, ...prev]);
    logSystemActivity('Registrasi Murid', `Menyisipkan nama santri ${s.name} kelas ${s.classroom}`);
  };

  const handleEditStudent = (s: Student) => {
    setStudents(prev => prev.map(item => item.id === s.id ? s : item));
    logSystemActivity('Modifikasi Murid', `Mengubah profil data santri ${s.name} (${s.nis})`);
  };

  const handleDeleteStudent = (id: string) => {
    setStudents(prev => prev.filter(item => item.id !== id));
    logSystemActivity('Penghapusan Murid', `Mencoret record santri ID ${id}`);
  };

  const handleAddTeacher = (t: Teacher) => {
    setTeachers(prev => [t, ...prev]);
    logSystemActivity('Registrasi Guru', `Mengangkat asatidzah baru ${t.name}`);
  };

  const handleEditTeacher = (t: Teacher) => {
    setTeachers(prev => prev.map(item => item.id === t.id ? t : item));
    logSystemActivity('Modifikasi Guru', `Merombak otoritas ustadz ${t.name}`);
  };

  const handleDeleteTeacher = (id: string) => {
    setTeachers(prev => prev.filter(item => item.id !== id));
    logSystemActivity('Penghapusan Guru', `Mencabut data ustadz ID ${id}`);
  };

  const handleAddLessonPlan = (plan: LessonPlan) => {
    setLessonPlans(prev => [plan, ...prev]);
    logSystemActivity('Penyusunan RPP', `Mengarsip naskah KD RPP "${plan.title}" dengan modul ajar`);
  };

  const handleDeleteLessonPlan = (id: string) => {
    setLessonPlans(prev => prev.filter(plan => plan.id !== id));
    logSystemActivity('Penghapusan RPP', `Membuang naskah RPP ID ${id}`);
  };

  const handleUpdateLessonPlanSync = (id: string, synced: boolean) => {
    setLessonPlans(prev => prev.map(plan => plan.id === id ? { ...plan, syncedToDocs: synced } : plan));
    logSystemActivity('Ekspor Dokumen', `Mengirimkan salinan RPP ID ${id} ke Google Dokumen`);
  };

  const handleAddAttendance = (logs: AttendanceLog[]) => {
    setAttendanceLogs(prev => [...logs, ...prev]);
    logSystemActivity('Perekaman Absensi', `Menyimpan absensi siswa harian`);
  };

  const handleAddJournal = (journal: TeachingJournal) => {
    setTeachingJournals(prev => [journal, ...prev]);
    logSystemActivity('Perekaman Jurnal', `Tulis materi harian tema "${journal.topic}"`);
  };

  const handleDeleteJournal = (id: string) => {
    setTeachingJournals(prev => prev.filter(j => j.id !== id));
    logSystemActivity('Penghapusan Jurnal', `Menghapus entri jurnal mengajar ID ${id}`);
  };

  const handleAddCharacterLog = (log: CharacterLog) => {
    setCharacterLogs(prev => [log, ...prev]);
    logSystemActivity('Pembinaan Adab', `Mencatat akhlak mulia santri ${log.studentName}`);
  };

  const handleDeleteCharacterLog = (id: string) => {
    setCharacterLogs(prev => prev.filter(c => c.id !== id));
    logSystemActivity('Penghapusan Karakter', `Menghapus log adab ID ${id}`);
  };

  const handleAddScore = (score: AcademicScore) => {
    setScoresState(prev => [score, ...prev]);
    logSystemActivity('Penilaian Santri', `Merekam skor formatif UTS/UAS mapel ${score.subjectName} untuk ${score.studentName}`);
  };

  const [scoresState, setScoresState] = useState<AcademicScore[]>(INITIAL_ACADEMIC_SCORES);

  const handleEditScore = (score: AcademicScore) => {
    setScoresState(prev => {
      const exists = prev.some(item => item.id === score.id);
      if (exists) {
        return prev.map(item => item.id === score.id ? score : item);
      } else {
        return [score, ...prev];
      }
    });
    logSystemActivity('Modifikasi Raport', `Menerapkan deskripsi capaian rapor untuk ${score.studentName}`);
  };

  const handleDeleteScore = (id: string) => {
    setScoresState(prev => prev.filter(item => item.id !== id));
    logSystemActivity('Pembatalan Nilai', `Membatalkan perekaman skor ID ${id}`);
  };

  const handleAddFile = (file: DigitalFile) => {
    setFiles(prev => [file, ...prev]);
    logSystemActivity('Arsip Digital', `Mengunggah lembaran berkas "${file.name}"`);
  };

  const handleDeleteFile = (id: string) => {
    setFiles(prev => prev.filter(f => f.id !== id));
    logSystemActivity('Penghapusan Arsip', `Membuang data berkas dari server ID ${id}`);
  };

  const handleUpdateProfile = (p: SchoolProfile) => {
    setSchoolProfile(p);
    logSystemActivity('Sunting Profile', 'Memperbarui profil pokok kelembagaan Al Faraby');
  };

  // Nav Links setup matching specified requirements
  const sidebarLinks = [
    { title: 'Dashboard', icon: LayoutDashboard },
    { title: 'Master Data', icon: Users },
    { title: 'Administrasi Pembelajaran', icon: BookOpen },
    { title: 'Administrasi Kelas', icon: ClipboardList },
    { title: 'Penilaian', icon: Award },
    { title: 'Bank Soal', icon: Database },
    { title: 'LKPD / LKS', icon: FileText },
    { title: 'Media Pembelajaran', icon: Presentation },
    { title: 'Laporan', icon: ClipboardList },
    { title: 'Arsip Digital', icon: FolderGit },
    { title: 'Pengaturan', icon: Settings },
    { title: 'Super Admin', icon: Shield }
  ];

  return (
    <AnimatePresence mode="wait">
      {!isAuthenticated ? (
        <motion.div
          key="login"
          initial={{ opacity: 0, scale: 0.97 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95, y: -20, filter: "blur(10px)" }}
          transition={{ duration: 0.5, ease: [0.34, 1.56, 0.64, 1] }}
          className="min-h-screen relative overflow-hidden bg-gradient-to-tr from-[#021c13] via-[#052b1b] to-[#0d1e21] flex items-center justify-center p-4 selection:bg-emerald-500 selection:text-slate-900 w-full"
        >
          {/* Glowing blur effects behind the glass card for luxury styling */}
          <div className="absolute top-1/4 left-1/4 w-[350px] h-[350px] bg-emerald-500/20 rounded-full blur-[100px] pointer-events-none animate-pulse" style={{ animationDuration: '8s' }} />
          <div className="absolute bottom-1/4 right-1/4 w-[400px] h-[400px] bg-emerald-600/15 rounded-full blur-[120px] pointer-events-none animate-pulse" style={{ animationDuration: '10s' }} />
          <div className="absolute inset-0 opacity-[0.03] bg-[radial-gradient(#ffffff_1px,transparent_1px)] [background-size:32px_32px] pointer-events-none" />

          <div className="w-full max-w-md bg-white/10 backdrop-blur-xl rounded-3xl overflow-hidden shadow-[0_8px_32px_0_rgba(0,0,0,0.37)] border border-white/20 p-8 space-y-6 flex flex-col justify-between relative z-10 transition-all duration-300">
            {/* Brand badge */}
            <div className="text-center space-y-2">
              <div className="h-16 w-16 bg-white/10 backdrop-blur-md rounded-2xl mx-auto flex items-center justify-center shadow-lg border border-white/20">
                <span className="text-2xl text-brand-gold-500 font-bold">&#127969;</span>
              </div>
              <h1 className="text-xl font-bold tracking-tight text-white school-display">
                SD ISLAM AL FARABY
              </h1>
              <p className="text-xs text-emerald-200/70 italic">
                "Unggul dalam Adab, Cerdas dalam Pengetahuan"
              </p>
            </div>

            {isResetMode ? (
              <form onSubmit={handleResetPassword} className="space-y-4">
                <div className="text-xs text-emerald-100 bg-emerald-950/40 p-3 rounded-lg border border-emerald-500/20 leading-relaxed">
                  Tuliskan email guru Anda untuk instrumen pemulihan tautan sandi.
                </div>
                <div>
                  <label className="block text-xxs font-bold text-emerald-200/90 uppercase">E-mail Terdaftar</label>
                  <div className="relative mt-1">
                    <Mail className="absolute left-3 top-3 h-4 w-4 text-emerald-300/60" />
                    <input
                      type="email"
                      required
                      className="w-full text-xs pl-10 pr-4 py-2.5 rounded-xl border border-white/10 bg-white/5 focus:outline-none focus:border-emerald-400 focus:bg-white/10 text-white placeholder-emerald-100/40 focus:ring-2 focus:ring-emerald-500/20"
                      placeholder="nama@alfaraby.sch.id"
                      value={resetEmailText}
                      onChange={e => setResetEmailText(e.target.value)}
                    />
                  </div>
                </div>
                <button
                  type="submit"
                  className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-3 rounded-xl shadow-md cursor-pointer text-xs transition duration-200 hover:scale-[1.02] active:scale-[0.98]"
                >
                  Kirim Tautan Sandi
                </button>
                <button
                  type="button"
                  onClick={() => setIsResetMode(false)}
                  className="w-full text-xxs font-bold text-emerald-200 hover:text-white cursor-pointer text-center block pt-1.5"
                >
                  &larr; Kembali Ke Halaman Login
                </button>
              </form>
            ) : (
              <form onSubmit={handleCredentialsSignIn} className="space-y-4">
                <div>
                  <label className="block text-xxs font-bold text-emerald-200/95 uppercase">E-mail Guru</label>
                  <div className="relative mt-1 block">
                    <Mail className="absolute left-3 top-3 h-4 w-4 text-emerald-300/60" />
                    <input
                      type="text"
                      required
                      id="login-email"
                      className="w-full text-xs pl-10 pr-4 py-2.5 rounded-xl border border-white/10 bg-white/5 focus:outline-none focus:border-emerald-400 focus:bg-white/10 text-white placeholder-emerald-100/30 focus:ring-2 focus:ring-emerald-500/20"
                      placeholder="Contoh: sitinurhaliza@alfaraby.sch.id"
                      value={loginEmail}
                      onChange={e => setLoginEmail(e.target.value)}
                    />
                  </div>
                  <div className="text-xxs text-emerald-200/70 mt-1 italic flex gap-1 items-center justify-between">
                    <span>* Ketik "admin" untuk role Administrator</span>
                    <span>* Ketik "kepsek" untuk Kepala Sekolah</span>
                  </div>
                </div>

                <div>
                  <label className="block text-xxs font-bold text-emerald-200/95 uppercase">Kata Sandi</label>
                  <div className="relative mt-1 block">
                    <Lock className="absolute left-3 top-3 h-4 w-4 text-emerald-300/60" />
                    <input
                      type="password"
                      required
                      id="login-password"
                      className="w-full text-xs pl-10 pr-4 py-2.5 rounded-xl border border-white/10 bg-white/5 focus:outline-none focus:border-emerald-400 focus:bg-white/10 text-white placeholder-emerald-100/30 focus:ring-2 focus:ring-emerald-500/20"
                      placeholder="Masukkan sandi..."
                      value={loginPass}
                      onChange={e => setLoginPass(e.target.value)}
                    />
                  </div>
                  <button
                    type="button"
                    onClick={() => setIsResetMode(true)}
                    className="text-xxxxs text-amber-300 hover:text-amber-200 block text-right mt-1.5 font-bold cursor-pointer"
                  >
                    Lupa password?
                  </button>
                </div>

                <button
                  type="submit"
                  id="login-submit-btn"
                  className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-xs py-3 rounded-xl shadow-lg transition duration-200 hover:scale-[1.02] active:scale-[0.98] cursor-pointer"
                >
                  Masuk Sistem Administrasi
                </button>

                <div className="relative flex py-2 items-center">
                  <div className="flex-grow border-t border-white/10" />
                  <span className="flex-shrink mx-3 text-xxxxs text-emerald-200/60 uppercase font-bold tracking-wider">Atau Masuk Melalui</span>
                  <div className="flex-grow border-t border-white/10" />
                </div>

                <button
                  type="button"
                  id="google-login-btn"
                  onClick={handleGoogleSignIn}
                  className="w-full border border-white/10 hover:bg-white/10 bg-white/5 text-white font-bold text-xs py-2.5 rounded-xl transition flex items-center justify-center gap-2 cursor-pointer shadow-sm"
                >
                  <svg className="h-4 w-4" viewBox="0 0 24 24">
                    <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                    <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                    <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22-.19-.63z" />
                    <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
                  </svg>
                  Masuk menggunakan Akun Google G-Suite
                </button>
              </form>
            )}

            <div className="pt-2 text-center text-xxxxs text-emerald-200/50 font-medium">
              Sistem Administrasi Santri Terpadu Al-Faraby Bogor &bull; TA 2026/2027
            </div>
          </div>
        </motion.div>
      ) : (
        <motion.div
          key="workspace"
          initial={{ opacity: 0, scale: 0.98, filter: "blur(6px)" }}
          animate={{ opacity: 1, scale: 1, filter: "blur(0px)" }}
          transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
          className="md:h-screen md:overflow-hidden bg-[#02130e] flex flex-col md:flex-row font-sans selection:bg-emerald-500 selection:text-slate-900 w-full relative"
        >
          {/* Background blurs */}
          <div className="absolute top-[10%] right-[10%] w-[500px] h-[500px] bg-emerald-500/5 rounded-full blur-[140px] pointer-events-none" />
          <div className="absolute bottom-[15%] left-[5%] w-[400px] h-[400px] bg-teal-500/5 rounded-full blur-[120px] pointer-events-none" />

          {/* 1. SIDEBAR DECK */}
          <aside className={`w-full md:h-full md:overflow-y-auto bg-emerald-950/40 backdrop-blur-xl text-white flex flex-col shrink-0 border-r border-white/5 shadow-2xl transition-all duration-300 relative z-20 ${
            sidebarCollapsed ? 'md:w-20' : 'md:w-68'
          }`}>
            {/* Institutional Branding Header */}
            <div className={`border-b border-white/5 flex transition-all duration-300 ${
              sidebarCollapsed 
                ? 'p-4 flex-col items-center justify-center gap-3' 
                : 'p-6 items-center justify-between gap-3'
            }`}>
              <div className="flex items-center gap-3 overflow-hidden">
                <div className="w-10 h-10 bg-white/10 backdrop-blur-md rounded-lg flex items-center justify-center font-bold text-white text-sm md:text-xl shadow-md shrink-0 border border-white/10">
                  AF
                </div>
                {!sidebarCollapsed && (
                  <div className="transition-all duration-300">
                    <h1 className="text-sm font-bold tracking-wider leading-tight text-white uppercase font-display whitespace-nowrap">
                      SD ISLAM<br/>AL FARABY
                    </h1>
                  </div>
                )}
              </div>
              <button
                onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
                className={`p-1 rounded bg-white/5 hover:bg-white/10 border border-white/10 text-emerald-200 hover:text-white transition cursor-pointer md:block hidden ${
                  sidebarCollapsed ? 'scale-100' : 'scale-90 shadow-xs'
                }`}
                title={sidebarCollapsed ? "Perluas Sidebar" : "Sembunyikan Sidebar"}
              >
                {sidebarCollapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
              </button>
            </div>

            {/* Navigation Menu Links */}
            <nav className="flex-grow py-4 space-y-0.5">
              {sidebarLinks.filter(link => {
                if (link.title === 'Super Admin' && currentUser.role === 'Administrator') {
                  return true;
                }
                return enabledMenus[link.title] !== false;
              }).map((link) => {
                const LinkIcon = link.icon;
                const isSelected = menuSelection === link.title;
                return (
                  <button
                    key={link.title}
                    onClick={() => setMenuSelection(link.title)}
                    className={`w-full text-left flex items-center gap-3 font-semibold text-xs transition cursor-pointer border-l-4 ${
                      sidebarCollapsed ? 'px-0 justify-center py-4' : 'px-6 py-3'
                    } ${
                      isSelected
                        ? 'bg-white/10 border-l-4 border-emerald-400 text-white font-extrabold shadow-sm'
                        : 'border-transparent text-emerald-100/85 hover:text-white hover:bg-white/5 transition-colors opacity-80 hover:opacity-100'
                    }`}
                    title={sidebarCollapsed ? link.title : undefined}
                  >
                    <LinkIcon className={`h-4.5 w-4.5 shrink-0 ${isSelected ? 'text-white' : 'text-emerald-300'}`} />
                    {!sidebarCollapsed && <span>{link.title}</span>}
                  </button>
                );
              })}
            </nav>

            {/* Operator profile card footer panel */}
            <div className={`border-t border-white/5 mt-auto text-xs bg-transparent transition-all duration-300 ${
              sidebarCollapsed ? 'p-4 flex flex-col items-center' : 'p-6'
            }`}>
              <div className="flex items-center gap-3">
                <div className="h-8 w-8 rounded-full bg-emerald-400 flex items-center justify-center text-emerald-900 font-bold text-[10px] md:text-xs uppercase shrink-0">
                  {currentUser.name.charAt(currentUser.name.indexOf(' ') + 1) || 'AF'}
                </div>
                {!sidebarCollapsed && (
                  <div className="min-w-0 transition-opacity duration-300">
                    <h4 className="font-semibold text-xs text-white leading-normal truncate">{currentUser.name.split(',')[0]}</h4>
                    <span className="text-[10px] text-emerald-300 block mt-0.5 uppercase tracking-wide">
                      {currentUser.role}
                    </span>
                  </div>
                )}
              </div>

              <button
                onClick={handleLogout}
                className={`mt-4 flex items-center justify-center gap-2 bg-rose-500/10 hover:bg-rose-600/20 text-rose-200 border border-rose-500/20 py-1.5 rounded-lg font-bold transition cursor-pointer ${
                  sidebarCollapsed ? 'w-8 h-8 px-0 py-0 rounded-full' : 'w-full text-xxs'
                }`}
                title="Keluar Sesi"
              >
                <LogOut className="h-3 w-3" />
                {!sidebarCollapsed && <span>Keluar Sesi</span>}
              </button>
            </div>
          </aside>

          {/* 2. MAIN DISPLAY FRAME WORKSPACE */}
          <main className="flex-1 flex flex-col min-w-0 md:h-full md:overflow-y-auto relative z-10">
            
            {/* Top Navbar */}
            <header className="h-16 bg-white/5 backdrop-blur-lg border-b border-white/5 flex items-center justify-between px-8 shadow-sm shrink-0">
              <div className="flex items-center gap-3 text-sm text-white/70">
                <span>Beranda</span>
                <span>/</span>
                <span className="font-semibold text-emerald-400 school-display">
                  {menuSelection}
                </span>
                <span className="h-4 w-px bg-white/10 hidden sm:inline" />
                <div className="hidden sm:flex items-center gap-1.5 text-xxs text-white/40 font-semibold uppercase tracking-wider">
                  <Clock className="h-3 w-3 text-emerald-400" />
                  Sesi: {sessionTime.toLocaleTimeString('id-ID', { hour12: false })} WIB
                </div>
              </div>

              {/* Cloud sync widgets mini indicators */}
              <div className="flex items-center gap-3 bg-white/5 border border-white/10 rounded-full px-4 py-1.5 text-xxs font-bold text-white/90">
                <Cloud className="h-3.5 w-3.5 text-emerald-400 animate-pulse" />
                <span className="text-white/60">Last Sync Sheets:</span>
                <span className="text-emerald-400">{lastSynced.sheets.split(' ')[1]} WIB</span>
              </div>
            </header>

            {/* Scrollable Work stage container */}
            <section className="flex-1 p-8 overflow-y-auto max-w-7xl w-full mx-auto space-y-6">
          
          {menuSelection === 'Dashboard' && (
            <div className="space-y-6 animate-in fade-in duration-150">
              <DashboardView
                students={students}
                teachers={teachers}
                subjects={subjects}
                rppCount={lessonPlans.length}
                activityLogs={activityLogs}
                activeUser={currentUser}
                onNavigateTo={setMenuSelection}
              />
              <GoogleSyncPanel lastSynced={lastSynced} onTriggerSync={handleGoogleSyncTrigger} />
            </div>
          )}

          {menuSelection === 'Master Data' && (
            <div className="animate-in fade-in duration-150">
              <MasterDataView
                students={students}
                teachers={teachers}
                subjects={subjects}
                classrooms={classrooms}
                academicYears={academicYears}
                onAddStudent={handleAddStudent}
                onEditStudent={handleEditStudent}
                onDeleteStudent={handleDeleteStudent}
                onAddTeacher={handleAddTeacher}
                onEditTeacher={handleEditTeacher}
                onDeleteTeacher={handleDeleteTeacher}
                onAddSubject={handleAddSubject}
                onEditSubject={handleEditSubject}
                onDeleteSubject={handleDeleteSubject}
                onAddClassroom={handleAddClassroom}
                onEditClassroom={handleEditClassroom}
                onDeleteClassroom={handleDeleteClassroom}
                onAddAcademicYear={handleAddAcademicYear}
                onEditAcademicYear={handleEditAcademicYear}
                onDeleteAcademicYear={handleDeleteAcademicYear}
              />
            </div>
          )}

          {menuSelection === 'Administrasi Pembelajaran' && (
            <div className="animate-in fade-in duration-150">
              <AdministrasiPembelajaranView
                subjects={subjects}
                lessonPlans={lessonPlans}
                onAddLessonPlan={handleAddLessonPlan}
                onDeleteLessonPlan={handleDeleteLessonPlan}
                onUpdateLessonPlanSync={handleUpdateLessonPlanSync}
              />
            </div>
          )}

          {menuSelection === 'Administrasi Kelas' && (
            <div className="animate-in fade-in duration-150">
              <AdministrasiKelasView
                students={students}
                attendanceLogs={attendanceLogs}
                teachingJournals={teachingJournals}
                characterLogs={characterLogs}
                onAddAttendance={handleAddAttendance}
                onAddJournal={handleAddJournal}
                onAddCharacterLog={handleAddCharacterLog}
                onDeleteJournal={handleDeleteJournal}
                onDeleteCharacterLog={handleDeleteCharacterLog}
              />
            </div>
          )}

          {menuSelection === 'Penilaian' && (
            <div className="animate-in fade-in duration-150">
              <PenilaianView
                students={students}
                subjects={subjects}
                academicScores={scoresState}
                onAddScore={handleAddScore}
                onEditScore={handleEditScore}
                onDeleteScore={handleDeleteScore}
              />
            </div>
          )}

          {menuSelection === 'Bank Soal' && (
            <div className="animate-in fade-in duration-150">
              <BankSoalView subjects={subjects} />
            </div>
          )}

          {menuSelection === 'LKPD / LKS' && (
            <div className="animate-in fade-in duration-150">
              <LkpdView subjects={subjects} />
            </div>
          )}

          {menuSelection === 'Media Pembelajaran' && (
            <div className="animate-in fade-in duration-150">
              <MediaPembelajaranView subjects={subjects} />
            </div>
          )}

          {menuSelection === 'Laporan' && (
            <div className="animate-in fade-in duration-150">
              <LaporanView
                students={students}
                subjects={subjects}
                academicScores={scoresState}
                attendanceLogs={attendanceLogs}
                teachingJournals={teachingJournals}
                teachers={teachers}
              />
            </div>
          )}

          {menuSelection === 'Arsip Digital' && (
            <div className="animate-in fade-in duration-150">
              <ArsipDigitalView
                files={files}
                onAddFile={handleAddFile}
                onDeleteFile={handleDeleteFile}
              />
            </div>
          )}

          {menuSelection === 'Pengaturan' && (
            <div className="animate-in fade-in duration-150">
              <PengaturanView
                schoolProfile={schoolProfile}
                onUpdateProfile={handleUpdateProfile}
              />
            </div>
          )}

          {menuSelection === 'Super Admin' && (
            <div className="animate-in fade-in duration-150">
              <SuperAdminView
                activityLogs={activityLogs}
                currentRole={currentUser.role}
                onRoleChange={(role) => {
                  setCurrentUser(prev => ({ ...prev, role }));
                  logSystemActivity('Pergantian Peran', `Beralih peran aktif simulator ke: ${role}`);
                }}
                onClearLogs={() => {
                  setActivityLogs([]);
                  logSystemActivity('Pembersihan Log', 'Membersihkan riwayat log aktivitas audit sistem');
                }}
                users={usersList}
                onAddUser={(user) => {
                  setUsersList(prev => [user, ...prev]);
                  logSystemActivity('Registrasi Pengguna', `Menambahkan pengguna baru: ${user.name} (${user.role})`);
                }}
                onUpdateUser={(updated) => {
                  setUsersList(prev => prev.map(u => u.id === updated.id ? updated : u));
                  logSystemActivity('Pembaruan Pengguna', `Mengubah profil pengguna: ${updated.name}`);
                }}
                onDeleteUser={(id) => {
                  const usr = usersList.find(u => u.id === id);
                  setUsersList(prev => prev.filter(u => u.id !== id));
                  if (usr) {
                    logSystemActivity('Penghapusan Akun', `Menghapus hak akun pengguna: ${usr.name}`);
                  }
                }}
                enabledMenus={enabledMenus}
                onToggleMenu={(menu) => {
                  setEnabledMenus(prev => {
                    const upd = { ...prev, [menu]: !prev[menu] };
                    return upd;
                  });
                  logSystemActivity('Pengaturan Menu', `Mengubah visibilitas untuk menu: ${menu}`);
                }}
                onResetMenus={() => {
                  setEnabledMenus({
                    'Dashboard': true,
                    'Master Data': true,
                    'Administrasi Pembelajaran': true,
                    'Administrasi Kelas': true,
                    'Penilaian': true,
                    'Bank Soal': true,
                    'LKPD / LKS': true,
                    'Media Pembelajaran': true,
                    'Laporan': true,
                    'Arsip Digital': true,
                    'Pengaturan': true,
                    'Super Admin': true,
                  });
                  logSystemActivity('Pengaturan Menu', 'Mengembalikan setting visibilitas menu seperti awal');
                }}
                onDatabaseSeeding={() => {
                  setStudents(INITIAL_STUDENTS);
                  setTeachers(INITIAL_TEACHERS);
                  setSubjects(INITIAL_SUBJECTS);
                  setClassrooms(INITIAL_CLASSROOMS);
                  setAcademicYears(INITIAL_ACADEMIC_YEARS);
                  setLessonPlans(INITIAL_LESSON_PLANS);
                  setAttendanceLogs(INITIAL_ATTENDANCE);
                  setTeachingJournals(INITIAL_JOURNALS);
                  setCharacterLogs(INITIAL_CHARACTER_LOGS);
                  setFiles(INITIAL_DIGITAL_FILES);
                  setScoresState(INITIAL_ACADEMIC_SCORES);
                  logSystemActivity('Pemulihan Basis Data', 'Mengonstruksi ulang database SD Islam Al Faraby ke data pabrik default');
                  alert('Database berhasil di-reset & di-seed ulang ke data awal default!');
                }}
                onDatabaseReset={() => {
                  setStudents([]);
                  setTeachers([]);
                  setSubjects([]);
                  setClassrooms([]);
                  setAcademicYears([]);
                  setLessonPlans([]);
                  setAttendanceLogs([]);
                  setTeachingJournals([]);
                  setCharacterLogs([]);
                  setFiles([]);
                  setScoresState([]);
                  logSystemActivity('Pembersihan Basis Data', 'Mengosongkan relasi dan seluruh record operasional kontemporer');
                  alert('Seluruh tabel database berhasil dikosongkan secara tuntas!');
                }}
              />
            </div>
          )}

        </section>
      </main>
    </motion.div>
    )}
    </AnimatePresence>
  );
}
