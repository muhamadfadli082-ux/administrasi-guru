import React, { useState } from 'react';
import { UserCheck, Book, ClipboardList, PenTool, Users, Archive, QrCode, Plus } from 'lucide-react';

export function ClassAdmin() {
  const [activeTab, setActiveTab] = useState('absensi');

  const tabs = [
    { id: 'absensi', label: 'Absensi Siswa', icon: <UserCheck size={16} /> },
    { id: 'agenda', label: 'Buku Agenda', icon: <Book size={16} /> },
    { id: 'jurnal', label: 'Jurnal Mengajar', icon: <ClipboardList size={16} /> },
    { id: 'catatan', label: 'Catatan Siswa', icon: <PenTool size={16} /> },
    { id: 'tamu', label: 'Buku Tamu', icon: <Users size={16} /> },
    { id: 'inventaris', label: 'Inventaris Kelas', icon: <Archive size={16} /> },
  ];

  const siswa = [
    { no: 1, nis: '2324001', nama: 'Ahmad Al Faruq', jk: 'L' },
    { no: 2, nis: '2324002', nama: 'Aisyah Putri', jk: 'P' },
    { no: 3, nis: '2324003', nama: 'Bima Sakti', jk: 'L' },
    { no: 4, nis: '2324004', nama: 'Citra Kirana', jk: 'P' },
    { no: 5, nis: '2324005', nama: 'Daffa Almer', jk: 'L' },
  ];

  return (
    <div className="flex flex-col md:flex-row gap-6 h-[calc(100vh-8rem)]">
      {/* Sidebar Tabs */}
      <div className="w-full md:w-64 bg-white rounded-xl shadow-sm border border-gray-100 flex flex-col shrink-0 overflow-y-auto">
        <div className="p-4 border-b border-gray-100 bg-gray-50">
          <h3 className="font-bold text-gray-900">Pilih Menu</h3>
          <p className="text-xs text-gray-500">Administrasi Kelas 5A</p>
        </div>
        <div className="p-2 space-y-1">
          {tabs.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                activeTab === tab.id 
                  ? 'bg-blue-50 text-blue-700' 
                  : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
              }`}
            >
              <span className={activeTab === tab.id ? 'text-blue-600' : 'text-gray-400'}>
                {tab.icon}
              </span>
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 bg-white rounded-xl shadow-sm border border-gray-100 flex flex-col min-w-0 overflow-y-auto">
        {activeTab === 'absensi' ? (
          <div className="flex flex-col h-full">
            <div className="p-6 border-b border-gray-100 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
              <div>
                <h3 className="text-lg font-bold text-gray-900">Absensi Harian</h3>
                <p className="text-sm text-gray-500">Kamis, 19 Juni 2026</p>
              </div>
              <div className="flex gap-2">
                <button className="flex items-center gap-2 bg-gray-100 text-gray-700 px-3 py-2 rounded-lg text-sm font-medium hover:bg-gray-200 transition-colors">
                  <QrCode size={18} />
                  <span>Scan QR Code</span>
                </button>
                <button className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-blue-700 transition-colors">
                  <UserCheck size={18} />
                  <span>Simpan Kehadiran</span>
                </button>
              </div>
            </div>

            <div className="flex-1 p-6 overflow-auto">
              <div className="border border-gray-200 rounded-lg overflow-hidden">
                <table className="w-full text-sm text-left">
                  <thead className="text-xs text-gray-700 uppercase bg-gray-50 border-b border-gray-200">
                    <tr>
                      <th className="px-4 py-3 font-semibold w-12 text-center">No</th>
                      <th className="px-4 py-3 font-semibold">NIS</th>
                      <th className="px-4 py-3 font-semibold">Nama Siswa</th>
                      <th className="px-4 py-3 font-semibold w-16 text-center">L/P</th>
                      <th className="px-4 py-3 font-semibold text-center w-64">Status Kehadiran</th>
                    </tr>
                  </thead>
                  <tbody>
                    {siswa.map((s) => (
                      <tr key={s.no} className="bg-white border-b hover:bg-gray-50">
                        <td className="px-4 py-3 text-center">{s.no}</td>
                        <td className="px-4 py-3">{s.nis}</td>
                        <td className="px-4 py-3 font-medium text-gray-900">{s.nama}</td>
                        <td className="px-4 py-3 text-center">{s.jk}</td>
                        <td className="px-4 py-3 flex justify-center gap-2">
                          <label className="flex items-center gap-1 cursor-pointer">
                            <input type="radio" name={`status-${s.no}`} defaultChecked className="w-4 h-4 text-green-600 border-gray-300 focus:ring-green-500" />
                            <span className="text-xs font-medium text-gray-700">H</span>
                          </label>
                          <label className="flex items-center gap-1 cursor-pointer ml-3">
                            <input type="radio" name={`status-${s.no}`} className="w-4 h-4 text-yellow-500 border-gray-300 focus:ring-yellow-500" />
                            <span className="text-xs font-medium text-gray-700">S</span>
                          </label>
                          <label className="flex items-center gap-1 cursor-pointer ml-3">
                            <input type="radio" name={`status-${s.no}`} className="w-4 h-4 text-blue-500 border-gray-300 focus:ring-blue-500" />
                            <span className="text-xs font-medium text-gray-700">I</span>
                          </label>
                          <label className="flex items-center gap-1 cursor-pointer ml-3">
                            <input type="radio" name={`status-${s.no}`} className="w-4 h-4 text-red-600 border-gray-300 focus:ring-red-500" />
                            <span className="text-xs font-medium text-gray-700">A</span>
                          </label>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        ) : activeTab === 'jurnal' ? (
          <div className="flex flex-col h-full">
            <div className="p-6 border-b border-gray-100 flex justify-between items-center">
              <div>
                <h3 className="text-lg font-bold text-gray-900">Jadwal & Jurnal Mengajar</h3>
                <p className="text-sm text-gray-500">Kamis, 19 Juni 2026</p>
              </div>
              <button className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-blue-700 transition-colors">
                <Plus size={18} />
                <span>Isi Jurnal</span>
              </button>
            </div>
            <div className="p-6 overflow-y-auto space-y-6">
              {[
                { time: '07:30 - 08:30', mapel: 'IPAS', materi: 'Bab 2: Sistem Peredaran Darah', status: 'Selesai', kegiatan: 'Menonton video animasi sistem peredaran darah, tanya jawab, dan pengerjaan LKPD.' },
                { time: '08:30 - 09:30', mapel: 'Matematika', materi: 'Operasi Hitung Pecahan Campuran', status: 'Selesai', kegiatan: 'Penjelasan konsep, diskusi kelompok menyelesaikan soal, presentasi hasil.' },
                { time: '10:00 - 11:30', mapel: 'Bahasa Indonesia', materi: 'Teks Persuasi', status: 'Belum Diisi', kegiatan: '-' }
              ].map((jurnal, i) => (
                <div key={i} className="border border-gray-200 rounded-xl p-5 hover:border-blue-300 transition-colors bg-white">
                  <div className="flex justify-between items-start mb-3">
                    <div className="flex items-center gap-3">
                      <span className="text-sm font-bold text-gray-600 w-24">{jurnal.time}</span>
                      <span className={`px-2 py-1 rounded text-xs font-medium ${
                        jurnal.mapel === 'IPAS' ? 'bg-green-50 text-green-700' :
                        jurnal.mapel === 'Matematika' ? 'bg-red-50 text-red-700' :
                        'bg-blue-50 text-blue-700'
                      }`}>
                        {jurnal.mapel}
                      </span>
                    </div>
                    <span className={`text-xs font-semibold px-2 py-1 rounded-full ${
                      jurnal.status === 'Selesai' ? 'bg-blue-100 text-blue-700' : 'bg-gray-100 text-gray-600'
                    }`}>
                      {jurnal.status}
                    </span>
                  </div>
                  <h4 className="font-bold text-gray-900 mb-1">{jurnal.materi}</h4>
                  <p className="text-sm text-gray-600"><span className="font-medium text-gray-700">Kegiatan:</span> {jurnal.kegiatan}</p>
                </div>
              ))}
            </div>
          </div>
        ) : activeTab === 'agenda' ? (
          <div className="flex flex-col h-full">
            <div className="p-6 border-b border-gray-100 flex justify-between items-center">
              <div>
                <h3 className="text-lg font-bold text-gray-900">Buku Agenda Kelas</h3>
                <p className="text-sm text-gray-500">Catatan harian kegiatan kelas 5A</p>
              </div>
              <button className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-blue-700 transition-colors">
                <Plus size={18} /> Tambah Agenda
              </button>
            </div>
            <div className="p-6 overflow-y-auto space-y-4">
              <div className="border border-gray-200 rounded-xl p-5 bg-white">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm font-medium text-gray-500">19 Juni 2026</span>
                  <span className="px-2 py-1 bg-purple-50 text-purple-700 rounded text-xs font-medium">Kegiatan Khusus</span>
                </div>
                <h4 className="font-bold text-gray-900 mb-1">Kunjungan Perpustakaan Daerah</h4>
                <p className="text-sm text-gray-600">Siswa diajak berkunjung ke perpustakaan daerah untuk kegiatan literasi membaca buku fiksi.</p>
              </div>
              <div className="border border-gray-200 rounded-xl p-5 bg-white">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm font-medium text-gray-500">18 Juni 2026</span>
                  <span className="px-2 py-1 bg-green-50 text-green-700 rounded text-xs font-medium">Rutin</span>
                </div>
                <h4 className="font-bold text-gray-900 mb-1">Kerja Bakti Membersihkan Kelas</h4>
                <p className="text-sm text-gray-600">Kegiatan jumat bersih, siswa membersihkan lingkungan sekitar ruang kelas 5A.</p>
              </div>
            </div>
          </div>
        ) : activeTab === 'catatan' ? (
          <div className="flex flex-col h-full">
            <div className="p-6 border-b border-gray-100 flex justify-between items-center">
              <div>
                <h3 className="text-lg font-bold text-gray-900">Catatan Siswa (Anekdotal)</h3>
                <p className="text-sm text-gray-500">Jurnal perkembangan sikap & perilaku</p>
              </div>
              <button className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-blue-700 transition-colors">
                <PenTool size={18} /> Tulis Catatan
              </button>
            </div>
            <div className="p-6 overflow-y-auto">
              <div className="border border-gray-200 rounded-lg overflow-hidden">
                <table className="w-full text-sm text-left">
                  <thead className="bg-gray-50 text-gray-700 font-semibold border-b border-gray-200">
                    <tr>
                      <th className="px-4 py-3">Tanggal</th>
                      <th className="px-4 py-3">Nama Siswa</th>
                      <th className="px-4 py-3">Peristiwa/Keterangan</th>
                      <th className="px-4 py-3 text-center">Jenis</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100">
                    <tr className="bg-white hover:bg-gray-50">
                      <td className="px-4 py-3 text-gray-600">18 Jun 2026</td>
                      <td className="px-4 py-3 font-medium text-gray-900">Bima Sakti</td>
                      <td className="px-4 py-3 text-gray-800">Menemukan dompet jatuh di lapangan dan menyerahkan ke guru piket.</td>
                      <td className="px-4 py-3 text-center"><span className="px-2 py-1 bg-green-100 text-green-700 text-xs rounded-full font-medium">Positif</span></td>
                    </tr>
                    <tr className="bg-white hover:bg-gray-50">
                      <td className="px-4 py-3 text-gray-600">15 Jun 2026</td>
                      <td className="px-4 py-3 font-medium text-gray-900">Daffa Almer</td>
                      <td className="px-4 py-3 text-gray-800">Tertidur di kelas saat jam pelajaran matematika. Sudah ditegur.</td>
                      <td className="px-4 py-3 text-center"><span className="px-2 py-1 bg-red-100 text-red-700 text-xs rounded-full font-medium">Negatif</span></td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        ) : activeTab === 'inventaris' ? (
          <div className="flex flex-col h-full">
            <div className="p-6 border-b border-gray-100 flex justify-between items-center">
              <div>
                <h3 className="text-lg font-bold text-gray-900">Inventaris Kelas</h3>
                <p className="text-sm text-gray-500">Daftar barang dan sarana prasarana kelas 5A</p>
              </div>
              <button className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-blue-700 transition-colors">
                <Plus size={18} /> Tambah Barang
              </button>
            </div>
            <div className="p-6 overflow-y-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {[
                { nama: 'Papan Tulis Whiteboard', jumlah: 1, kondisi: 'Baik', kode: 'INV.001' },
                { nama: 'Meja Siswa Ganda', jumlah: 15, kondisi: 'Layak Pakai', kode: 'INV.002' },
                { nama: 'Kursi Kayu Siswa', jumlah: 30, kondisi: 'Baik', kode: 'INV.003' },
                { nama: 'Lemari Buku (Kaca)', jumlah: 2, kondisi: 'Rusak Ringan', kode: 'INV.004' },
                { nama: 'Jam Dinding Besar', jumlah: 1, kondisi: 'Baik', kode: 'INV.005' },
              ].map((item, idx) => (
                <div key={idx} className="border border-gray-200 p-4 rounded-xl relative hover:border-blue-300 bg-white shadow-sm flex flex-col justify-between">
                  <div>
                    <div className="text-xs text-gray-400 mb-1">{item.kode}</div>
                    <h4 className="font-bold text-gray-800 mb-2">{item.nama}</h4>
                  </div>
                  <div className="mt-4 flex justify-between items-center">
                    <span className="text-2xl font-black text-blue-600">{item.jumlah} <span className="text-xs font-normal text-gray-500">Buah</span></span>
                    <span className={`text-xs px-2 py-1 rounded font-medium ${
                      item.kondisi === 'Baik' ? 'bg-green-50 text-green-700' :
                      item.kondisi === 'Rusak Ringan' ? 'bg-yellow-50 text-yellow-700' :
                      'bg-gray-100 text-gray-600'
                    }`}>{item.kondisi}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ) : (
          <div className="flex-1 flex items-center justify-center flex-col text-gray-500 p-6">
            {tabs.find(t => t.id === activeTab)?.icon && React.cloneElement(tabs.find(t => t.id === activeTab)!.icon as any, { size: 48, className: "mb-4 text-gray-300" })}
            <h3 className="text-lg font-medium text-gray-900 mb-1">{tabs.find(t => t.id === activeTab)?.label}</h3>
            <p className="text-sm text-center max-w-sm mt-2">Modul ini sedang dalam pengembangan.</p>
          </div>
        )}
      </div>
    </div>
  );
}
