import React, { useState } from 'react';
import { FileText, Plus, Download, Printer, Sparkles, Loader2, X, BookOpen, Calendar, Clock, Book } from 'lucide-react';
import ReactMarkdown from 'react-markdown';

export function LearningAdmin() {
  const [activeTab, setActiveTab] = useState('modul');
  const [isGenerating, setIsGenerating] = useState(false);
  const [showAiModal, setShowAiModal] = useState(false);
  const [aiPrompt, setAiPrompt] = useState('Modul Ajar Matematika, Kelas 5, Materi Pecahan Campuran');
  const [aiResult, setAiResult] = useState('');

  const [modulData, setModulData] = useState([
    { judul: 'Modul Ajar Bab 1: Bilangan Pecahan', mapel: 'Matematika', fase: 'C (Kelas 5)', status: 'Selesai', date: '12 Jul 2023' },
    { judul: 'Modul Ajar Bab 2: KPK dan FPB', mapel: 'Matematika', fase: 'C (Kelas 5)', status: 'Selesai', date: '20 Jul 2023' },
    { judul: 'Modul Ajar Bab 1: Teks Narasi', mapel: 'Bahasa Indonesia', fase: 'C (Kelas 5)', status: 'Draft', date: '25 Jul 2023' },
  ]);

  const tabs = [
    { id: 'cp', label: 'Capaian Pembelajaran (CP)' },
    { id: 'tp', label: 'Tujuan Pembelajaran (TP)' },
    { id: 'atp', label: 'Alur Tujuan Pembelajaran' },
    { id: 'modul', label: 'Modul Ajar' },
    { id: 'prota', label: 'Prota & Promes' },
    { id: 'jadwal', label: 'Jadwal Mengajar' },
  ];

  const handleGenerateAI = async () => {
    setIsGenerating(true);
    setAiResult('');
    try {
      const response = await fetch('/api/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: `Buatkan outline Modul Ajar (RPP Kurikulum Merdeka) untuk: ${aiPrompt}. Format dengan markdown singkat dan rapi.` }),
      });
      const data = await response.json();
      if (data.result) {
        setAiResult(data.result);
        setModulData([
          { judul: `Modul Ajar: ${aiPrompt.split(',')[2] || 'Baru'}`, mapel: aiPrompt.split(',')[0], fase: aiPrompt.split(',')[1] || 'C', status: 'Draft', date: new Date().toLocaleDateString('id-ID') },
          ...modulData
        ]);
      } else {
        setAiResult('Gagal menghasilkan modul. Pastikan API key dikonfigurasi.');
      }
    } catch (e) {
      setAiResult('Terjadi kesalahan saat memanggil API.');
    }
    setIsGenerating(false);
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 flex flex-col h-[calc(100vh-8rem)] relative">
      {/* AI Modal */}
      {showAiModal && (
        <div className="absolute inset-0 z-50 bg-black/50 rounded-xl flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-xl w-full max-w-2xl flex flex-col max-h-[90%]">
            <div className="p-4 border-b border-gray-100 flex justify-between items-center bg-gray-50 rounded-t-xl">
              <h3 className="font-bold flex items-center gap-2"><Sparkles className="text-purple-500" size={20} /> Generate Modul Ajar dengan AI</h3>
              <button onClick={() => setShowAiModal(false)} className="text-gray-500 hover:text-gray-900"><X size={20} /></button>
            </div>
            <div className="p-6 overflow-y-auto flex-1">
              <label className="block text-sm font-medium text-gray-700 mb-2">Deskripsikan Modul Ajar yang Anda inginkan</label>
              <textarea 
                value={aiPrompt}
                onChange={(e) => setAiPrompt(e.target.value)}
                className="w-full border border-gray-300 rounded-lg p-3 text-sm focus:ring-purple-500 focus:border-purple-500"
                rows={3}
              ></textarea>
              <button 
                onClick={handleGenerateAI}
                disabled={isGenerating}
                className="mt-4 bg-purple-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-purple-700 transition flex items-center gap-2 w-full justify-center disabled:opacity-70"
              >
                {isGenerating ? <Loader2 className="animate-spin" size={18} /> : <Sparkles size={18} />}
                {isGenerating ? 'Sedang Memproses...' : 'Generate Sekarang'}
              </button>

              {aiResult && (
                <div className="mt-6">
                  <h4 className="font-semibold text-gray-900 mb-2 text-sm">Hasil Generate (Draft Tersimpan):</h4>
                  <div className="p-4 bg-gray-50 rounded-lg border border-gray-200 text-sm prose prose-sm max-w-none max-h-64 overflow-y-auto">
                    <ReactMarkdown>{aiResult}</ReactMarkdown>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      <div className="border-b border-gray-100 flex overflow-x-auto">
        {tabs.map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`px-5 py-4 text-sm font-medium whitespace-nowrap border-b-2 transition-colors ${
              activeTab === tab.id 
                ? 'border-blue-600 text-blue-600' 
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      <div className="p-6 flex-1 flex flex-col overflow-auto">
        {activeTab === 'modul' ? (
          <>
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
              <div>
                <h3 className="text-lg font-bold text-gray-900">Daftar Modul Ajar</h3>
                <p className="text-sm text-gray-500">Kelola modul ajar sesuai Kurikulum Merdeka</p>
              </div>
              <div className="flex gap-2">
                <button 
                  onClick={() => setShowAiModal(true)}
                  className="flex items-center gap-2 bg-purple-100 text-purple-700 border border-purple-200 px-4 py-2 rounded-lg text-sm font-medium hover:bg-purple-200 transition-colors"
                >
                  <Sparkles size={18} />
                  <span>Generate AI</span>
                </button>
                <button className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-blue-700 transition-colors">
                  <Plus size={18} />
                  <span>Buat Manual</span>
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {modulData.map((modul, i) => (
                <div key={i} className="border border-gray-200 rounded-xl p-5 hover:border-blue-300 hover:shadow-md transition-all group bg-white">
                  <div className="flex justify-between items-start mb-4">
                    <div className="p-2 bg-blue-50 text-blue-600 rounded-lg">
                      <FileText size={24} />
                    </div>
                    <span className={`text-xs font-medium px-2 py-1 rounded-full ${
                      modul.status === 'Selesai' ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-600'
                    }`}>
                      {modul.status}
                    </span>
                  </div>
                  <h4 className="font-bold text-gray-900 mb-1 line-clamp-2">{modul.judul}</h4>
                  <p className="text-sm text-gray-500 mb-4">{modul.mapel} &bull; Fase {modul.fase}</p>
                  
                  <div className="pt-4 border-t border-gray-100 flex justify-between items-center mt-auto">
                    <span className="text-xs text-gray-400">Dibuat: {modul.date}</span>
                    <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button className="p-1.5 text-gray-500 hover:text-blue-600 hover:bg-blue-50 rounded"><Download size={16}/></button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </>
        ) : activeTab === 'jadwal' ? (
          <div>
            <div className="flex justify-between items-center mb-6">
              <div>
                <h3 className="text-lg font-bold text-gray-900">Jadwal Mengajar</h3>
                <p className="text-sm text-gray-500">Tahun Pelajaran 2023/2024 - Semester Ganjil</p>
              </div>
              <button className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-blue-700 transition">
                <Printer size={16} /> Cetak Jadwal
              </button>
            </div>
            <div className="border border-gray-200 rounded-lg overflow-hidden">
              <table className="w-full text-sm text-left">
                <thead className="bg-gray-50 text-gray-700 font-semibold border-b border-gray-200">
                  <tr>
                    <th className="px-4 py-3">Hari</th>
                    <th className="px-4 py-3">Jam Ke</th>
                    <th className="px-4 py-3">Waktu</th>
                    <th className="px-4 py-3">Mata Pelajaran</th>
                    <th className="px-4 py-3">Kelas</th>
                    <th className="px-4 py-3">Ruang</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  <tr className="bg-white hover:bg-gray-50">
                    <td className="px-4 py-3 font-medium text-gray-900" rowSpan={3}>Senin</td>
                    <td className="px-4 py-3 text-center">1-2</td>
                    <td className="px-4 py-3 flex items-center gap-2"><Clock size={14} className="text-gray-400"/> 07:30 - 08:30</td>
                    <td className="px-4 py-3"><span className="px-2 py-1 bg-blue-50 text-blue-700 rounded text-xs font-medium">Upacara / IPAS</span></td>
                    <td className="px-4 py-3">5A</td>
                    <td className="px-4 py-3 text-gray-500">R. 05</td>
                  </tr>
                  <tr className="bg-white hover:bg-gray-50">
                    <td className="px-4 py-3 text-center">3-4</td>
                    <td className="px-4 py-3 flex items-center gap-2"><Clock size={14} className="text-gray-400"/> 08:30 - 09:30</td>
                    <td className="px-4 py-3"><span className="px-2 py-1 bg-red-50 text-red-700 rounded text-xs font-medium">Matematika</span></td>
                    <td className="px-4 py-3">5A</td>
                    <td className="px-4 py-3 text-gray-500">R. 05</td>
                  </tr>
                  <tr className="bg-gray-50">
                    <td colSpan={5} className="px-4 py-2 text-center text-gray-500 text-xs italic">Istirahat</td>
                  </tr>
                  <tr className="bg-white hover:bg-gray-50">
                    <td className="px-4 py-3 font-medium text-gray-900 border-t border-gray-200">Selasa</td>
                    <td className="px-4 py-3 text-center border-t border-gray-200">1-2</td>
                    <td className="px-4 py-3 flex items-center gap-2 border-t border-gray-200"><Clock size={14} className="text-gray-400"/> 07:30 - 08:30</td>
                    <td className="px-4 py-3 border-t border-gray-200"><span className="px-2 py-1 bg-green-50 text-green-700 rounded text-xs font-medium">Bahasa Indonesia</span></td>
                    <td className="px-4 py-3 border-t border-gray-200">5A</td>
                    <td className="px-4 py-3 text-gray-500 border-t border-gray-200">R. 05</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        ) : activeTab === 'prota' ? (
          <div>
             <div className="flex justify-between items-center mb-6">
              <div>
                <h3 className="text-lg font-bold text-gray-900">Program Tahunan & Semester</h3>
                <p className="text-sm text-gray-500">Alokasi waktu pembelajaran selama satu tahun ajaran</p>
              </div>
              <button className="bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-blue-700 transition">
                <Plus size={16} className="inline mr-1" /> Tambah Baru
              </button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {['Program Tahunan (Prota) IPAS Kelas 5', 'Program Semester (Promes) IPAS Ganjil', 'Program Tahunan Matematika Kelas 5', 'Program Semester Matematika Genap'].map((item, idx) => (
                <div key={idx} className="border border-gray-200 p-4 rounded-xl flex items-start gap-4 hover:border-blue-300 transition-colors bg-white">
                  <div className="p-3 bg-blue-50 text-blue-600 rounded-lg shrink-0">
                    <Book size={20} />
                  </div>
                  <div className="flex-1">
                    <h4 className="font-semibold text-gray-800 text-sm">{item}</h4>
                    <p className="text-xs text-gray-500 mt-1">Tahun Ajaran 2023/2024</p>
                  </div>
                  <button className="text-gray-400 hover:text-blue-600 transition">
                    <Download size={18} />
                  </button>
                </div>
              ))}
            </div>
          </div>
        ) : activeTab === 'cp' ? (
          <div>
            <div className="flex justify-between items-center mb-6">
              <div>
                <h3 className="text-lg font-bold text-gray-900">Capaian Pembelajaran (CP)</h3>
                <p className="text-sm text-gray-500">Berdasarkan BSKAP Kemdikbudristek (Kurikulum Merdeka)</p>
              </div>
              <button className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-blue-700 transition">
                <Download size={16} /> Import dari Excel
              </button>
            </div>
            <div className="grid gap-4">
              {['IPAS - Fase C', 'Matematika - Fase C', 'Bahasa Indonesia - Fase C'].map((item, idx) => (
                <div key={idx} className="border border-gray-200 p-5 rounded-xl bg-white hover:border-blue-300 transition-colors">
                  <div className="flex justify-between items-center mb-2">
                    <h4 className="font-bold text-gray-800">{item}</h4>
                    <span className="px-2 py-1 bg-gray-100 text-gray-600 rounded text-xs">Capaian Umum</span>
                  </div>
                  <p className="text-sm text-gray-600 leading-relaxed">Peserta didik mampu memahami dan menerapkan konsep dasar sesuai dengan fase capaian yang telah ditetapkan, mengembangkan keterampilan berpikir kritis, serta menunjukkan sikap profil pelajar pancasila dalam kehidupan sehari-hari...</p>
                  <button className="text-blue-600 text-sm font-medium mt-3 hover:underline">Lihat Detail CP per Elemen</button>
                </div>
              ))}
            </div>
          </div>
        ) : activeTab === 'tp' ? (
          <div>
            <div className="flex justify-between items-center mb-6">
              <div>
                <h3 className="text-lg font-bold text-gray-900">Tujuan Pembelajaran (TP)</h3>
                <p className="text-sm text-gray-500">Breakdown dari Capaian Pembelajaran</p>
              </div>
              <button className="bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-blue-700 transition">
                <Plus size={16} className="inline mr-1" /> Buat TP Baru
              </button>
            </div>
            <div className="border border-gray-200 rounded-lg overflow-hidden">
              <table className="w-full text-sm text-left">
                <thead className="bg-gray-50 text-gray-700 font-semibold border-b border-gray-200">
                  <tr>
                    <th className="px-4 py-3">Kode TP</th>
                    <th className="px-4 py-3">Elemen CP</th>
                    <th className="px-4 py-3">Deskripsi Tujuan Pembelajaran</th>
                    <th className="px-4 py-3">Aksi</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  <tr className="bg-white hover:bg-gray-50">
                    <td className="px-4 py-3 font-medium text-gray-900">TP.IPAS.5.1</td>
                    <td className="px-4 py-3 text-gray-600">Pemahaman IPAS</td>
                    <td className="px-4 py-3 text-gray-800">Siswa dapat menjelaskan fungsi sistem peredaran darah manusia.</td>
                    <td className="px-4 py-3"><button className="text-blue-600 hover:text-blue-800 font-medium">Edit</button></td>
                  </tr>
                  <tr className="bg-white hover:bg-gray-50">
                    <td className="px-4 py-3 font-medium text-gray-900">TP.MTK.5.1</td>
                    <td className="px-4 py-3 text-gray-600">Bilangan</td>
                    <td className="px-4 py-3 text-gray-800">Siswa dapat melakukan operasi hitung penjumlahan pecahan beda penyebut.</td>
                    <td className="px-4 py-3"><button className="text-blue-600 hover:text-blue-800 font-medium">Edit</button></td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        ) : activeTab === 'atp' ? (
          <div>
            <div className="flex justify-between items-center mb-6">
              <div>
                <h3 className="text-lg font-bold text-gray-900">Alur Tujuan Pembelajaran (ATP)</h3>
                <p className="text-sm text-gray-500">Urutan pembelajaran dalam satu fase</p>
              </div>
              <button className="bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-blue-700 transition">
                <Plus size={16} className="inline mr-1" /> Susun ATP Baru
              </button>
            </div>
            <div className="grid grid-cols-1 gap-4">
              {['ATP IPAS Fase C (Kelas 5)', 'ATP Matematika Fase C (Kelas 5)'].map((item, idx) => (
                <div key={idx} className="border border-gray-200 p-4 rounded-xl flex items-center justify-between hover:border-blue-300 transition-colors bg-white">
                  <div className="flex gap-4 items-center">
                    <div className="p-3 bg-indigo-50 text-indigo-600 rounded-lg">
                      <BookOpen size={20} />
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-800">{item}</h4>
                      <p className="text-xs text-gray-500 mt-1">Status: Disetujui Kepala Sekolah</p>
                    </div>
                  </div>
                  <button className="text-gray-500 hover:text-blue-600 bg-gray-50 hover:bg-blue-50 px-3 py-2 rounded text-sm font-medium transition">
                    Lihat Alur
                  </button>
                </div>
              ))}
            </div>
          </div>
        ) : (
          <div className="flex-1 flex items-center justify-center flex-col text-gray-500">
            <h3 className="text-lg font-medium text-gray-900 mb-1">Menu {tabs.find(t => t.id === activeTab)?.label}</h3>
            <p className="text-sm text-center max-w-sm flex flex-col items-center gap-2">
              <span className="p-3 bg-gray-100 rounded-full mb-2"><BookOpen className="text-gray-400" size={32}/></span>
              Modul ini sedang dalam pengembangan.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
