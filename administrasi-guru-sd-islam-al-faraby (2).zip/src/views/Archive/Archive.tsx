import React, { useState } from 'react';
import { Folder, FileText, Search, UploadCloud, Cloud, Clock, RefreshCw, FolderOpen, Image as ImageIcon, Download } from 'lucide-react';

export function Archive() {
  const folders = [
    { name: 'Modul Ajar', icon: <Folder className="text-blue-500 fill-blue-500/20" size={24} />, count: 12 },
    { name: 'Program Tahunan', icon: <Folder className="text-yellow-500 fill-yellow-500/20" size={24} />, count: 2 },
    { name: 'Program Semester', icon: <Folder className="text-green-500 fill-green-500/20" size={24} />, count: 4 },
    { name: 'ATP', icon: <Folder className="text-purple-500 fill-purple-500/20" size={24} />, count: 8 },
    { name: 'CP & TP', icon: <Folder className="text-indigo-500 fill-indigo-500/20" size={24} />, count: 10 },
    { name: 'LKPD', icon: <Folder className="text-pink-500 fill-pink-500/20" size={24} />, count: 24 },
    { name: 'Penilaian', icon: <Folder className="text-red-500 fill-red-500/20" size={24} />, count: 18 },
    { name: 'Laporan', icon: <Folder className="text-orange-500 fill-orange-500/20" size={24} />, count: 6 },
    { name: 'Sertifikat', icon: <Folder className="text-teal-500 fill-teal-500/20" size={24} />, count: 5 },
    { name: 'Foto', icon: <Folder className="text-blue-400 fill-blue-400/20" size={24} />, count: 42 },
  ];

  const recentFiles = [
    { name: 'Modul Ajar MTK Bab 2.pdf', date: 'Hari ini, 08:30', size: '2.4 MB', type: 'pdf' },
    { name: 'Rekap Nilai Ganjil.xlsx', date: 'Kemarin, 14:15', size: '1.1 MB', type: 'excel' },
    { name: 'Sertifikat Pelatihan Kurmer.pdf', date: '12 Jan 2024', size: '1.8 MB', type: 'pdf' },
    { name: 'Foto Kegiatan Outdoor.jpg', date: '10 Jan 2024', size: '4.5 MB', type: 'image' },
  ];

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 flex flex-col h-[calc(100vh-8rem)] p-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
        <div>
          <h2 className="text-xl font-bold text-gray-900 flex items-center gap-2">
            <Cloud className="text-blue-500" /> Drive Penyimpanan
          </h2>
          <p className="text-sm text-gray-500">Terintegrasi dengan Google Drive Al Faraby</p>
        </div>
        <div className="flex gap-3">
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search size={16} className="text-gray-400" />
            </div>
            <input
              type="text"
              className="block w-64 pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500 text-sm outline-none"
              placeholder="Cari file atau folder..."
            />
          </div>
          <button className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-blue-700 transition">
            <UploadCloud size={18} /> Upload File
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto pr-2">
        <div className="mb-8">
          <div className="flex justify-between items-center mb-4">
            <h3 className="font-bold text-gray-800 text-sm uppercase tracking-wider">Struktur Folder Utama</h3>
            <button className="text-blue-600 text-sm font-medium hover:underline flex items-center gap-1">
              <RefreshCw size={14} /> Sinkronisasi
            </button>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
            {folders.map((folder, i) => (
              <div key={i} className="border border-gray-200 rounded-xl p-4 hover:bg-gray-50 hover:border-blue-300 cursor-pointer transition-all group flex flex-col items-center text-center">
                <div className="mb-3 transform group-hover:scale-110 transition-transform">
                  {folder.icon}
                </div>
                <h4 className="font-semibold text-gray-800 text-sm mb-1">{folder.name}</h4>
                <p className="text-xs text-gray-500">{folder.count} Item</p>
              </div>
            ))}
          </div>
        </div>

        <div>
          <h3 className="font-bold text-gray-800 text-sm uppercase tracking-wider mb-4 flex items-center gap-2">
            <Clock size={16} /> Baru Saja Diubah
          </h3>
          <div className="border border-gray-200 rounded-xl overflow-hidden divide-y divide-gray-100">
            {recentFiles.map((file, i) => (
              <div key={i} className="flex items-center justify-between p-4 hover:bg-gray-50 transition-colors cursor-pointer">
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-lg ${
                    file.type === 'pdf' ? 'bg-red-50 text-red-500' :
                    file.type === 'excel' ? 'bg-green-50 text-green-500' :
                    'bg-blue-50 text-blue-500'
                  }`}>
                    {file.type === 'image' ? <ImageIcon size={20} /> : <FileText size={20} />}
                  </div>
                  <div>
                    <h4 className="font-medium text-gray-900 text-sm">{file.name}</h4>
                    <p className="text-xs text-gray-500">{file.date}</p>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <span className="text-xs text-gray-500 font-medium">{file.size}</span>
                  <button className="p-1 text-gray-400 hover:text-blue-600 rounded">
                    <Download size={18} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
