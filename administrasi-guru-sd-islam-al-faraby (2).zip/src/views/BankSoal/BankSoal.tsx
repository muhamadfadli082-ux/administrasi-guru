import React, { useState } from 'react';
import { UploadCloud, FileText, Database, Plus, Search, Sparkles, Loader2, X } from 'lucide-react';
import ReactMarkdown from 'react-markdown';

export function BankSoal() {
  const [showAiModal, setShowAiModal] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [aiPrompt, setAiPrompt] = useState('Soal IPAS Kelas 5 Materi Tata Surya (Pilihan Ganda dan Uraian, HOTS)');
  const [aiResult, setAiResult] = useState('');

  const [soalList, setSoalList] = useState([
    { id: 1, materi: 'Sistem Pencernaan Manusia', mapel: 'IPA', tingkat: 'HOTS', bentuk: 'Pilihan Ganda' },
    { id: 2, materi: 'Pecahan Campuran', mapel: 'Matematika', tingkat: 'MOTS', bentuk: 'Uraian' },
    { id: 3, materi: 'Pahlawan Kemerdekaan', mapel: 'IPS', tingkat: 'LOTS', bentuk: 'Isian Singkat' },
  ]);

  const handleGenerateAI = async () => {
    setIsGenerating(true);
    setAiResult('');
    try {
      const response = await fetch('/api/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: `Buatkan 5 butir soal dan kunci jawabannya untuk: ${aiPrompt}. Format dengan markdown singkat dan rapi.` }),
      });
      const data = await response.json();
      if (data.result) {
        setAiResult(data.result);
        setSoalList([
          { id: Date.now(), materi: 'Generated: ' + aiPrompt.substring(0, 15) + '...', mapel: 'Campuran', tingkat: 'HOTS', bentuk: 'Pilihan Ganda & Uraian' },
          ...soalList
        ]);
      } else {
        setAiResult('Gagal menghasilkan soal. Pastikan API key dikonfigurasi.');
      }
    } catch (e) {
      setAiResult('Terjadi kesalahan saat memanggil API.');
    }
    setIsGenerating(false);
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 flex flex-col h-[calc(100vh-8rem)] p-6 relative">
      {/* AI Modal */}
      {showAiModal && (
        <div className="absolute inset-0 z-50 bg-black/50 rounded-xl flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-xl w-full max-w-2xl flex flex-col max-h-[90%]">
            <div className="p-4 border-b border-gray-100 flex justify-between items-center bg-gray-50 rounded-t-xl">
              <h3 className="font-bold flex items-center gap-2"><Sparkles className="text-purple-500" size={20} /> Generate Bank Soal dengan AI</h3>
              <button onClick={() => setShowAiModal(false)} className="text-gray-500 hover:text-gray-900"><X size={20} /></button>
            </div>
            <div className="p-6 overflow-y-auto flex-1">
              <label className="block text-sm font-medium text-gray-700 mb-2">Deskripsikan kriteria butir soal (Mapel, Kelas, Materi, Tingkat HOTS/LOTS, dll)</label>
              <textarea 
                value={aiPrompt}
                onChange={(e) => setAiPrompt(e.target.value)}
                className="w-full border border-gray-300 rounded-lg p-3 text-sm focus:ring-purple-500 focus:border-purple-500"
                rows={3}
              ></textarea>
              <button 
                onClick={handleGenerateAI}
                disabled={isGenerating}
                className="mt-4 bg-purple-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-purple-700 transition flex items-center gap-2 w-full justify-center disabled:opacity-70"
              >
                {isGenerating ? <Loader2 className="animate-spin" size={18} /> : <Sparkles size={18} />}
                {isGenerating ? 'Sedang Memproses...' : 'Generate Soal'}
              </button>

              {aiResult && (
                <div className="mt-6">
                  <h4 className="font-semibold text-gray-900 mb-2 text-sm">Draft Soal Tersimpan ke Bank:</h4>
                  <div className="p-4 bg-gray-50 rounded-lg border border-gray-200 text-sm prose prose-sm max-w-none max-h-64 overflow-y-auto">
                    <ReactMarkdown>{aiResult}</ReactMarkdown>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
        <div>
          <h3 className="text-xl font-bold text-gray-900">Bank Soal Terpadu</h3>
          <p className="text-sm text-gray-500">Kelola master soal untuk di-generate saat ujian</p>
        </div>
        <div className="flex gap-2">
          <button className="flex items-center gap-2 bg-gray-100 border border-gray-200 text-gray-700 px-3 py-2 rounded-lg text-sm font-medium hover:bg-gray-200 transition-colors">
            <UploadCloud size={18} />
            <span>Import Excel/Word</span>
          </button>
          <button 
            onClick={() => setShowAiModal(true)}
            className="flex items-center gap-2 bg-purple-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-purple-700 transition-colors"
          >
            <Sparkles size={18} />
            <span>Generate Soal AI</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <select className="border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-blue-500">
          <option>Filter Mata Pelajaran</option>
          <option>Matematika</option>
          <option>IPA</option>
          <option>IPS</option>
        </select>
        <select className="border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-blue-500">
          <option>Filter Bentuk Soal</option>
          <option>Pilihan Ganda</option>
          <option>Isian Singkat</option>
          <option>Uraian</option>
          <option>Menjodohkan</option>
        </select>
        <div className="relative col-span-1 md:col-span-2">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search size={18} className="text-gray-400" />
          </div>
          <input
            type="text"
            className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500 text-sm"
            placeholder="Cari materi atau kata kunci soal..."
          />
        </div>
      </div>

      <div className="flex-1 overflow-auto border border-gray-200 rounded-lg">
        <table className="w-full text-sm text-left">
          <thead className="text-xs text-gray-700 uppercase bg-gray-50 border-b border-gray-200 sticky top-0">
            <tr>
              <th className="px-6 py-4 font-semibold">Materi</th>
              <th className="px-6 py-4 font-semibold">Mapel</th>
              <th className="px-6 py-4 font-semibold">Tingkat</th>
              <th className="px-6 py-4 font-semibold">Bentuk Soal</th>
              <th className="px-6 py-4 font-semibold text-right">Aksi</th>
            </tr>
          </thead>
          <tbody>
            {soalList.map((soal) => (
              <tr key={soal.id} className="bg-white border-b hover:bg-gray-50">
                <td className="px-6 py-4 font-medium text-gray-900">{soal.materi}</td>
                <td className="px-6 py-4 text-gray-600">{soal.mapel}</td>
                <td className="px-6 py-4">
                  <span className={`px-2 py-1 rounded text-xs font-semibold ${soal.tingkat === 'HOTS' ? 'bg-red-100 text-red-700' : soal.tingkat === 'MOTS' ? 'bg-yellow-100 text-yellow-700' : 'bg-green-100 text-green-700'}`}>
                    {soal.tingkat}
                  </span>
                </td>
                <td className="px-6 py-4 text-gray-600">{soal.bentuk}</td>
                <td className="px-6 py-4 text-right">
                  <button className="text-blue-600 hover:text-blue-800 font-medium text-sm">Lihat Detail</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
