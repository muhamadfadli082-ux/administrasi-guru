import React, { useState } from 'react';
import { Users, ShieldAlert, Activity, Database, Menu, CheckCircle, XCircle } from 'lucide-react';

export function SuperAdmin() {
  const [activeTab, setActiveTab] = useState('pengguna');

  const tabs = [
    { id: 'pengguna', label: 'Manajemen Pengguna', icon: <Users size={16} /> },
    { id: 'aktivitas', label: 'Log Aktivitas', icon: <Activity size={16} /> },
    { id: 'hak-akses', label: 'Hak Akses & Menu', icon: <ShieldAlert size={16} /> },
    { id: 'database', label: 'Kelola Database', icon: <Database size={16} /> },
  ];

  const usersList = [
    { id: 1, nama: 'Ahmad Fadli, S.Pd', email: 'ahmad.fadli@alfaraby.sch.id', role: 'Guru', status: 'Aktif' },
    { id: 2, nama: 'Siti Aminah, S.Pd.I', email: 'siti.aminah@alfaraby.sch.id', role: 'Guru', status: 'Aktif' },
    { id: 3, nama: 'H. Achmad, M.Pd', email: 'kepsek@alfaraby.sch.id', role: 'Kepala Sekolah', status: 'Aktif' },
    { id: 4, nama: 'Operator Sekolah', email: 'ops@alfaraby.sch.id', role: 'Operator', status: 'Nonaktif' },
  ];

  return (
    <div className="flex flex-col md:flex-row gap-6 h-[calc(100vh-8rem)]">
      <div className="w-full md:w-64 bg-white rounded-xl shadow-sm border border-gray-100 flex flex-col shrink-0 overflow-y-auto">
        <div className="p-4 border-b border-gray-100 bg-gray-50">
          <h3 className="font-bold text-gray-900">Modul 13</h3>
          <p className="text-xs text-gray-500">Super Admin Panel</p>
        </div>
        <div className="p-2 space-y-1">
          {tabs.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                activeTab === tab.id 
                  ? 'bg-blue-50 text-blue-700' 
                  : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
              }`}
            >
              <span className={activeTab === tab.id ? 'text-blue-600' : 'text-gray-400'}>
                {tab.icon}
              </span>
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      <div className="flex-1 bg-white rounded-xl shadow-sm border border-gray-100 flex flex-col min-w-0 p-6 overflow-y-auto">
        {activeTab === 'pengguna' ? (
          <div>
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-lg font-bold text-gray-900">Manajemen Pengguna Aplikasi</h3>
              <button className="bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-blue-700 transition">
                + Tambah Akun
              </button>
            </div>
            <div className="border border-gray-200 rounded-lg overflow-hidden">
              <table className="w-full text-sm text-left">
                <thead className="text-xs text-gray-700 uppercase bg-gray-50 border-b border-gray-200">
                  <tr>
                    <th className="px-4 py-3 font-semibold">Nama / Email</th>
                    <th className="px-4 py-3 font-semibold text-center">Hak Akses</th>
                    <th className="px-4 py-3 font-semibold text-center">Status</th>
                    <th className="px-4 py-3 font-semibold text-right">Aksi</th>
                  </tr>
                </thead>
                <tbody>
                  {usersList.map((user) => (
                    <tr key={user.id} className="bg-white border-b hover:bg-gray-50">
                      <td className="px-4 py-3">
                        <div className="font-medium text-gray-900">{user.nama}</div>
                        <div className="text-xs text-gray-500">{user.email}</div>
                      </td>
                      <td className="px-4 py-3 text-center">
                        <span className="px-2 py-1 bg-blue-50 text-blue-700 rounded text-xs font-medium">
                          {user.role}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-center">
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                          user.status === 'Aktif' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
                        }`}>
                          {user.status === 'Aktif' ? <span className="flex items-center gap-1 justify-center"><CheckCircle size={12}/> Aktif</span> : <span className="flex items-center gap-1 justify-center"><XCircle size={12}/> Nonaktif</span>}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-right">
                        <button className="text-blue-600 hover:text-blue-800 font-medium text-xs px-2 py-1">Edit</button>
                        <button className="text-red-600 hover:text-red-800 font-medium text-xs px-2 py-1 border-l border-gray-200 ml-1">Suspend</button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        ) : (
          <div className="flex-1 flex items-center justify-center flex-col text-gray-500 p-6 h-full">
            {tabs.find(t => t.id === activeTab)?.icon && React.cloneElement(tabs.find(t => t.id === activeTab)!.icon as any, { size: 48, className: "mb-4 text-gray-300" })}
            <h3 className="text-lg font-medium text-gray-900 mb-1">{tabs.find(t => t.id === activeTab)?.label}</h3>
            <p className="text-sm text-center max-w-sm mt-2">Disediakan untuk administrator tingkat lanjut. Monitoring {tabs.find(t => t.id === activeTab)?.label.toLowerCase()} berjalan di backend system.</p>
          </div>
        )}
      </div>
    </div>
  );
}
