import React, { useState } from 'react';
import { Save, Building2, Bell, Database, ShieldCheck, Mail, HardDrive } from 'lucide-react';

export function Settings() {
  const [activeTab, setActiveTab] = useState('umum');

  const tabs = [
    { id: 'umum', label: 'Umum & Identitas', icon: <Building2 size={18} /> },
    { id: 'akademik', label: 'Tahun Akademik', icon: <Database size={18} /> },
    { id: 'notifikasi', label: 'Notifikasi', icon: <Bell size={18} /> },
    { id: 'backup', label: 'Backup & Restore', icon: <HardDrive size={18} /> },
    { id: 'keamanan', label: 'Keamanan', icon: <ShieldCheck size={18} /> },
  ];

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 flex flex-col md:flex-row h-[calc(100vh-8rem)]">
      <div className="w-full md:w-64 border-b md:border-b-0 md:border-r border-gray-100 p-4 shrink-0 overflow-y-auto bg-gray-50/50">
        <h3 className="font-bold text-gray-900 mb-4 px-2">Pengaturan</h3>
        <div className="space-y-1">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                activeTab === tab.id
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-gray-600 hover:bg-white hover:text-gray-900'
              }`}
            >
              <span className={activeTab === tab.id ? 'text-white' : 'text-gray-400'}>
                {tab.icon}
              </span>
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      <div className="flex-1 p-6 overflow-y-auto">
        <div className="max-w-3xl">
          <div className="flex justify-between items-center mb-8">
            <div>
              <h2 className="text-xl font-bold text-gray-900">
                {tabs.find((t) => t.id === activeTab)?.label}
              </h2>
              <p className="text-sm text-gray-500">Konfigurasi pengaturan sistem dan aplikasi</p>
            </div>
            <button className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-blue-700 transition">
              <Save size={18} /> Simpan Perubahan
            </button>
          </div>

          {activeTab === 'umum' && (
            <div className="space-y-6">
              <div className="bg-white border border-gray-200 rounded-xl p-6 shadow-sm">
                <h3 className="font-semibold text-gray-800 mb-4 border-b pb-2">Identitas Sekolah</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="col-span-2">
                    <label className="block text-sm font-medium text-gray-700 mb-1">Nama Sekolah</label>
                    <input type="text" className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-blue-500 focus:border-blue-500 outline-none" defaultValue="SD Islam Al Faraby" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">NPSN</label>
                    <input type="text" className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-blue-500 focus:border-blue-500 outline-none" defaultValue="12345678" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Jenjang</label>
                    <select className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-blue-500 focus:border-blue-500 outline-none">
                      <option>SD</option>
                      <option>SMP</option>
                    </select>
                  </div>
                  <div className="col-span-2">
                    <label className="block text-sm font-medium text-gray-700 mb-1">Alamat Sekolah</label>
                    <textarea className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-blue-500 focus:border-blue-500 outline-none h-20" defaultValue="Jl. Pendidikan No. 1, Kota Belajar"></textarea>
                  </div>
                </div>
              </div>

              <div className="bg-white border border-gray-200 rounded-xl p-6 shadow-sm">
                <h3 className="font-semibold text-gray-800 mb-4 border-b pb-2">Kepala Sekolah</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Nama Kepala Sekolah</label>
                    <input type="text" className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-blue-500 focus:border-blue-500 outline-none" defaultValue="H. Achmad, M.Pd" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">NIP</label>
                    <input type="text" className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-blue-500 focus:border-blue-500 outline-none" defaultValue="19700101 200003 1 001" />
                  </div>
                  <div className="col-span-2">
                    <label className="block text-sm font-medium text-gray-700 mb-1">Tanda Tangan Digital (Url Gambar)</label>
                    <input type="text" className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-blue-500 focus:border-blue-500 outline-none" placeholder="https://..." />
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'akademik' && (
            <div className="bg-white border border-gray-200 rounded-xl p-6 shadow-sm space-y-4">
               <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Tahun Pelajaran Aktif</label>
                  <select className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-blue-500 focus:border-blue-500 outline-none" defaultValue="2023/2024">
                    <option>2022/2023</option>
                    <option value="2023/2024">2023/2024</option>
                    <option>2024/2025</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Semester Aktif</label>
                  <select className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-blue-500 focus:border-blue-500 outline-none" defaultValue="Ganjil">
                    <option value="Ganjil">Ganjil</option>
                    <option>Genap</option>
                  </select>
                </div>
            </div>
          )}

          {activeTab === 'notifikasi' && (
            <div className="bg-white border border-gray-200 rounded-xl p-6 shadow-sm space-y-6">
              <div>
                <h3 className="font-semibold text-gray-800 mb-4 border-b pb-2">Notifikasi Sistem</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="text-sm font-medium text-gray-900">Email Notifikasi</h4>
                      <p className="text-xs text-gray-500">Kirim pemberitahuan penting melalui email</p>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input type="checkbox" value="" className="sr-only peer" defaultChecked />
                      <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                    </label>
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="text-sm font-medium text-gray-900">Notifikasi Dalam Aplikasi</h4>
                      <p className="text-xs text-gray-500">Pemberitahuan real-time saat aplikasi sedang dibuka</p>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input type="checkbox" value="" className="sr-only peer" defaultChecked />
                      <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                    </label>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'backup' && (
            <div className="bg-white border border-gray-200 rounded-xl p-6 shadow-sm space-y-6">
              <div>
                <h3 className="font-semibold text-gray-800 mb-4 border-b pb-2">Backup & Restore</h3>
                <p className="text-sm text-gray-600 mb-6">Amankan data aplikasi Anda dengan melakukan backup rutin. Anda juga dapat memulihkan data jika terjadi kesalahan.</p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="border border-green-200 bg-green-50 rounded-xl p-5 flex flex-col items-center justify-center text-center">
                    <HardDrive className="text-green-600 mb-3" size={32} />
                    <h4 className="font-medium text-green-900 mb-1">Backup Data Sekarang</h4>
                    <p className="text-xs text-green-700 mb-4">Unduh seluruh data dalam format zip</p>
                    <button className="bg-green-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-green-700 transition w-full">
                      Mulai Backup
                    </button>
                  </div>
                  <div className="border border-blue-200 bg-blue-50 rounded-xl p-5 flex flex-col items-center justify-center text-center">
                    <Database className="text-blue-600 mb-3" size={32} />
                    <h4 className="font-medium text-blue-900 mb-1">Restore Data</h4>
                    <p className="text-xs text-blue-700 mb-4">Pulihkan data dari file backup sebelumnya</p>
                    <button className="bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-blue-700 transition w-full">
                      Pilih File Backup
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'keamanan' && (
            <div className="bg-white border border-gray-200 rounded-xl p-6 shadow-sm space-y-6">
              <div>
                <h3 className="font-semibold text-gray-800 mb-4 border-b pb-2">Pengaturan Keamanan</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 border border-gray-100 rounded-lg bg-gray-50">
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-blue-100 text-blue-600 rounded-lg">
                        <ShieldCheck size={20} />
                      </div>
                      <div>
                        <h4 className="text-sm font-medium text-gray-900">Ubah Kata Sandi</h4>
                        <p className="text-xs text-gray-500">Perbarui kata sandi admin secara berkala untuk keamanan.</p>
                      </div>
                    </div>
                    <button className="text-blue-600 font-medium text-sm hover:underline">Ganti Sandi</button>
                  </div>
                  <div className="flex items-center justify-between p-4 border border-gray-100 rounded-lg bg-gray-50">
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-blue-100 text-blue-600 rounded-lg">
                        <Mail size={20} />
                      </div>
                      <div>
                        <h4 className="text-sm font-medium text-gray-900">Autentikasi Dua Faktor (2FA)</h4>
                        <p className="text-xs text-gray-500">Tambahkan lapisan keamanan ekstra dengan OTP email.</p>
                      </div>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input type="checkbox" value="" className="sr-only peer" />
                      <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                    </label>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab !== 'umum' && activeTab !== 'akademik' && activeTab !== 'notifikasi' && activeTab !== 'backup' && activeTab !== 'keamanan' && (
             <div className="border-2 border-dashed border-gray-200 rounded-xl flex flex-col items-center justify-center p-12 text-center text-gray-500">
               <h3 className="font-semibold text-gray-700 mb-2">Pengaturan {tabs.find(t => t.id === activeTab)?.label}</h3>
               <p className="text-sm">Fitur konfigurasi ini akan terhubung langsung ke properti Google Apps Script pada backend.</p>
             </div>
          )}
        </div>
      </div>
    </div>
  );
}
