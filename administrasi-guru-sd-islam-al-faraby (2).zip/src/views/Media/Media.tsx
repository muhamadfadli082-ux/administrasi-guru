import React from 'react';
import { PlaySquare, FileVideo, Image as ImageIcon, Presentation, ExternalLink, Plus } from 'lucide-react';

export function Media() {
  const mediaList = [
    { title: 'Animasi Tata Surya', type: 'video', size: '25 MB', date: '21 Jun 2023', icon: <FileVideo className="text-red-500" size={32} /> },
    { title: 'Materi IPA Kelas 5', type: 'ppt', size: '12 MB', date: '05 Jul 2023', icon: <Presentation className="text-orange-500" size={32} /> },
    { title: 'Bagan Jenis-Jenis Teks', type: 'image', size: '2 MB', date: '12 Jul 2023', icon: <ImageIcon className="text-blue-500" size={32} /> },
    { title: 'Video Pembelajaran YouTube', type: 'link', size: '-', date: '15 Jul 2023', icon: <PlaySquare className="text-gray-700" size={32} /> },
    { title: 'Template Canva Organ Tubuh', type: 'canva', size: '-', date: '18 Jul 2023', icon: <ExternalLink className="text-teal-500" size={32} /> },
  ];

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 flex flex-col h-[calc(100vh-8rem)] p-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8 border-b pb-6">
        <div>
          <h3 className="text-xl font-bold text-gray-900">Perpustakaan Media</h3>
          <p className="text-sm text-gray-500">Akses cepat ke materi presentasi, video, dan bahan ajar interaktif</p>
        </div>
        <button className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-blue-700 transition-colors">
          <Plus size={18} />
          <span>Upload Media</span>
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 overflow-auto">
        {mediaList.map((media, i) => (
          <div key={i} className="border border-gray-200 rounded-xl p-5 hover:border-blue-300 hover:shadow-md transition-all group bg-gray-50 relative overflow-hidden cursor-pointer">
            <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-br from-blue-100 to-transparent -mr-8 -mt-8 rounded-full opacity-0 group-hover:opacity-50 transition-opacity"></div>
            
            <div className="mb-4 bg-white p-3 inline-block rounded-lg shadow-sm border border-gray-100">
              {media.icon}
            </div>
            
            <h4 className="font-bold text-gray-900 mb-1 line-clamp-2">{media.title}</h4>
            <div className="flex justify-between items-center text-xs text-gray-500 mt-4">
              <span>{media.date}</span>
              <span className="px-2 py-1 bg-gray-200 rounded text-gray-700 font-medium uppercase">{media.type}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
