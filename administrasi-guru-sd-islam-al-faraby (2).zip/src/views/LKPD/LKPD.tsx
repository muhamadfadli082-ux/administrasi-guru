import React, { useState } from 'react';
import { Target, ListChecks, Wand2, FileText, Sparkles, Loader2 } from 'lucide-react';
import ReactMarkdown from 'react-markdown';

export function LKPD() {
  const [isGenerating, setIsGenerating] = useState(false);
  const [mapel, setMapel] = useState('Matematika');
  const [kelas, setKelas] = useState('Kelas 5 (Fase C)');
  const [materi, setMateri] = useState('');
  const [tujuan, setTujuan] = useState('');
  const [jenis, setJenis] = useState('Campuran (Isian & Esai)');
  const [aiResult, setAiResult] = useState('');
  
  const handleGenerateLKPD = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsGenerating(true);
    setAiResult('');
    
    const prompt = `Buatkan struktur Lembar Kerja Peserta Didik (LKPD) yang menarik untuk siswa SD. 
Mata Pelajaran: ${mapel}. Kelas: ${kelas}. Materi: ${materi}. Tujuan Pembelajaran: ${tujuan}. Format Soal: ${jenis}. 
Gunakan bahasa yang mudah dipahami anak-anak. Gunakan markdown untuk memformat teksnya.`;

    try {
      const response = await fetch('/api/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt }),
      });
      const data = await response.json();
      if (data.result) {
        setAiResult(data.result);
      } else {
        setAiResult('Gagal menghasilkan LKPD. Periksa API key dan koneksi.');
      }
    } catch (err) {
      setAiResult('Terjadi kesalahan saat memanggil API.');
    }
    setIsGenerating(false);
  };

  return (
    <div className="flex flex-col md:flex-row gap-6 h-[calc(100vh-8rem)]">
      <div className="w-full md:w-1/3 bg-white rounded-xl shadow-sm border border-gray-100 p-6 flex flex-col shrink-0 overflow-y-auto">
        <div className="mb-6">
          <h3 className="font-bold text-gray-900 flex items-center gap-2"><Sparkles size={20} className="text-purple-600" /> AI LKPD Generator</h3>
          <p className="text-sm text-gray-500 mt-1">Buat lembar kerja otomatis dan interaktif menggunakan AI Intelligence.</p>
        </div>

        <form onSubmit={handleGenerateLKPD} className="space-y-4 flex-1">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Mata Pelajaran</label>
            <select value={mapel} onChange={e => setMapel(e.target.value)} className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-purple-500">
              <option>Pilih Mata Pelajaran</option>
              <option>Matematika</option>
              <option>Ilmu Pengetahuan Alam</option>
              <option>Bahasa Indonesia</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Kelas / Fase</label>
            <select value={kelas} onChange={e => setKelas(e.target.value)} className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-purple-500">
              <option>Pilih Kelas</option>
              <option>Kelas 5 (Fase C)</option>
              <option>Kelas 6 (Fase C)</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Materi Pokok</label>
            <input value={materi} onChange={e => setMateri(e.target.value)} type="text" className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-purple-500" placeholder="Contoh: Tata Surya" required />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Tujuan Pembelajaran</label>
            <textarea value={tujuan} onChange={e => setTujuan(e.target.value)} className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-purple-500 h-20" placeholder="Peserta didik mampu..." required></textarea>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Tingkat Kesulitan / Jenis Soal</label>
            <select value={jenis} onChange={e => setJenis(e.target.value)} className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-purple-500">
              <option>Campuran (Isian & Esai)</option>
              <option>Pilihan Ganda Saja</option>
              <option>Proyek Kreatif</option>
            </select>
          </div>

          <button 
            type="submit" 
            disabled={isGenerating}
            className="w-full mt-6 bg-purple-600 text-white font-medium py-3 rounded-lg flex justify-center items-center gap-2 hover:bg-purple-700 transition disabled:opacity-70"
          >
            {isGenerating ? <Loader2 size={18} className="animate-spin" /> : <Sparkles size={18} />}
            {isGenerating ? 'Membuat LKPD...' : 'Generate LKPD dengan AI'}
          </button>
        </form>
      </div>

      <div className="flex-1 bg-white rounded-xl shadow-sm border border-gray-100 flex flex-col min-w-0 p-6 overflow-hidden relative">
        {!aiResult && !isGenerating ? (
          <div className="flex flex-col items-center justify-center text-center h-full">
            <FileText size={64} className="text-gray-200 mb-4" />
            <h3 className="text-xl font-bold text-gray-800">Pratinjau LKPD</h3>
            <p className="text-gray-500 max-w-sm mt-2">Lengkapi form di sebelah kiri lalu klik "Generate LKPD" untuk melihat pratinjau lembar kerja peserta didik.</p>
          </div>
        ) : (
          <div className="flex flex-col h-full w-full">
            <div className="flex justify-between items-center mb-4 border-b pb-4">
              <h3 className="text-lg font-bold text-gray-800">Hasil Generate LKPD</h3>
              <div className="flex gap-2">
                <button className="flex items-center gap-2 px-3 py-1.5 border border-gray-200 rounded-lg bg-gray-50 hover:bg-gray-100 transition text-sm font-medium">
                  <span className="text-blue-600 font-bold">W</span> Word
                </button>
                <button className="flex items-center gap-2 px-3 py-1.5 border border-gray-200 rounded-lg bg-gray-50 hover:bg-gray-100 transition text-sm font-medium">
                  <span className="text-red-600 font-bold">P</span> PDF
                </button>
              </div>
            </div>
            <div className="flex-1 overflow-y-auto w-full prose prose-sm max-w-none p-2 relative">
               {isGenerating && (
                 <div className="absolute inset-0 bg-white/70 flex items-center justify-center z-10">
                   <div className="flex flex-col items-center">
                     <Loader2 size={32} className="animate-spin text-purple-600 mb-2" />
                     <p className="text-sm text-gray-600">AI sedang menulis struktur LKPD...</p>
                   </div>
                 </div>
               )}
               <ReactMarkdown>{aiResult}</ReactMarkdown>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
