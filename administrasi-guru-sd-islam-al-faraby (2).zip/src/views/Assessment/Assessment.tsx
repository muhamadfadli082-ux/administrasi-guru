import React, { useState } from 'react';
import { BookOpen, PieChart, Plus, Download, Printer } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

export function Assessment() {
  const [activeTab, setActiveTab] = useState('pengetahuan');

  const tabs = [
    { id: 'pengetahuan', label: 'Pengetahuan' },
    { id: 'keterampilan', label: 'Keterampilan' },
    { id: 'sikap', label: 'Sikap' },
    { id: 'analisis', label: 'Analisis Nilai' },
    { id: 'remedial', label: 'Remedial & Pengayaan' },
  ];

  const analysisData = [
    { name: 'Sangat Baik', jumlah: 15 },
    { name: 'Baik', jumlah: 10 },
    { name: 'Cukup', jumlah: 5 },
    { name: 'Kurang', jumlah: 2 },
  ];

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 flex flex-col h-[calc(100vh-8rem)]">
      <div className="border-b border-gray-100 flex overflow-x-auto">
        {tabs.map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`px-5 py-4 text-sm font-medium whitespace-nowrap border-b-2 transition-colors ${
              activeTab === tab.id 
                ? 'border-blue-600 text-blue-600' 
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      <div className="p-6 flex-1 flex flex-col overflow-auto">
        {activeTab === 'analisis' ? (
          <div className="space-y-6">
            <div className="flex justify-between items-center bg-gray-50 p-4 rounded-xl border border-gray-100">
              <div>
                <h3 className="font-bold text-gray-900">Analisis Nilai: Sumatif Harian 1</h3>
                <p className="text-sm text-gray-500">Mata Pelajaran: Matematika | Kelas: 5A</p>
              </div>
              <div className="flex gap-2">
                <button className="flex items-center gap-2 bg-white border border-gray-200 text-gray-700 px-3 py-1.5 rounded-lg text-sm font-medium hover:bg-gray-50 transition-colors">
                  <Download size={16} /> Export PDF
                </button>
                <button className="flex items-center gap-2 bg-blue-600 text-white px-3 py-1.5 rounded-lg text-sm font-medium hover:bg-blue-700 transition-colors">
                  <Printer size={16} /> Cetak
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm col-span-2">
                <h4 className="font-semibold text-gray-800 mb-4">Grafik Ketuntasan Kelas</h4>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={analysisData}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} />
                      <XAxis dataKey="name" axisLine={false} tickLine={false} />
                      <YAxis axisLine={false} tickLine={false} />
                      <Tooltip cursor={{ fill: 'transparent' }} />
                      <Bar dataKey="jumlah" fill="#3B82F6" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
              
              <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm space-y-4">
                <h4 className="font-semibold text-gray-800 border-b pb-2">Ringkasan Statistik</h4>
                <div className="flex justify-between">
                  <span className="text-gray-500">Rata-rata Kelas</span>
                  <span className="font-bold text-gray-900">82.5</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Nilai Tertinggi</span>
                  <span className="font-bold text-green-600">100</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Nilai Terendah</span>
                  <span className="font-bold text-red-600">55</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Tuntas</span>
                  <span className="font-bold text-blue-600">25 (78%)</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Belum Tuntas</span>
                  <span className="font-bold text-orange-600">7 (22%)</span>
                </div>
              </div>
            </div>
          </div>
        ) : activeTab === 'pengetahuan' ? (
          <div className="flex flex-col h-full space-y-4">
             <div className="flex justify-between items-center">
                <div>
                  <h3 className="text-lg font-bold text-gray-900">Penilaian Pengetahuan</h3>
                  <p className="text-sm text-gray-500">Daftar Nilai Ulangan dan Tugas</p>
                </div>
                <button className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-blue-700 transition">
                  <Plus size={16} /> Input Nilai Baru
                </button>
             </div>
             
             <div className="flex gap-4 items-center bg-gray-50 p-4 rounded-xl border border-gray-100">
               <div className="w-48">
                 <label className="text-xs text-gray-500 font-medium uppercase tracking-wider mb-1 block">Mata Pelajaran</label>
                 <select className="w-full border border-gray-300 rounded p-2 text-sm focus:ring-blue-500 focus:border-blue-500">
                   <option>IPAS</option>
                   <option>Matematika</option>
                   <option>Bahasa Indonesia</option>
                 </select>
               </div>
               <div className="w-48">
                 <label className="text-xs text-gray-500 font-medium uppercase tracking-wider mb-1 block">Jenis Penilaian</label>
                 <select className="w-full border border-gray-300 rounded p-2 text-sm focus:ring-blue-500 focus:border-blue-500">
                   <option>Sumatif Harian 1</option>
                   <option>Sumatif Harian 2</option>
                   <option>Tugas 1</option>
                   <option>PTS</option>
                 </select>
               </div>
               <div className="mt-5">
                 <button className="bg-white border border-gray-300 text-gray-700 px-4 py-2 rounded text-sm hover:bg-gray-50">Filter</button>
               </div>
               <div className="mt-5 ml-auto flex gap-2">
                 <button className="bg-green-50 text-green-700 border border-green-200 px-3 py-2 rounded text-sm hover:bg-green-100 flex items-center gap-2"><Download size={16}/> Import/Export</button>
               </div>
             </div>

             <div className="border border-gray-200 rounded-lg overflow-hidden flex-1 flex flex-col">
              <div className="overflow-auto flex-1">
                <table className="w-full text-sm text-left">
                  <thead className="bg-gray-50 text-gray-700 font-semibold border-b border-gray-200 sticky top-0 z-10">
                    <tr>
                      <th className="px-4 py-3 w-12 text-center">No</th>
                      <th className="px-4 py-3">Nama Siswa</th>
                      <th className="px-4 py-3 text-center">Tugas 1</th>
                      <th className="px-4 py-3 text-center">Tugas 2</th>
                      <th className="px-4 py-3 text-center bg-blue-50 text-blue-700">SH 1</th>
                      <th className="px-4 py-3 text-center text-blue-700">Rata-Rata</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100">
                    {[
                      {no: 1, nama: 'Ahmad Al Faruq', t1: 85, t2: 90, sh1: 88, rata: 87.6},
                      {no: 2, nama: 'Aisyah Putri', t1: 90, t2: 92, sh1: 95, rata: 92.3},
                      {no: 3, nama: 'Bima Sakti', t1: 75, t2: 80, sh1: 78, rata: 77.6, warning: true},
                      {no: 4, nama: 'Citra Kirana', t1: 88, t2: 85, sh1: 90, rata: 87.6},
                      {no: 5, nama: 'Daffa Almer', t1: 95, t2: 95, sh1: 100, rata: 96.6},
                    ].map((row, i) => (
                      <tr key={i} className="bg-white hover:bg-gray-50">
                        <td className="px-4 py-2 text-center">{row.no}</td>
                        <td className="px-4 py-2 font-medium text-gray-900">{row.nama}</td>
                        <td className="px-4 py-2 text-center">
                          <input type="number" defaultValue={row.t1} className="w-16 border rounded p-1 text-center text-sm" />
                        </td>
                        <td className="px-4 py-2 text-center">
                          <input type="number" defaultValue={row.t2} className="w-16 border rounded p-1 text-center text-sm" />
                        </td>
                        <td className="px-4 py-2 text-center bg-blue-50/30">
                          <input type="number" defaultValue={row.sh1} className={`w-16 border rounded p-1 text-center text-sm font-semibold ${row.warning ? 'bg-red-50 text-red-700 border-red-200' : 'bg-white'}`} />
                        </td>
                        <td className="px-4 py-2 text-center font-bold text-gray-700">{row.rata}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
             </div>
          </div>
        ) : activeTab === 'keterampilan' ? (
          <div className="flex flex-col h-full space-y-4">
             <div className="flex justify-between items-center">
                <div>
                  <h3 className="text-lg font-bold text-gray-900">Penilaian Keterampilan</h3>
                  <p className="text-sm text-gray-500">Nilai Praktik, Proyek, dan Portofolio</p>
                </div>
                <button className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-blue-700 transition">
                  <Plus size={16} /> Input Keterampilan
                </button>
             </div>
             
             <div className="border border-gray-200 rounded-lg overflow-hidden flex-1 flex flex-col mt-4">
              <div className="overflow-auto flex-1">
                <table className="w-full text-sm text-left">
                  <thead className="bg-gray-50 text-gray-700 font-semibold border-b border-gray-200 sticky top-0 z-10">
                    <tr>
                      <th className="px-4 py-3 w-12 text-center">No</th>
                      <th className="px-4 py-3">Nama Siswa</th>
                      <th className="px-4 py-3 text-center">Praktik 1</th>
                      <th className="px-4 py-3 text-center">Proyek 1</th>
                      <th className="px-4 py-3 text-center">Portofolio</th>
                      <th className="px-4 py-3 text-center text-blue-700">Skor Akhir</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100">
                    {[
                      {no: 1, nama: 'Ahmad Al Faruq', p1: 85, pr1: 90, port: 88, akhir: 88},
                      {no: 2, nama: 'Aisyah Putri', p1: 92, pr1: 95, port: 95, akhir: 94},
                      {no: 3, nama: 'Bima Sakti', p1: 80, pr1: 82, port: 85, akhir: 82},
                      {no: 4, nama: 'Citra Kirana', p1: 88, pr1: 85, port: 90, akhir: 88},
                      {no: 5, nama: 'Daffa Almer', p1: 95, pr1: 100, port: 95, akhir: 97},
                    ].map((row, i) => (
                      <tr key={i} className="bg-white hover:bg-gray-50">
                        <td className="px-4 py-2 text-center">{row.no}</td>
                        <td className="px-4 py-2 font-medium text-gray-900">{row.nama}</td>
                        <td className="px-4 py-2 text-center">
                          <input type="number" defaultValue={row.p1} className="w-16 border rounded p-1 text-center text-sm" />
                        </td>
                        <td className="px-4 py-2 text-center">
                          <input type="number" defaultValue={row.pr1} className="w-16 border rounded p-1 text-center text-sm" />
                        </td>
                        <td className="px-4 py-2 text-center">
                          <input type="number" defaultValue={row.port} className="w-16 border rounded p-1 text-center text-sm" />
                        </td>
                        <td className="px-4 py-2 text-center font-bold text-gray-700">{row.akhir}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
             </div>
          </div>
        ) : activeTab === 'sikap' ? (
          <div className="flex flex-col h-full space-y-4">
             <div className="flex justify-between items-center">
                <div>
                  <h3 className="text-lg font-bold text-gray-900">Penilaian Sikap & Observasi</h3>
                  <p className="text-sm text-gray-500">Jurnal Pengamatan Profil Pelajar Pancasila</p>
                </div>
                <button className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-blue-700 transition">
                  <Plus size={16} /> Catat Sikap
                </button>
             </div>
             
             <div className="border border-gray-200 rounded-lg overflow-hidden flex-1 flex flex-col mt-4">
              <div className="overflow-auto flex-1">
                <table className="w-full text-sm text-left">
                  <thead className="bg-gray-50 text-gray-700 font-semibold border-b border-gray-200 sticky top-0 z-10">
                    <tr>
                      <th className="px-4 py-3 w-12 text-center">No</th>
                      <th className="px-4 py-3">Nama Siswa</th>
                      <th className="px-4 py-3 text-center">Gotong Royong</th>
                      <th className="px-4 py-3 text-center">Mandiri</th>
                      <th className="px-4 py-3 text-center">Bernalar Kritis</th>
                      <th className="px-4 py-3">Deskripsi/Catatan</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100">
                    {[
                      {no: 1, nama: 'Ahmad Al Faruq', s1: 'SB', s2: 'B', s3: 'B', desc: 'Menunjukkan sikap kerja sama yang baik.'},
                      {no: 2, nama: 'Aisyah Putri', s1: 'SB', s2: 'SB', s3: 'SB', desc: 'Mandiri dan aktif bertanya di kelas.'},
                      {no: 3, nama: 'Bima Sakti', s1: 'B', s2: 'C', s3: 'B', desc: 'Perlu bimbingan dalam kedisiplinan dan kemandirian.'},
                    ].map((row, i) => (
                      <tr key={i} className="bg-white hover:bg-gray-50">
                        <td className="px-4 py-3 text-center">{row.no}</td>
                        <td className="px-4 py-3 font-medium text-gray-900">{row.nama}</td>
                        <td className="px-4 py-3 text-center font-bold text-green-700">{row.s1}</td>
                        <td className="px-4 py-3 text-center font-bold text-blue-700">{row.s2}</td>
                        <td className="px-4 py-3 text-center font-bold text-indigo-700">{row.s3}</td>
                        <td className="px-4 py-3 text-gray-600 text-xs">{row.desc}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
             </div>
          </div>
        ) : (
          <div className="flex-1 flex items-center justify-center flex-col text-gray-500">
            <PieChart size={48} className="mb-4 text-gray-300" />
            <h3 className="text-lg font-medium text-gray-900 mb-1">Modul {tabs.find(t => t.id === activeTab)?.label}</h3>
            <p className="text-sm text-center max-w-sm mt-2">Modul ini sedang dalam pengembangan.</p>
          </div>
        )}
      </div>
    </div>
  );
}
