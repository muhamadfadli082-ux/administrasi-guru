import React, { useState } from 'react';
import { FileBarChart, Download, FileText, FileSpreadsheet, Printer, Calendar } from 'lucide-react';

export function Reports() {
  const [reportType, setReportType] = useState('kehadiran');
  const [period, setPeriod] = useState('semester');

  const reportTypes = [
    { id: 'kehadiran', label: 'Laporan Kehadiran', icon: <FileBarChart size={18} /> },
    { id: 'jurnal', label: 'Jurnal Mengajar', icon: <FileText size={18} /> },
    { id: 'agenda', label: 'Buku Agenda', icon: <Calendar size={18} /> },
    { id: 'nilai', label: 'Rekapitulasi Nilai', icon: <FileSpreadsheet size={18} /> },
    { id: 'administrasi', label: 'Administrasi Guru', icon: <FileText size={18} /> },
  ];

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 flex flex-col md:flex-row h-[calc(100vh-8rem)]">
      <div className="w-full md:w-64 border-b md:border-b-0 md:border-r border-gray-100 p-4 shrink-0 overflow-y-auto bg-gray-50/50">
        <h3 className="font-bold text-gray-900 mb-4 px-2">Jenis Laporan</h3>
        <div className="space-y-1">
          {reportTypes.map((type) => (
            <button
              key={type.id}
              onClick={() => setReportType(type.id)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                reportType === type.id
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-gray-600 hover:bg-white hover:text-gray-900'
              }`}
            >
              <span className={reportType === type.id ? 'text-white' : 'text-gray-400'}>
                {type.icon}
              </span>
              {type.label}
            </button>
          ))}
        </div>
      </div>

      <div className="flex-1 p-6 overflow-y-auto flex flex-col">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
          <div>
            <h2 className="text-xl font-bold text-gray-900">
              {reportTypes.find((t) => t.id === reportType)?.label}
            </h2>
            <p className="text-sm text-gray-500">Tahun Pelajaran 2023/2024 - Ganjil</p>
          </div>
        </div>

        <div className="bg-white border border-gray-200 rounded-xl p-6 shadow-sm mb-6">
          <h3 className="font-semibold text-gray-800 mb-4">Pengaturan Filter</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Periode</label>
              <select 
                value={period} 
                onChange={(e) => setPeriod(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-blue-500 focus:border-blue-500 outline-none"
              >
                <option value="bulanan">Bulanan</option>
                <option value="tengah_semester">Tengah Semester</option>
                <option value="semester">Akhir Semester</option>
                <option value="tahunan">Tahunan</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Kelas</label>
              <select className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-blue-500 focus:border-blue-500 outline-none">
                <option>Semua Kelas</option>
                <option>Kelas 5A</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Mata Pelajaran</label>
              <select className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-blue-500 focus:border-blue-500 outline-none">
                <option>Semua Mata Pelajaran</option>
                <option>Matematika</option>
                <option>IPAS</option>
              </select>
            </div>
          </div>
        </div>

        <div className="flex-1 rounded-xl flex flex-col">
          {reportType === 'kehadiran' ? (
            <div className="bg-white border border-gray-200 rounded-xl overflow-hidden flex flex-col h-full shadow-sm">
                <div className="p-4 border-b border-gray-200 bg-gray-50 flex justify-between items-center">
                    <h3 className="font-bold text-gray-800 text-sm">Pratinjau: Rekapitulasi Kehadiran</h3>
                    <div className="flex gap-2">
                        <button className="flex items-center gap-2 bg-red-50 text-red-700 border border-red-200 px-3 py-1.5 rounded text-xs font-medium hover:bg-red-100 transition"><Download size={14} /> PDF</button>
                        <button className="flex items-center gap-2 bg-green-50 text-green-700 border border-green-200 px-3 py-1.5 rounded text-xs font-medium hover:bg-green-100 transition"><Download size={14} /> Excel</button>
                    </div>
                </div>
                <div className="overflow-auto p-4 flex-1">
                    <table className="w-full text-sm text-left border border-gray-200">
                      <thead className="bg-gray-100 text-gray-700 font-semibold border-b border-gray-200">
                        <tr>
                          <th className="px-4 py-2 border-r border-gray-200 w-12 text-center" rowSpan={2}>No</th>
                          <th className="px-4 py-2 border-r border-gray-200" rowSpan={2}>Nama Siswa</th>
                          <th className="px-4 py-2 border-r border-gray-200 text-center" colSpan={4}>Rekapitulasi</th>
                          <th className="px-4 py-2 text-center" rowSpan={2}>Persentase</th>
                        </tr>
                        <tr>
                          <th className="px-2 py-1 border-t border-r border-gray-200 text-center bg-gray-50 text-xs">Sakit</th>
                          <th className="px-2 py-1 border-t border-r border-gray-200 text-center bg-gray-50 text-xs">Izin</th>
                          <th className="px-2 py-1 border-t border-r border-gray-200 text-center bg-gray-50 text-xs">Alpa</th>
                          <th className="px-2 py-1 border-t border-r border-gray-200 text-center bg-gray-50 text-xs">Hadir</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-200">
                        <tr className="hover:bg-gray-50">
                          <td className="px-4 py-2 border-r border-gray-200 text-center">1</td>
                          <td className="px-4 py-2 border-r border-gray-200 font-medium">Ahmad Al Faruq</td>
                          <td className="px-2 py-2 border-r border-gray-200 text-center">1</td>
                          <td className="px-2 py-2 border-r border-gray-200 text-center">0</td>
                          <td className="px-2 py-2 border-r border-gray-200 text-center">0</td>
                          <td className="px-2 py-2 border-r border-gray-200 text-center">89</td>
                          <td className="px-4 py-2 text-center font-bold text-green-600">98%</td>
                        </tr>
                        <tr className="hover:bg-gray-50">
                          <td className="px-4 py-2 border-r border-gray-200 text-center">2</td>
                          <td className="px-4 py-2 border-r border-gray-200 font-medium">Aisyah Putri</td>
                          <td className="px-2 py-2 border-r border-gray-200 text-center">0</td>
                          <td className="px-2 py-2 border-r border-gray-200 text-center">0</td>
                          <td className="px-2 py-2 border-r border-gray-200 text-center">0</td>
                          <td className="px-2 py-2 border-r border-gray-200 text-center">90</td>
                          <td className="px-4 py-2 text-center font-bold text-green-600">100%</td>
                        </tr>
                        <tr className="hover:bg-gray-50">
                          <td className="px-4 py-2 border-r border-gray-200 text-center">3</td>
                          <td className="px-4 py-2 border-r border-gray-200 font-medium">Bima Sakti</td>
                          <td className="px-2 py-2 border-r border-gray-200 text-center">2</td>
                          <td className="px-2 py-2 border-r border-gray-200 text-center">1</td>
                          <td className="px-2 py-2 border-r border-gray-200 text-center">3</td>
                          <td className="px-2 py-2 border-r border-gray-200 text-center">84</td>
                          <td className="px-4 py-2 text-center font-bold text-yellow-600">93%</td>
                        </tr>
                      </tbody>
                    </table>
                </div>
            </div>
          ) : (
            <div className="flex-1 border-2 border-dashed border-gray-200 rounded-xl flex flex-col items-center justify-center p-8 text-center bg-gray-50/50">
              <FileBarChart size={64} className="text-gray-300 mb-4" />
              <h3 className="text-lg font-bold text-gray-800">Pratinjau Data</h3>
              <p className="text-sm text-gray-500 max-w-md mt-2 mb-6">
                Pilih filter di atas, lalu klik tombol export di bawah ini untuk mengunduh laporan atau mencetaknya langsung.
              </p>
    
              <div className="flex flex-wrap justify-center gap-3">
                <button className="flex items-center gap-2 bg-red-50 text-red-700 border border-red-200 px-4 py-2 rounded-lg text-sm font-medium hover:bg-red-100 transition">
                  <Download size={18} /> Export PDF
                </button>
                <button className="flex items-center gap-2 bg-green-50 text-green-700 border border-green-200 px-4 py-2 rounded-lg text-sm font-medium hover:bg-green-100 transition">
                  <Download size={18} /> Export Excel
                </button>
                <button className="flex items-center gap-2 bg-blue-50 text-blue-700 border border-blue-200 px-4 py-2 rounded-lg text-sm font-medium hover:bg-blue-100 transition">
                  <Download size={18} /> Export Word
                </button>
                <button className="flex items-center gap-2 bg-gray-100 text-gray-700 border border-gray-200 px-4 py-2 rounded-lg text-sm font-medium hover:bg-gray-200 transition">
                  <Printer size={18} /> Cetak Langsung
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
