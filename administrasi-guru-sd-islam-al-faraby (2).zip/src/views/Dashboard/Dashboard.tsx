import React from 'react';
import { 
  Users, 
  BookOpen, 
  CheckCircle, 
  Clock,
  Calendar as CalendarIcon 
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  LineChart,
  Line
} from 'recharts';
import { attendanceData, gradeData, todaySchedule } from '../../data/mock';

export function Dashboard() {
  const stats = [
    { title: 'Total Peserta Didik', value: '142', icon: <Users size={24} className="text-blue-600" />, bgColor: 'bg-blue-100' },
    { title: 'Modul Ajar Selesai', value: '12', icon: <BookOpen size={24} className="text-green-600" />, bgColor: 'bg-green-100' },
    { title: 'Persentase Adminis.', value: '85%', icon: <CheckCircle size={24} className="text-purple-600" />, bgColor: 'bg-purple-100' },
    { title: 'Jam Mengajar', value: '24 JP', icon: <Clock size={24} className="text-orange-600" />, bgColor: 'bg-orange-100' },
  ];

  return (
    <div className="space-y-6">
      {/* Welcome Banner */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-800 rounded-2xl p-8 text-white flex justify-between items-center shadow-sm">
        <div>
          <h2 className="text-2xl font-bold mb-2">Selamat Datang, Ahmad Fadli, S.Pd</h2>
          <p className="text-blue-100">Anda memiliki jadwal mengajar 3 kelas hari ini. Jangan lupa mengisi jurnal harian.</p>
        </div>
        <div className="hidden md:block">
          <CalendarIcon size={64} className="text-blue-300 opacity-50" />
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => (
          <div key={index} className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 flex items-center gap-4">
            <div className={`w-12 h-12 ${stat.bgColor} rounded-full flex items-center justify-center`}>
              {stat.icon}
            </div>
            <div>
              <p className="text-sm text-gray-500 font-medium">{stat.title}</p>
              <h3 className="text-2xl font-bold text-gray-900">{stat.value}</h3>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Charts Container */}
        <div className="col-span-1 lg:col-span-2 space-y-6">
          <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
            <h3 className="text-lg font-bold text-gray-900 mb-4">Grafik Kehadiran Siswa (Minggu Ini)</h3>
            <div className="h-72">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={attendanceData} margin={{ top: 20, right: 30, left: 0, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E5E7EB" />
                  <XAxis dataKey="name" axisLine={false} tickLine={false} />
                  <YAxis axisLine={false} tickLine={false} />
                  <Tooltip 
                    contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                  />
                  <Bar dataKey="hadir" name="Hadir" fill="#3B82F6" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="sakit" name="Sakit/Izin" fill="#F59E0B" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
            <h3 className="text-lg font-bold text-gray-900 mb-4">Rata-rata Nilai per Mata Pelajaran</h3>
            <div className="h-72">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={gradeData} margin={{ top: 20, right: 30, left: 0, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E5E7EB" />
                  <XAxis dataKey="subject" axisLine={false} tickLine={false} />
                  <YAxis axisLine={false} tickLine={false} domain={[60, 100]} />
                  <Tooltip 
                    contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                  />
                  <Line type="monotone" dataKey="average" name="Rata-rata Nilai" stroke="#10B981" strokeWidth={3} dot={{ r: 4, strokeWidth: 2 }} activeDot={{ r: 6 }} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* Schedule Sidebar Container */}
        <div className="col-span-1 space-y-6">
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
            <div className="p-6 border-b border-gray-100 bg-gray-50 flex justify-between items-center">
              <h3 className="text-lg font-bold text-gray-900">Jadwal Hari Ini</h3>
              <span className="text-sm text-blue-600 font-medium">Lihat Semua</span>
            </div>
            <div className="divide-y divide-gray-100">
              {todaySchedule.map((schedule, i) => (
                <div key={i} className="p-4 hover:bg-gray-50 transition-colors flex gap-4">
                  <div className="w-24 shrink-0 text-sm font-semibold text-gray-500 py-1">
                    {schedule.time}
                  </div>
                  <div className="flex-1">
                    <p className={`font-semibold text-sm ${schedule.subject === 'Istirahat' ? 'text-gray-400' : 'text-gray-800'}`}>
                      {schedule.subject}
                    </p>
                    <p className="text-xs text-gray-500 mt-1">{schedule.class}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <h3 className="text-lg font-bold text-gray-900 mb-4">Tugas Administrasi</h3>
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <div className="mt-0.5"><input type="checkbox" className="w-4 h-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500" /></div>
                <div>
                  <p className="text-sm font-medium text-gray-800">Upload Modul Ajar Matematika Bab 2</p>
                  <p className="text-xs text-red-500 mt-1">Tenggat: Besok</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="mt-0.5"><input type="checkbox" className="w-4 h-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500" /></div>
                <div>
                  <p className="text-sm font-medium text-gray-800">Isi Jurnal Mengajar Kelas 5A</p>
                  <p className="text-xs text-gray-500 mt-1">Hari ini</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="mt-0.5"><input type="checkbox" className="w-4 h-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500" /></div>
                <div>
                  <p className="text-sm font-medium text-gray-800">Rekap Absensi Bulan Agustus</p>
                  <p className="text-xs text-gray-500 mt-1">Jumat, 1 Sep</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
