import React, { useState } from 'react';
import { Search, Plus, Edit2, Trash2 } from 'lucide-react';

export function MasterData() {
  const [activeTab, setActiveTab] = useState('guru');

  const tabs = [
    { id: 'guru', label: 'Data Guru' },
    { id: 'siswa', label: 'Peserta Didik' },
    { id: 'kelas', label: 'Data Kelas' },
    { id: 'mapel', label: 'Mata Pelajaran' },
    { id: 'tapel', label: 'Tahun Pelajaran' },
  ];

  // Dummy Data
  const guruData = [
    { nip: '198501012010011001', nama: 'Ahmad Fadli, S.Pd', jk: 'L', mapel: 'Guru Kelas 5', status: 'PNS' },
    { nip: '198802022015042002', nama: 'Siti Aminah, S.Pd.I', jk: 'P', mapel: 'PAI', status: 'PNS' },
    { nip: '199003032018011003', nama: 'Budi Santoso, S.Or', jk: 'L', mapel: 'PJOK', status: 'GTY' },
  ];

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 flex flex-col h-[calc(100vh-8rem)]">
      <div className="border-b border-gray-100 flex overflow-x-auto">
        {tabs.map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`px-6 py-4 text-sm font-medium whitespace-nowrap border-b-2 transition-colors ${
              activeTab === tab.id 
                ? 'border-blue-600 text-blue-600' 
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      <div className="p-6 flex-1 flex flex-col">
        {/* Toolbar */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
          <div className="relative w-full sm:w-72">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search size={18} className="text-gray-400" />
            </div>
            <input
              type="text"
              className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500 text-sm"
              placeholder={`Cari ${tabs.find(t => t.id === activeTab)?.label.toLowerCase()}...`}
            />
          </div>
          <button className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-blue-700 transition-colors">
            <Plus size={18} />
            Tambah Data
          </button>
        </div>

        {/* Table Container */}
        <div className="flex-1 overflow-auto border border-gray-200 rounded-lg">
          <table className="w-full text-sm text-left">
            <thead className="text-xs text-gray-700 uppercase bg-gray-50 border-b border-gray-200 sticky top-0">
              {activeTab === 'guru' && (
                <tr>
                  <th className="px-6 py-4 font-semibold">NIP/NUPTK</th>
                  <th className="px-6 py-4 font-semibold">Nama Lengkap</th>
                  <th className="px-6 py-4 font-semibold">L/P</th>
                  <th className="px-6 py-4 font-semibold">Tugas/Mapel</th>
                  <th className="px-6 py-4 font-semibold">Status</th>
                  <th className="px-6 py-4 font-semibold text-right">Aksi</th>
                </tr>
              )}
              {activeTab !== 'guru' && (
                <tr>
                  <th className="px-6 py-4 font-semibold">Data Belum Tersedia di Mock</th>
                </tr>
              )}
            </thead>
            <tbody>
              {activeTab === 'guru' && guruData.map((guru, index) => (
                <tr key={index} className="bg-white border-b hover:bg-gray-50">
                  <td className="px-6 py-4">{guru.nip}</td>
                  <td className="px-6 py-4 font-medium text-gray-900">{guru.nama}</td>
                  <td className="px-6 py-4">{guru.jk}</td>
                  <td className="px-6 py-4">{guru.mapel}</td>
                  <td className="px-6 py-4">
                    <span className={`px-2.5 py-1 rounded-full text-xs font-medium ${
                      guru.status === 'PNS' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'
                    }`}>
                      {guru.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-right">
                    <div className="flex justify-end gap-2">
                      <button className="p-1.5 text-blue-600 hover:bg-blue-50 rounded-md transition-colors">
                        <Edit2 size={16} />
                      </button>
                      <button className="p-1.5 text-red-600 hover:bg-red-50 rounded-md transition-colors">
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
              {activeTab !== 'guru' && (
                <tr>
                  <td className="px-6 py-8 text-center text-gray-500">
                    Silakan pilih menu Data Guru untuk melihat contoh tabel.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
