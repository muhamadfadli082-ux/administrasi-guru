export type Role = 'Administrator' | 'Kepala Sekolah' | 'Guru' | 'Operator';

export interface User {
  id: string;
  name: string;
  role: Role;
  email: string;
  photoUrl?: string;
  nip: string;
}

export interface StatCardProps {
  title: string;
  value: string | number;
  icon: React.ReactNode;
  trend?: string;
  trendUp?: boolean;
}

export type ViewState = 
  | 'login'
  | 'dashboard'
  | 'master-data'
  | 'learning-admin'
  | 'class-admin'
  | 'assessment'
  | 'bank-soal'
  | 'lkpd'
  | 'media'
  | 'reports'
  | 'digital-archive'
  | 'settings'
  | 'super-admin';
