import React from 'react';
import { Sidebar } from '../../components/layout/Sidebar';
import { Header } from '../../components/layout/Header';
import { currentUser } from '../../data/mock';
import { ViewState } from '../../types';

interface LayoutProps {
  currentView: ViewState;
  setCurrentView: (view: ViewState) => void;
  onLogout: () => void;
  children: React.ReactNode;
}

export function Layout({ currentView, setCurrentView, onLogout, children }: LayoutProps) {
  return (
    <div className="flex bg-gray-50 min-h-screen">
      <Sidebar 
        currentView={currentView} 
        setCurrentView={setCurrentView} 
        onLogout={onLogout} 
      />
      <div className="flex-1 ml-64 flex flex-col h-screen">
        <Header 
          user={currentUser} 
          currentView={currentView}
          academicYear="2023/2024"
          semester="Ganjil"
        />
        <main className="flex-1 overflow-y-auto p-6">
          {children}
        </main>
      </div>
    </div>
  );
}
