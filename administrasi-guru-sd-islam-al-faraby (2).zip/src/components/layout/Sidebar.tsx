import React from 'react';
import { 
  LayoutDashboard, 
  Database, 
  BookOpen, 
  Users, 
  FileCheck2, 
  FileBarChart, 
  Archive, 
  Settings, 
  ShieldAlert,
  LogOut,
  HelpCircle,
  FileSignature,
  MonitorPlay
} from 'lucide-react';
import { ViewState } from '../../types';

interface SidebarProps {
  currentView: ViewState;
  setCurrentView: (view: ViewState) => void;
  onLogout: () => void;
}

export function Sidebar({ currentView, setCurrentView, onLogout }: SidebarProps) {
  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard size={20} /> },
    { id: 'master-data', label: 'Master Data', icon: <Database size={20} /> },
    { id: 'learning-admin', label: 'Admin Pembelajaran', icon: <BookOpen size={20} /> },
    { id: 'class-admin', label: 'Administrasi Kelas', icon: <Users size={20} /> },
    { id: 'assessment', label: 'Penilaian', icon: <FileCheck2 size={20} /> },
    { id: 'bank-soal', label: 'Bank Soal', icon: <HelpCircle size={20} /> },
    { id: 'lkpd', label: 'E-LKPD', icon: <FileSignature size={20} /> },
    { id: 'media', label: 'Media Pembelajaran', icon: <MonitorPlay size={20} /> },
    { id: 'reports', label: 'Laporan', icon: <FileBarChart size={20} /> },
    { id: 'digital-archive', label: 'Arsip Digital', icon: <Archive size={20} /> },
    { id: 'settings', label: 'Pengaturan', icon: <Settings size={20} /> },
  ];

  return (
    <div className="w-64 bg-[#0a192f] text-white flex flex-col h-screen fixed top-0 left-0">
      <div className="p-6 border-b border-gray-700 flex items-center gap-3">
        <div className="w-8 h-8 bg-blue-500 rounded-lg flex items-center justify-center font-bold text-lg">
          AF
        </div>
        <div>
          <h1 className="text-sm font-bold leading-tight">SD Islam Al Faraby</h1>
          <p className="text-xs text-gray-400">Guru Administration</p>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto py-4">
        <nav className="space-y-1 px-3">
          {menuItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setCurrentView(item.id as ViewState)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-colors text-sm font-medium ${
                currentView === item.id 
                  ? 'bg-blue-600 outline-none text-white' 
                  : 'text-gray-300 hover:bg-gray-800 hover:text-white'
              }`}
            >
              {item.icon}
              {item.label}
            </button>
          ))}
          
          <div className="pt-4 mt-4 border-t border-gray-700">
            <button
              onClick={() => setCurrentView('super-admin' as ViewState)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-colors text-sm font-medium ${
                currentView === 'super-admin'
                  ? 'bg-blue-600 outline-none text-white' 
                  : 'text-gray-300 hover:bg-gray-800 hover:text-white'
              }`}
            >
              <ShieldAlert size={20} />
              Super Admin
            </button>
          </div>
        </nav>
      </div>

      <div className="p-4 border-t border-gray-700">
        <button 
          onClick={onLogout}
          className="w-full flex items-center gap-3 px-3 py-2 text-red-400 hover:bg-red-500/10 rounded-lg transition-colors text-sm font-medium"
        >
          <LogOut size={20} />
          Keluar Aplikasi
        </button>
      </div>
    </div>
  );
}
