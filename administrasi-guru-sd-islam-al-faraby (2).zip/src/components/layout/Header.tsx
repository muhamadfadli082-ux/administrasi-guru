import React from 'react';
import { Bell, Search, Menu } from 'lucide-react';
import { User, ViewState } from '../../types';

interface HeaderProps {
  user: User;
  currentView: ViewState;
  academicYear: string;
  semester: string;
}

export function Header({ user, currentView, academicYear, semester }: HeaderProps) {
  const getPageTitle = (view: ViewState) => {
    const titles: Record<string, string> = {
      'dashboard': 'Dashboard Informasi',
      'master-data': 'Manajemen Data Master',
      'learning-admin': 'Administrasi Pembelajaran',
      'class-admin': 'Administrasi Kelas',
      'assessment': 'Penilaian Siswa',
      'bank-soal': 'Bank Soal Terpadu',
      'lkpd': 'Generator LKPD',
      'media': 'Media Pembelajaran',
      'reports': 'Laporan Hasil Belajar',
      'digital-archive': 'Arsip Dokumen Digital',
      'settings': 'Pengaturan Sistem',
      'super-admin': 'Super Admin Panel',
    };
    return titles[view] || 'Dashboard';
  };

  return (
    <header className="h-16 bg-white border-b flex items-center justify-between px-6 sticky top-0 z-10 shadow-sm">
      <div className="flex items-center gap-4">
        <button className="md:hidden text-gray-500 hover:text-gray-700">
          <Menu size={24} />
        </button>
        <div>
          <h2 className="text-xl font-bold text-gray-800">{getPageTitle(currentView)}</h2>
          <div className="text-xs text-gray-500 font-medium hidden sm:block">
            Tahun Pelajaran: {academicYear} | Semester: {semester}
          </div>
        </div>
      </div>

      <div className="flex items-center gap-6">
        <div className="hidden md:flex items-center bg-gray-100 rounded-full px-4 py-2 w-64 border border-transparent focus-within:border-blue-500 focus-within:bg-white transition-all">
          <Search size={18} className="text-gray-400" />
          <input 
            type="text" 
            placeholder="Cari sesuatu..." 
            className="bg-transparent border-none outline-none ml-2 text-sm w-full"
          />
        </div>

        <button className="relative text-gray-500 hover:text-gray-700 transition-colors">
          <Bell size={20} />
          <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full text-[10px] text-white flex items-center justify-center font-bold">
            3
          </span>
        </button>

        <div className="flex items-center gap-3 border-l pl-6">
          <div className="text-right hidden sm:block">
            <p className="text-sm font-semibold text-gray-800">{user.name}</p>
            <p className="text-xs text-gray-500">{user.role}</p>
          </div>
          <img 
            src={user.photoUrl} 
            alt={user.name} 
            className="w-10 h-10 rounded-full border-2 border-gray-200"
          />
        </div>
      </div>
    </header>
  );
}
