/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Layout } from './components/layout/Layout';
import { Login } from './views/Login';
import { Dashboard } from './views/Dashboard/Dashboard';
import { MasterData } from './views/MasterData/MasterData';
import { LearningAdmin } from './views/LearningAdmin/LearningAdmin';
import { ClassAdmin } from './views/ClassAdmin/ClassAdmin';
import { Assessment } from './views/Assessment/Assessment';
import { BankSoal } from './views/BankSoal/BankSoal';
import { LKPD } from './views/LKPD/LKPD';
import { Media } from './views/Media/Media';
import { Reports } from './views/Reports/Reports';
import { Archive } from './views/Archive/Archive';
import { Settings } from './views/Settings/Settings';
import { SuperAdmin } from './views/SuperAdmin/SuperAdmin';
import { ViewState } from './types';
import { Construction } from 'lucide-react';

function UnderConstruction({ title }: { title: string }) {
  return (
    <div className="flex-1 flex flex-col items-center justify-center text-gray-500 h-[calc(100vh-8rem)] bg-white rounded-xl border border-gray-100 shadow-sm">
      <Construction size={48} className="mb-4 text-gray-300" />
      <h3 className="text-lg font-medium text-gray-900 mb-1">{title}</h3>
      <p className="text-sm text-center max-w-md mt-2">
        Modul ini sedang dalam tahap pengembangan. Fitur Google Integration (Spreadsheet/Drive) akan ditangani oleh Apps Script di backend.
      </p>
    </div>
  );
}

export default function App() {
  const [currentView, setCurrentView] = useState<ViewState>('login');

  const handleLogin = () => {
    setCurrentView('dashboard');
  };

  const handleLogout = () => {
    setCurrentView('login');
  };

  if (currentView === 'login') {
    return <Login onLogin={handleLogin} />;
  }

  const renderContent = () => {
    switch (currentView) {
      case 'dashboard':
        return <Dashboard />;
      case 'master-data':
        return <MasterData />;
      case 'learning-admin':
        return <LearningAdmin />;
      case 'class-admin':
        return <ClassAdmin />;
      case 'assessment':
        return <Assessment />;
      case 'bank-soal':
        return <BankSoal />;
      case 'lkpd':
        return <LKPD />;
      case 'media':
        return <Media />;
      case 'reports':
        return <Reports />;
      case 'digital-archive':
        return <Archive />;
      case 'settings':
        return <Settings />;
      case 'super-admin':
        return <SuperAdmin />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <Layout 
      currentView={currentView} 
      setCurrentView={setCurrentView} 
      onLogout={handleLogout}
    >
      {renderContent()}
    </Layout>
  );
}

