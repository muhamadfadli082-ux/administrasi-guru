import { User } from '../types';

export const currentUser: User = {
  id: '1',
  name: 'Ahmad Fadli, S.Pd',
  role: 'Guru',
  email: 'ahmad.fadli@alfaraby.sch.id',
  nip: '198501012010011001',
  photoUrl: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Ahmad'
};

export const attendanceData = [
  { name: 'Sen', hadir: 30, sakit: 1, izin: 1, alfa: 0 },
  { name: 'Sel', hadir: 31, sakit: 0, izin: 1, alfa: 0 },
  { name: 'Rab', hadir: 29, sakit: 2, izin: 0, alfa: 1 },
  { name: 'Kam', hadir: 32, sakit: 0, izin: 0, alfa: 0 },
  { name: 'Jum', hadir: 30, sakit: 1, izin: 1, alfa: 0 },
];

export const gradeData = [
  { subject: 'MTK', average: 85 },
  { subject: 'IPA', average: 88 },
  { subject: 'IPS', average: 82 },
  { subject: 'B.Indo', average: 90 },
  { subject: 'PAI', average: 92 },
];

export const todaySchedule = [
  { time: '07:30 - 08:05', subject: 'Pendidikan Agama Islam', class: 'Kelas 5A' },
  { time: '08:05 - 08:40', subject: 'Matematika', class: 'Kelas 5A' },
  { time: '08:40 - 09:15', subject: 'Matematika', class: 'Kelas 5A' },
  { time: '09:15 - 09:45', subject: 'Istirahat', class: '-' },
  { time: '09:45 - 10:20', subject: 'Bahasa Indonesia', class: 'Kelas 5A' },
  { time: '10:20 - 10:55', subject: 'Bahasa Indonesia', class: 'Kelas 5A' },
];
